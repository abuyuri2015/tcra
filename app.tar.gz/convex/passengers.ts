import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireUser } from "./lib/auth.ts";
import { roomTypeValidator } from "./schema/passengers.ts";
import { logActivity } from "./activityLog.ts";

const passengerFields = {
  firstName: v.string(),
  lastName: v.string(),
  roomType: roomTypeValidator,
  sharingWith: v.optional(v.string()),
  dietaryRequirements: v.optional(v.string()),
  notes: v.optional(v.string()),
};

async function requirePassenger(
  ctx: QueryCtx | MutationCtx,
  id: Id<"passengers">,
): Promise<Doc<"passengers">> {
  const p = await ctx.db.get(id);
  if (!p) throw new ConvexError({ code: "NOT_FOUND", message: "Passenger not found." });
  return p;
}

export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"passengers">[]> => {
    return await ctx.db
      .query("passengers")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("asc")
      .collect();
  },
});

/** Returns aggregate counts for the file overview stat cards. */
export const countsByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (
    ctx,
    args,
  ): Promise<{ total: number; rooms: number }> => {
    const rows = await ctx.db
      .query("passengers")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .collect();

    // Count rooms: single = 1 room, double/twin/triple/suite count based on sharing
    // Simple approximation: each unique (roomType + sharingWith group) is one room.
    // We count rooms as: solo passengers (no sharingWith) + unique sharing pairs.
    let rooms = 0;
    const pairingsSeen = new Set<string>();
    for (const p of rows) {
      if (!p.sharingWith) {
        rooms++;
      } else {
        const fullName = `${p.firstName} ${p.lastName}`.trim().toLowerCase();
        const partner = p.sharingWith.trim().toLowerCase();
        const pairKey = [fullName, partner].sort().join("|||");
        if (!pairingsSeen.has(pairKey)) {
          pairingsSeen.add(pairKey);
          rooms++;
        }
      }
    }
    return { total: rows.length, rooms };
  },
});

export const create = mutation({
  args: { groupFileId: v.id("groupFiles"), ...passengerFields },
  handler: async (ctx, args): Promise<Id<"passengers">> => {
    const user = await requireUser(ctx);
    const first = args.firstName.trim();
    const last = args.lastName.trim();
    if (!first || !last)
      throw new ConvexError({ code: "BAD_REQUEST", message: "First and last name are required." });
    const id = await ctx.db.insert("passengers", {
      ...args,
      firstName: first,
      lastName: last,
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "passenger_added",
      description: `Added passenger ${first} ${last}`,
      user,
    });

    return id;
  },
});

export const update = mutation({
  args: { id: v.id("passengers"), ...passengerFields },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    await requirePassenger(ctx, id);
    const first = fields.firstName.trim();
    const last = fields.lastName.trim();
    if (!first || !last)
      throw new ConvexError({ code: "BAD_REQUEST", message: "First and last name are required." });
    await ctx.db.patch(id, { ...fields, firstName: first, lastName: last });
    return null;
  },
});

export const bulkCreate = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    passengers: v.array(
      v.object({
        firstName: v.string(),
        lastName: v.string(),
        roomType: roomTypeValidator,
        sharingWith: v.optional(v.string()),
        dietaryRequirements: v.optional(v.string()),
        notes: v.optional(v.string()),
      }),
    ),
  },
  handler: async (ctx, args): Promise<{ imported: number; skipped: number }> => {
    const user = await requireUser(ctx);
    let imported = 0;
    let skipped = 0;
    for (const p of args.passengers) {
      const first = p.firstName.trim();
      const last = p.lastName.trim();
      if (!first || !last) {
        skipped++;
        continue;
      }
      await ctx.db.insert("passengers", {
        ...p,
        firstName: first,
        lastName: last,
        groupFileId: args.groupFileId,
        createdById: user._id,
      });
      imported++;
    }
    return { imported, skipped };
  },
});

export const remove = mutation({
  args: { id: v.id("passengers") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const passenger = await requirePassenger(ctx, args.id);

    await logActivity(ctx, {
      groupFileId: passenger.groupFileId,
      action: "passenger_removed",
      description: `Removed passenger ${passenger.firstName} ${passenger.lastName}`,
      user,
    });

    await ctx.db.delete(args.id);
    return null;
  },
});
