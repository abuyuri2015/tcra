"use node";

import { v } from "convex/values";
import { action } from "../_generated/server";
import OpenAI from "openai";
import { zodResponseFormat } from "openai/helpers/zod";
import * as z from "zod";

const openai = new OpenAI({
  baseURL: "https://ai-gateway.hercules.app/v1",
  apiKey: process.env.HERCULES_API_KEY,
});

// ── Shared sub-schemas ─────────────────────────────────────────────────────────

const HotelSchema = z.object({
  name: z.string(),
  category: z.enum([
    "5-star-luxury",
    "5-star",
    "4-star-superior",
    "4-star",
    "3-star",
    "boutique",
    "resort",
    "apartment",
    "venue",
  ]),
  status: z.enum(["preferred", "active", "archived"]).default("active"),
  city: z.string(),
  country: z.string(),
  address: z.string().nullable().optional(),
  website: z.string().nullable().optional(),
  contactName: z.string().nullable().optional(),
  contactEmail: z.string().nullable().optional(),
  contactPhone: z.string().nullable().optional(),
  totalRooms: z.number().nullable().optional(),
  meetingRooms: z.number().nullable().optional(),
  largestMeetingCapacity: z.number().nullable().optional(),
  currency: z.enum(["EUR", "USD", "GBP", "CHF", "AED", "SEK", "NOK", "DKK"]).default("EUR"),
  amenities: z.array(z.string()).default([]),
  notes: z.string().nullable().optional(),
  roomTypes: z
    .array(
      z.object({
        name: z.string(),
        occupancy: z.number().min(1),
        board: z.enum([
          "room-only",
          "breakfast",
          "half-board",
          "full-board",
          "all-inclusive",
        ]),
        nightlyRate: z.number().nullable().optional(),
        notes: z.string().nullable().optional(),
      }),
    )
    .default([]),
});

const SupplierSchema = z.object({
  name: z.string(),
  category: z.enum([
    "hotel",
    "transfer",
    "restaurant",
    "activity",
    "venue",
    "flight",
    "other",
  ]),
  country: z.string().nullable().optional(),
  city: z.string().nullable().optional(),
  contactPerson: z.string().nullable().optional(),
  email: z.string().nullable().optional(),
  phone: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
});

const ClientSchema = z.object({
  kind: z.enum(["individual", "company"]),
  name: z.string(),
  contactName: z.string().nullable().optional(),
  email: z.string().nullable().optional(),
  phone: z.string().nullable().optional(),
  address: z.string().nullable().optional(),
  city: z.string().nullable().optional(),
  country: z.string().nullable().optional(),
  taxId: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
});

const PassengerSchema = z.object({
  firstName: z.string(),
  lastName: z.string(),
  roomType: z.enum(["single", "double", "twin", "triple", "suite"]),
  sharingWith: z.string().nullable().optional(),
  dietaryRequirements: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
});

const ItineraryDaySchema = z.object({
  dayNumber: z.number(),
  date: z.string().nullable().optional(), // ISO date hint, optional
  title: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
  items: z.array(
    z.object({
      sortOrder: z.number(),
      type: z.enum([
        "arrival",
        "departure",
        "transfer",
        "hotel",
        "meal",
        "activity",
        "meeting",
        "flight",
        "free-time",
        "other",
      ]),
      time: z.string().nullable().optional(),
      title: z.string(),
      description: z.string().nullable().optional(),
      location: z.string().nullable().optional(),
      notes: z.string().nullable().optional(),
    }),
  ),
});

// ── Null-stripping helper ───────────────────────────────────────────────────────
// OpenAI structured outputs require optional fields to also be nullable, so parsed
// results may contain explicit `null`s where the app expects `undefined`. Strip them
// recursively before handing data back to the frontend, and reflect that in the type.
type StripNull<T> = T extends null
  ? undefined
  : T extends (infer U)[]
    ? StripNull<U>[]
    : T extends object
      ? { [K in keyof T]: StripNull<T[K]> }
      : T;

function stripNulls<T>(value: T): StripNull<T> {
  if (value === null) {
    return undefined as StripNull<T>;
  }
  if (Array.isArray(value)) {
    return value.map((item) => stripNulls(item)) as StripNull<T>;
  }
  if (typeof value === "object") {
    const result: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
      result[key] = stripNulls(val);
    }
    return result as StripNull<T>;
  }
  return value as StripNull<T>;
}

// ── Website import helpers ──────────────────────────────────────────────────────

/** Strips scripts/styles/tags from raw HTML and decodes basic entities into plain text. */
function htmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(br|p|div|li|h[1-6]|tr)[^>]*>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n+/g, "\n")
    .trim();
}

/** Pulls og:image / twitter:image meta tags and gallery/content <img> tags, resolved against the page URL. */
function extractImageUrls(html: string, pageUrl: string, limit = 5): string[] {
  const urls = new Set<string>();

  // Prefer meta tags first — they're usually the hotel's chosen hero/cover shot.
  const metaRegex =
    /<meta[^>]+(?:property|name)=["'](?:og:image(?::secure_url)?|twitter:image)["'][^>]+content=["']([^"']+)["'][^>]*>|<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["'](?:og:image(?::secure_url)?|twitter:image)["'][^>]*>/gi;
  let match: RegExpExecArray | null;
  while ((match = metaRegex.exec(html)) !== null) {
    const raw = match[1] || match[2];
    if (!raw) continue;
    try {
      urls.add(new URL(raw, pageUrl).toString());
    } catch {
      // Ignore unresolvable URLs.
    }
  }

  // Fall back to <img> tags (src or the largest srcset candidate) for more photos,
  // skipping obvious non-content assets like icons, logos, and tiny placeholders.
  const skipPattern = /logo|icon|sprite|favicon|placeholder|avatar|badge|payment|pixel/i;
  const imgRegex = /<img\s+[^>]*>/gi;
  const srcRegex = /\ssrc=["']([^"']+)["']/i;
  const srcsetRegex = /\ssrcset=["']([^"']+)["']/i;
  let imgMatch: RegExpExecArray | null;
  while (urls.size < limit * 3 && (imgMatch = imgRegex.exec(html)) !== null) {
    const tag = imgMatch[0];
    if (skipPattern.test(tag)) continue;
    const srcsetMatch = srcsetRegex.exec(tag);
    let raw: string | undefined;
    if (srcsetMatch) {
      // srcset is a comma-separated list of "url size" candidates — take the last (largest).
      const candidates = srcsetMatch[1].split(",").map((c) => c.trim().split(/\s+/)[0]);
      raw = candidates[candidates.length - 1];
    }
    if (!raw) {
      raw = srcRegex.exec(tag)?.[1];
    }
    if (!raw || raw.startsWith("data:") || skipPattern.test(raw)) continue;
    try {
      urls.add(new URL(raw, pageUrl).toString());
    } catch {
      // Ignore unresolvable URLs.
    }
  }

  return Array.from(urls).slice(0, limit);
}

/** Finds the first same-origin link whose href or text matches one of the given keywords. */
function findSubpageUrl(html: string, pageUrl: string, keywords: RegExp): string | null {
  const origin = new URL(pageUrl).origin;
  const linkRegex = /<a\s+[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let match: RegExpExecArray | null;
  while ((match = linkRegex.exec(html)) !== null) {
    const href = match[1];
    const label = match[2].replace(/<[^>]+>/g, " ");
    if (!keywords.test(href) && !keywords.test(label)) continue;
    try {
      const resolved = new URL(href, pageUrl);
      if (resolved.origin === origin && resolved.toString() !== pageUrl) {
        return resolved.toString();
      }
    } catch {
      // Ignore unresolvable URLs.
    }
  }
  return null;
}

/** Best-effort fetch of a page's HTML. Returns null instead of throwing on failure. */
async function tryFetchHtml(url: string): Promise<string | null> {
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; HerculesHotelImport/1.0; +https://hercules.app)",
      },
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

// ── Actions ────────────────────────────────────────────────────────────────────

export const extractSupplierFromUrl = action({
  args: { url: v.string() },
  handler: async (
    _ctx,
    args,
  ): Promise<{ data: StripNull<z.infer<typeof SupplierSchema>> & { website: string } }> => {
    let pageUrl: string;
    try {
      pageUrl = new URL(args.url).toString();
    } catch {
      throw new Error("That doesn't look like a valid website address.");
    }

    const homeHtml = await tryFetchHtml(pageUrl);
    if (homeHtml === null) {
      throw new Error(
        "Couldn't reach that website. Check the URL and try again — some sites block automated requests.",
      );
    }

    // Also try a contact / about page for more details
    const contactUrl = findSubpageUrl(homeHtml, pageUrl, /contact|about|team|company/i);
    const contactHtml = contactUrl ? await tryFetchHtml(contactUrl) : null;

    let text = htmlToText(homeHtml).slice(0, 14000);
    if (contactHtml) {
      text += `\n\n--- Contact / about page (${contactUrl}) ---\n${htmlToText(contactHtml).slice(0, 6000)}`;
    }
    if (!text.trim()) {
      throw new Error("That page didn't contain any readable content to extract from.");
    }

    try {
      const SupplierResult = z.object({ supplier: SupplierSchema });
      const response = await openai.chat.completions.parse({
        model: "openai/gpt-5.6-luna",
        reasoning_effort: "low",
        messages: [
          {
            role: "system",
            content:
              "You are a data extraction specialist for a group travel agency management system. " +
              "The following text was scraped from a service provider / supplier's website. " +
              "Extract the supplier's details: company name, category (hotel, transfer, restaurant, activity, venue, flight, other), " +
              "city, country, contact person name, email address, and phone number. " +
              "Infer the category from the type of services described. " +
              "Infer missing fields when strongly implied by context, leave truly unknown optional fields undefined. " +
              "Add a brief notes field summarising what the supplier offers.",
          },
          { role: "user", content: `Page URL: ${pageUrl}\n\nPage content:\n${text}` },
        ],
        response_format: zodResponseFormat(SupplierResult, "supplier_result"),
      });
      const supplier = response.choices[0]?.message?.parsed?.supplier;
      if (!supplier) {
        throw new Error("Couldn't extract supplier details from that page.");
      }
      return {
        data: {
          ...stripNulls(supplier),
          website: pageUrl,
        },
      };
    } catch (err) {
      if (err instanceof OpenAI.APIError) {
        throw new Error(`AI extraction failed: ${err.message}`);
      }
      throw err;
    }
  },
});

export const extractClientFromUrl = action({
  args: { url: v.string() },
  handler: async (
    _ctx,
    args,
  ): Promise<{ data: StripNull<z.infer<typeof ClientSchema>> }> => {
    let pageUrl: string;
    try {
      pageUrl = new URL(args.url).toString();
    } catch {
      throw new Error("That doesn't look like a valid website address.");
    }

    const homeHtml = await tryFetchHtml(pageUrl);
    if (homeHtml === null) {
      throw new Error(
        "Couldn't reach that website. Check the URL and try again — some sites block automated requests.",
      );
    }

    // Also try a contact / about page for more details
    const contactUrl = findSubpageUrl(homeHtml, pageUrl, /contact|about|team|company/i);
    const contactHtml = contactUrl ? await tryFetchHtml(contactUrl) : null;

    let text = htmlToText(homeHtml).slice(0, 14000);
    if (contactHtml) {
      text += `\n\n--- Contact / about page (${contactUrl}) ---\n${htmlToText(contactHtml).slice(0, 6000)}`;
    }
    if (!text.trim()) {
      throw new Error("That page didn't contain any readable content to extract from.");
    }

    try {
      const ClientResult = z.object({ client: ClientSchema });
      const response = await openai.chat.completions.parse({
        model: "openai/gpt-5.6-luna",
        reasoning_effort: "low",
        messages: [
          {
            role: "system",
            content:
              "You are a data extraction specialist for a group travel agency management system. " +
              "The following text was scraped from a company's website — this company is a prospective " +
              "or existing travel-agency client (not a hotel or supplier). Extract its details: kind " +
              "(\"company\" unless the site clearly represents a single individual), name, primary contact " +
              "person, email address, phone number, address, city, country, and tax/VAT ID if shown. " +
              "Infer missing fields when strongly implied by context, leave truly unknown optional fields " +
              "undefined. Add a brief notes field summarising who they are and what kind of trips they might book.",
          },
          { role: "user", content: `Page URL: ${pageUrl}\n\nPage content:\n${text}` },
        ],
        response_format: zodResponseFormat(ClientResult, "client_result"),
      });
      const client = response.choices[0]?.message?.parsed?.client;
      if (!client) {
        throw new Error("Couldn't extract client details from that page.");
      }
      return { data: stripNulls(client) };
    } catch (err) {
      if (err instanceof OpenAI.APIError) {
        throw new Error(`AI extraction failed: ${err.message}`);
      }
      throw err;
    }
  },
});

export const extractHotelFromUrl = action({
  args: { url: v.string() },
  handler: async (
    _ctx,
    args,
  ): Promise<{ data: StripNull<z.infer<typeof HotelSchema>> & { imageUrls: string[] } }> => {
    let pageUrl: string;
    try {
      pageUrl = new URL(args.url).toString();
    } catch {
      throw new Error("That doesn't look like a valid website address.");
    }

    const homeHtml = await tryFetchHtml(pageUrl);
    if (homeHtml === null) {
      throw new Error(
        "Couldn't reach that website. Check the URL and try again — some sites block automated requests.",
      );
    }

    // Best-effort: also pull a rooms/accommodation subpage and a gallery subpage, since
    // room types and photos often live off the homepage. Failures here are non-fatal.
    const roomsUrl = findSubpageUrl(homeHtml, pageUrl, /room|accommodation|suite|stay/i);
    const galleryUrl = findSubpageUrl(homeHtml, pageUrl, /gallery|photo|media/i);
    const [roomsHtml, galleryHtml] = await Promise.all([
      roomsUrl ? tryFetchHtml(roomsUrl) : Promise.resolve(null),
      galleryUrl && galleryUrl !== roomsUrl ? tryFetchHtml(galleryUrl) : Promise.resolve(null),
    ]);

    const imageUrls = Array.from(
      new Set([
        ...extractImageUrls(homeHtml, pageUrl, 5),
        ...(galleryHtml ? extractImageUrls(galleryHtml, galleryUrl ?? pageUrl, 5) : []),
        ...(roomsHtml ? extractImageUrls(roomsHtml, roomsUrl ?? pageUrl, 5) : []),
      ]),
    ).slice(0, 5);

    let text = htmlToText(homeHtml).slice(0, 14000);
    if (roomsHtml) {
      text += `\n\n--- Rooms/accommodation page (${roomsUrl}) ---\n${htmlToText(roomsHtml).slice(0, 8000)}`;
    }
    if (!text.trim()) {
      throw new Error("That page didn't contain any readable content to extract from.");
    }

    try {
      const HotelResult = z.object({ hotel: HotelSchema });
      const response = await openai.chat.completions.parse({
        model: "openai/gpt-5.6-luna",
        reasoning_effort: "low",
        messages: [
          {
            role: "system",
            content:
              "You are a data extraction specialist for a group travel agency management system. " +
              "The following text was scraped from a hotel's website (homepage, and often a rooms/accommodation " +
              "subpage too). Extract the hotel's details. Be thorough about room types: list every distinct room " +
              "or suite category mentioned (e.g. Standard Room, Deluxe Room, Suite, Villa), each with its typical " +
              "occupancy, board basis, and nightly rate if shown. Infer missing fields when strongly implied by " +
              "context, leave truly unknown optional fields undefined. Currency codes must be ISO 4217 (EUR, USD, " +
              "GBP, CHF, AED, SEK, NOK, DKK). Hotel categories: 5-star-luxury, 5-star, 4-star-superior, 4-star, " +
              "3-star, boutique, resort, apartment, venue. If a room type has no listed price, omit nightlyRate.",
          },
          { role: "user", content: `Page URL: ${pageUrl}\n\nPage content:\n${text}` },
        ],
        response_format: zodResponseFormat(HotelResult, "hotel_result"),
      });
      const hotel = response.choices[0]?.message?.parsed?.hotel;
      if (!hotel) {
        throw new Error("Couldn't extract hotel details from that page.");
      }
      const cleanHotel = stripNulls(hotel);
      return {
        data: {
          ...cleanHotel,
          website: cleanHotel.website ?? pageUrl,
          imageUrls,
        },
      };
    } catch (err) {
      if (err instanceof OpenAI.APIError) {
        throw new Error(`AI extraction failed: ${err.message}`);
      }
      throw err;
    }
  },
});

export const extractData = action({
  args: {
    type: v.union(
      v.literal("hotel"),
      v.literal("hotels"),
      v.literal("supplier"),
      v.literal("suppliers"),
      v.literal("passengers"),
      v.literal("itinerary"),
      v.literal("clients"),
    ),
    text: v.string(),
    /** Context hint for itinerary import: the file's startDate ISO string */
    startDate: v.optional(v.string()),
  },
  handler: async (
    _ctx,
    args,
  ): Promise<{
    type: string;
    data: unknown;
    rawText?: string;
  }> => {
    const { type, text } = args;

    const systemBase =
      "You are a data extraction specialist for a group travel agency management system. " +
      "Extract all relevant information from the provided text. " +
      "Be thorough: infer missing fields when strongly implied, leave truly unknown optional fields undefined. " +
      "Currency codes must be ISO 4217 (EUR, USD, GBP, CHF, AED, SEK, NOK, DKK). " +
      "Hotel categories: 5-star-luxury, 5-star, 4-star-superior, 4-star, 3-star, boutique, resort, apartment, venue.";

    try {
      if (type === "hotel") {
        const HotelResult = z.object({ hotel: HotelSchema });
        const response = await openai.chat.completions.parse({
          model: "openai/gpt-5.6-luna",
          reasoning_effort: "low",
          messages: [
            { role: "system", content: systemBase + " Extract a single hotel record." },
            { role: "user", content: text },
          ],
          response_format: zodResponseFormat(HotelResult, "hotel_result"),
        });
        return { type, data: stripNulls(response.choices[0]?.message?.parsed?.hotel) };
      }

      if (type === "hotels") {
        const HotelsResult = z.object({ hotels: z.array(HotelSchema) });
        const response = await openai.chat.completions.parse({
          model: "openai/gpt-5.6-luna",
          reasoning_effort: "low",
          messages: [
            {
              role: "system",
              content: systemBase + " Extract all hotels mentioned. Return an array.",
            },
            { role: "user", content: text },
          ],
          response_format: zodResponseFormat(HotelsResult, "hotels_result"),
        });
        return { type, data: stripNulls(response.choices[0]?.message?.parsed?.hotels ?? []) };
      }

      if (type === "supplier") {
        const SupplierResult = z.object({ supplier: SupplierSchema });
        const response = await openai.chat.completions.parse({
          model: "openai/gpt-5.6-luna",
          reasoning_effort: "low",
          messages: [
            { role: "system", content: systemBase + " Extract a single supplier record." },
            { role: "user", content: text },
          ],
          response_format: zodResponseFormat(SupplierResult, "supplier_result"),
        });
        return { type, data: stripNulls(response.choices[0]?.message?.parsed?.supplier) };
      }

      if (type === "suppliers") {
        const SuppliersResult = z.object({ suppliers: z.array(SupplierSchema) });
        const response = await openai.chat.completions.parse({
          model: "openai/gpt-5.6-luna",
          reasoning_effort: "low",
          messages: [
            {
              role: "system",
              content:
                systemBase +
                " Extract all suppliers/service providers mentioned. Infer category from context. Return an array.",
            },
            { role: "user", content: text },
          ],
          response_format: zodResponseFormat(SuppliersResult, "suppliers_result"),
        });
        return { type, data: stripNulls(response.choices[0]?.message?.parsed?.suppliers ?? []) };
      }

      if (type === "passengers") {
        const PassengersResult = z.object({ passengers: z.array(PassengerSchema) });
        const response = await openai.chat.completions.parse({
          model: "openai/gpt-5.6-luna",
          reasoning_effort: "low",
          messages: [
            {
              role: "system",
              content:
                systemBase +
                " Extract all passengers/travelers. Room type: single, double, twin, triple, suite. " +
                "If not specified default to double. sharingWith is the roommate's full name if mentioned.",
            },
            { role: "user", content: text },
          ],
          response_format: zodResponseFormat(PassengersResult, "passengers_result"),
        });
        return { type, data: stripNulls(response.choices[0]?.message?.parsed?.passengers ?? []) };
      }

      if (type === "clients") {
        const ClientsResult = z.object({ clients: z.array(ClientSchema) });
        const response = await openai.chat.completions.parse({
          model: "openai/gpt-5.6-luna",
          reasoning_effort: "low",
          messages: [
            {
              role: "system",
              content:
                systemBase +
                " Extract all clients (individuals or companies) mentioned — travel agency customers, not " +
                "suppliers or hotels. kind is \"individual\" for a single person, or \"company\" for an " +
                "organization/agency/group booking on behalf of others. For a company, contactName is the " +
                "primary contact person there. Return an array.",
            },
            { role: "user", content: text },
          ],
          response_format: zodResponseFormat(ClientsResult, "clients_result"),
        });
        return { type, data: stripNulls(response.choices[0]?.message?.parsed?.clients ?? []) };
      }

      if (type === "itinerary") {
        const ItineraryResult = z.object({ days: z.array(ItineraryDaySchema) });
        const startHint = args.startDate
          ? ` The trip starts on ${args.startDate}. Assign dates accordingly.`
          : "";
        const response = await openai.chat.completions.parse({
          model: "openai/gpt-5.6-luna",
          reasoning_effort: "low",
          messages: [
            {
              role: "system",
              content:
                systemBase +
                " Extract a multi-day itinerary. Each day has a dayNumber (1-based), optional title and notes, " +
                "and a list of items with sortOrder (1-based), type, optional time (HH:MM), title, description, location, notes." +
                startHint,
            },
            { role: "user", content: text },
          ],
          response_format: zodResponseFormat(ItineraryResult, "itinerary_result"),
        });
        return { type, data: stripNulls(response.choices[0]?.message?.parsed?.days ?? []) };
      }

      throw new Error(`Unknown extraction type: ${type}`);
    } catch (err) {
      if (err instanceof OpenAI.APIError) {
        throw new Error(`AI extraction failed: ${err.message}`);
      }
      throw err;
    }
  },
});
