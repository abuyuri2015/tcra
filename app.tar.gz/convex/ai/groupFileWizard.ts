"use node";

import { v } from "convex/values";
import { action } from "../_generated/server";
import OpenAI from "openai";
import { zodResponseFormat } from "openai/helpers/zod";
import * as z from "zod";

const openai = new OpenAI({
  baseURL: "https://ai-gateway.hercules.app/v1",
  apiKey: process.env.HERCULES_API_KEY,
});

// ── Draft schema ─────────────────────────────────────────────────────────────
// Mirrors convex/schema/groupFiles.ts baseFields, but every field is optional
// since the wizard fills it in incrementally from a conversation or a document.

const DraftSchema = z.object({
  title: z.string().nullable().optional(),
  fileType: z
    .enum(["group", "meeting", "incentive", "conference", "event"])
    .nullable()
    .optional(),
  clientName: z.string().nullable().optional(),
  clientContactName: z.string().nullable().optional(),
  clientContactEmail: z.string().nullable().optional(),
  clientContactPhone: z.string().nullable().optional(),
  destination: z.string().nullable().optional(),
  // Plain calendar dates, YYYY-MM-DD — converted to ISO instants on the frontend.
  startDate: z.string().nullable().optional(),
  endDate: z.string().nullable().optional(),
  pax: z.number().nullable().optional(),
  currency: z
    .enum(["EUR", "USD", "GBP", "CHF", "AED", "SEK", "NOK", "DKK"])
    .nullable()
    .optional(),
  notes: z.string().nullable().optional(),
});

export type GroupFileDraft = z.infer<typeof DraftSchema>;

/** Same shape as GroupFileDraft, but with nulls stripped (undefined instead). */
export type CleanGroupFileDraft = {
  title?: string;
  fileType?: "group" | "meeting" | "incentive" | "conference" | "event";
  clientName?: string;
  clientContactName?: string;
  clientContactEmail?: string;
  clientContactPhone?: string;
  destination?: string;
  startDate?: string;
  endDate?: string;
  pax?: number;
  currency?: "EUR" | "USD" | "GBP" | "CHF" | "AED" | "SEK" | "NOK" | "DKK";
  notes?: string;
};

function stripNulls<T>(value: T): T {
  if (value === null) return undefined as T;
  if (Array.isArray(value)) return value.map((item) => stripNulls(item)) as T;
  if (typeof value === "object") {
    const result: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
      result[key] = stripNulls(val);
    }
    return result as T;
  }
  return value;
}

const SYSTEM_PROMPT =
  "You are a friendly assistant inside a group travel agency management system. " +
  "Your job is to help a travel agent create a new 'group file' (a booking for a group trip, " +
  "meeting, incentive, conference, or event) by chatting with them. " +
  "As the conversation progresses, extract whatever structured details are known so far into `draft`. " +
  "Leave a field unset until it is actually known — never invent destinations, dates, client names or pax counts. " +
  "Required fields to complete a file: title, clientName, destination, startDate, endDate, pax. " +
  "In `reply`, write a short, warm, conversational message: acknowledge what you understood, and ask ONE " +
  "clear follow-up question for the most important missing required field. " +
  "Once all required fields are known, say so and invite them to review and create the file — do not keep asking questions. " +
  "Currency codes must be ISO 4217 (EUR, USD, GBP, CHF, AED, SEK, NOK, DKK); default to EUR if a client's home currency is unclear. " +
  "Dates must be plain YYYY-MM-DD strings (no time component).";

const ChatResultSchema = z.object({
  reply: z.string(),
  draft: DraftSchema,
});

export const chatTurn = action({
  args: {
    messages: v.array(
      v.object({
        role: v.union(v.literal("user"), v.literal("assistant")),
        content: v.string(),
      }),
    ),
  },
  handler: async (
    _ctx,
    args,
  ): Promise<{ reply: string; draft: CleanGroupFileDraft }> => {
    if (args.messages.length === 0) {
      throw new Error("Say a bit about the trip to get started.");
    }
    try {
      const response = await openai.chat.completions.parse({
        model: "openai/gpt-5.6-luna",
        reasoning_effort: "low",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...args.messages.map((m) => ({ role: m.role, content: m.content })),
        ],
        response_format: zodResponseFormat(ChatResultSchema, "chat_result"),
      });
      const parsed = response.choices[0]?.message?.parsed;
      if (!parsed) {
        throw new Error("The assistant didn't respond. Please try again.");
      }
      return {
        reply: parsed.reply,
        draft: stripNulls<GroupFileDraft>(parsed.draft) as CleanGroupFileDraft,
      };
    } catch (err) {
      if (err instanceof OpenAI.APIError) {
        throw new Error(`AI request failed: ${err.message}`);
      }
      throw err;
    }
  },
});

const EXTRACT_SYSTEM_PROMPT =
  "You are a data extraction specialist for a group travel agency management system. " +
  "You will be given the content of a forwarded email, quote, or booking request (as text, and " +
  "optionally a photo/screenshot of it). Extract the details needed to create a 'group file': " +
  "title (a short descriptive name for the trip/event), fileType, clientName, client contact details, " +
  "destination, startDate, endDate (both plain YYYY-MM-DD), pax (number of travellers), currency, and any " +
  "other useful context as notes. Leave a field unset if it is not actually present in the source — never guess. " +
  "Currency codes must be ISO 4217 (EUR, USD, GBP, CHF, AED, SEK, NOK, DKK).";

const ExtractResultSchema = z.object({
  draft: DraftSchema,
  /** Short note on what was found / what's missing, shown to the agent. */
  summary: z.string(),
});

export const extractFromContent = action({
  args: {
    text: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
  },
  handler: async (
    _ctx,
    args,
  ): Promise<{ draft: CleanGroupFileDraft; summary: string }> => {
    const text = (args.text ?? "").trim();
    if (!text && !args.imageUrl) {
      throw new Error("Paste some email text or upload a document first.");
    }

    const userContent: Array<
      | { type: "text"; text: string }
      | { type: "image_url"; image_url: { url: string } }
    > = [];
    if (text) {
      userContent.push({ type: "text", text });
    } else {
      userContent.push({
        type: "text",
        text: "Extract the group file details from this image.",
      });
    }
    if (args.imageUrl) {
      userContent.push({ type: "image_url", image_url: { url: args.imageUrl } });
    }

    try {
      const response = await openai.chat.completions.parse({
        model: "openai/gpt-5.6-luna",
        reasoning_effort: "low",
        messages: [
          { role: "system", content: EXTRACT_SYSTEM_PROMPT },
          { role: "user", content: userContent },
        ],
        response_format: zodResponseFormat(ExtractResultSchema, "extract_result"),
      });
      const parsed = response.choices[0]?.message?.parsed;
      if (!parsed) {
        throw new Error(
          "Couldn't read any group file details from that. Try pasting the email text instead.",
        );
      }
      const draft = stripNulls<GroupFileDraft>(parsed.draft) as CleanGroupFileDraft;
      const hasAnything = Object.values(draft).some(
        (v) => v !== undefined && v !== null && v !== "",
      );
      if (!hasAnything) {
        throw new Error(
          "Couldn't find any usable trip details in that content. Double-check it contains the client, destination, dates or traveller count, then try again.",
        );
      }
      return { draft, summary: parsed.summary };
    } catch (err) {
      if (err instanceof OpenAI.APIError) {
        throw new Error(`AI extraction failed: ${err.message}`);
      }
      throw err;
    }
  },
});
