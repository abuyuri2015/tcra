/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as activityLog from "../activityLog.js";
import type * as agencyProfile from "../agencyProfile.js";
import type * as ai_extract from "../ai/extract.js";
import type * as ai_groupFileWizard from "../ai/groupFileWizard.js";
import type * as attachments from "../attachments.js";
import type * as calendar from "../calendar.js";
import type * as clients from "../clients.js";
import type * as crons from "../crons.js";
import type * as dashboard from "../dashboard.js";
import type * as documents from "../documents.js";
import type * as email_identities from "../email/identities.js";
import type * as email_logs from "../email/logs.js";
import type * as email_send from "../email/send.js";
import type * as fileTemplates from "../fileTemplates.js";
import type * as finance from "../finance.js";
import type * as financeLines from "../financeLines.js";
import type * as followUps from "../followUps.js";
import type * as groupFiles from "../groupFiles.js";
import type * as hotels from "../hotels.js";
import type * as itineraries from "../itineraries.js";
import type * as itinerary from "../itinerary.js";
import type * as lib_auth from "../lib/auth.js";
import type * as lib_reservationLock from "../lib/reservationLock.js";
import type * as lib_supplierSync from "../lib/supplierSync.js";
import type * as modificationRequests from "../modificationRequests.js";
import type * as notifications from "../notifications.js";
import type * as offerSelections from "../offerSelections.js";
import type * as offers from "../offers.js";
import type * as passengers from "../passengers.js";
import type * as paymentSchedules from "../paymentSchedules.js";
import type * as reports from "../reports.js";
import type * as reservations from "../reservations.js";
import type * as schema_activityLog from "../schema/activityLog.js";
import type * as schema_agencyProfile from "../schema/agencyProfile.js";
import type * as schema_attachments from "../schema/attachments.js";
import type * as schema_clients from "../schema/clients.js";
import type * as schema_emailLogs from "../schema/emailLogs.js";
import type * as schema_fileTemplates from "../schema/fileTemplates.js";
import type * as schema_financeLines from "../schema/financeLines.js";
import type * as schema_groupFiles from "../schema/groupFiles.js";
import type * as schema_hotels from "../schema/hotels.js";
import type * as schema_itinerary from "../schema/itinerary.js";
import type * as schema_modificationRequests from "../schema/modificationRequests.js";
import type * as schema_notifications from "../schema/notifications.js";
import type * as schema_offerSelections from "../schema/offerSelections.js";
import type * as schema_offers from "../schema/offers.js";
import type * as schema_passengers from "../schema/passengers.js";
import type * as schema_paymentSchedules from "../schema/paymentSchedules.js";
import type * as schema_reservations from "../schema/reservations.js";
import type * as schema_suppliers from "../schema/suppliers.js";
import type * as schema_tasks from "../schema/tasks.js";
import type * as schema_users from "../schema/users.js";
import type * as search from "../search.js";
import type * as suppliers from "../suppliers.js";
import type * as tasks from "../tasks.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  activityLog: typeof activityLog;
  agencyProfile: typeof agencyProfile;
  "ai/extract": typeof ai_extract;
  "ai/groupFileWizard": typeof ai_groupFileWizard;
  attachments: typeof attachments;
  calendar: typeof calendar;
  clients: typeof clients;
  crons: typeof crons;
  dashboard: typeof dashboard;
  documents: typeof documents;
  "email/identities": typeof email_identities;
  "email/logs": typeof email_logs;
  "email/send": typeof email_send;
  fileTemplates: typeof fileTemplates;
  finance: typeof finance;
  financeLines: typeof financeLines;
  followUps: typeof followUps;
  groupFiles: typeof groupFiles;
  hotels: typeof hotels;
  itineraries: typeof itineraries;
  itinerary: typeof itinerary;
  "lib/auth": typeof lib_auth;
  "lib/reservationLock": typeof lib_reservationLock;
  "lib/supplierSync": typeof lib_supplierSync;
  modificationRequests: typeof modificationRequests;
  notifications: typeof notifications;
  offerSelections: typeof offerSelections;
  offers: typeof offers;
  passengers: typeof passengers;
  paymentSchedules: typeof paymentSchedules;
  reports: typeof reports;
  reservations: typeof reservations;
  "schema/activityLog": typeof schema_activityLog;
  "schema/agencyProfile": typeof schema_agencyProfile;
  "schema/attachments": typeof schema_attachments;
  "schema/clients": typeof schema_clients;
  "schema/emailLogs": typeof schema_emailLogs;
  "schema/fileTemplates": typeof schema_fileTemplates;
  "schema/financeLines": typeof schema_financeLines;
  "schema/groupFiles": typeof schema_groupFiles;
  "schema/hotels": typeof schema_hotels;
  "schema/itinerary": typeof schema_itinerary;
  "schema/modificationRequests": typeof schema_modificationRequests;
  "schema/notifications": typeof schema_notifications;
  "schema/offerSelections": typeof schema_offerSelections;
  "schema/offers": typeof schema_offers;
  "schema/passengers": typeof schema_passengers;
  "schema/paymentSchedules": typeof schema_paymentSchedules;
  "schema/reservations": typeof schema_reservations;
  "schema/suppliers": typeof schema_suppliers;
  "schema/tasks": typeof schema_tasks;
  "schema/users": typeof schema_users;
  search: typeof search;
  suppliers: typeof suppliers;
  tasks: typeof tasks;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
