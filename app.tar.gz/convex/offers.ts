import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireGroupFile, requireIdentity, requireUser } from "./lib/auth.ts";
import { currencyValidator } from "./schema/groupFiles.ts";
import { reservationTypeValidator } from "./schema/reservations.ts";
import { offerStatusValidator } from "./schema/offers.ts";
import { hotelBoardValidator } from "./schema/hotels.ts";
import { logActivity } from "./activityLog.ts";
import { ensureSupplierOrHotelLinked } from "./lib/supplierSync.ts";

const offerFields = {
  type: reservationTypeValidator,
  status: offerStatusValidator,
  supplierName: v.string(),
  hotelId: v.optional(v.id("hotels")),
  description: v.string(),
  startDate: v.string(),
  endDate: v.optional(v.string()),
  units: v.number(),
  unitLabel: v.optional(v.string()),
  board: v.optional(hotelBoardValidator),
  nights: v.optional(v.number()),
  supplierRef: v.optional(v.string()),
  ratePerUnit: v.optional(v.number()),
  costPerUnit: v.optional(v.number()),
  currency: currencyValidator,
  notes: v.optional(v.string()),
};

async function requireOffer(
  ctx: QueryCtx | MutationCtx,
  id: Id<"offers">,
): Promise<Doc<"offers">> {
  const offer = await ctx.db.get("offers", id);
  if (!offer) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Offer not found." });
  }
  return offer;
}

/** Maps a service type to the closest cost category used on the Cost & income tab. */
function costCategoryForType(type: Doc<"offers">["type"]): string {
  switch (type) {
    case "hotel":
      return "accommodation";
    case "transfer":
      return "transport";
    case "restaurant":
      return "meals";
    case "activity":
      return "activities";
    case "venue":
      return "venue";
    case "flight":
      return "flights";
    default:
      return "other";
  }
}

/**
 * Converts an offer into a booked reservation and, when the offer has a cost
 * per unit, books the resulting cost/income impact as new finance lines
 * (cost = costPerUnit x units, income = sell rate x units, using the sell
 * rate if set or the file's default markup % otherwise). Idempotent: returns
 * the existing reservation id if this offer was already converted.
 */
async function convertOfferToReservationInternal(
  ctx: MutationCtx,
  offer: Doc<"offers">,
  user: Doc<"users">,
): Promise<Id<"reservations">> {
  if (offer.convertedReservationId) return offer.convertedReservationId;

  const reservationId = await ctx.db.insert("reservations", {
    groupFileId: offer.groupFileId,
    type: offer.type,
    status: "option",
    supplierName: offer.supplierName,
    hotelId: offer.hotelId,
    description: offer.description,
    startDate: offer.startDate,
    endDate: offer.endDate,
    units: offer.units,
    unitLabel: offer.unitLabel,
    board: offer.board,
    nights: offer.nights,
    supplierRef: offer.supplierRef,
    ratePerUnit: offer.ratePerUnit,
    costPerUnit: offer.costPerUnit,
    currency: offer.currency,
    notes: offer.notes,
    createdById: user._id,
  });

  await ctx.db.patch("offers", offer._id, {
    status: "accepted",
    convertedReservationId: reservationId,
  });

  await logActivity(ctx, {
    groupFileId: offer.groupFileId,
    action: "offer_converted",
    description: `Converted offer "${offer.supplierName}" into a reservation`,
    user,
  });

  // Auto-book the cost/income impact when the offer has a cost per unit —
  // otherwise there's nothing to calculate automatically.
  const file = await ctx.db.get("groupFiles", offer.groupFileId);
  if (file && offer.costPerUnit !== undefined) {
    const costAmount = offer.costPerUnit * offer.units;
    const lineDescription = `${offer.supplierName} — ${offer.description} (accepted offer)`;

    await ctx.db.insert("financeLines", {
      groupFileId: offer.groupFileId,
      kind: "cost",
      category: costCategoryForType(offer.type),
      description: lineDescription,
      supplierName: offer.supplierName,
      amount: costAmount,
      currency: offer.currency,
      exchangeRateToBase: file.exchangeRateToBase,
      unitRate: offer.costPerUnit,
      quantity: offer.units,
      quantityLabel: offer.unitLabel,
      notes: "Auto-generated from accepted offer.",
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: offer.groupFileId,
      action: "finance_line_added",
      description: `Added cost line "${lineDescription}" (${offer.currency} ${costAmount.toFixed(2)})`,
      user,
    });

    // Mirror an income line using the sell rate if set, otherwise the file's
    // default markup % on top of cost.
    const sellRatePerUnit =
      offer.ratePerUnit ?? offer.costPerUnit * (1 + (file.markupPercent ?? 0) / 100);
    const incomeAmount = sellRatePerUnit * offer.units;

    await ctx.db.insert("financeLines", {
      groupFileId: offer.groupFileId,
      kind: "income",
      category: "client-payment",
      description: lineDescription,
      supplierName: offer.supplierName,
      amount: incomeAmount,
      currency: offer.currency,
      exchangeRateToBase: file.exchangeRateToBase,
      unitRate: sellRatePerUnit,
      quantity: offer.units,
      quantityLabel: offer.unitLabel,
      notes: "Auto-generated from accepted offer.",
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: offer.groupFileId,
      action: "finance_line_added",
      description: `Added income line "${lineDescription}" (${offer.currency} ${incomeAmount.toFixed(2)})`,
      user,
    });
  }

  return reservationId;
}


export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"offers">[]> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("offers")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("desc")
      .collect();
  },
});

/** Fetch a single offer by id — used to show live offer details on a client selection. */
export const get = query({
  args: { id: v.id("offers") },
  handler: async (ctx, args): Promise<Doc<"offers"> | null> => {
    await requireIdentity(ctx);
    return await ctx.db.get("offers", args.id);
  },
});

export const create = mutation({
  args: { groupFileId: v.id("groupFiles"), ...offerFields },
  handler: async (ctx, args): Promise<Id<"offers">> => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    if (args.units < 1) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Units must be at least 1." });
    }
    // Auto-add brand-new supplier/hotel names to the reusable database.
    const hotelId = await ensureSupplierOrHotelLinked(ctx, {
      type: args.type,
      supplierName: args.supplierName,
      hotelId: args.hotelId,
      currency: args.currency,
      createdById: user._id,
    });
    const id = await ctx.db.insert("offers", {
      ...args,
      hotelId,
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "offer_added",
      description: `Added ${args.type} offer "${args.supplierName}"`,
      user,
    });

    return id;
  },
});

/**
 * Creates a hotel offer with several room types (e.g. single, double, Jr
 * suite) bundled under one quote for the same hotel. Each room type becomes
 * its own offer row (with its own units/rate/cost so it can be individually
 * accepted, rejected, or converted) but all rows share the hotel-level
 * details and an `offerGroupId` so they display and can be selected together.
 */
export const createHotelOffer = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    status: offerStatusValidator,
    supplierName: v.string(),
    hotelId: v.optional(v.id("hotels")),
    startDate: v.string(),
    endDate: v.optional(v.string()),
    nights: v.optional(v.number()),
    board: v.optional(hotelBoardValidator),
    supplierRef: v.optional(v.string()),
    currency: currencyValidator,
    notes: v.optional(v.string()),
    roomTypes: v.array(
      v.object({
        description: v.string(),
        units: v.number(),
        unitLabel: v.optional(v.string()),
        ratePerUnit: v.optional(v.number()),
        costPerUnit: v.optional(v.number()),
      }),
    ),
  },
  handler: async (ctx, args): Promise<Id<"offers">[]> => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    if (args.roomTypes.length === 0) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "Add at least one room type.",
      });
    }
    for (const roomType of args.roomTypes) {
      if (!roomType.description.trim()) {
        throw new ConvexError({
          code: "BAD_REQUEST",
          message: "Enter a description for every room type.",
        });
      }
      if (roomType.units < 1) {
        throw new ConvexError({ code: "BAD_REQUEST", message: "Units must be at least 1." });
      }
    }

    const hotelId = await ensureSupplierOrHotelLinked(ctx, {
      type: "hotel",
      supplierName: args.supplierName,
      hotelId: args.hotelId,
      currency: args.currency,
      createdById: user._id,
    });

    const ids: Id<"offers">[] = [];
    let offerGroupId: Id<"offers"> | undefined;
    for (const roomType of args.roomTypes) {
      const id = await ctx.db.insert("offers", {
        groupFileId: args.groupFileId,
        type: "hotel",
        status: args.status,
        supplierName: args.supplierName,
        hotelId,
        description: roomType.description.trim(),
        startDate: args.startDate,
        endDate: args.endDate,
        units: roomType.units,
        unitLabel: roomType.unitLabel,
        board: args.board,
        nights: args.nights,
        supplierRef: args.supplierRef,
        ratePerUnit: roomType.ratePerUnit,
        costPerUnit: roomType.costPerUnit,
        currency: args.currency,
        notes: args.notes,
        offerGroupId,
        createdById: user._id,
      });
      if (!offerGroupId) {
        offerGroupId = id;
        await ctx.db.patch("offers", id, { offerGroupId: id });
      }
      ids.push(id);
    }

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "offer_added",
      description: `Added hotel offer "${args.supplierName}" with ${args.roomTypes.length} room type${args.roomTypes.length > 1 ? "s" : ""}`,
      user,
    });

    return ids;
  },
});

/**
 * Adds one more room type to an existing hotel offer group, inheriting the
 * shared hotel-level details (dates, board, supplier, currency, notes) from
 * another offer in the same group. Converts a standalone hotel offer into a
 * group of one if it doesn't have an `offerGroupId` yet.
 */
export const addRoomTypeToGroup = mutation({
  args: {
    offerId: v.id("offers"),
    description: v.string(),
    units: v.number(),
    unitLabel: v.optional(v.string()),
    ratePerUnit: v.optional(v.number()),
    costPerUnit: v.optional(v.number()),
  },
  handler: async (ctx, args): Promise<Id<"offers">> => {
    const user = await requireUser(ctx);
    const template = await requireOffer(ctx, args.offerId);
    if (!args.description.trim()) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Enter a room type description." });
    }
    if (args.units < 1) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Units must be at least 1." });
    }

    const offerGroupId = template.offerGroupId ?? template._id;
    if (!template.offerGroupId) {
      await ctx.db.patch("offers", template._id, { offerGroupId });
    }

    const id = await ctx.db.insert("offers", {
      groupFileId: template.groupFileId,
      type: "hotel",
      status: "pending",
      supplierName: template.supplierName,
      hotelId: template.hotelId,
      description: args.description.trim(),
      startDate: template.startDate,
      endDate: template.endDate,
      units: args.units,
      unitLabel: args.unitLabel,
      board: template.board,
      nights: template.nights,
      supplierRef: template.supplierRef,
      ratePerUnit: args.ratePerUnit,
      costPerUnit: args.costPerUnit,
      currency: template.currency,
      notes: template.notes,
      offerGroupId,
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: template.groupFileId,
      action: "offer_added",
      description: `Added room type "${args.description.trim()}" to hotel offer "${template.supplierName}"`,
      user,
    });

    return id;
  },
});

/** Lists every offer sharing the given group id (the room types of one hotel offer). */
export const listByGroup = query({
  args: { offerGroupId: v.id("offers") },
  handler: async (ctx, args): Promise<Doc<"offers">[]> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("offers")
      .withIndex("by_offer_group", (q) => q.eq("offerGroupId", args.offerGroupId))
      .collect();
  },
});

export const update = mutation({
  args: { id: v.id("offers"), ...offerFields },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const { id, ...fields } = args;
    const existing = await requireOffer(ctx, id);
    if (existing.convertedReservationId) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "This offer has already been converted into a reservation.",
      });
    }
    if (fields.units < 1) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Units must be at least 1." });
    }
    // Auto-add brand-new supplier/hotel names to the reusable database.
    const hotelId = await ensureSupplierOrHotelLinked(ctx, {
      type: fields.type,
      supplierName: fields.supplierName,
      hotelId: fields.hotelId,
      currency: fields.currency,
      createdById: user._id,
    });
    await ctx.db.patch("offers", id, { ...fields, hotelId });

    await logActivity(ctx, {
      groupFileId: existing.groupFileId,
      action: "offer_updated",
      description: `Updated ${fields.type} offer "${fields.supplierName}"`,
      user,
    });

    return null;
  },
});

/**
 * Sets an offer's status and, when accepted, automatically books it as a
 * reservation and generates the matching cost/income finance lines. Shared
 * by the staff-facing `setStatus` mutation and by marking a client offer
 * selection as reviewed (which accepts every offer the client picked).
 * No-ops (returns immediately) if the offer was already converted.
 */
async function setOfferStatusInternal(
  ctx: MutationCtx,
  offer: Doc<"offers">,
  status: Doc<"offers">["status"],
  user: Doc<"users">,
): Promise<void> {
  if (offer.convertedReservationId) return;

  await ctx.db.patch("offers", offer._id, { status });

  await logActivity(ctx, {
    groupFileId: offer.groupFileId,
    action: status === "accepted" ? "offer_accepted" : "offer_updated",
    description: `Offer "${offer.supplierName}" status → ${status}`,
    user,
  });

  if (status === "accepted") {
    const updated = await requireOffer(ctx, offer._id);
    await convertOfferToReservationInternal(ctx, updated, user);
  }
}

export const setStatus = mutation({
  args: { id: v.id("offers"), status: offerStatusValidator },
  handler: async (ctx, args): Promise<null> => {
    const user = await requireUser(ctx);
    const offer = await requireOffer(ctx, args.id);
    if (offer.convertedReservationId) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "This offer has already been converted into a reservation.",
      });
    }
    await setOfferStatusInternal(ctx, offer, args.status, user);
    return null;
  },
});

/**
 * Accepts an offer by id, booking it as a reservation, if it's still pending
 * and not already converted. Silently no-ops otherwise (e.g. an offer in a
 * client selection that staff already handled another way). Used when a
 * client offer selection is marked reviewed, to accept every offer the
 * client picked in one step.
 */
export async function acceptOfferIfPending(
  ctx: MutationCtx,
  offerId: Id<"offers">,
  user: Doc<"users">,
): Promise<void> {
  const offer = await ctx.db.get("offers", offerId);
  if (!offer || offer.status !== "pending" || offer.convertedReservationId) return;
  await setOfferStatusInternal(ctx, offer, "accepted", user);
}

export const remove = mutation({
  args: { id: v.id("offers") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const offer = await requireOffer(ctx, args.id);

    await logActivity(ctx, {
      groupFileId: offer.groupFileId,
      action: "offer_removed",
      description: `Removed ${offer.type} offer "${offer.supplierName}"`,
      user,
    });

    await ctx.db.delete("offers", args.id);
    return null;
  },
});

/** Converts an accepted offer into a real reservation on the same file. */
export const convertToReservation = mutation({
  args: { id: v.id("offers") },
  handler: async (ctx, args): Promise<Id<"reservations">> => {
    const user = await requireUser(ctx);
    const offer = await requireOffer(ctx, args.id);
    if (offer.convertedReservationId) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "This offer has already been converted into a reservation.",
      });
    }

    return await convertOfferToReservationInternal(ctx, offer, user);
  },
});

/**
 * Logs that the offer link was (re)sent to the client — called after a
 * successful email send. Also stamps `lastOfferLinkSentAt` (used by the
 * "pending response" follow-up flag) and clears any earlier dismiss, since a
 * fresh send restarts the follow-up clock.
 */
export const logOfferLinkSent = mutation({
  args: { groupFileId: v.id("groupFiles"), to: v.string() },
  handler: async (ctx, args): Promise<null> => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    await ctx.db.patch("groupFiles", args.groupFileId, {
      lastOfferLinkSentAt: new Date().toISOString(),
      offerFollowUpDismissedAt: undefined,
    });
    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "offer_link_sent",
      description: `Sent the offer link to ${args.to}`,
      user,
    });
    return null;
  },
});
