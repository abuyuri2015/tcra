import { v } from "convex/values";
import { query } from "./_generated/server.js";
import { requireIdentity } from "./lib/auth.ts";
import type { Id } from "./_generated/dataModel.js";

export type CalendarFile = {
  id: Id<"groupFiles">;
  reference: string;
  title: string;
  clientName: string;
  destination: string;
  startDate: string;
  endDate: string;
  status: string;
  pax: number;
};

/**
 * Returns all group files whose date range overlaps with [rangeStart, rangeEnd].
 * Both are ISO date strings (YYYY-MM-DD).
 */
export const filesInRange = query({
  args: {
    rangeStart: v.string(), // inclusive, e.g. "2026-03-01"
    rangeEnd: v.string(),   // inclusive, e.g. "2026-03-31"
  },
  handler: async (ctx, args): Promise<CalendarFile[]> => {
    await requireIdentity(ctx);

    // Fetch files ordered by start date, bounded at 500.
    // A file overlaps [rangeStart, rangeEnd] when:
    //   file.startDate <= rangeEnd AND file.endDate >= rangeStart
    // We can narrow with an index range on startDate (<= rangeEnd),
    // then filter for endDate >= rangeStart client-side.
    const candidates = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date", (q) => q.lte("startDate", args.rangeEnd + "T23:59:59Z"))
      .order("asc")
      .take(500);

    return candidates
      .filter((f) => f.endDate >= args.rangeStart)
      .filter((f) => f.status !== "cancelled")
      .map((f) => ({
        id: f._id,
        reference: f.reference,
        title: f.title,
        clientName: f.clientName,
        destination: f.destination,
        startDate: f.startDate,
        endDate: f.endDate,
        status: f.status,
        pax: f.pax,
      }));
  },
});
