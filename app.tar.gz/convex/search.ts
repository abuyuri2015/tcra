import { v } from "convex/values";
import { query } from "./_generated/server.js";
import { requireIdentity } from "./lib/auth.ts";
import type { Id } from "./_generated/dataModel.js";

export type SearchResult =
  | {
      kind: "file";
      id: Id<"groupFiles">;
      title: string;
      subtitle: string;
      status: string;
      reference: string;
    }
  | {
      kind: "hotel";
      id: Id<"hotels">;
      title: string;
      subtitle: string;
      status: string;
    }
  | {
      kind: "reservation";
      id: Id<"reservations">;
      groupFileId: Id<"groupFiles">;
      fileReference: string;
      fileTitle: string;
      title: string;
      subtitle: string;
      type: string;
      status: string;
    }
  | {
      kind: "supplier";
      id: Id<"suppliers">;
      title: string;
      subtitle: string;
      category: string;
    }
  | {
      kind: "passenger";
      id: Id<"passengers">;
      groupFileId: Id<"groupFiles">;
      fileReference: string;
      fileTitle: string;
      title: string;
      subtitle: string;
      roomType: string;
    }
  | {
      kind: "client";
      id: Id<"clients">;
      title: string;
      subtitle: string;
      clientKind: string;
    };

export const search = query({
  args: { q: v.string() },
  handler: async (ctx, args): Promise<SearchResult[]> => {
    await requireIdentity(ctx);

    const q = args.q.trim();
    if (q.length < 2) return [];

    const LIMIT = 5;

    // ── Files ─────────────────────────────────────────────────────────────────
    const [byTitle, byClient, byDest] = await Promise.all([
      ctx.db
        .query("groupFiles")
        .withSearchIndex("search_title", (s) => s.search("title", q))
        .take(LIMIT),
      ctx.db
        .query("groupFiles")
        .withSearchIndex("search_client", (s) => s.search("clientName", q))
        .take(LIMIT),
      ctx.db
        .query("groupFiles")
        .withSearchIndex("search_destination", (s) => s.search("destination", q))
        .take(LIMIT),
    ]);

    const fileMap = new Map<string, (typeof byTitle)[0]>();
    for (const f of [...byTitle, ...byClient, ...byDest]) {
      if (!fileMap.has(f._id)) fileMap.set(f._id, f);
    }

    const fileResults: SearchResult[] = [...fileMap.values()]
      .slice(0, 8)
      .map((f) => ({
        kind: "file",
        id: f._id,
        title: f.title,
        subtitle: `${f.reference} · ${f.clientName} · ${f.destination}`,
        status: f.status,
        reference: f.reference,
      }));

    // ── Hotels ────────────────────────────────────────────────────────────────
    const [byName, byCity] = await Promise.all([
      ctx.db
        .query("hotels")
        .withSearchIndex("search_name", (s) => s.search("name", q))
        .take(LIMIT),
      ctx.db
        .query("hotels")
        .withSearchIndex("search_city", (s) => s.search("city", q))
        .take(LIMIT),
    ]);

    const hotelMap = new Map<string, (typeof byName)[0]>();
    for (const h of [...byName, ...byCity]) {
      if (!hotelMap.has(h._id)) hotelMap.set(h._id, h);
    }

    const hotelResults: SearchResult[] = [...hotelMap.values()]
      .slice(0, 5)
      .map((h) => ({
        kind: "hotel",
        id: h._id,
        title: h.name,
        subtitle: `${h.city}, ${h.country} · ${h.category}`,
        status: h.status,
      }));

    // ── Reservations ──────────────────────────────────────────────────────────
    const [bySupplier, byDesc] = await Promise.all([
      ctx.db
        .query("reservations")
        .withSearchIndex("search_supplier", (s) => s.search("supplierName", q))
        .take(LIMIT),
      ctx.db
        .query("reservations")
        .withSearchIndex("search_description", (s) => s.search("description", q))
        .take(LIMIT),
    ]);

    const resMap = new Map<string, (typeof bySupplier)[0]>();
    for (const r of [...bySupplier, ...byDesc]) {
      if (!resMap.has(r._id)) resMap.set(r._id, r);
    }

    // ── Suppliers ─────────────────────────────────────────────────────────────
    const [suppByName, suppByCity] = await Promise.all([
      ctx.db
        .query("suppliers")
        .withSearchIndex("search_name", (s) => s.search("name", q))
        .take(LIMIT),
      ctx.db
        .query("suppliers")
        .withSearchIndex("search_city", (s) => s.search("city", q))
        .take(LIMIT),
    ]);

    const suppMap = new Map<string, (typeof suppByName)[0]>();
    for (const s of [...suppByName, ...suppByCity]) {
      if (!suppMap.has(s._id)) suppMap.set(s._id, s);
    }

    const supplierResults: SearchResult[] = [...suppMap.values()]
      .slice(0, 5)
      .map((s) => ({
        kind: "supplier",
        id: s._id,
        title: s.name,
        subtitle: [s.city, s.country, s.category].filter(Boolean).join(" · "),
        category: s.category,
      }));

    // ── Passengers ────────────────────────────────────────────────────────────
    const [paxByLast, paxByFirst] = await Promise.all([
      ctx.db
        .query("passengers")
        .withSearchIndex("search_last_name", (s) => s.search("lastName", q))
        .take(LIMIT),
      ctx.db
        .query("passengers")
        .withSearchIndex("search_first_name", (s) => s.search("firstName", q))
        .take(LIMIT),
    ]);

    const paxMap = new Map<string, (typeof paxByLast)[0]>();
    for (const p of [...paxByLast, ...paxByFirst]) {
      if (!paxMap.has(p._id)) paxMap.set(p._id, p);
    }

    // Batch-fetch parent files for reservations and passengers
    const resFileIds = [...new Set([...resMap.values()].map((r) => r.groupFileId))];
    const paxFileIds = [...new Set([...paxMap.values()].map((p) => p.groupFileId))];
    const allParentIds = [...new Set([...resFileIds, ...paxFileIds])];
    const parentFiles = await Promise.all(
      allParentIds.map((id) => ctx.db.get("groupFiles", id)),
    );
    const fileLabels = new Map<string, { reference: string; title: string }>();
    for (const pf of parentFiles) {
      if (pf) fileLabels.set(pf._id, { reference: pf.reference, title: pf.title });
    }

    const resResults: SearchResult[] = [...resMap.values()]
      .slice(0, 5)
      .map((r) => {
        const pf = fileLabels.get(r.groupFileId) ?? { reference: "—", title: "—" };
        return {
          kind: "reservation",
          id: r._id,
          groupFileId: r.groupFileId,
          fileReference: pf.reference,
          fileTitle: pf.title,
          title: r.supplierName,
          subtitle: `${r.description} · ${pf.reference}`,
          type: r.type,
          status: r.status,
        };
      });

    const passengerResults: SearchResult[] = [...paxMap.values()]
      .slice(0, 5)
      .map((p) => {
        const pf = fileLabels.get(p.groupFileId) ?? { reference: "—", title: "—" };
        return {
          kind: "passenger",
          id: p._id,
          groupFileId: p.groupFileId,
          fileReference: pf.reference,
          fileTitle: pf.title,
          title: `${p.firstName} ${p.lastName}`,
          subtitle: `${pf.reference} · ${p.roomType}`,
          roomType: p.roomType,
        };
      });

    // ── Clients ───────────────────────────────────────────────────────────────
    const clientMatches = await ctx.db
      .query("clients")
      .withSearchIndex("search_name", (s) => s.search("name", q))
      .take(8);

    const clientResults: SearchResult[] = clientMatches.map((c) => ({
      kind: "client",
      id: c._id,
      title: c.name,
      subtitle: [c.kind === "company" ? "Company" : "Individual", c.city, c.country]
        .filter(Boolean)
        .join(" · "),
      clientKind: c.kind,
    }));

    return [
      ...fileResults,
      ...clientResults,
      ...hotelResults,
      ...supplierResults,
      ...resResults,
      ...passengerResults,
    ];
  },
});
