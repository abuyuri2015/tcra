import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import { requireIdentity, requireUser, requireGroupFile } from "./lib/auth.ts";
import type { MutationCtx } from "./_generated/server.js";
import type { Id } from "./_generated/dataModel.js";
import { logActivity } from "./activityLog.ts";

// ── Helpers ───────────────────────────────────────────────────────────────────

async function requireLine(ctx: MutationCtx, id: Id<"financeLines">) {
  const line = await ctx.db.get("financeLines", id);
  if (!line) {
    throw new ConvexError({ message: "Finance line not found", code: "NOT_FOUND" });
  }
  return line;
}

// ── Queries ───────────────────────────────────────────────────────────────────

export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<
    Array<{
      _id: Id<"financeLines">;
      _creationTime: number;
      groupFileId: Id<"groupFiles">;
      kind: "cost" | "income";
      category: string;
      description: string;
      supplierName?: string;
      amount: number;
      currency: string;
      exchangeRateToBase: number;
      unitRate?: number;
      quantity?: number;
      quantityLabel?: string;
      notes?: string;
      createdById: Id<"users">;
      paidAt?: string;
      paymentDueDate?: string;
      amountInBase: number;
    }>
  > => {
    await requireIdentity(ctx);
    const lines = await ctx.db
      .query("financeLines")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .collect();
    return lines.map((l) => ({
      ...l,
      amountInBase: l.amount * l.exchangeRateToBase,
    }));
  },
});

export const summaryByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<{
    totalCostByCurrency: Record<string, number>;
    totalIncomeByCurrency: Record<string, number>;
    totalCostEur: number;
    totalIncomeEur: number;
    marginEur: number;
    marginPct: number | null;
  }> => {
    await requireIdentity(ctx);
    const lines = await ctx.db
      .query("financeLines")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .collect();

    const totalCostByCurrency: Record<string, number> = {};
    const totalIncomeByCurrency: Record<string, number> = {};
    let totalCostEur = 0;
    let totalIncomeEur = 0;

    for (const l of lines) {
      const eur = l.amount * l.exchangeRateToBase;
      if (l.kind === "cost") {
        totalCostByCurrency[l.currency] =
          (totalCostByCurrency[l.currency] ?? 0) + l.amount;
        totalCostEur += eur;
      } else {
        totalIncomeByCurrency[l.currency] =
          (totalIncomeByCurrency[l.currency] ?? 0) + l.amount;
        totalIncomeEur += eur;
      }
    }

    const marginEur = totalIncomeEur - totalCostEur;
    const marginPct =
      totalIncomeEur > 0 ? (marginEur / totalIncomeEur) * 100 : null;

    return {
      totalCostByCurrency,
      totalIncomeByCurrency,
      totalCostEur,
      totalIncomeEur,
      marginEur,
      marginPct,
    };
  },
});

// ── Mutations ─────────────────────────────────────────────────────────────────

export const create = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    kind: v.union(v.literal("cost"), v.literal("income")),
    category: v.string(),
    description: v.string(),
    supplierName: v.optional(v.string()),
    amount: v.number(),
    currency: v.string(),
    exchangeRateToBase: v.number(),
    unitRate: v.optional(v.number()),
    quantity: v.optional(v.number()),
    quantityLabel: v.optional(v.string()),
    notes: v.optional(v.string()),
    paymentDueDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    const id = await ctx.db.insert("financeLines", {
      ...args,
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "finance_line_added",
      description: `Added ${args.kind} line "${args.description}" (${args.currency} ${args.amount.toFixed(2)})`,
      user,
    });

    return id;
  },
});

export const update = mutation({
  args: {
    id: v.id("financeLines"),
    kind: v.union(v.literal("cost"), v.literal("income")),
    category: v.string(),
    description: v.string(),
    supplierName: v.optional(v.string()),
    amount: v.number(),
    currency: v.string(),
    exchangeRateToBase: v.number(),
    unitRate: v.optional(v.number()),
    quantity: v.optional(v.number()),
    quantityLabel: v.optional(v.string()),
    notes: v.optional(v.string()),
    paymentDueDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    await requireLine(ctx, id);
    await ctx.db.patch("financeLines", id, fields);
  },
});

export const remove = mutation({
  args: { id: v.id("financeLines") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const line = await requireLine(ctx, args.id);

    await logActivity(ctx, {
      groupFileId: line.groupFileId,
      action: "finance_line_removed",
      description: `Removed ${line.kind} line "${line.description}"`,
      user,
    });

    await ctx.db.delete("financeLines", args.id);
  },
});

export const setPaid = mutation({
  args: {
    id: v.id("financeLines"),
    paid: v.boolean(),
    // Allow backdating the payment date; defaults to now when marking as paid.
    paidAt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const line = await requireLine(ctx, args.id);

    const paidAt = args.paid ? args.paidAt ?? new Date().toISOString() : undefined;
    await ctx.db.patch("financeLines", args.id, { paidAt });

    const who = line.kind === "income" ? "by client" : "to supplier";
    await logActivity(ctx, {
      groupFileId: line.groupFileId,
      action: args.paid ? "finance_line_paid" : "finance_line_unpaid",
      description: args.paid
        ? `Marked "${line.description}" as paid ${who} (${line.currency} ${line.amount.toFixed(2)})`
        : `Marked "${line.description}" as unpaid`,
      user,
    });
  },
});

/**
 * Marks the whole client invoice (every income line on a file) as paid/unpaid
 * in one go. Clients pay per invoice — a % of the package value — not per
 * individual income line, so payment status is tracked at the invoice level
 * rather than per line.
 */
export const setInvoicePaid = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    paid: v.boolean(),
    // Allow backdating the payment date; defaults to now when marking as paid.
    paidAt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);

    const incomeLines = await ctx.db
      .query("financeLines")
      .withIndex("by_group_file_and_kind", (q) =>
        q.eq("groupFileId", args.groupFileId).eq("kind", "income"),
      )
      .collect();

    const paidAt = args.paid ? args.paidAt ?? new Date().toISOString() : undefined;
    for (const line of incomeLines) {
      await ctx.db.patch("financeLines", line._id, { paidAt });
    }

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: args.paid ? "finance_line_paid" : "finance_line_unpaid",
      description: args.paid
        ? `Marked invoice as paid by client (${incomeLines.length} income line${incomeLines.length !== 1 ? "s" : ""})`
        : "Marked invoice as unpaid by client",
      user,
    });
  },
});
