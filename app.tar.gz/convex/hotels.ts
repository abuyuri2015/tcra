import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireIdentity, requireUser } from "./lib/auth.ts";
import { currencyValidator } from "./schema/groupFiles.ts";
import {
  hotelBoardValidator,
  hotelCategoryValidator,
  hotelStatusValidator,
} from "./schema/hotels.ts";

const hotelFields = {
  name: v.string(),
  category: hotelCategoryValidator,
  status: hotelStatusValidator,
  city: v.string(),
  country: v.string(),
  address: v.optional(v.string()),
  website: v.optional(v.string()),
  contactName: v.optional(v.string()),
  contactEmail: v.optional(v.string()),
  contactPhone: v.optional(v.string()),
  totalRooms: v.optional(v.number()),
  meetingRooms: v.optional(v.number()),
  largestMeetingCapacity: v.optional(v.number()),
  currency: currencyValidator,
  imageUrls: v.array(v.string()),
  amenities: v.array(v.string()),
  notes: v.optional(v.string()),
};

const roomTypeFields = {
  name: v.string(),
  occupancy: v.number(),
  board: hotelBoardValidator,
  nightlyRate: v.optional(v.number()),
  notes: v.optional(v.string()),
};

async function requireHotel(
  ctx: QueryCtx | MutationCtx,
  id: Id<"hotels">,
): Promise<Doc<"hotels">> {
  const hotel = await ctx.db.get("hotels", id);
  if (!hotel) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Hotel not found." });
  }
  return hotel;
}

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    status: v.optional(hotelStatusValidator),
  },
  handler: async (ctx, args) => {
    await requireIdentity(ctx);
    const base =
      args.status !== undefined
        ? ctx.db
            .query("hotels")
            .withIndex("by_status_and_name", (q) =>
              q.eq("status", args.status!),
            )
        : ctx.db.query("hotels").withIndex("by_search_name");
    return await base.order("asc").paginate(args.paginationOpts);
  },
});

export const stats = query({
  args: {},
  handler: async (ctx) => {
    await requireIdentity(ctx);
    const all = await ctx.db.query("hotels").take(500);
    const cities = new Set(all.map((h) => `${h.city}|${h.country}`));
    return {
      total: all.length,
      preferred: all.filter((h) => h.status === "preferred").length,
      cities: cities.size,
    };
  },
});

export const get = query({
  args: { id: v.id("hotels") },
  handler: async (
    ctx,
    args,
  ): Promise<{
    hotel: Doc<"hotels">;
    roomTypes: Doc<"hotelRoomTypes">[];
  } | null> => {
    await requireIdentity(ctx);
    const hotel = await ctx.db.get("hotels", args.id);
    if (!hotel) return null;
    const roomTypes = await ctx.db
      .query("hotelRoomTypes")
      .withIndex("by_hotel", (q) => q.eq("hotelId", hotel._id))
      .collect();
    return { hotel, roomTypes };
  },
});

export const create = mutation({
  args: hotelFields,
  handler: async (ctx, args): Promise<Id<"hotels">> => {
    const user = await requireUser(ctx);
    return await ctx.db.insert("hotels", {
      ...args,
      searchName: args.name.trim().toLowerCase(),
      createdById: user._id,
    });
  },
});

export const update = mutation({
  args: { id: v.id("hotels"), ...hotelFields },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    await requireHotel(ctx, id);
    await ctx.db.patch("hotels", id, {
      ...fields,
      searchName: fields.name.trim().toLowerCase(),
    });
    return null;
  },
});

export const setStatus = mutation({
  args: { id: v.id("hotels"), status: hotelStatusValidator },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireHotel(ctx, args.id);
    await ctx.db.patch("hotels", args.id, { status: args.status });
    return null;
  },
});

export const bulkCreate = mutation({
  args: {
    hotels: v.array(
      v.object({
        ...hotelFields,
        roomTypes: v.array(
          v.object({
            name: v.string(),
            occupancy: v.number(),
            board: hotelBoardValidator,
            nightlyRate: v.optional(v.number()),
            notes: v.optional(v.string()),
          }),
        ),
      }),
    ),
  },
  handler: async (
    ctx,
    args,
  ): Promise<{ imported: number; skipped: number }> => {
    const user = await requireUser(ctx);
    const existing = await ctx.db.query("hotels").take(2000);
    const existingNames = new Set(existing.map((h) => h.name.trim().toLowerCase()));

    let imported = 0;
    let skipped = 0;

    for (const { roomTypes, ...hotel } of args.hotels) {
      const name = hotel.name.trim();
      if (!name || existingNames.has(name.toLowerCase())) {
        skipped++;
        continue;
      }
      const hotelId = await ctx.db.insert("hotels", {
        ...hotel,
        name,
        searchName: name.toLowerCase(),
        createdById: user._id,
      });
      for (const rt of roomTypes) {
        await ctx.db.insert("hotelRoomTypes", { hotelId, ...rt });
      }
      existingNames.add(name.toLowerCase());
      imported++;
    }

    return { imported, skipped };
  },
});

export const remove = mutation({
  args: { id: v.id("hotels") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireHotel(ctx, args.id);
    // Room types belong to the hotel, so remove them alongside it.
    const roomTypes = await ctx.db
      .query("hotelRoomTypes")
      .withIndex("by_hotel", (q) => q.eq("hotelId", args.id))
      .collect();
    for (const room of roomTypes) {
      await ctx.db.delete("hotelRoomTypes", room._id);
    }
    await ctx.db.delete("hotels", args.id);
    return null;
  },
});

export const bulkUpdateStatus = mutation({
  args: {
    ids: v.array(v.id("hotels")),
    status: hotelStatusValidator,
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    for (const id of args.ids) {
      const hotel = await ctx.db.get("hotels", id);
      if (hotel) {
        await ctx.db.patch("hotels", id, { status: args.status });
      }
    }
    return null;
  },
});

export const bulkDelete = mutation({
  args: { ids: v.array(v.id("hotels")) },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    for (const id of args.ids) {
      const hotel = await ctx.db.get("hotels", id);
      if (!hotel) continue;
      const roomTypes = await ctx.db
        .query("hotelRoomTypes")
        .withIndex("by_hotel", (q) => q.eq("hotelId", id))
        .collect();
      for (const room of roomTypes) {
        await ctx.db.delete("hotelRoomTypes", room._id);
      }
      await ctx.db.delete("hotels", id);
    }
    return null;
  },
});

export const addRoomType = mutation({
  args: { hotelId: v.id("hotels"), ...roomTypeFields },
  handler: async (ctx, args): Promise<Id<"hotelRoomTypes">> => {
    await requireUser(ctx);
    await requireHotel(ctx, args.hotelId);
    if (args.occupancy < 1) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "Occupancy must be at least 1 guest.",
      });
    }
    return await ctx.db.insert("hotelRoomTypes", args);
  },
});

export const updateRoomType = mutation({
  args: { id: v.id("hotelRoomTypes"), ...roomTypeFields },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    const existing = await ctx.db.get("hotelRoomTypes", id);
    if (!existing) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Room type not found.",
      });
    }
    await ctx.db.patch("hotelRoomTypes", id, fields);
    return null;
  },
});

export const removeRoomType = mutation({
  args: { id: v.id("hotelRoomTypes") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const existing = await ctx.db.get("hotelRoomTypes", args.id);
    if (!existing) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Room type not found.",
      });
    }
    await ctx.db.delete("hotelRoomTypes", args.id);
    return null;
  },
});
