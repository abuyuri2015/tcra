import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { ConvexError } from "convex/values";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

async function setupFileWithHotelReservation(
  t: ReturnType<typeof convexTest>,
  status: "option" | "confirmed" = "confirmed",
) {
  const asUser = t.withIdentity({ name: "Ada" });

  const hotelId = await asUser.mutation(api.hotels.create, {
    name: "Test Hotel",
    category: "4-star",
    status: "active",
    city: "Paris",
    country: "France",
    currency: "EUR",
    contactEmail: "reservations@testhotel.com",
    imageUrls: [],
    amenities: [],
  });

  const groupFileId = await asUser.mutation(api.groupFiles.create, {
    title: "Test Trip",
    fileType: "group",
    status: "confirmed",
    clientName: "Acme Co",
    destination: "Paris",
    startDate: "2027-01-01T00:00:00.000Z",
    endDate: "2027-01-05T00:00:00.000Z",
    pax: 10,
    currency: "EUR",
    exchangeRateToBase: 1,
  });

  const reservationId = await asUser.mutation(api.reservations.create, {
    groupFileId,
    type: "hotel",
    status,
    supplierName: "Test Hotel",
    hotelId,
    description: "Double room",
    startDate: "2027-01-01T00:00:00.000Z",
    units: 10,
    unitLabel: "rooms",
    costPerUnit: 100,
    ratePerUnit: 120,
    currency: "EUR",
  });

  return { asUser, groupFileId, reservationId, hotelId };
}

describe("confirmed reservations require hotel approval for any change", () => {
  it("blocks a direct staff update on a confirmed reservation", async () => {
    const t = convexTest(schema, modules);
    const { asUser, reservationId } = await setupFileWithHotelReservation(t, "confirmed");

    await expect(
      asUser.mutation(api.reservations.update, {
        id: reservationId,
        type: "hotel",
        status: "confirmed",
        supplierName: "Test Hotel",
        description: "Different room",
        startDate: "2027-01-01T00:00:00.000Z",
        units: 12,
        currency: "EUR",
      }),
    ).rejects.toThrow(ConvexError);
  });

  it("blocks a direct staff removal of a confirmed reservation", async () => {
    const t = convexTest(schema, modules);
    const { asUser, reservationId } = await setupFileWithHotelReservation(t, "confirmed");

    await expect(asUser.mutation(api.reservations.remove, { id: reservationId })).rejects.toThrow(
      ConvexError,
    );
  });

  it("blocks changing the status of a confirmed reservation directly", async () => {
    const t = convexTest(schema, modules);
    const { asUser, reservationId } = await setupFileWithHotelReservation(t, "confirmed");

    await expect(
      asUser.mutation(api.reservations.setStatus, { id: reservationId, status: "cancelled" }),
    ).rejects.toThrow(ConvexError);
  });

  it("still allows direct edits on a non-confirmed reservation", async () => {
    const t = convexTest(schema, modules);
    const { asUser, reservationId } = await setupFileWithHotelReservation(t, "option");

    await expect(
      asUser.mutation(api.reservations.update, {
        id: reservationId,
        type: "hotel",
        status: "option",
        supplierName: "Test Hotel",
        description: "Updated room",
        startDate: "2027-01-01T00:00:00.000Z",
        units: 12,
        currency: "EUR",
      }),
    ).resolves.toBeNull();
  });

  it("allows confirming a reservation for the first time directly", async () => {
    const t = convexTest(schema, modules);
    const { asUser, reservationId } = await setupFileWithHotelReservation(t, "option");

    await expect(
      asUser.mutation(api.reservations.setStatus, { id: reservationId, status: "confirmed" }),
    ).resolves.toBeNull();
  });
});

describe("modificationRequests.submitByStaff", () => {
  it("requires authentication", async () => {
    const t = convexTest(schema, modules);
    const { groupFileId, reservationId } = await setupFileWithHotelReservation(t, "confirmed");

    await expect(
      t.mutation(api.modificationRequests.submitByStaff, {
        groupFileId,
        reservationId,
        kind: "units",
        requestedUnits: 12,
        message: "",
        appOrigin: "https://example.com",
      }),
    ).rejects.toThrow(ConvexError);
  });

  it("creates a request tagged as staff-submitted and applies it identically once approved", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithHotelReservation(
      t,
      "confirmed",
    );

    const { id: requestId } = await asUser.mutation(api.modificationRequests.submitByStaff, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 12,
      message: "",
      appOrigin: "https://example.com",
    });

    const requests = await asUser.query(api.modificationRequests.listByFile, { groupFileId });
    const created = requests.find((r) => r._id === requestId);
    expect(created?.submittedBy).toBe("staff");
    expect(created?.status).toBe("pending_hotel");

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "approved",
    });

    const reservation = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservation[0]?.units).toBe(12);
  });

  it("blocks a staff change request when the file is finance-locked", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithHotelReservation(
      t,
      "confirmed",
    );

    await asUser.mutation(api.groupFiles.setFinanceLocked, { id: groupFileId, locked: true });

    await expect(
      asUser.mutation(api.modificationRequests.submitByStaff, {
        groupFileId,
        reservationId,
        kind: "units",
        requestedUnits: 12,
        message: "",
        appOrigin: "https://example.com",
      }),
    ).rejects.toThrow(ConvexError);
  });
});
