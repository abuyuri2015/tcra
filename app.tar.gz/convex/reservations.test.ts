import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

describe("reservations.create auto-adds suppliers/hotels", () => {
  it("creates a new hotel record when a brand-new hotel name is typed", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const fileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "enquiry",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    await asUser.mutation(api.reservations.create, {
      groupFileId: fileId,
      type: "hotel",
      status: "option",
      supplierName: "Brand New Hotel",
      description: "Double room",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 1,
      currency: "EUR",
    });

    const hotels = await asUser.query(api.hotels.list, { paginationOpts: { numItems: 50, cursor: null } });
    expect(hotels.page.some((h) => h.name === "Brand New Hotel")).toBe(true);

    const reservations = await asUser.query(api.reservations.listByFile, { groupFileId: fileId });
    expect(reservations[0]?.hotelId).toBeDefined();
  });

  it("does not create a duplicate hotel for an existing name (case-insensitive)", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const fileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "enquiry",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    await asUser.mutation(api.reservations.create, {
      groupFileId: fileId,
      type: "hotel",
      status: "option",
      supplierName: "Grand Hotel",
      description: "Double room",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 1,
      currency: "EUR",
    });
    await asUser.mutation(api.reservations.create, {
      groupFileId: fileId,
      type: "hotel",
      status: "option",
      supplierName: "grand hotel",
      description: "Single room",
      startDate: "2027-01-02T00:00:00.000Z",
      units: 1,
      currency: "EUR",
    });

    const hotels = await asUser.query(api.hotels.list, { paginationOpts: { numItems: 50, cursor: null } });
    expect(hotels.page.filter((h) => h.name.toLowerCase() === "grand hotel")).toHaveLength(1);
  });

  it("creates a new supplier record for a non-hotel service type", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const fileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "enquiry",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    await asUser.mutation(api.reservations.create, {
      groupFileId: fileId,
      type: "transfer",
      status: "option",
      supplierName: "New Transfer Co",
      description: "Airport pickup",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 1,
      currency: "EUR",
    });

    const suppliers = await asUser.query(api.suppliers.list, {});
    expect(suppliers.some((s) => s.name === "New Transfer Co" && s.category === "transfer")).toBe(
      true,
    );
  });

  it("does not create a duplicate supplier for an existing name in the same category", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    await asUser.mutation(api.suppliers.create, {
      name: "Existing Coach Co",
      category: "transfer",
    });

    const fileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "enquiry",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    await asUser.mutation(api.reservations.create, {
      groupFileId: fileId,
      type: "transfer",
      status: "option",
      supplierName: "Existing Coach Co",
      description: "Airport pickup",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 1,
      currency: "EUR",
    });

    const suppliers = await asUser.query(api.suppliers.list, {});
    expect(suppliers.filter((s) => s.name === "Existing Coach Co")).toHaveLength(1);
  });

  it("reuses the picked hotelId instead of creating a new hotel", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const hotelId = await asUser.mutation(api.hotels.create, {
      name: "Picked Hotel",
      category: "4-star",
      status: "active",
      city: "Paris",
      country: "France",
      currency: "EUR",
      imageUrls: [],
      amenities: [],
    });

    const fileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "enquiry",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    await asUser.mutation(api.reservations.create, {
      groupFileId: fileId,
      type: "hotel",
      status: "option",
      supplierName: "Picked Hotel",
      hotelId,
      description: "Double room",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 1,
      currency: "EUR",
    });

    const hotels = await asUser.query(api.hotels.list, { paginationOpts: { numItems: 50, cursor: null } });
    expect(hotels.page.filter((h) => h.name === "Picked Hotel")).toHaveLength(1);
  });
});
