import { query } from "./_generated/server.js";
import { requireIdentity } from "./lib/auth.ts";
import type { Id } from "./_generated/dataModel.js";

export type ItineraryOverviewRow = {
  fileId: Id<"groupFiles">;
  reference: string;
  title: string;
  clientName: string;
  destination: string;
  startDate: string;
  endDate: string;
  status: string;
  fileType: string;
  pax: number;
  dayCount: number;
  itemCount: number;
  ownerName: string | null;
};

/**
 * Returns all group files that have at least one itinerary day,
 * with day and item counts. Bounded to 200 files.
 */
export const overview = query({
  args: {},
  handler: async (ctx): Promise<ItineraryOverviewRow[]> => {
    await requireIdentity(ctx);

    const files = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date")
      .order("desc")
      .take(200);

    const rows: ItineraryOverviewRow[] = [];

    await Promise.all(
      files.map(async (file) => {
        const days = await ctx.db
          .query("itineraryDays")
          .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
          .collect();

        if (days.length === 0) return;

        // Count items across all days
        let itemCount = 0;
        await Promise.all(
          days.map(async (day) => {
            const items = await ctx.db
              .query("itineraryItems")
              .withIndex("by_day", (q) => q.eq("dayId", day._id))
              .collect();
            itemCount += items.length;
          }),
        );

        const owner = await ctx.db.get("users", file.ownerId);

        rows.push({
          fileId: file._id,
          reference: file.reference,
          title: file.title,
          clientName: file.clientName,
          destination: file.destination,
          startDate: file.startDate,
          endDate: file.endDate,
          status: file.status,
          fileType: file.fileType,
          pax: file.pax,
          dayCount: days.length,
          itemCount,
          ownerName: owner?.name ?? owner?.email ?? null,
        });
      }),
    );

    // Sort by start date desc
    rows.sort((a, b) => b.startDate.localeCompare(a.startDate));

    return rows;
  },
});
