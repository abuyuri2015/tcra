import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

describe("marking a client offer selection as reviewed", () => {
  it("automatically accepts every selected offer and books it as a reservation", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const groupFileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "confirmed",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    const hotelOfferId = await asUser.mutation(api.offers.create, {
      groupFileId,
      type: "hotel",
      status: "pending",
      supplierName: "Test Hotel",
      description: "Double room",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 10,
      unitLabel: "rooms",
      costPerUnit: 100,
      ratePerUnit: 130,
      currency: "EUR",
    });
    const transferOfferId = await asUser.mutation(api.offers.create, {
      groupFileId,
      type: "transfer",
      status: "pending",
      supplierName: "Test Transfers",
      description: "Airport pick up",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 1,
      unitLabel: "pax",
      costPerUnit: 50,
      ratePerUnit: 60,
      currency: "EUR",
    });

    const { id: selectionId } = await t.mutation(api.offerSelections.submitPublic, {
      groupFileId,
      items: [
        { offerId: hotelOfferId, requestedUnits: 10 },
        { offerId: transferOfferId, requestedUnits: 1 },
      ],
    });

    await asUser.mutation(api.offerSelections.markReviewed, {
      id: selectionId,
      status: "reviewed",
    });

    const offers = await asUser.query(api.offers.listByFile, { groupFileId });
    for (const offerId of [hotelOfferId, transferOfferId]) {
      const offer = offers.find((o) => o._id === offerId);
      expect(offer?.status).toBe("accepted");
      expect(offer?.convertedReservationId).toBeDefined();
    }

    const reservations = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservations).toHaveLength(2);
    expect(reservations.map((r) => r.supplierName).sort()).toEqual([
      "Test Hotel",
      "Test Transfers",
    ]);
  });

  it("does not error when an offer was already accepted through another selection", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const groupFileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "confirmed",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    const offerId = await asUser.mutation(api.offers.create, {
      groupFileId,
      type: "hotel",
      status: "pending",
      supplierName: "Test Hotel",
      description: "Double room",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 10,
      unitLabel: "rooms",
      costPerUnit: 100,
      currency: "EUR",
    });

    const { id: selectionId } = await t.mutation(api.offerSelections.submitPublic, {
      groupFileId,
      items: [{ offerId, requestedUnits: 10 }],
    });

    // Staff already accepted it manually before reviewing the selection.
    await asUser.mutation(api.offers.setStatus, { id: offerId, status: "accepted" });

    await expect(
      asUser.mutation(api.offerSelections.markReviewed, {
        id: selectionId,
        status: "reviewed",
      }),
    ).resolves.toBeNull();

    const reservations = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservations).toHaveLength(1);
  });
});
