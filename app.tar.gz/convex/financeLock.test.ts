import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { ConvexError } from "convex/values";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

async function setupFileWithReservation(t: ReturnType<typeof convexTest>) {
  const asUser = t.withIdentity({ name: "Ada" });

  const groupFileId = await asUser.mutation(api.groupFiles.create, {
    title: "Test Trip",
    fileType: "group",
    status: "confirmed",
    clientName: "Acme Co",
    destination: "Paris",
    startDate: "2027-01-01T00:00:00.000Z",
    endDate: "2027-01-05T00:00:00.000Z",
    pax: 10,
    currency: "EUR",
    exchangeRateToBase: 1,
  });

  const reservationId = await asUser.mutation(api.reservations.create, {
    groupFileId,
    type: "hotel",
    status: "option",
    supplierName: "Test Hotel",
    description: "Double room",
    startDate: "2027-01-01T00:00:00.000Z",
    units: 5,
    currency: "EUR",
  });

  return { asUser, groupFileId, reservationId };
}

describe("finance lock blocks edits to existing reservations", () => {
  it("blocks update, remove, and setStatus once the file is locked", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithReservation(t);

    await asUser.mutation(api.groupFiles.setFinanceLocked, { id: groupFileId, locked: true });

    await expect(
      asUser.mutation(api.reservations.update, {
        id: reservationId,
        type: "hotel",
        status: "option",
        supplierName: "Test Hotel",
        description: "Different room",
        startDate: "2027-01-01T00:00:00.000Z",
        units: 6,
        currency: "EUR",
      }),
    ).rejects.toThrow(ConvexError);

    await expect(
      asUser.mutation(api.reservations.setStatus, { id: reservationId, status: "confirmed" }),
    ).rejects.toThrow(ConvexError);

    await expect(
      asUser.mutation(api.reservations.remove, { id: reservationId }),
    ).rejects.toThrow(ConvexError);
  });

  it("still allows adding new reservations while locked", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId } = await setupFileWithReservation(t);

    await asUser.mutation(api.groupFiles.setFinanceLocked, { id: groupFileId, locked: true });

    await expect(
      asUser.mutation(api.reservations.create, {
        groupFileId,
        type: "transfer",
        status: "option",
        supplierName: "Airport Coach",
        description: "Extra transfer",
        startDate: "2027-01-01T00:00:00.000Z",
        units: 1,
        currency: "EUR",
      }),
    ).resolves.toBeDefined();
  });

  it("allows editing again once reopened", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithReservation(t);

    await asUser.mutation(api.groupFiles.setFinanceLocked, { id: groupFileId, locked: true });
    await asUser.mutation(api.groupFiles.setFinanceLocked, { id: groupFileId, locked: false });

    await expect(
      asUser.mutation(api.reservations.update, {
        id: reservationId,
        type: "hotel",
        status: "option",
        supplierName: "Test Hotel",
        description: "Updated room",
        startDate: "2027-01-01T00:00:00.000Z",
        units: 6,
        currency: "EUR",
      }),
    ).resolves.toBeNull();
  });

  it("blocks a client modification request once the file is locked", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithReservation(t);

    await asUser.mutation(api.groupFiles.setFinanceLocked, { id: groupFileId, locked: true });

    await expect(
      t.mutation(api.modificationRequests.submitPublic, {
        groupFileId,
        reservationId,
        kind: "units",
        requestedUnits: 8,
        message: "",
        appOrigin: "https://example.com",
      }),
    ).rejects.toThrow(ConvexError);
  });
});
