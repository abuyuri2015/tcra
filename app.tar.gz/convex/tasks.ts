import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import { requireUser, requireIdentity } from "./lib/auth.ts";
import { taskStatusValidator } from "./schema/tasks.ts";
import type { Id, Doc } from "./_generated/dataModel.js";
import { logActivity } from "./activityLog.ts";

// ── Queries ───────────────────────────────────────────────────────────────────

/** All tasks for a group file, ordered by due date asc (nulls last). */
export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"tasks">[]> => {
    await requireIdentity(ctx);
    const tasks = await ctx.db
      .query("tasks")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .collect();
    return tasks.sort((a, b) => {
      if (!a.dueDate && !b.dueDate) return 0;
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return a.dueDate.localeCompare(b.dueDate);
    });
  },
});

export type DashboardTask = Doc<"tasks"> & {
  fileReference: string;
  fileTitle: string;
  fileId: Id<"groupFiles">;
};

/**
 * Returns open + in_progress tasks with a due date, ordered by due date asc.
 * Used on the dashboard. Bounded to 100 tasks.
 */
export const upcoming = query({
  args: {},
  handler: async (ctx): Promise<{
    overdue: DashboardTask[];
    upcoming: DashboardTask[];
  }> => {
    await requireIdentity(ctx);

    const now = new Date().toISOString();

    const open = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "open"))
      .take(100);
    const inProgress = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "in_progress"))
      .take(100);

    const all = [...open, ...inProgress].filter((t) => !!t.dueDate);
    all.sort((a, b) => a.dueDate!.localeCompare(b.dueDate!));

    // Batch-fetch parent files
    const fileIds = [...new Set(all.map((t) => t.groupFileId))];
    const fileMap = new Map<string, { reference: string; title: string }>();
    await Promise.all(
      fileIds.map(async (id) => {
        const f = await ctx.db.get("groupFiles", id);
        if (f) fileMap.set(id, { reference: f.reference, title: f.title });
      }),
    );

    const enriched: DashboardTask[] = all.map((t) => ({
      ...t,
      fileReference: fileMap.get(t.groupFileId)?.reference ?? "—",
      fileTitle: fileMap.get(t.groupFileId)?.title ?? "—",
      fileId: t.groupFileId,
    }));

    return {
      overdue: enriched.filter((t) => t.dueDate! < now),
      upcoming: enriched.filter((t) => t.dueDate! >= now).slice(0, 8),
    };
  },
});

/** All tasks across all files, enriched with file info. Used by /tasks page. */
export const listAll = query({
  args: {
    status: v.optional(taskStatusValidator),
  },
  handler: async (ctx, args): Promise<DashboardTask[]> => {
    await requireIdentity(ctx);

    const now = new Date().toISOString();

    let tasks: Doc<"tasks">[];
    if (args.status) {
      tasks = await ctx.db
        .query("tasks")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .take(500);
    } else {
      // Fetch each status bucket separately to stay within index bounds
      const open = await ctx.db
        .query("tasks")
        .withIndex("by_status", (q) => q.eq("status", "open"))
        .take(250);
      const inProg = await ctx.db
        .query("tasks")
        .withIndex("by_status", (q) => q.eq("status", "in_progress"))
        .take(250);
      const done = await ctx.db
        .query("tasks")
        .withIndex("by_status", (q) => q.eq("status", "done"))
        .take(250);
      tasks = [...open, ...inProg, ...done];
    }

    // Batch-fetch parent files
    const fileIds = [...new Set(tasks.map((t) => t.groupFileId))];
    const fileMap = new Map<string, { reference: string; title: string }>();
    await Promise.all(
      fileIds.map(async (id) => {
        const f = await ctx.db.get("groupFiles", id);
        if (f) fileMap.set(id, { reference: f.reference, title: f.title });
      }),
    );

    const enriched: DashboardTask[] = tasks.map((t) => ({
      ...t,
      fileReference: fileMap.get(t.groupFileId)?.reference ?? "—",
      fileTitle: fileMap.get(t.groupFileId)?.title ?? "—",
      fileId: t.groupFileId,
    }));

    // Sort: overdue first, then by due date asc, tasks without due date last
    enriched.sort((a, b) => {
      // Done tasks always go after open/in-progress
      if (a.status === "done" && b.status !== "done") return 1;
      if (a.status !== "done" && b.status === "done") return -1;

      // Among non-done, overdue first
      const aOverdue = a.status !== "done" && a.dueDate && a.dueDate < now;
      const bOverdue = b.status !== "done" && b.dueDate && b.dueDate < now;
      if (aOverdue && !bOverdue) return -1;
      if (!aOverdue && bOverdue) return 1;

      // Then by due date
      if (!a.dueDate && !b.dueDate) return 0;
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return a.dueDate.localeCompare(b.dueDate);
    });

    return enriched;
  },
});

/** Count of open + in_progress tasks for a file (for badge). */
export const openCountByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<number> => {
    await requireIdentity(ctx);
    const open = await ctx.db
      .query("tasks")
      .withIndex("by_group_file_and_status", (q) =>
        q.eq("groupFileId", args.groupFileId).eq("status", "open"),
      )
      .collect();
    const inProg = await ctx.db
      .query("tasks")
      .withIndex("by_group_file_and_status", (q) =>
        q.eq("groupFileId", args.groupFileId).eq("status", "in_progress"),
      )
      .collect();
    return open.length + inProg.length;
  },
});

// ── Mutations ─────────────────────────────────────────────────────────────────

export const create = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    title: v.string(),
    dueDate: v.optional(v.string()),
    assignee: v.optional(v.string()),
    status: taskStatusValidator,
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const id = await ctx.db.insert("tasks", {
      ...args,
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "task_added",
      description: `Added task "${args.title}"`,
      user,
    });

    return id;
  },
});

export const update = mutation({
  args: {
    id: v.id("tasks"),
    title: v.string(),
    dueDate: v.optional(v.string()),
    assignee: v.optional(v.string()),
    status: taskStatusValidator,
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const { id, ...fields } = args;
    const task = await ctx.db.get("tasks", id);
    if (!task) throw new ConvexError({ message: "Task not found", code: "NOT_FOUND" });

    // Detect status transitions for richer log messages
    const wasCompleted = task.status === "done" && fields.status !== "done";
    const nowCompleted = task.status !== "done" && fields.status === "done";

    await ctx.db.patch("tasks", id, fields);

    if (nowCompleted) {
      await logActivity(ctx, {
        groupFileId: task.groupFileId,
        action: "task_completed",
        description: `Completed task "${fields.title}"`,
        user,
      });
    } else if (wasCompleted) {
      await logActivity(ctx, {
        groupFileId: task.groupFileId,
        action: "task_reopened",
        description: `Reopened task "${fields.title}"`,
        user,
      });
    }
  },
});

export const setStatus = mutation({
  args: { id: v.id("tasks"), status: taskStatusValidator },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const task = await ctx.db.get("tasks", args.id);
    if (!task) throw new ConvexError({ message: "Task not found", code: "NOT_FOUND" });
    await ctx.db.patch("tasks", args.id, { status: args.status });

    if (args.status === "done" && task.status !== "done") {
      await logActivity(ctx, {
        groupFileId: task.groupFileId,
        action: "task_completed",
        description: `Completed task "${task.title}"`,
        user,
      });
    } else if (args.status !== "done" && task.status === "done") {
      await logActivity(ctx, {
        groupFileId: task.groupFileId,
        action: "task_reopened",
        description: `Reopened task "${task.title}"`,
        user,
      });
    }
  },
});

export const remove = mutation({
  args: { id: v.id("tasks") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const task = await ctx.db.get("tasks", args.id);
    if (!task) throw new ConvexError({ message: "Task not found", code: "NOT_FOUND" });
    await ctx.db.delete("tasks", args.id);
  },
});
