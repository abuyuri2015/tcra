import { v } from "convex/values";
import { query, mutation, internalMutation } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireIdentity } from "./lib/auth.ts";

// ── Public query ─────────────────────────────────────────────────────────────

export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args) => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("activityLog")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("desc")
      .take(100);
  },
});

// ── Internal helper (callable from other mutations) ──────────────────────────

/**
 * Logs an activity event. Call from any mutation that changes group-file data.
 * Requires a MutationCtx + the user doc from `requireUser`.
 */
export async function logActivity(
  ctx: MutationCtx,
  opts: {
    groupFileId: Id<"groupFiles">;
    action: Doc<"activityLog">["action"];
    description: string;
    user: Doc<"users">;
  },
) {
  await ctx.db.insert("activityLog", {
    groupFileId: opts.groupFileId,
    action: opts.action,
    description: opts.description,
    userId: opts.user._id,
    userName: opts.user.name ?? opts.user.email ?? "Unknown",
    timestamp: new Date().toISOString(),
  });
}
