import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import { requireIdentity, requireUser, requireGroupFile } from "./lib/auth.ts";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";

// ── Helpers ───────────────────────────────────────────────────────────────────

async function requireDay(ctx: MutationCtx | QueryCtx, id: Id<"itineraryDays">) {
  const day = await ctx.db.get("itineraryDays", id);
  if (!day) throw new ConvexError({ message: "Day not found", code: "NOT_FOUND" });
  return day;
}

async function requireItem(ctx: MutationCtx, id: Id<"itineraryItems">) {
  const item = await ctx.db.get("itineraryItems", id);
  if (!item) throw new ConvexError({ message: "Item not found", code: "NOT_FOUND" });
  return item;
}

// ── Queries ───────────────────────────────────────────────────────────────────

/** Returns all days for a file, sorted by date, each with their items sorted by sortOrder. */
export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<
    Array<
      Doc<"itineraryDays"> & {
        items: Doc<"itineraryItems">[];
      }
    >
  > => {
    await requireIdentity(ctx);
    const days = await ctx.db
      .query("itineraryDays")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("asc")
      .collect();

    return await Promise.all(
      days.map(async (day) => {
        const items = await ctx.db
          .query("itineraryItems")
          .withIndex("by_day_and_order", (q) => q.eq("dayId", day._id))
          .order("asc")
          .collect();
        return { ...day, items };
      }),
    );
  },
});

/** Public query — no auth required — used by the shareable client page. */
export const listByFilePublic = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<
    Array<
      Doc<"itineraryDays"> & {
        items: Doc<"itineraryItems">[];
      }
    >
  > => {
    const days = await ctx.db
      .query("itineraryDays")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("asc")
      .collect();

    return await Promise.all(
      days.map(async (day) => {
        const items = await ctx.db
          .query("itineraryItems")
          .withIndex("by_day_and_order", (q) => q.eq("dayId", day._id))
          .order("asc")
          .collect();
        return { ...day, items };
      }),
    );
  },
});

// ── Day mutations ─────────────────────────────────────────────────────────────

export const createDay = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    date: v.string(),
    dayNumber: v.number(),
    title: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    return await ctx.db.insert("itineraryDays", args);
  },
});

export const updateDay = mutation({
  args: {
    id: v.id("itineraryDays"),
    title: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    await requireDay(ctx, id);
    await ctx.db.patch("itineraryDays", id, fields);
  },
});

export const removeDay = mutation({
  args: { id: v.id("itineraryDays") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireDay(ctx, args.id);
    // Remove all items in this day first
    const items = await ctx.db
      .query("itineraryItems")
      .withIndex("by_day", (q) => q.eq("dayId", args.id))
      .collect();
    for (const item of items) {
      await ctx.db.delete("itineraryItems", item._id);
    }
    await ctx.db.delete("itineraryDays", args.id);
  },
});

/** Generates all days from the file's startDate to endDate */
export const generateDays = mutation({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const file = await requireGroupFile(ctx, args.groupFileId);

    // Clear existing days & items
    const existingDays = await ctx.db
      .query("itineraryDays")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .collect();
    for (const day of existingDays) {
      const items = await ctx.db
        .query("itineraryItems")
        .withIndex("by_day", (q) => q.eq("dayId", day._id))
        .collect();
      for (const item of items) {
        await ctx.db.delete("itineraryItems", item._id);
      }
      await ctx.db.delete("itineraryDays", day._id);
    }

    // Build days
    const start = new Date(file.startDate);
    const end = new Date(file.endDate);
    let dayNumber = 1;
    const cur = new Date(start);
    while (cur <= end) {
      await ctx.db.insert("itineraryDays", {
        groupFileId: args.groupFileId,
        date: cur.toISOString(),
        dayNumber,
      });
      cur.setDate(cur.getDate() + 1);
      dayNumber++;
    }
  },
});

// ── Item mutations ────────────────────────────────────────────────────────────

export const createItem = mutation({
  args: {
    dayId: v.id("itineraryDays"),
    groupFileId: v.id("groupFiles"),
    sortOrder: v.number(),
    type: v.union(
      v.literal("arrival"), v.literal("departure"), v.literal("transfer"),
      v.literal("hotel"), v.literal("meal"), v.literal("activity"),
      v.literal("meeting"), v.literal("flight"), v.literal("free-time"),
      v.literal("other"),
    ),
    time: v.optional(v.string()),
    title: v.string(),
    description: v.optional(v.string()),
    location: v.optional(v.string()),
    notes: v.optional(v.string()),
    reservationId: v.optional(v.id("reservations")),
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    return await ctx.db.insert("itineraryItems", args);
  },
});

export const updateItem = mutation({
  args: {
    id: v.id("itineraryItems"),
    type: v.union(
      v.literal("arrival"), v.literal("departure"), v.literal("transfer"),
      v.literal("hotel"), v.literal("meal"), v.literal("activity"),
      v.literal("meeting"), v.literal("flight"), v.literal("free-time"),
      v.literal("other"),
    ),
    time: v.optional(v.string()),
    title: v.string(),
    description: v.optional(v.string()),
    location: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    await requireItem(ctx, id);
    await ctx.db.patch("itineraryItems", id, fields);
  },
});

export const removeItem = mutation({
  args: { id: v.id("itineraryItems") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireItem(ctx, args.id);
    await ctx.db.delete("itineraryItems", args.id);
  },
});

export const reorderItem = mutation({
  args: { id: v.id("itineraryItems"), sortOrder: v.number() },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireItem(ctx, args.id);
    await ctx.db.patch("itineraryItems", args.id, { sortOrder: args.sortOrder });
  },
});
