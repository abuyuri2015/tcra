import { v } from "convex/values";
import { query } from "./_generated/server.js";
import { requireIdentity } from "./lib/auth.ts";
import { groupFileStatusValidator } from "./schema/groupFiles.ts";
import { reservationTypeValidator } from "./schema/reservations.ts";
import type { Id, Doc } from "./_generated/dataModel.js";

export type VoucherRow = Doc<"reservations"> & {
  file: {
    _id: Id<"groupFiles">;
    reference: string;
    title: string;
    clientName: string;
    destination: string;
    startDate: string;
    endDate: string;
    status: string;
    pax: number;
    currency: string;
    exchangeRateToBase: number;
    clientContactName?: string;
    clientContactEmail?: string;
    ownerName: string | null;
  };
};

export type InvoiceRow = {
  file: Doc<"groupFiles"> & { ownerName: string | null };
  incomeLines: Array<Doc<"financeLines"> & { amountInBase: number }>;
  invoiceNumber: string;
  totalEur: number;
};

/**
 * Returns all vouchers (reservations) and invoices (file + income lines),
 * bounded to 200 files. Filters applied server-side.
 */
export const overview = query({
  args: {
    fileStatus: v.optional(groupFileStatusValidator),
    reservationType: v.optional(reservationTypeValidator),
  },
  handler: async (
    ctx,
    args,
  ): Promise<{ vouchers: VoucherRow[]; invoices: InvoiceRow[] }> => {
    await requireIdentity(ctx);

    // Fetch files — by status index if filtered, otherwise all (bounded)
    const files = args.fileStatus
      ? await ctx.db
          .query("groupFiles")
          .withIndex("by_status", (q) => q.eq("status", args.fileStatus!))
          .take(200)
      : await ctx.db
          .query("groupFiles")
          .withIndex("by_start_date")
          .order("desc")
          .take(200);

    // Fetch owner names in one batch
    const ownerIds = [...new Set(files.map((f) => f.ownerId))];
    const ownerMap: Record<string, string | null> = {};
    await Promise.all(
      ownerIds.map(async (id) => {
        const user = await ctx.db.get("users", id);
        ownerMap[id] = user?.name ?? user?.email ?? null;
      }),
    );

    const vouchers: VoucherRow[] = [];
    const invoices: InvoiceRow[] = [];

    await Promise.all(
      files.map(async (file) => {
        const fileShape = {
          _id: file._id,
          reference: file.reference,
          title: file.title,
          clientName: file.clientName,
          destination: file.destination,
          startDate: file.startDate,
          endDate: file.endDate,
          status: file.status,
          pax: file.pax,
          currency: file.currency,
          exchangeRateToBase: file.exchangeRateToBase,
          clientContactName: file.clientContactName,
          clientContactEmail: file.clientContactEmail,
          ownerName: ownerMap[file.ownerId] ?? null,
        };

        // Reservations
        const reservations = await ctx.db
          .query("reservations")
          .withIndex("by_group_file_and_start", (q) =>
            q.eq("groupFileId", file._id),
          )
          .order("asc")
          .collect();

        const activeReservations = reservations.filter(
          (r) => r.status !== "cancelled",
        );
        const filtered =
          args.reservationType
            ? activeReservations.filter((r) => r.type === args.reservationType)
            : activeReservations;

        for (const r of filtered) {
          vouchers.push({ ...r, file: fileShape });
        }

        // Finance lines (income only)
        const lines = await ctx.db
          .query("financeLines")
          .withIndex("by_group_file_and_kind", (q) =>
            q.eq("groupFileId", file._id).eq("kind", "income"),
          )
          .collect();

        const incomeLines = lines.map((l) => ({
          ...l,
          amountInBase: l.amount * l.exchangeRateToBase,
        }));

        const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);

        invoices.push({
          file: { ...file, ownerName: ownerMap[file.ownerId] ?? null },
          incomeLines,
          invoiceNumber: `INV-${file.reference.replace(/^GM-/, "")}`,
          totalEur: Math.round(totalEur),
        });
      }),
    );

    // Sort vouchers by file start date desc, then reservation start asc
    vouchers.sort((a, b) => {
      const fd = b.file.startDate.localeCompare(a.file.startDate);
      return fd !== 0 ? fd : a.startDate.localeCompare(b.startDate);
    });

    // Sort invoices by file start date desc
    invoices.sort((a, b) =>
      b.file.startDate.localeCompare(a.file.startDate),
    );

    return { vouchers, invoices };
  },
});
