import { query } from "./_generated/server";
import { requireIdentity } from "./lib/auth.ts";

/**
 * Single query powering the dashboard page.
 * Scans a bounded set of upcoming group files + their finance lines.
 */
export const stats = query({
  args: {},
  handler: async (ctx): Promise<{
    activeCount: number;
    upcomingPax: number;
    pipelineRevenueEur: number;
    confirmedRevenueEur: number;
    marginPct: number | null;
    byStatus: Record<string, number>;
    departuresThisMonth: number;
    openEnquiries: number;
    openEnquiryFiles: Array<{
      _id: string;
      title: string;
      reference: string;
      clientName: string;
      status: string;
    }>;
    overdueTasks: number;
    overduePayments: number;
    nextDepartures: Array<{
      _id: string;
      title: string;
      reference: string;
      clientName: string;
      destination: string;
      status: string;
      pax: number;
      startDate: string;
      endDate: string;
      ownerName: string | null;
    }>;
    recentFiles: Array<{
      _id: string;
      _creationTime: number;
      title: string;
      reference: string;
      destination: string;
      status: string;
      ownerName: string | null;
    }>;
  }> => {
    await requireIdentity(ctx);

    const now = new Date();
    const nowIso = now.toISOString();

    // 14-day window for departures
    const in14Days = new Date(now);
    in14Days.setDate(in14Days.getDate() + 14);
    const in14DaysIso = in14Days.toISOString();

    // Month boundaries for "this month" count
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999).toISOString();

    // All upcoming (non-past) active files — bounded at 200
    const upcoming = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date", (q) => q.gte("startDate", nowIso))
      .take(200);

    const active = upcoming.filter(
      (f) => f.status !== "cancelled" && f.status !== "closed",
    );

    // Status breakdown counts
    const byStatus: Record<string, number> = {};
    for (const f of active) {
      byStatus[f.status] = (byStatus[f.status] ?? 0) + 1;
    }

    // Departures this month
    const departuresThisMonth = upcoming.filter(
      (f) => f.status !== "cancelled" && f.startDate >= monthStart && f.startDate <= monthEnd,
    ).length;

    // Open enquiries
    const openEnquiryFilesRaw = active.filter((f) => f.status === "enquiry");
    const openEnquiries = openEnquiryFilesRaw.length;

    // Next 8 departures within 14 days (sorted asc — index already returns asc)
    const nextDepartures = active
      .filter((f) => f.startDate <= in14DaysIso)
      .slice(0, 8);

    // Fetch owner names for upcoming departures
    const ownerIds = [...new Set(nextDepartures.map((f) => f.ownerId))];
    const owners: Record<string, string> = {};
    await Promise.all(
      ownerIds.map(async (id) => {
        const user = await ctx.db.get("users", id);
        if (user) owners[id] = user.name ?? user.email ?? "Unknown";
      }),
    );

    // Revenue: collect income lines for active files, capped at 50 files to keep reads bounded
    const filesForRevenue = active.slice(0, 50);
    let pipelineRevenueEur = 0;
    let confirmedRevenueEur = 0;
    let totalCostEur = 0;
    let totalIncomeEur = 0;

    await Promise.all(
      filesForRevenue.map(async (file) => {
        const lines = await ctx.db
          .query("financeLines")
          .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
          .collect();

        const fileIncome = lines
          .filter((l) => l.kind === "income")
          .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);
        const fileCost = lines
          .filter((l) => l.kind === "cost")
          .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);

        pipelineRevenueEur += fileIncome;
        totalCostEur += fileCost;
        totalIncomeEur += fileIncome;

        if (file.status === "confirmed" || file.status === "operating") {
          confirmedRevenueEur += fileIncome;
        }
      }),
    );

    const grossMarginEur = totalIncomeEur - totalCostEur;
    const marginPct =
      totalIncomeEur > 0
        ? Math.round((grossMarginEur / totalIncomeEur) * 100)
        : null;

    // Overdue tasks — open/in_progress with dueDate in the past
    const openTasks = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "open"))
      .take(200);
    const inProgressTasks = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "in_progress"))
      .take(200);
    const overdueTasks = [...openTasks, ...inProgressTasks].filter(
      (t) => t.dueDate && t.dueDate < nowIso,
    ).length;

    // Overdue payments — unpaid finance lines whose payment due date has
    // passed, scanned across the same bounded set of files used for revenue.
    let overduePayments = 0;
    await Promise.all(
      filesForRevenue.map(async (file) => {
        const lines = await ctx.db
          .query("financeLines")
          .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
          .collect();
        overduePayments += lines.filter(
          (l) =>
            l.paidAt === undefined &&
            l.paymentDueDate !== undefined &&
            l.paymentDueDate < nowIso,
        ).length;
      }),
    );

    // Recent files — last 5 by creation time
    const recentRaw = await ctx.db
      .query("groupFiles")
      .order("desc")
      .take(5);

    const recentWithOwners = await Promise.all(
      recentRaw.map(async (f) => {
        const owner = await ctx.db.get("users", f.ownerId);
        return {
          _id: f._id,
          _creationTime: f._creationTime,
          title: f.title,
          reference: f.reference,
          destination: f.destination,
          status: f.status,
          ownerName: owner?.name ?? owner?.email ?? null,
        };
      }),
    );

    return {
      // Stat cards
      activeCount: active.length,
      upcomingPax: active.reduce((s, f) => s + f.pax, 0),
      pipelineRevenueEur: Math.round(pipelineRevenueEur),
      confirmedRevenueEur: Math.round(confirmedRevenueEur),
      marginPct,
      byStatus,
      departuresThisMonth,
      openEnquiries,
      openEnquiryFiles: openEnquiryFilesRaw.slice(0, 20).map((f) => ({
        _id: f._id,
        title: f.title,
        reference: f.reference,
        clientName: f.clientName,
        status: f.status,
      })),
      overdueTasks,
      overduePayments,

      // Upcoming departures (next 8 within 14 days)
      nextDepartures: nextDepartures.map((f) => ({
        _id: f._id,
        title: f.title,
        reference: f.reference,
        clientName: f.clientName,
        destination: f.destination,
        status: f.status,
        pax: f.pax,
        startDate: f.startDate,
        endDate: f.endDate,
        ownerName: owners[f.ownerId] ?? null,
      })),

      // Recent files
      recentFiles: recentWithOwners,
    };
  },
});
