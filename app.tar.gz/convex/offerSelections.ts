import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireIdentity, requireUser } from "./lib/auth.ts";
import { logActivity } from "./activityLog.ts";
import { broadcastNotification } from "./notifications.ts";
import { offerSelectionStatusValidator } from "./schema/offerSelections.ts";
import { acceptOfferIfPending } from "./offers.ts";

/** Public — the offer page reads all still-open (pending) offers for a file. */
export const listOffersPublic = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"offers">[]> => {
    return await ctx.db
      .query("offers")
      .withIndex("by_group_file_and_status", (q) =>
        q.eq("groupFileId", args.groupFileId).eq("status", "pending"),
      )
      .collect();
  },
});

/** Public — the client submits their selection of offers with adjusted units. */
export const submitPublic = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    items: v.array(
      v.object({
        offerId: v.id("offers"),
        requestedUnits: v.number(),
      }),
    ),
    clientNote: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{ id: Id<"offerSelections"> }> => {
    const file = await ctx.db.get("groupFiles", args.groupFileId);
    if (!file) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Booking not found." });
    }
    if (args.items.length === 0) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "Select at least one option before submitting.",
      });
    }

    // Validate every selected offer actually belongs to this file and is
    // still pending — offers may have been accepted/rejected/removed since
    // the client loaded the page.
    for (const item of args.items) {
      if (!Number.isInteger(item.requestedUnits) || item.requestedUnits < 1) {
        throw new ConvexError({
          code: "BAD_REQUEST",
          message: "Enter a valid quantity for each selected option.",
        });
      }
      const offer = await ctx.db.get("offers", item.offerId);
      if (!offer || offer.groupFileId !== args.groupFileId || offer.status !== "pending") {
        throw new ConvexError({
          code: "CONFLICT",
          message:
            "One of the selected options is no longer available. Please refresh and try again.",
        });
      }
    }

    const id = await ctx.db.insert("offerSelections", {
      groupFileId: args.groupFileId,
      status: "new",
      items: args.items,
      clientNote: args.clientNote?.trim() || undefined,
      createdAt: new Date().toISOString(),
    });

    const owner =
      (await ctx.db.get("users", file.ownerId)) ??
      (await ctx.db.get("users", file.createdById));
    if (owner) {
      await logActivity(ctx, {
        groupFileId: args.groupFileId,
        action: "offer_selection_submitted",
        description: `${file.clientName} submitted their offer selection (${args.items.length} item${args.items.length > 1 ? "s" : ""})`,
        user: owner,
      });
    }

    await broadcastNotification(ctx, {
      type: "offer_selection_submitted",
      title: "Client selected offers",
      body: `${file.clientName} chose ${args.items.length} option${args.items.length > 1 ? "s" : ""} for ${file.reference}. Review and book from the Offers tab.`,
      linkTo: `/files/${args.groupFileId}?tab=offers`,
      relatedId: `offer_selection:${id}`,
    });

    return { id };
  },
});

/** Staff — list submissions for a file, most recent first. */
export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"offerSelections">[]> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("offerSelections")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("desc")
      .collect();
  },
});

/**
 * Staff — mark a submission as reviewed after acting on it. Marking as
 * reviewed automatically accepts every offer the client picked (booking it
 * as a reservation and generating cost/income lines), so both the Offers
 * and Reservations tabs reflect the client's choice immediately.
 */
export const markReviewed = mutation({
  args: { id: v.id("offerSelections"), status: offerSelectionStatusValidator },
  handler: async (ctx, args): Promise<null> => {
    const user = await requireUser(ctx);
    const selection = await ctx.db.get("offerSelections", args.id);
    if (!selection) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Selection not found." });
    }
    await ctx.db.patch("offerSelections", args.id, {
      status: args.status,
      reviewedAt: args.status === "reviewed" ? new Date().toISOString() : undefined,
    });

    if (args.status === "reviewed") {
      for (const item of selection.items) {
        await acceptOfferIfPending(ctx, item.offerId, user);
      }
    }

    return null;
  },
});
