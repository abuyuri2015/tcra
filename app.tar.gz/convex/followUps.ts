import { v } from "convex/values";
import { query, mutation, internalMutation } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import { requireGroupFile, requireIdentity, requireUser } from "./lib/auth.ts";
import { createNotification } from "./notifications.ts";

/**
 * Days of silence before an outstanding offer or hotel-modification request
 * is flagged as "needs follow-up" — matches the stale-pipeline threshold
 * used elsewhere in the app for consistency.
 */
export const FOLLOWUP_THRESHOLD_DAYS = 7;

function isOlderThanThreshold(iso: string, now: number): boolean {
  return now - new Date(iso).getTime() > FOLLOWUP_THRESHOLD_DAYS * 24 * 60 * 60 * 1000;
}

export type PendingOfferFollowUp = Doc<"groupFiles"> & { ownerName: string | null };
export type PendingModificationFollowUp = Doc<"modificationRequests"> & {
  fileReference: string;
  fileTitle: string;
};

/**
 * Shared scan for both the live dashboard query and the daily notification
 * cron. Bounded to active (non-cancelled/closed) files and pending
 * modification requests — small-team app scale.
 */
async function findPendingFollowUps(
  ctx: QueryCtx | MutationCtx,
  now: number,
): Promise<{
  offerFollowUps: PendingOfferFollowUp[];
  modFollowUps: PendingModificationFollowUp[];
}> {
  const activeStatuses: Array<Doc<"groupFiles">["status"]> = [
    "enquiry",
    "quoted",
    "confirmed",
    "operating",
  ];
  const candidateFiles: Doc<"groupFiles">[] = [];
  for (const status of activeStatuses) {
    const files = await ctx.db
      .query("groupFiles")
      .withIndex("by_status", (q) => q.eq("status", status))
      .take(200);
    candidateFiles.push(...files);
  }

  const offerFollowUps: PendingOfferFollowUp[] = [];
  for (const file of candidateFiles) {
    if (!file.lastOfferLinkSentAt || file.offerFollowUpDismissedAt) continue;
    if (!isOlderThanThreshold(file.lastOfferLinkSentAt, now)) continue;

    // Skip if the client already responded after the last send.
    const latestSelection = await ctx.db
      .query("offerSelections")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
      .order("desc")
      .first();
    if (latestSelection && latestSelection.createdAt > file.lastOfferLinkSentAt) continue;

    const owner = await ctx.db.get("users", file.ownerId);
    offerFollowUps.push({ ...file, ownerName: owner?.name ?? owner?.email ?? null });
  }

  const pendingRequests = await ctx.db
    .query("modificationRequests")
    .withIndex("by_status", (q) => q.eq("status", "pending_hotel"))
    .take(200);

  const modFollowUps: PendingModificationFollowUp[] = [];
  for (const request of pendingRequests) {
    if (!request.hotelEmailSentAt || request.followUpDismissedAt) continue;
    if (!isOlderThanThreshold(request.hotelEmailSentAt, now)) continue;
    const file = await ctx.db.get("groupFiles", request.groupFileId);
    if (!file) continue;
    modFollowUps.push({ ...request, fileReference: file.reference, fileTitle: file.title });
  }

  return { offerFollowUps, modFollowUps };
}

// ── Query: staff-visible "needs follow-up" list (Dashboard panel) ───────────

export const listPending = query({
  args: {},
  handler: async (
    ctx,
  ): Promise<{
    offers: PendingOfferFollowUp[];
    modifications: PendingModificationFollowUp[];
  }> => {
    await requireIdentity(ctx);
    const { offerFollowUps, modFollowUps } = await findPendingFollowUps(ctx, Date.now());
    return { offers: offerFollowUps, modifications: modFollowUps };
  },
});

// ── Mutation: dismiss/snooze an offer follow-up ──────────────────────────────

export const dismissOfferFollowUp = mutation({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<null> => {
    await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    await ctx.db.patch("groupFiles", args.groupFileId, {
      offerFollowUpDismissedAt: new Date().toISOString(),
    });
    return null;
  },
});

// ── Scheduled task: bell notifications for pending follow-ups ───────────────

/**
 * Internal mutation called by a daily cron. Broadcasts one bell notification
 * per flagged offer/modification-request per day, deduped via `relatedId`
 * keyed by the day and entity id (mirrors generateDailyDigest's pattern).
 */
export const generateFollowUpNotifications = internalMutation({
  args: {},
  handler: async (ctx): Promise<void> => {
    const now = Date.now();
    const today = new Date(now).toISOString().slice(0, 10); // YYYY-MM-DD
    const { offerFollowUps, modFollowUps } = await findPendingFollowUps(ctx, now);

    const users = await ctx.db.query("users").take(50);

    for (const file of offerFollowUps) {
      const relatedId = `followup:offer:${file._id}:${today}`;
      await notifyIfNotAlreadySent(ctx, users, relatedId, {
        title: "Offer awaiting client response",
        body: `${file.clientName} hasn't responded to the offer for ${file.reference} in over ${FOLLOWUP_THRESHOLD_DAYS} days. Consider a follow-up.`,
        linkTo: `/files/${file._id}?tab=offers`,
      });
    }

    for (const request of modFollowUps) {
      const relatedId = `followup:modreq:${request._id}:${today}`;
      await notifyIfNotAlreadySent(ctx, users, relatedId, {
        title: "Hotel hasn't responded to a change request",
        body: `${request.supplierName} hasn't responded to the change request for ${request.fileReference} in over ${FOLLOWUP_THRESHOLD_DAYS} days.`,
        linkTo: `/files/${request.groupFileId}`,
      });
    }
  },
});

async function notifyIfNotAlreadySent(
  ctx: MutationCtx,
  users: Doc<"users">[],
  relatedId: string,
  content: { title: string; body: string; linkTo: string },
): Promise<void> {
  for (const user of users) {
    const existing = await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .take(100);
    const alreadySent = existing.some((n) => n.relatedId === relatedId);
    if (alreadySent) continue;

    await createNotification(ctx, {
      userId: user._id,
      type: "pending_response_followup",
      title: content.title,
      body: content.body,
      linkTo: content.linkTo,
      relatedId,
    });
  }
}

