import { defineTable } from "convex/server";
import { v } from "convex/values";

/** Documents and files attached to a group file (contracts, briefs, visa letters, etc.) */
export const groupFileAttachments = defineTable({
  groupFileId: v.id("groupFiles"),
  storageId: v.id("_storage"),
  filename: v.string(),       // original filename, stored separately (Convex doesn't keep it)
  contentType: v.string(),
  size: v.number(),           // bytes
  uploadedById: v.id("users"),
})
  .index("by_group_file", ["groupFileId"]);
