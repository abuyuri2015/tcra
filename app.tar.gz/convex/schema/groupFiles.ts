import { defineTable } from "convex/server";
import { v } from "convex/values";

export const CURRENCIES = [
  "EUR",
  "USD",
  "GBP",
  "CHF",
  "AED",
  "SEK",
  "NOK",
  "DKK",
] as const;

export const currencyValidator = v.union(
  v.literal("EUR"),
  v.literal("USD"),
  v.literal("GBP"),
  v.literal("CHF"),
  v.literal("AED"),
  v.literal("SEK"),
  v.literal("NOK"),
  v.literal("DKK"),
);

export const GROUP_FILE_STATUSES = [
  "enquiry",
  "quoted",
  "confirmed",
  "operating",
  "closed",
  "cancelled",
] as const;

export const groupFileStatusValidator = v.union(
  v.literal("enquiry"),
  v.literal("quoted"),
  v.literal("confirmed"),
  v.literal("operating"),
  v.literal("closed"),
  v.literal("cancelled"),
);

export const GROUP_FILE_TYPES = [
  "group",
  "meeting",
  "incentive",
  "conference",
  "event",
] as const;

export const groupFileTypeValidator = v.union(
  v.literal("group"),
  v.literal("meeting"),
  v.literal("incentive"),
  v.literal("conference"),
  v.literal("event"),
);

export const groupFiles = defineTable({
  // Human readable sequential reference, e.g. "GM-2026-0001"
  reference: v.string(),
  title: v.string(),
  fileType: groupFileTypeValidator,
  status: groupFileStatusValidator,

  clientName: v.string(),
  clientContactName: v.optional(v.string()),
  clientContactEmail: v.optional(v.string()),
  clientContactPhone: v.optional(v.string()),

  destination: v.string(),
  // ISO 8601 date-time strings in UTC
  startDate: v.string(),
  endDate: v.string(),

  pax: v.number(),
  currency: currencyValidator,
  // Rate to convert the file currency into the agency base currency (EUR)
  exchangeRateToBase: v.number(),
  // Default markup % applied on top of reservation costs for this group request
  // (e.g. 20 = sell at cost + 20%). Used to suggest sell rates on reservations.
  markupPercent: v.optional(v.number()),

  notes: v.optional(v.string()),
  ownerId: v.id("users"),
  createdById: v.id("users"),

  // ISO 8601 timestamp — set the first time a client confirmation email is
  // auto-sent for this file, so we only ever send it once.
  confirmationSentAt: v.optional(v.string()),

  // Set by finance once the file is closed for full payment in/out. Once
  // locked, existing reservations can no longer be edited, deleted, or have
  // their status changed — only new items (or credit-note finance lines) can
  // be added. Independent of `status` so finance can lock/unlock at will.
  financeLocked: v.optional(v.boolean()),
  financeLockedAt: v.optional(v.string()),

  // Set when staff dismiss the "offer awaiting client response" follow-up
  // flag for this file without resending. Silenced until a fresh offer
  // email is sent (logged after this timestamp) or the client responds.
  offerFollowUpDismissedAt: v.optional(v.string()),

  // ISO 8601 timestamp of the most recent time staff sent/resent the offer
  // link to the client. Drives the "pending response" follow-up flag —
  // updated every send/resend, so the flag always measures from the latest
  // outreach, not the first.
  lastOfferLinkSentAt: v.optional(v.string()),
})
  .index("by_reference", ["reference"])
  .index("by_status", ["status"])
  .index("by_start_date", ["startDate"])
  .index("by_owner", ["ownerId"])
  .searchIndex("search_title", { searchField: "title" })
  .searchIndex("search_client", { searchField: "clientName" })
  .searchIndex("search_destination", { searchField: "destination" });
