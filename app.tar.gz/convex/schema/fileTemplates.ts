import { defineTable } from "convex/server";
import { v } from "convex/values";
import { groupFileTypeValidator, currencyValidator } from "./groupFiles.ts";
import { itineraryItemTypeValidator } from "./itinerary.ts";

/** Snapshot of an itinerary item within a template day. */
const templateItineraryItem = v.object({
  sortOrder: v.number(),
  type: itineraryItemTypeValidator,
  time: v.optional(v.string()),
  title: v.string(),
  description: v.optional(v.string()),
  location: v.optional(v.string()),
  notes: v.optional(v.string()),
});

/** Snapshot of a single itinerary day. */
const templateItineraryDay = v.object({
  dayNumber: v.number(),
  title: v.optional(v.string()),
  notes: v.optional(v.string()),
  items: v.array(templateItineraryItem),
});

/** Snapshot of a finance line category preset. */
const templateFinanceLine = v.object({
  kind: v.union(v.literal("cost"), v.literal("income")),
  category: v.string(),
  description: v.string(),
  notes: v.optional(v.string()),
});

export const fileTemplates = defineTable({
  name: v.string(),
  description: v.optional(v.string()),

  // Pre-fill defaults for the new file form
  fileType: groupFileTypeValidator,
  destination: v.optional(v.string()),
  pax: v.optional(v.number()),
  currency: currencyValidator,
  notes: v.optional(v.string()),

  // Embedded snapshots (no foreign keys — templates are self-contained)
  itineraryDays: v.array(templateItineraryDay),
  financeLines: v.array(templateFinanceLine),

  createdById: v.id("users"),
}).searchIndex("search_name", { searchField: "name" });
