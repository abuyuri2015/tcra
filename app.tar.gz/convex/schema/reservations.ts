import { defineTable } from "convex/server";
import { v } from "convex/values";
import { currencyValidator } from "./groupFiles.ts";
import { hotelBoardValidator } from "./hotels.ts";

/**
 * A reservation is one bookable service attached to a group file.
 * Types:
 *  - hotel:     hotel rooms for one or more nights
 *  - transfer:  coach / vehicle movement
 *  - restaurant: group dinner / lunch
 *  - activity:  excursion, team-building, etc.
 *  - venue:     meeting room / conference hall
 *  - flight:    air ticket block
 *  - other:     anything that doesn't fit above
 */
export const RESERVATION_TYPES = [
  "hotel",
  "transfer",
  "restaurant",
  "activity",
  "venue",
  "flight",
  "other",
] as const;

export const reservationTypeValidator = v.union(
  v.literal("hotel"),
  v.literal("transfer"),
  v.literal("restaurant"),
  v.literal("activity"),
  v.literal("venue"),
  v.literal("flight"),
  v.literal("other"),
);

export const RESERVATION_STATUSES = [
  "option",
  "requested",
  "confirmed",
  "cancelled",
] as const;

export const reservationStatusValidator = v.union(
  v.literal("option"),
  v.literal("requested"),
  v.literal("confirmed"),
  v.literal("cancelled"),
);

export const reservations = defineTable({
  groupFileId: v.id("groupFiles"),

  type: reservationTypeValidator,
  status: reservationStatusValidator,

  // Free-text supplier / venue name (always set, even when linked to a hotel)
  supplierName: v.string(),
  // Optional link to a hotel in the hotel database
  hotelId: v.optional(v.id("hotels")),

  // Service description (room type, transfer route, activity name …)
  description: v.string(),

  // Date range of the service (ISO UTC strings)
  startDate: v.string(),
  endDate: v.optional(v.string()),

  // Quantity: number of units (rooms, seats, pax …)
  units: v.number(),
  unitLabel: v.optional(v.string()), // e.g. "rooms", "pax", "seats"

  // Hotel-specific: board basis and number of nights
  board: v.optional(hotelBoardValidator),
  nights: v.optional(v.number()),

  // Confirmation reference from the supplier
  supplierRef: v.optional(v.string()),

  // Rate per unit in the file currency
  ratePerUnit: v.optional(v.number()),
  // Cost per unit (what the agency pays the supplier) — used to suggest a sell
  // rate via the group file's markup %.
  costPerUnit: v.optional(v.number()),
  currency: currencyValidator,

  notes: v.optional(v.string()),
  createdById: v.id("users"),

  // Transfer / activity (excursion) operational details — pickup logistics,
  // linked flight, and the assigned guide, so staff can confirm the service
  // with everything the guide and passengers need on the day.
  pickupLocation: v.optional(v.string()),
  pickupTime: v.optional(v.string()), // free text, e.g. "09:00"
  flightDetails: v.optional(v.string()), // e.g. "BA476 arriving 14:20"
  guideName: v.optional(v.string()),
  guidePhone: v.optional(v.string()),

  // Passenger manifest for this transfer/activity: every group passenger
  // rides/attends by default. IDs listed here are explicitly excluded.
  excludedPassengerIds: v.optional(v.array(v.id("passengers"))),
})
  .index("by_group_file", ["groupFileId"])
  .index("by_group_file_and_type", ["groupFileId", "type"])
  .index("by_group_file_and_start", ["groupFileId", "startDate"])
  .searchIndex("search_supplier", { searchField: "supplierName" })
  .searchIndex("search_description", { searchField: "description" });
