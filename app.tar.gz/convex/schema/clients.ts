import { defineTable } from "convex/server";
import { v } from "convex/values";

export const CLIENT_KINDS = ["individual", "company"] as const;

export const clientKindValidator = v.union(
  v.literal("individual"),
  v.literal("company"),
);

export const clients = defineTable({
  kind: clientKindValidator,
  name: v.string(),
  // Only meaningful for individuals — the company they belong to, if any.
  parentClientId: v.optional(v.id("clients")),
  contactName: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  address: v.optional(v.string()),
  city: v.optional(v.string()),
  country: v.optional(v.string()),
  taxId: v.optional(v.string()),
  notes: v.optional(v.string()),
  createdById: v.id("users"),
})
  .index("by_kind", ["kind"])
  .index("by_parent", ["parentClientId"])
  .searchIndex("search_name", { searchField: "name" });
