import { defineTable } from "convex/server";
import { v } from "convex/values";

export const TASK_STATUSES = ["open", "in_progress", "done"] as const;

export const taskStatusValidator = v.union(
  v.literal("open"),
  v.literal("in_progress"),
  v.literal("done"),
);

export const tasks = defineTable({
  groupFileId: v.id("groupFiles"),
  title: v.string(),
  dueDate: v.optional(v.string()),   // ISO 8601 UTC string
  assignee: v.optional(v.string()),  // free text
  status: taskStatusValidator,
  notes: v.optional(v.string()),
  createdById: v.id("users"),
})
  .index("by_group_file", ["groupFileId"])
  .index("by_status", ["status"])
  .index("by_group_file_and_status", ["groupFileId", "status"]);
