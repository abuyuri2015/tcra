import { defineTable } from "convex/server";
import { v } from "convex/values";

// Tracks every email sent from within a group file
export const emailLogs = defineTable({
  groupFileId: v.id("groupFiles"),
  sentAt: v.string(), // ISO 8601
  to: v.string(),
  subject: v.string(),
  emailType: v.union(
    v.literal("voucher"),
    v.literal("invoice"),
    v.literal("itinerary"),
    v.literal("quote"),
    v.literal("confirmation"),
    v.literal("hotel_modification_request"),
    v.literal("offer"),
    v.literal("other"),
  ),
  // Optional reference (reservation _id for vouchers, etc.)
  refId: v.optional(v.string()),
  refLabel: v.optional(v.string()), // human-readable, e.g. supplier name
  // Hercules email API response id
  herculesEmailId: v.optional(v.string()),
  senderAddress: v.string(),
}).index("by_file", ["groupFileId"]);
