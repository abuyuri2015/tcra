import { defineTable } from "convex/server";
import { v } from "convex/values";

export const ROOM_TYPES = [
  "single",
  "double",
  "twin",
  "triple",
  "suite",
] as const;

export const roomTypeValidator = v.union(
  v.literal("single"),
  v.literal("double"),
  v.literal("twin"),
  v.literal("triple"),
  v.literal("suite"),
);

export const passengers = defineTable({
  groupFileId: v.id("groupFiles"),
  firstName: v.string(),
  lastName: v.string(),
  roomType: roomTypeValidator,
  // Free-text name of the passenger they share a room with
  sharingWith: v.optional(v.string()),
  dietaryRequirements: v.optional(v.string()),
  notes: v.optional(v.string()),
  createdById: v.id("users"),
})
  .index("by_group_file", ["groupFileId"])
  .searchIndex("search_last_name", { searchField: "lastName" })
  .searchIndex("search_first_name", { searchField: "firstName" });
