import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * Tracks key changes to group files as a timeline for accountability.
 * Each entry is a single event (status change, edit, reservation added, etc.).
 */
export const activityLog = defineTable({
  groupFileId: v.id("groupFiles"),
  action: v.union(
    v.literal("created"),
    v.literal("updated"),
    v.literal("status_changed"),
    v.literal("duplicated"),
    v.literal("reservation_added"),
    v.literal("reservation_updated"),
    v.literal("reservation_removed"),
    v.literal("offer_added"),
    v.literal("offer_updated"),
    v.literal("offer_removed"),
    v.literal("offer_accepted"),
    v.literal("offer_converted"),
    v.literal("finance_line_added"),
    v.literal("finance_line_removed"),
    v.literal("finance_line_paid"),
    v.literal("finance_line_unpaid"),
    v.literal("task_added"),
    v.literal("task_completed"),
    v.literal("task_reopened"),
    v.literal("passenger_added"),
    v.literal("passenger_removed"),
    v.literal("attachment_added"),
    v.literal("attachment_removed"),
    v.literal("email_sent"),
    v.literal("modification_requested"),
    v.literal("modification_approved"),
    v.literal("modification_declined"),
    v.literal("offer_link_sent"),
    v.literal("offer_selection_submitted"),
  ),
  /** Human-readable description, e.g. "Status changed from Enquiry to Confirmed" */
  description: v.string(),
  /** The user who performed the action */
  userId: v.id("users"),
  userName: v.string(),
  /** ISO 8601 timestamp */
  timestamp: v.string(),
}).index("by_group_file", ["groupFileId"]);
