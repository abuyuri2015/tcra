import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * How a payment schedule item becomes due:
 *  - on_confirmation: due as soon as the file is confirmed (e.g. a deposit)
 *  - days_before_departure: due N days before the file's start date
 */
export const paymentScheduleTriggerValidator = v.union(
  v.literal("on_confirmation"),
  v.literal("days_before_departure"),
);

export const paymentScheduleItemValidator = v.object({
  // Stable client-generated id so items can be reordered/edited without
  // relying on array index.
  id: v.string(),
  label: v.string(),
  // % of `totalValueEur` this item represents. Staff-editable; percentages
  // are not enforced to sum to 100 so credit notes/discounts stay possible.
  percent: v.number(),
  triggerType: paymentScheduleTriggerValidator,
  // Only used when triggerType === "days_before_departure"
  triggerDays: v.optional(v.number()),
  // Set once an invoice/income line has been generated for this item.
  financeLineId: v.optional(v.id("financeLines")),
  invoiceNumber: v.optional(v.string()),
  invoicedAt: v.optional(v.string()),
});

/**
 * One payment schedule per group file — a small, staff-editable set of
 * installments (deposit, pre-departure payments, final balance) used to
 * generate income finance lines + invoices on demand. Bounded to a handful
 * of items, so storing them as an array on a single document is safe.
 */
export const paymentSchedules = defineTable({
  groupFileId: v.id("groupFiles"),
  // Snapshot of the total package value (EUR) percentages are calculated
  // against. Editable by staff if the deal size changes.
  totalValueEur: v.number(),
  items: v.array(paymentScheduleItemValidator),
  createdById: v.id("users"),
}).index("by_group_file", ["groupFileId"]);
