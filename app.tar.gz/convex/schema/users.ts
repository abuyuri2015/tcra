import { defineTable } from "convex/server";
import { v } from "convex/values";

export const users = defineTable({
  tokenIdentifier: v.string(),
  name: v.optional(v.string()),
  email: v.optional(v.string()),
}).index("by_token", ["tokenIdentifier"]);
