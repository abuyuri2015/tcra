import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * Supplier categories mirror the reservation service types so they can be
 * cross-filtered in the reservation form picker.
 */
export const SUPPLIER_CATEGORIES = [
  "hotel",
  "transfer",
  "restaurant",
  "activity",
  "venue",
  "flight",
  "other",
] as const;

export const supplierCategoryValidator = v.union(
  v.literal("hotel"),
  v.literal("transfer"),
  v.literal("restaurant"),
  v.literal("activity"),
  v.literal("venue"),
  v.literal("flight"),
  v.literal("other"),
);

export const suppliers = defineTable({
  name: v.string(),
  category: supplierCategoryValidator,
  country: v.optional(v.string()),
  city: v.optional(v.string()),
  contactPerson: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  notes: v.optional(v.string()),
  createdById: v.id("users"),
})
  .index("by_category", ["category"])
  .searchIndex("search_name", { searchField: "name" })
  .searchIndex("search_city", { searchField: "city" });
