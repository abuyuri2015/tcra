import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * A client-submitted selection of offers from the public "/offer/:fileId"
 * page. One row per submission (a client can submit again later if new
 * offers were added — each submission is kept for history, staff review the
 * latest one). Never auto-books: staff always convert the chosen offers into
 * reservations manually from the Offers tab.
 */
export const offerSelectionStatuses = ["new", "reviewed"] as const;

export const offerSelectionStatusValidator = v.union(
  v.literal("new"),
  v.literal("reviewed"),
);

export const offerSelections = defineTable({
  groupFileId: v.id("groupFiles"),
  status: offerSelectionStatusValidator,

  // Snapshot of what the client picked — one entry per selected offer, with
  // the units they requested (may differ from the offered quantity, e.g.
  // fewer rooms). Offer details are looked up live via offerId so staff
  // always see the current offer, not a stale copy.
  items: v.array(
    v.object({
      offerId: v.id("offers"),
      requestedUnits: v.number(),
    }),
  ),

  clientNote: v.optional(v.string()),

  createdAt: v.string(), // ISO 8601
  reviewedAt: v.optional(v.string()),
})
  .index("by_group_file", ["groupFileId"])
  .index("by_group_file_and_status", ["groupFileId", "status"]);
