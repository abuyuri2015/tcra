import { defineTable } from "convex/server";
import { v } from "convex/values";

export const financeLines = defineTable({
  groupFileId: v.id("groupFiles"),
  kind: v.union(v.literal("cost"), v.literal("income")),
  category: v.string(),
  description: v.string(),
  supplierName: v.optional(v.string()),
  amount: v.number(),
  currency: v.string(),
  /** Rate used to convert `amount` to base (EUR): amount * exchangeRateToBase = EUR value */
  exchangeRateToBase: v.number(),
  // Optional itemized breakdown so clients can see how `amount` was calculated,
  // e.g. "€120 × 25 rooms = €3,000". When set, unitRate * quantity == amount.
  unitRate: v.optional(v.number()),
  quantity: v.optional(v.number()),
  quantityLabel: v.optional(v.string()),
  notes: v.optional(v.string()),
  createdById: v.id("users"),
  // Payment tracking: for income lines this is when the client paid; for cost
  // lines this is when the agency paid the supplier/hotel. Undefined = unpaid.
  paidAt: v.optional(v.string()),
  // When this payment is due. Used to flag overdue payments (unpaid + past
  // this date) on the dashboard and via notifications.
  paymentDueDate: v.optional(v.string()),
})
  .index("by_group_file", ["groupFileId"])
  .index("by_group_file_and_kind", ["groupFileId", "kind"]);
