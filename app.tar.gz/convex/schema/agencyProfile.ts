import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * Agency-wide profile used in PDF branding, invoices, and email signatures.
 * Singleton — only one row should exist (no user-specific data).
 */
export const agencyProfile = defineTable({
  agencyName: v.string(),
  address: v.optional(v.string()),
  phone: v.optional(v.string()),
  email: v.optional(v.string()),
  website: v.optional(v.string()),
  logoUrl: v.optional(v.string()),
  // Bank details (for invoices)
  bankName: v.optional(v.string()),
  iban: v.optional(v.string()),
  bic: v.optional(v.string()),
  // Default payment terms shown on invoices
  paymentTerms: v.optional(v.string()),
  // Full booking terms & conditions text, attached to deposit/installment
  // invoices generated from a file's payment schedule.
  termsAndConditions: v.optional(v.string()),
  // Tax / VAT ID
  taxId: v.optional(v.string()),
});
