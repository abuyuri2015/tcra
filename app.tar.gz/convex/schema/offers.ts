import { defineTable } from "convex/server";
import { v } from "convex/values";
import { currencyValidator } from "./groupFiles.ts";
import { hotelBoardValidator } from "./hotels.ts";
import { reservationTypeValidator } from "./reservations.ts";

/**
 * An offer is a candidate option for a service on a group file — a hotel
 * quote, a transfer proposal, a restaurant menu price, an excursion price,
 * etc. Several offers can exist per service type so the agent can compare
 * suppliers before choosing one. An accepted offer can be converted into an
 * actual Reservation (booking).
 */
export const OFFER_STATUSES = ["pending", "accepted", "rejected"] as const;

export const offerStatusValidator = v.union(
  v.literal("pending"),
  v.literal("accepted"),
  v.literal("rejected"),
);

export const offers = defineTable({
  groupFileId: v.id("groupFiles"),

  // Reuses the same service categories as reservations (hotel, transfer,
  // restaurant, activity, venue, flight, other) so an offer maps 1:1 onto a
  // reservation once accepted.
  type: reservationTypeValidator,
  status: offerStatusValidator,

  supplierName: v.string(),
  hotelId: v.optional(v.id("hotels")),

  description: v.string(),

  startDate: v.string(),
  endDate: v.optional(v.string()),

  units: v.number(),
  unitLabel: v.optional(v.string()),

  board: v.optional(hotelBoardValidator),
  nights: v.optional(v.number()),

  supplierRef: v.optional(v.string()),

  ratePerUnit: v.optional(v.number()),
  costPerUnit: v.optional(v.number()),
  currency: currencyValidator,

  notes: v.optional(v.string()),

  // Set once this offer has been converted into a booked reservation.
  convertedReservationId: v.optional(v.id("reservations")),

  // Links several room-type offers (single, double, Jr suite, ...) for the
  // same hotel quote together so they display and are sent as one bundled
  // "hotel offer" even though each room type stays its own row for
  // independent accept/reject/convert/select actions. Set to the group's own
  // first offer id (self-referential) — undefined for ungrouped offers.
  offerGroupId: v.optional(v.id("offers")),

  createdById: v.id("users"),
})
  .index("by_group_file", ["groupFileId"])
  .index("by_group_file_and_type", ["groupFileId", "type"])
  .index("by_group_file_and_status", ["groupFileId", "status"])
  .index("by_status", ["status"])
  .index("by_offer_group", ["offerGroupId"]);
