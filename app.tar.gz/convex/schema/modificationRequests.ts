import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * A client-submitted request to change a reservation, submitted from the
 * public confirmation page. If the reservation is linked to a hotel with a
 * contact email, it is auto-emailed to the hotel with an approve/decline
 * link — no staff step required. Otherwise it falls back to a staff
 * notification since there is no automated recipient to route it to.
 */
export const MODIFICATION_REQUEST_STATUSES = [
  "pending_hotel",
  "no_hotel_contact",
  "approved",
  "declined",
] as const;

export const modificationRequestStatusValidator = v.union(
  v.literal("pending_hotel"),
  v.literal("no_hotel_contact"),
  v.literal("approved"),
  v.literal("declined"),
);

/**
 * "units": a structured request to change the booked quantity (rooms,
 * seats, pax…). Auto-applies to the reservation and generates finance lines
 * when approved, since the cost impact can be calculated.
 * "other": a free-text request (dates, room type, anything else). Approving
 * it appends the approved note to the reservation for visibility, but staff
 * must adjust cost/units manually since it can't be parsed automatically.
 */
export const modificationRequestKindValidator = v.union(
  v.literal("units"),
  v.literal("other"),
);

/**
 * Who initiated the request. "client" comes from the public confirmation
 * page; "staff" comes from a signed-in team member editing a confirmed
 * reservation in the back office. Both funnel through the same hotel
 * approve/decline email flow — staff get no shortcut around it.
 * Optional for backward compatibility with rows written before this field
 * existed; treat missing as "client" (the only source before staff requests
 * existed).
 */
export const modificationRequestSubmittedByValidator = v.union(
  v.literal("client"),
  v.literal("staff"),
);

export const modificationRequests = defineTable({
  groupFileId: v.id("groupFiles"),
  reservationId: v.id("reservations"),
  submittedBy: v.optional(modificationRequestSubmittedByValidator),

  // The submitting browser's origin (window.location.origin), captured at
  // request time. Reused later to build the client's updated confirmation
  // link once the hotel approves — the hotel response page has no browser
  // origin of its own to supply one. Optional for rows written before this
  // field existed.
  appOrigin: v.optional(v.string()),

  // Snapshot of reservation details at submit time, shown on the hotel's
  // response page even if the reservation later changes.
  supplierName: v.string(),
  reservationDescription: v.string(),

  // Set once this field existed on every row (kept required for new writes;
  // the one-time backfill of pre-existing rows is complete).
  kind: modificationRequestKindValidator,
  // Only set when kind === "units" — the booked quantity before/after the
  // requested change, used to auto-apply the change and compute the cost
  // impact when the hotel approves.
  previousUnits: v.optional(v.number()),
  requestedUnits: v.optional(v.number()),
  unitLabel: v.optional(v.string()),

  // Free text: required for kind "other", an optional note for kind "units".
  message: v.string(),
  status: modificationRequestStatusValidator,

  hotelId: v.optional(v.id("hotels")),
  hotelContactEmail: v.optional(v.string()),
  hotelEmailSentAt: v.optional(v.string()),

  respondedAt: v.optional(v.string()),
  responseNote: v.optional(v.string()),

  // Set once the approved change has been applied to the reservation and
  // (for kind "units") matching cost/income finance lines were created.
  // Prevents double-application if this mutation is ever retried.
  appliedAt: v.optional(v.string()),
  createdFinanceLineIds: v.optional(
    v.array(v.id("financeLines")),
  ),

  createdAt: v.string(), // ISO 8601

  // Set when staff dismiss the "pending hotel response" follow-up flag for
  // this request without resending — silences it until the request is
  // resent (a fresh hotelEmailSentAt) or responded to.
  followUpDismissedAt: v.optional(v.string()),
})
  .index("by_group_file", ["groupFileId"])
  .index("by_reservation", ["reservationId"])
  .index("by_status", ["status"]);
