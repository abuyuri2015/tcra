import { defineTable } from "convex/server";
import { v } from "convex/values";
import { currencyValidator } from "./groupFiles.ts";

/** Star / quality classification used across the hotel database. */
export const HOTEL_CATEGORIES = [
  "5-star-luxury",
  "5-star",
  "4-star-superior",
  "4-star",
  "3-star",
  "boutique",
  "resort",
  "apartment",
  "venue",
] as const;

export const hotelCategoryValidator = v.union(
  v.literal("5-star-luxury"),
  v.literal("5-star"),
  v.literal("4-star-superior"),
  v.literal("4-star"),
  v.literal("3-star"),
  v.literal("boutique"),
  v.literal("resort"),
  v.literal("apartment"),
  v.literal("venue"),
);

export const HOTEL_STATUSES = ["preferred", "active", "archived"] as const;

export const hotelStatusValidator = v.union(
  v.literal("preferred"),
  v.literal("active"),
  v.literal("archived"),
);

export const hotels = defineTable({
  name: v.string(),
  // Lowercased name used for prefix search on the index
  searchName: v.string(),
  category: hotelCategoryValidator,
  status: hotelStatusValidator,

  city: v.string(),
  country: v.string(),
  address: v.optional(v.string()),
  website: v.optional(v.string()),

  // Sales / reservations contact at the property
  contactName: v.optional(v.string()),
  contactEmail: v.optional(v.string()),
  contactPhone: v.optional(v.string()),

  totalRooms: v.optional(v.number()),
  meetingRooms: v.optional(v.number()),
  largestMeetingCapacity: v.optional(v.number()),

  // Default contracting currency for rates at this property
  currency: currencyValidator,
  // Small, curated list of image URLs shown in the gallery
  imageUrls: v.array(v.string()),
  amenities: v.array(v.string()),
  notes: v.optional(v.string()),

  createdById: v.id("users"),
})
  .index("by_search_name", ["searchName"])
  .index("by_city", ["city"])
  .index("by_status_and_name", ["status", "searchName"])
  .searchIndex("search_name", { searchField: "name" })
  .searchIndex("search_city", { searchField: "city" });

export const HOTEL_BOARD_TYPES = [
  "room-only",
  "breakfast",
  "half-board",
  "full-board",
  "all-inclusive",
] as const;

export const hotelBoardValidator = v.union(
  v.literal("room-only"),
  v.literal("breakfast"),
  v.literal("half-board"),
  v.literal("full-board"),
  v.literal("all-inclusive"),
);

export const hotelRoomTypes = defineTable({
  hotelId: v.id("hotels"),
  name: v.string(),
  // Guests the room sleeps
  occupancy: v.number(),
  board: hotelBoardValidator,
  // Indicative nightly rate in the hotel's currency
  nightlyRate: v.optional(v.number()),
  notes: v.optional(v.string()),
}).index("by_hotel", ["hotelId"]);
