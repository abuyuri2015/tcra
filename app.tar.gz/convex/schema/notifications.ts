import { defineTable } from "convex/server";
import { v } from "convex/values";

export const NOTIFICATION_TYPES = [
  "task_due_today",
  "task_overdue",
  "file_status_changed",
  "task_assigned",
  "modification_requested",
  "modification_responded",
  "offer_selection_submitted",
  "daily_digest",
  "pending_response_followup",
  "payment_overdue",
] as const;

export const notificationTypeValidator = v.union(
  v.literal("task_due_today"),
  v.literal("task_overdue"),
  v.literal("file_status_changed"),
  v.literal("task_assigned"),
  v.literal("modification_requested"),
  v.literal("modification_responded"),
  v.literal("offer_selection_submitted"),
  v.literal("daily_digest"),
  v.literal("pending_response_followup"),
  v.literal("payment_overdue"),
);

export const notifications = defineTable({
  userId: v.id("users"),
  type: notificationTypeValidator,
  title: v.string(),
  body: v.string(),
  /** The route to navigate to when clicked */
  linkTo: v.string(),
  isRead: v.boolean(),
  /** ISO 8601 timestamp */
  timestamp: v.string(),
  /** Optional related entity IDs for dedup */
  relatedId: v.optional(v.string()),
})
  .index("by_user", ["userId"])
  .index("by_user_and_read", ["userId", "isRead"]);
