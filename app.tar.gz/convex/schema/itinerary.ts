import { defineTable } from "convex/server";
import { v } from "convex/values";

export const ITINERARY_ITEM_TYPES = [
  "arrival",
  "departure",
  "transfer",
  "hotel",
  "meal",
  "activity",
  "meeting",
  "flight",
  "free-time",
  "other",
] as const;

export const itineraryItemTypeValidator = v.union(
  v.literal("arrival"),
  v.literal("departure"),
  v.literal("transfer"),
  v.literal("hotel"),
  v.literal("meal"),
  v.literal("activity"),
  v.literal("meeting"),
  v.literal("flight"),
  v.literal("free-time"),
  v.literal("other"),
);

/** One calendar day in the itinerary */
export const itineraryDays = defineTable({
  groupFileId: v.id("groupFiles"),
  date: v.string(), // ISO 8601 UTC string
  dayNumber: v.number(), // 1-based display number
  title: v.optional(v.string()), // e.g. "Arrival & welcome dinner"
  notes: v.optional(v.string()),
})
  .index("by_group_file", ["groupFileId"])
  .index("by_group_file_and_date", ["groupFileId", "date"]);

/** A single event/item within a day */
export const itineraryItems = defineTable({
  dayId: v.id("itineraryDays"),
  groupFileId: v.id("groupFiles"), // denormalised for efficient listing
  sortOrder: v.number(),
  type: itineraryItemTypeValidator,
  time: v.optional(v.string()), // "09:00" free text
  title: v.string(),
  description: v.optional(v.string()),
  location: v.optional(v.string()),
  notes: v.optional(v.string()),
  reservationId: v.optional(v.id("reservations")),
})
  .index("by_day", ["dayId"])
  .index("by_day_and_order", ["dayId", "sortOrder"])
  .index("by_group_file", ["groupFileId"]);
