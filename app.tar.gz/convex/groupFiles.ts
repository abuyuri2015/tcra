import { ConvexError, v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query, internalQuery } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireGroupFile, requireIdentity, requireUser } from "./lib/auth.ts";
import {
  currencyValidator,
  groupFileStatusValidator,
  groupFileTypeValidator,
} from "./schema/groupFiles.ts";
import { broadcastNotification } from "./notifications.ts";
import { logActivity } from "./activityLog.ts";
import { createDefaultScheduleIfMissing } from "./paymentSchedules.ts";

const baseFields = {
  title: v.string(),
  fileType: groupFileTypeValidator,
  status: groupFileStatusValidator,
  clientName: v.string(),
  clientContactName: v.optional(v.string()),
  clientContactEmail: v.optional(v.string()),
  clientContactPhone: v.optional(v.string()),
  destination: v.string(),
  startDate: v.string(),
  endDate: v.string(),
  pax: v.number(),
  currency: currencyValidator,
  exchangeRateToBase: v.number(),
  markupPercent: v.optional(v.number()),
  notes: v.optional(v.string()),
};

function validate(args: { startDate: string; endDate: string; pax: number; markupPercent?: number }) {
  if (new Date(args.endDate) < new Date(args.startDate)) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: "End date cannot be before the start date.",
    });
  }
  if (args.pax < 1) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: "A file must have at least one traveller.",
    });
  }
  if (args.markupPercent !== undefined && args.markupPercent < 0) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: "Markup % cannot be negative.",
    });
  }
}

const STATUS_LABELS: Record<string, string> = {
  enquiry: "Enquiry",
  quoted: "Quoted",
  confirmed: "Confirmed",
  operating: "Operating",
  closed: "Closed",
  cancelled: "Cancelled",
};

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    status: v.optional(groupFileStatusValidator),
  },
  handler: async (ctx, args) => {
    await requireIdentity(ctx);
    const base =
      args.status !== undefined
        ? ctx.db
            .query("groupFiles")
            .withIndex("by_status", (q) => q.eq("status", args.status!))
        : ctx.db.query("groupFiles").withIndex("by_start_date");
    return await base.order("desc").paginate(args.paginationOpts);
  },
});

export const stats = query({
  args: {},
  handler: async (ctx) => {
    await requireIdentity(ctx);
    const upcoming = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date", (q) =>
        q.gte("startDate", new Date().toISOString()),
      )
      .take(200);
    const active = upcoming.filter(
      (f) => f.status !== "cancelled" && f.status !== "closed",
    );
    return {
      upcomingCount: active.length,
      upcomingPax: active.reduce((sum, f) => sum + f.pax, 0),
      confirmedCount: active.filter((f) => f.status === "confirmed").length,
      enquiryCount: active.filter(
        (f) => f.status === "enquiry" || f.status === "quoted",
      ).length,
    };
  },
});

export const get = query({
  args: { id: v.id("groupFiles") },
  handler: async (
    ctx,
    args,
  ): Promise<Doc<"groupFiles"> & { ownerName: string | null }> => {
    await requireIdentity(ctx);
    const file = await requireGroupFile(ctx, args.id);
    const owner = await ctx.db.get("users", file.ownerId);
    return { ...file, ownerName: owner?.name ?? owner?.email ?? null };
  },
});

/** Public query — no auth — used by the shareable client itinerary page. */
export const getPublic = query({
  args: { id: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"groupFiles"> | null> => {
    return await ctx.db.get("groupFiles", args.id);
  },
});

/** Internal — callable only from other Convex functions (e.g. email actions). */
export const getInternal = internalQuery({
  args: { id: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"groupFiles"> | null> => {
    return await ctx.db.get("groupFiles", args.id);
  },
});

export const create = mutation({
  args: baseFields,
  handler: async (ctx, args): Promise<Id<"groupFiles">> => {
    const user = await requireUser(ctx);
    validate(args);

    const year = new Date(args.startDate).getUTCFullYear();
    const prefix = `GM-${year}-`;
    const latest = await ctx.db
      .query("groupFiles")
      .withIndex("by_reference", (q) =>
        q.gte("reference", prefix).lt("reference", `${prefix}9999`),
      )
      .order("desc")
      .first();
    const nextNumber = latest
      ? Number.parseInt(latest.reference.slice(prefix.length), 10) + 1
      : 1;
    const reference = `${prefix}${String(nextNumber).padStart(4, "0")}`;

    const id = await ctx.db.insert("groupFiles", {
      ...args,
      reference,
      ownerId: user._id,
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: id,
      action: "created",
      description: `Created file "${args.title}"`,
      user,
    });

    return id;
  },
});

export const update = mutation({
  args: { id: v.id("groupFiles"), ...baseFields },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const { id, ...fields } = args;
    await requireGroupFile(ctx, id);
    validate(fields);
    await ctx.db.patch("groupFiles", id, fields);

    await logActivity(ctx, {
      groupFileId: id,
      action: "updated",
      description: `Updated file details`,
      user,
    });

    return null;
  },
});

/**
 * Live average margin % across every priced offer and reservation on this
 * file. Each item's margin % is (rate - cost) / rate * 100. Items are first
 * averaged within their service type (hotel, transfer, restaurant, etc.),
 * then those per-type averages are averaged again with equal weight — so a
 * type with many line items doesn't drown out a type with just one.
 * Returns null when nothing on the file has both a rate and a cost yet.
 */
export const averageMarginPercent = query({
  args: { id: v.id("groupFiles") },
  handler: async (ctx, args): Promise<number | null> => {
    await requireIdentity(ctx);

    const [offers, reservations] = await Promise.all([
      ctx.db
        .query("offers")
        .withIndex("by_group_file", (q) => q.eq("groupFileId", args.id))
        .collect(),
      ctx.db
        .query("reservations")
        .withIndex("by_group_file", (q) => q.eq("groupFileId", args.id))
        .collect(),
    ]);

    const marginsByType = new Map<string, number[]>();
    for (const item of [...offers, ...reservations]) {
      if (item.ratePerUnit === undefined || item.costPerUnit === undefined) continue;
      if (item.ratePerUnit <= 0) continue;
      const marginPct =
        ((item.ratePerUnit - item.costPerUnit) / item.ratePerUnit) * 100;
      const existing = marginsByType.get(item.type) ?? [];
      existing.push(marginPct);
      marginsByType.set(item.type, existing);
    }

    if (marginsByType.size === 0) return null;

    const typeAverages = Array.from(marginsByType.values()).map(
      (margins) => margins.reduce((s, m) => s + m, 0) / margins.length,
    );
    return typeAverages.reduce((s, m) => s + m, 0) / typeAverages.length;
  },
});

/**
 * Locks/unlocks the file for full payment. While locked, existing
 * reservations can't be edited, deleted, or have their status changed —
 * only new reservations and credit-note finance lines can be added. This is
 * a manual finance action, never automatic from the travel date passing.
 */
export const setFinanceLocked = mutation({
  args: { id: v.id("groupFiles"), locked: v.boolean() },
  handler: async (ctx, args): Promise<null> => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.id);
    await ctx.db.patch("groupFiles", args.id, {
      financeLocked: args.locked,
      financeLockedAt: args.locked ? new Date().toISOString() : undefined,
    });

    await logActivity(ctx, {
      groupFileId: args.id,
      action: "updated",
      description: args.locked
        ? "Closed for full payment — reservations are now locked"
        : "Reopened — reservations can be edited again",
      user,
    });

    return null;
  },
});

export const setStatus = mutation({
  args: { id: v.id("groupFiles"), status: groupFileStatusValidator },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const file = await requireGroupFile(ctx, args.id);
    const oldLabel = STATUS_LABELS[file.status] ?? file.status;
    const newLabel = STATUS_LABELS[args.status] ?? args.status;
    await ctx.db.patch("groupFiles", args.id, { status: args.status });

    await logActivity(ctx, {
      groupFileId: args.id,
      action: "status_changed",
      description: `Status changed from ${oldLabel} to ${newLabel}`,
      user,
    });

    // Notify all users about the status change
    await broadcastNotification(ctx, {
      type: "file_status_changed",
      title: "File status updated",
      body: `${file.reference} "${file.title}" moved to ${newLabel}`,
      linkTo: `/files/${args.id}`,
      relatedId: `file_status:${args.id}:${args.status}`,
    });

    // The first time a file is confirmed, auto-create its default payment
    // schedule (10% deposit / 50% at 30 days / 40% at 14 days before
    // departure) so staff can generate/send installment invoices later.
    // Never sends anything — invoicing stays a staff-triggered action.
    if (args.status === "confirmed" && file.status !== "confirmed") {
      await createDefaultScheduleIfMissing(ctx, args.id, user._id);
    }

    return null;
  },
});

export const duplicate = mutation({
  args: {
    id: v.id("groupFiles"),
    copyItinerary: v.boolean(),
  },
  handler: async (ctx, args): Promise<Id<"groupFiles">> => {
    const user = await requireUser(ctx);
    const source = await requireGroupFile(ctx, args.id);

    // Generate the next reference for the same year
    const year = new Date(source.startDate).getUTCFullYear();
    const prefix = `GM-${year}-`;
    const latest = await ctx.db
      .query("groupFiles")
      .withIndex("by_reference", (q) =>
        q.gte("reference", prefix).lt("reference", `${prefix}9999`),
      )
      .order("desc")
      .first();
    const nextNumber = latest
      ? Number.parseInt(latest.reference.slice(prefix.length), 10) + 1
      : 1;
    const reference = `${prefix}${String(nextNumber).padStart(4, "0")}`;

    const newFileId = await ctx.db.insert("groupFiles", {
      reference,
      title: `Copy of ${source.title}`,
      fileType: source.fileType,
      status: "enquiry",
      clientName: source.clientName,
      clientContactName: source.clientContactName,
      clientContactEmail: source.clientContactEmail,
      clientContactPhone: source.clientContactPhone,
      destination: source.destination,
      startDate: source.startDate,
      endDate: source.endDate,
      pax: source.pax,
      currency: source.currency,
      exchangeRateToBase: source.exchangeRateToBase,
      markupPercent: source.markupPercent,
      notes: source.notes,
      ownerId: user._id,
      createdById: user._id,
    });

    if (args.copyItinerary) {
      const days = await ctx.db
        .query("itineraryDays")
        .withIndex("by_group_file", (q) => q.eq("groupFileId", args.id))
        .order("asc")
        .collect();

      for (const day of days) {
        const newDayId = await ctx.db.insert("itineraryDays", {
          groupFileId: newFileId,
          date: day.date,
          dayNumber: day.dayNumber,
          title: day.title,
          notes: day.notes,
        });
        const items = await ctx.db
          .query("itineraryItems")
          .withIndex("by_day_and_order", (q) => q.eq("dayId", day._id))
          .order("asc")
          .collect();
        for (const item of items) {
          await ctx.db.insert("itineraryItems", {
            dayId: newDayId,
            groupFileId: newFileId,
            sortOrder: item.sortOrder,
            type: item.type,
            time: item.time,
            title: item.title,
            description: item.description,
            location: item.location,
            notes: item.notes,
            // reservationId intentionally omitted — reservations are not copied
          });
        }
      }
    }

    // Log on the SOURCE file (so you see "duplicated" in the original timeline)
    await logActivity(ctx, {
      groupFileId: args.id,
      action: "duplicated",
      description: `Duplicated to "${reference}"`,
      user,
    });

    // Log on the NEW file
    await logActivity(ctx, {
      groupFileId: newFileId,
      action: "created",
      description: `Created as duplicate of "${source.reference}"`,
      user,
    });

    return newFileId;
  },
});

/** Returns all files for the pipeline view (including cancelled), bounded at 400. */
export const listForPipeline = query({
  args: {},
  handler: async (ctx): Promise<
    Array<Doc<"groupFiles"> & { totalIncome: number; lastActivityAt: string }>
  > => {
    await requireIdentity(ctx);
    const files = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date")
      .order("asc")
      .take(400);

    return await Promise.all(
      files.map(async (file) => {
        const lines = await ctx.db
          .query("financeLines")
          .withIndex("by_group_file_and_kind", (q) =>
            q.eq("groupFileId", file._id).eq("kind", "income"),
          )
          .collect();
        const totalIncome = lines.reduce(
          (s, l) => s + l.amount * l.exchangeRateToBase,
          0,
        );

        // Latest activity timestamp, used to flag stale enquiries/quotes on the
        // pipeline board. Falls back to creation time if nothing was logged yet.
        const [latestActivity] = await ctx.db
          .query("activityLog")
          .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
          .order("desc")
          .take(1);
        const lastActivityAt =
          latestActivity?.timestamp ?? new Date(file._creationTime).toISOString();

        return { ...file, totalIncome, lastActivityAt };
      }),
    );
  },
});

export const remove = mutation({
  args: { id: v.id("groupFiles") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireGroupFile(ctx, args.id);
    // No activity log for delete — the file is being removed
    await ctx.db.delete("groupFiles", args.id);
    return null;
  },
});

/** Create a new group file pre-filled from a template. */
export const createFromTemplate = mutation({
  args: {
    templateId: v.id("fileTemplates"),
    ...baseFields,
  },
  handler: async (ctx, args): Promise<Id<"groupFiles">> => {
    const user = await requireUser(ctx);
    const { templateId, ...fields } = args;
    validate(fields);

    const template = await ctx.db.get(templateId);
    if (!template) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Template not found." });
    }

    // Generate reference
    const year = new Date(fields.startDate).getUTCFullYear();
    const prefix = `GM-${year}-`;
    const latest = await ctx.db
      .query("groupFiles")
      .withIndex("by_reference", (q) =>
        q.gte("reference", prefix).lt("reference", `${prefix}9999`),
      )
      .order("desc")
      .first();
    const nextNumber = latest
      ? Number.parseInt(latest.reference.slice(prefix.length), 10) + 1
      : 1;
    const reference = `${prefix}${String(nextNumber).padStart(4, "0")}`;

    const fileId = await ctx.db.insert("groupFiles", {
      ...fields,
      reference,
      ownerId: user._id,
      createdById: user._id,
    });

    // Materialise itinerary days + items from template
    if (template.itineraryDays.length > 0) {
      const fileStart = new Date(fields.startDate);
      for (const tDay of template.itineraryDays) {
        // Offset each day from the file start date
        const dayDate = new Date(fileStart);
        dayDate.setUTCDate(dayDate.getUTCDate() + tDay.dayNumber - 1);
        const dateIso = dayDate.toISOString();

        const dayId = await ctx.db.insert("itineraryDays", {
          groupFileId: fileId,
          date: dateIso,
          dayNumber: tDay.dayNumber,
          title: tDay.title,
          notes: tDay.notes,
        });

        for (const tItem of tDay.items) {
          await ctx.db.insert("itineraryItems", {
            dayId,
            groupFileId: fileId,
            sortOrder: tItem.sortOrder,
            type: tItem.type,
            time: tItem.time,
            title: tItem.title,
            description: tItem.description,
            location: tItem.location,
            notes: tItem.notes,
          });
        }
      }
    }

    // Materialise finance line stubs from template (amounts zeroed out)
    if (template.financeLines.length > 0) {
      for (const tLine of template.financeLines) {
        await ctx.db.insert("financeLines", {
          groupFileId: fileId,
          kind: tLine.kind,
          category: tLine.category,
          description: tLine.description,
          notes: tLine.notes,
          amount: 0,
          currency: fields.currency,
          exchangeRateToBase: fields.exchangeRateToBase,
          createdById: user._id,
        });
      }
    }

    await logActivity(ctx, {
      groupFileId: fileId,
      action: "created",
      description: `Created from template "${template.name}"`,
      user,
    });

    return fileId;
  },
});

/** Bulk-update the status of multiple group files in one transaction. */
export const bulkUpdateStatus = mutation({
  args: {
    ids: v.array(v.id("groupFiles")),
    status: groupFileStatusValidator,
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    if (args.ids.length === 0) return null;
    for (const id of args.ids) {
      const file = await ctx.db.get(id);
      if (!file) continue;
      await ctx.db.patch(id, { status: args.status });
      await logActivity(ctx, {
        groupFileId: id,
        action: "updated",
        description: `Status changed to "${args.status}" (bulk)`,
        user,
      });
      if (args.status === "confirmed" && file.status !== "confirmed") {
        await createDefaultScheduleIfMissing(ctx, id, user._id);
      }
    }
    return null;
  },
});

/** Bulk-assign an owner to multiple group files in one transaction. */
export const bulkAssignOwner = mutation({
  args: {
    ids: v.array(v.id("groupFiles")),
    ownerId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    if (args.ids.length === 0) return null;
    const owner = await ctx.db.get("users", args.ownerId);
    if (!owner) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Selected owner not found." });
    }
    const ownerLabel = owner.name ?? owner.email ?? "Unknown";
    for (const id of args.ids) {
      const file = await ctx.db.get(id);
      if (!file) continue;
      await ctx.db.patch(id, { ownerId: args.ownerId });
      await logActivity(ctx, {
        groupFileId: id,
        action: "updated",
        description: `Owner changed to ${ownerLabel} (bulk)`,
        user,
      });
    }
    return null;
  },
});

/** Bulk-delete multiple group files in one transaction. */
export const bulkDelete = mutation({
  args: { ids: v.array(v.id("groupFiles")) },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    if (args.ids.length === 0) return null;
    for (const id of args.ids) {
      await ctx.db.delete(id);
    }
    return null;
  },
});
