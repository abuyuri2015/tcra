import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

async function setupFileWithHotelReservation(
  t: ReturnType<typeof convexTest>,
  clientContactEmail?: string,
) {
  const asUser = t.withIdentity({ name: "Ada" });

  const hotelId = await asUser.mutation(api.hotels.create, {
    name: "Test Hotel",
    category: "4-star",
    status: "active",
    city: "Paris",
    country: "France",
    currency: "EUR",
    contactEmail: "reservations@testhotel.com",
    imageUrls: [],
    amenities: [],
  });

  const groupFileId = await asUser.mutation(api.groupFiles.create, {
    title: "Test Trip",
    fileType: "group",
    status: "confirmed",
    clientName: "Acme Co",
    destination: "Paris",
    startDate: "2027-01-01T00:00:00.000Z",
    endDate: "2027-01-05T00:00:00.000Z",
    pax: 10,
    currency: "EUR",
    exchangeRateToBase: 1,
  });

  if (clientContactEmail) {
    await asUser.mutation(api.groupFiles.update, {
      id: groupFileId,
      title: "Test Trip",
      fileType: "group",
      status: "confirmed",
      clientName: "Acme Co",
      clientContactEmail,
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });
  }

  const reservationId = await asUser.mutation(api.reservations.create, {
    groupFileId,
    type: "hotel",
    status: "confirmed",
    supplierName: "Test Hotel",
    hotelId,
    description: "Double room",
    startDate: "2027-01-01T00:00:00.000Z",
    units: 10,
    unitLabel: "rooms",
    costPerUnit: 100,
    ratePerUnit: 120,
    currency: "EUR",
  });

  return { asUser, groupFileId, reservationId, hotelId };
}

async function countScheduledSends(
  t: ReturnType<typeof convexTest>,
  functionName: string,
): Promise<number> {
  const scheduled = await t.run(async (ctx) => {
    return await ctx.db.system.query("_scheduled_functions").collect();
  });
  return scheduled.filter((s) => s.name.endsWith(functionName)).length;
}

describe("client update notification after an approved change", () => {
  it("schedules an updated confirmation email when a units change is approved", async () => {
    const t = convexTest(schema, modules);
    const { groupFileId, reservationId } = await setupFileWithHotelReservation(
      t,
      "client@example.com",
    );

    const { id: requestId } = await t.mutation(api.modificationRequests.submitPublic, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 12,
      message: "",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "approved",
    });

    expect(await countScheduledSends(t, "sendConfirmationUpdated")).toBe(1);
  });

  it("schedules an updated confirmation email for a staff-submitted change once approved", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithHotelReservation(
      t,
      "client@example.com",
    );

    const { id: requestId } = await asUser.mutation(api.modificationRequests.submitByStaff, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 12,
      message: "",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "approved",
    });

    expect(await countScheduledSends(t, "sendConfirmationUpdated")).toBe(1);
  });

  it("does not schedule an email when the request is declined", async () => {
    const t = convexTest(schema, modules);
    const { groupFileId, reservationId } = await setupFileWithHotelReservation(
      t,
      "client@example.com",
    );

    const { id: requestId } = await t.mutation(api.modificationRequests.submitPublic, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 12,
      message: "",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "declined",
    });

    expect(await countScheduledSends(t, "sendConfirmationUpdated")).toBe(0);
  });

  it("does not schedule an email when the file has no client contact email", async () => {
    const t = convexTest(schema, modules);
    const { groupFileId, reservationId } = await setupFileWithHotelReservation(t);

    const { id: requestId } = await t.mutation(api.modificationRequests.submitPublic, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 12,
      message: "",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "approved",
    });

    expect(await countScheduledSends(t, "sendConfirmationUpdated")).toBe(0);
  });
});
