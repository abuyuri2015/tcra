import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import type { MutationCtx } from "./_generated/server";
import { requireIdentity, requireUser, requireGroupFile } from "./lib/auth.ts";
import { logActivity } from "./activityLog.ts";
import {
  paymentScheduleItemValidator,
  paymentScheduleTriggerValidator,
} from "./schema/paymentSchedules.ts";

/** Default schedule offered when a file is confirmed: 10/50/40 split. */
const DEFAULT_ITEMS: Array<{
  label: string;
  percent: number;
  triggerType: "on_confirmation" | "days_before_departure";
  triggerDays?: number;
}> = [
  { label: "Deposit", percent: 10, triggerType: "on_confirmation" },
  { label: "Installment", percent: 50, triggerType: "days_before_departure", triggerDays: 30 },
  { label: "Final balance", percent: 40, triggerType: "days_before_departure", triggerDays: 14 },
];

function makeItemId(): string {
  return Math.random().toString(36).slice(2, 10);
}

/**
 * Auto-creates the default 10/50/40 schedule the first time a file is
 * confirmed. Total value is best-effort — the sum of existing income finance
 * lines (usually the accepted offer amounts). Staff can edit everything
 * (percentages, labels, trigger days, total value) afterward. No-ops if a
 * schedule already exists for this file. Never sends anything to the client.
 */
export async function createDefaultScheduleIfMissing(
  ctx: MutationCtx,
  groupFileId: Id<"groupFiles">,
  createdById: Id<"users">,
): Promise<void> {
  const existing = await ctx.db
    .query("paymentSchedules")
    .withIndex("by_group_file", (q) => q.eq("groupFileId", groupFileId))
    .unique();
  if (existing) return;

  const incomeLines = await ctx.db
    .query("financeLines")
    .withIndex("by_group_file_and_kind", (q) =>
      q.eq("groupFileId", groupFileId).eq("kind", "income"),
    )
    .collect();
  const totalValueEur = incomeLines.reduce(
    (sum, l) => sum + l.amount * l.exchangeRateToBase,
    0,
  );

  await ctx.db.insert("paymentSchedules", {
    groupFileId,
    totalValueEur,
    items: DEFAULT_ITEMS.map((i) => ({ ...i, id: makeItemId() })),
    createdById,
  });
}

// ── Queries ───────────────────────────────────────────────────────────────────

export const getByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"paymentSchedules"> | null> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("paymentSchedules")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .unique();
  },
});

// ── Mutations ─────────────────────────────────────────────────────────────────

/**
 * Creates the default 10/50/40 schedule for a file (deposit on confirmation,
 * then two pre-departure installments). No-ops if a schedule already exists.
 */
export const ensureDefault = mutation({
  args: { groupFileId: v.id("groupFiles"), totalValueEur: v.number() },
  handler: async (ctx, args): Promise<Id<"paymentSchedules">> => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);

    const existing = await ctx.db
      .query("paymentSchedules")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .unique();
    if (existing) return existing._id;

    const id = await ctx.db.insert("paymentSchedules", {
      groupFileId: args.groupFileId,
      totalValueEur: args.totalValueEur,
      items: DEFAULT_ITEMS.map((i) => ({ ...i, id: makeItemId() })),
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "finance_line_added",
      description: "Created payment schedule (10% deposit / 50% at 30 days / 40% at 14 days)",
      user,
    });

    return id;
  },
});

/** Full replace of the schedule's total value + items (staff edits percentages, labels, trigger days). */
export const update = mutation({
  args: {
    id: v.id("paymentSchedules"),
    totalValueEur: v.number(),
    items: v.array(paymentScheduleItemValidator),
  },
  handler: async (ctx, args): Promise<null> => {
    const user = await requireUser(ctx);
    const schedule = await ctx.db.get("paymentSchedules", args.id);
    if (!schedule) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Payment schedule not found." });
    }
    if (args.totalValueEur < 0) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Total value cannot be negative." });
    }
    await ctx.db.patch("paymentSchedules", args.id, {
      totalValueEur: args.totalValueEur,
      items: args.items,
    });

    await logActivity(ctx, {
      groupFileId: schedule.groupFileId,
      action: "updated",
      description: "Updated payment schedule",
      user,
    });

    return null;
  },
});

export const addItem = mutation({
  args: {
    id: v.id("paymentSchedules"),
    label: v.string(),
    percent: v.number(),
    triggerType: paymentScheduleTriggerValidator,
    triggerDays: v.optional(v.number()),
  },
  handler: async (ctx, args): Promise<null> => {
    await requireUser(ctx);
    const schedule = await ctx.db.get("paymentSchedules", args.id);
    if (!schedule) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Payment schedule not found." });
    }
    await ctx.db.patch("paymentSchedules", args.id, {
      items: [
        ...schedule.items,
        {
          id: makeItemId(),
          label: args.label,
          percent: args.percent,
          triggerType: args.triggerType,
          triggerDays: args.triggerDays,
        },
      ],
    });
    return null;
  },
});

export const removeItem = mutation({
  args: { id: v.id("paymentSchedules"), itemId: v.string() },
  handler: async (ctx, args): Promise<null> => {
    await requireUser(ctx);
    const schedule = await ctx.db.get("paymentSchedules", args.id);
    if (!schedule) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Payment schedule not found." });
    }
    await ctx.db.patch("paymentSchedules", args.id, {
      items: schedule.items.filter((i) => i.id !== args.itemId),
    });
    return null;
  },
});

/**
 * Generates an income finance line for one schedule item (percent × total
 * value) and marks the item as invoiced. Returns the new finance line id so
 * the caller can immediately build/send an invoice PDF for it. Staff must
 * still click "send" separately — nothing is emailed here.
 */
export const generateInvoiceLine = mutation({
  args: { id: v.id("paymentSchedules"), itemId: v.string(), invoiceNumber: v.string() },
  handler: async (ctx, args): Promise<{ financeLineId: Id<"financeLines"> }> => {
    const user = await requireUser(ctx);
    const schedule = await ctx.db.get("paymentSchedules", args.id);
    if (!schedule) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Payment schedule not found." });
    }
    const item = schedule.items.find((i) => i.id === args.itemId);
    if (!item) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Schedule item not found." });
    }
    if (item.financeLineId) {
      throw new ConvexError({ code: "CONFLICT", message: "An invoice was already generated for this item." });
    }

    const file = await requireGroupFile(ctx, schedule.groupFileId);
    const amountEur = (schedule.totalValueEur * item.percent) / 100;

    const financeLineId = await ctx.db.insert("financeLines", {
      groupFileId: schedule.groupFileId,
      kind: "income",
      category: "deposit",
      description: `${item.label} (${item.percent}% of package value) — ${args.invoiceNumber}`,
      amount: amountEur,
      currency: "EUR",
      exchangeRateToBase: 1,
      notes: `Generated from payment schedule for ${file.reference}`,
      createdById: user._id,
    });

    const now = new Date().toISOString();
    await ctx.db.patch("paymentSchedules", args.id, {
      items: schedule.items.map((i) =>
        i.id === args.itemId
          ? { ...i, financeLineId, invoiceNumber: args.invoiceNumber, invoicedAt: now }
          : i,
      ),
    });

    await logActivity(ctx, {
      groupFileId: schedule.groupFileId,
      action: "finance_line_added",
      description: `Generated ${item.label} invoice ${args.invoiceNumber} (€${amountEur.toFixed(2)})`,
      user,
    });

    return { financeLineId };
  },
});
