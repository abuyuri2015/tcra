import { v } from "convex/values";
import { query } from "./_generated/server.js";
import { requireIdentity } from "./lib/auth.ts";
import { groupFileStatusValidator } from "./schema/groupFiles.ts";
import type { Id } from "./_generated/dataModel.js";

export type FilePnL = {
  fileId: Id<"groupFiles">;
  reference: string;
  title: string;
  clientName: string;
  destination: string;
  startDate: string;
  endDate: string;
  status: string;
  fileType: string;
  pax: number;
  totalCostEur: number;
  totalIncomeEur: number;
  marginEur: number;
  marginPct: number | null;
};

/**
 * Cross-file P&L summary. Returns one row per group file, with aggregated
 * cost, income, and margin in EUR. Bounded at 200 files.
 */
export const overview = query({
  args: {
    status: v.optional(groupFileStatusValidator),
    fromDate: v.optional(v.string()),
    toDate: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<{
    rows: FilePnL[];
    totals: {
      totalCostEur: number;
      totalIncomeEur: number;
      marginEur: number;
      marginPct: number | null;
      fileCount: number;
    };
  }> => {
    await requireIdentity(ctx);

    // Fetch files — filtered by status index when possible, otherwise full scan (bounded)
    let files = args.status
      ? await ctx.db
          .query("groupFiles")
          .withIndex("by_status", (q) => q.eq("status", args.status!))
          .take(200)
      : await ctx.db
          .query("groupFiles")
          .withIndex("by_start_date")
          .order("desc")
          .take(200);

    // Client-side date filtering
    if (args.fromDate) {
      files = files.filter((f) => f.startDate >= args.fromDate!);
    }
    if (args.toDate) {
      files = files.filter((f) => f.startDate <= args.toDate!);
    }

    // Aggregate finance lines per file
    const rows: FilePnL[] = await Promise.all(
      files.map(async (file) => {
        const lines = await ctx.db
          .query("financeLines")
          .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
          .collect();

        const totalCostEur = lines
          .filter((l) => l.kind === "cost")
          .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);
        const totalIncomeEur = lines
          .filter((l) => l.kind === "income")
          .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);
        const marginEur = totalIncomeEur - totalCostEur;
        const marginPct =
          totalIncomeEur > 0
            ? Math.round((marginEur / totalIncomeEur) * 100)
            : null;

        return {
          fileId: file._id,
          reference: file.reference,
          title: file.title,
          clientName: file.clientName,
          destination: file.destination,
          startDate: file.startDate,
          endDate: file.endDate,
          status: file.status,
          fileType: file.fileType,
          pax: file.pax,
          totalCostEur: Math.round(totalCostEur),
          totalIncomeEur: Math.round(totalIncomeEur),
          marginEur: Math.round(marginEur),
          marginPct,
        };
      }),
    );

    // Overall totals
    const totalCostEur = rows.reduce((s, r) => s + r.totalCostEur, 0);
    const totalIncomeEur = rows.reduce((s, r) => s + r.totalIncomeEur, 0);
    const marginEur = totalIncomeEur - totalCostEur;
    const marginPct =
      totalIncomeEur > 0
        ? Math.round((marginEur / totalIncomeEur) * 100)
        : null;

    return {
      rows,
      totals: {
        totalCostEur,
        totalIncomeEur,
        marginEur,
        marginPct,
        fileCount: rows.length,
      },
    };
  },
});
