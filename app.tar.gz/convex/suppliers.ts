import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireUser, requireIdentity } from "./lib/auth.ts";
import { supplierCategoryValidator } from "./schema/suppliers.ts";

const supplierFields = {
  name: v.string(),
  category: supplierCategoryValidator,
  country: v.optional(v.string()),
  city: v.optional(v.string()),
  contactPerson: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  notes: v.optional(v.string()),
};

async function requireSupplier(
  ctx: QueryCtx | MutationCtx,
  id: Id<"suppliers">,
): Promise<Doc<"suppliers">> {
  const s = await ctx.db.get(id);
  if (!s) throw new ConvexError({ code: "NOT_FOUND", message: "Supplier not found." });
  return s;
}

/** List all suppliers, optionally filtered by category. */
export const list = query({
  args: {
    category: v.optional(supplierCategoryValidator),
    paginationOpts: v.optional(
      v.object({ numItems: v.number(), cursor: v.union(v.string(), v.null()) }),
    ),
  },
  handler: async (ctx, args): Promise<Doc<"suppliers">[]> => {
    const q = args.category
      ? ctx.db
          .query("suppliers")
          .withIndex("by_category", (q) => q.eq("category", args.category!))
      : ctx.db.query("suppliers");
    return await q.order("asc").take(200);
  },
});

/** Full-text search across supplier names. */
export const search = query({
  args: { query: v.string(), category: v.optional(supplierCategoryValidator) },
  handler: async (ctx, args): Promise<Doc<"suppliers">[]> => {
    if (!args.query.trim()) {
      return await ctx.db
        .query("suppliers")
        .order("asc")
        .take(50);
    }
    const results = await ctx.db
      .query("suppliers")
      .withSearchIndex("search_name", (q) => {
        const base = q.search("name", args.query);
        return base;
      })
      .take(50);

    if (args.category) {
      return results.filter((s) => s.category === args.category);
    }
    return results;
  },
});

export const get = query({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args): Promise<Doc<"suppliers"> | null> => {
    return await ctx.db.get(args.id);
  },
});

export type SupplierReservation = {
  _id: string;
  groupFileId: string;
  groupFileTitle: string;
  groupFileReference: string;
  type: string;
  status: string;
  description: string;
  startDate: string;
  endDate: string | undefined;
  units: number;
  unitLabel: string | undefined;
};

/** Full detail for the supplier page: supplier + linked reservations + group files. */
export const getDetail = query({
  args: { id: v.id("suppliers") },
  handler: async (
    ctx,
    args,
  ): Promise<{
    supplier: Doc<"suppliers">;
    reservations: SupplierReservation[];
  } | null> => {
    await requireIdentity(ctx);
    const supplier = await ctx.db.get(args.id);
    if (!supplier) return null;

    // Find reservations matching this supplier by name (search index)
    const matchingReservations = supplier.name.trim()
      ? await ctx.db
          .query("reservations")
          .withSearchIndex("search_supplier", (q) =>
            q.search("supplierName", supplier.name),
          )
          .take(100)
      : [];

    // Only keep exact name matches (search can be fuzzy)
    const exactMatches = matchingReservations.filter(
      (r) => r.supplierName.toLowerCase() === supplier.name.toLowerCase(),
    );

    // Batch-fetch the group files for those reservations
    const fileIds = [...new Set(exactMatches.map((r) => r.groupFileId))];
    const fileMap = new Map<string, { title: string; reference: string }>();
    await Promise.all(
      fileIds.map(async (id) => {
        const f = await ctx.db.get(id);
        if (f) fileMap.set(id, { title: f.title, reference: f.reference });
      }),
    );

    const reservations: SupplierReservation[] = exactMatches.map((r) => ({
      _id: r._id,
      groupFileId: r.groupFileId,
      groupFileTitle: fileMap.get(r.groupFileId)?.title ?? "—",
      groupFileReference: fileMap.get(r.groupFileId)?.reference ?? "—",
      type: r.type,
      status: r.status,
      description: r.description,
      startDate: r.startDate,
      endDate: r.endDate,
      units: r.units,
      unitLabel: r.unitLabel,
    }));

    // Sort by start date descending (most recent first)
    reservations.sort((a, b) => b.startDate.localeCompare(a.startDate));

    return { supplier, reservations };
  },
});

export const create = mutation({
  args: supplierFields,
  handler: async (ctx, args): Promise<Id<"suppliers">> => {
    const user = await requireUser(ctx);
    const name = args.name.trim();
    if (!name) throw new ConvexError({ code: "BAD_REQUEST", message: "Supplier name is required." });
    return await ctx.db.insert("suppliers", { ...args, name, createdById: user._id });
  },
});

export const update = mutation({
  args: { id: v.id("suppliers"), ...supplierFields },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    await requireSupplier(ctx, id);
    const name = fields.name.trim();
    if (!name) throw new ConvexError({ code: "BAD_REQUEST", message: "Supplier name is required." });
    await ctx.db.patch(id, { ...fields, name });
    return null;
  },
});

export const bulkCreate = mutation({
  args: {
    suppliers: v.array(
      v.object({
        name: v.string(),
        category: supplierCategoryValidator,
        country: v.optional(v.string()),
        city: v.optional(v.string()),
        contactPerson: v.optional(v.string()),
        email: v.optional(v.string()),
        phone: v.optional(v.string()),
        notes: v.optional(v.string()),
      }),
    ),
  },
  handler: async (ctx, args): Promise<{ imported: number; skipped: number }> => {
    const user = await requireUser(ctx);

    // Fetch existing supplier names for duplicate detection
    const existing = await ctx.db.query("suppliers").take(2000);
    const existingNames = new Set(existing.map((s) => s.name.trim().toLowerCase()));

    let imported = 0;
    let skipped = 0;
    for (const supplier of args.suppliers) {
      const name = supplier.name.trim();
      if (!name) {
        skipped++;
        continue;
      }
      if (existingNames.has(name.toLowerCase())) {
        skipped++;
        continue;
      }
      await ctx.db.insert("suppliers", {
        ...supplier,
        name,
        createdById: user._id,
      });
      existingNames.add(name.toLowerCase());
      imported++;
    }

    return { imported, skipped };
  },
});

export const remove = mutation({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await requireSupplier(ctx, args.id);
    await ctx.db.delete(args.id);
    return null;
  },
});
