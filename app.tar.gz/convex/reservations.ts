import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireGroupFile, requireIdentity, requireUser } from "./lib/auth.ts";
import { currencyValidator } from "./schema/groupFiles.ts";
import {
  reservationStatusValidator,
  reservationTypeValidator,
} from "./schema/reservations.ts";
import { logActivity } from "./activityLog.ts";
import { hotelBoardValidator } from "./schema/hotels.ts";
import { internal } from "./_generated/api";
import { ensureSupplierOrHotelLinked } from "./lib/supplierSync.ts";
import { requireFileNotLocked, requireReservationDirectlyEditable } from "./lib/reservationLock.ts";

const reservationFields = {
  type: reservationTypeValidator,
  status: reservationStatusValidator,
  supplierName: v.string(),
  hotelId: v.optional(v.id("hotels")),
  description: v.string(),
  startDate: v.string(),
  endDate: v.optional(v.string()),
  units: v.number(),
  unitLabel: v.optional(v.string()),
  board: v.optional(hotelBoardValidator),
  nights: v.optional(v.number()),
  supplierRef: v.optional(v.string()),
  ratePerUnit: v.optional(v.number()),
  costPerUnit: v.optional(v.number()),
  currency: currencyValidator,
  notes: v.optional(v.string()),
  pickupLocation: v.optional(v.string()),
  pickupTime: v.optional(v.string()),
  flightDetails: v.optional(v.string()),
  guideName: v.optional(v.string()),
  guidePhone: v.optional(v.string()),
  excludedPassengerIds: v.optional(v.array(v.id("passengers"))),
};

async function requireReservation(
  ctx: QueryCtx | MutationCtx,
  id: Id<"reservations">,
): Promise<Doc<"reservations">> {
  const res = await ctx.db.get("reservations", id);
  if (!res) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Reservation not found." });
  }
  return res;
}

export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"reservations">[]> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("reservations")
      .withIndex("by_group_file_and_start", (q) =>
        q.eq("groupFileId", args.groupFileId),
      )
      .order("asc")
      .collect();
  },
});

export const create = mutation({
  args: { groupFileId: v.id("groupFiles"), ...reservationFields },
  handler: async (ctx, args): Promise<Id<"reservations">> => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    if (args.units < 1) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Units must be at least 1." });
    }
    // Auto-add brand-new supplier/hotel names to the reusable database.
    const hotelId = await ensureSupplierOrHotelLinked(ctx, {
      type: args.type,
      supplierName: args.supplierName,
      hotelId: args.hotelId,
      currency: args.currency,
      createdById: user._id,
    });
    const id = await ctx.db.insert("reservations", {
      ...args,
      hotelId,
      createdById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "reservation_added",
      description: `Added ${args.type} reservation "${args.supplierName}"`,
      user,
    });

    return id;
  },
});

export const update = mutation({
  args: { id: v.id("reservations"), ...reservationFields },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const { id, ...fields } = args;
    const existing = await requireReservation(ctx, id);
    const file = await requireGroupFile(ctx, existing.groupFileId);
    requireFileNotLocked(file);
    requireReservationDirectlyEditable(existing);
    if (fields.units < 1) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Units must be at least 1." });
    }
    // Auto-add brand-new supplier/hotel names to the reusable database.
    const hotelId = await ensureSupplierOrHotelLinked(ctx, {
      type: fields.type,
      supplierName: fields.supplierName,
      hotelId: fields.hotelId,
      currency: fields.currency,
      createdById: user._id,
    });
    await ctx.db.patch("reservations", id, { ...fields, hotelId });

    await logActivity(ctx, {
      groupFileId: existing.groupFileId,
      action: "reservation_updated",
      description: `Updated ${fields.type} reservation "${fields.supplierName}"`,
      user,
    });

    return null;
  },
});

export const setStatus = mutation({
  args: {
    id: v.id("reservations"),
    status: reservationStatusValidator,
    // The staff browser's origin (window.location.origin), used to build the
    // absolute confirmation link in the auto-sent client email. Optional —
    // if omitted (e.g. bulk tooling), no auto-email is sent.
    appOrigin: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<null> => {
    const user = await requireUser(ctx);
    const reservation = await requireReservation(ctx, args.id);
    const file = await requireGroupFile(ctx, reservation.groupFileId);
    requireFileNotLocked(file);
    // Confirming for the first time is allowed directly. Changing the status
    // of an already-confirmed reservation must go through hotel approval, so
    // it isn't treated any differently from any other change to it.
    if (reservation.status === "confirmed" && args.status !== reservation.status) {
      requireReservationDirectlyEditable(reservation);
    }
    await ctx.db.patch("reservations", args.id, { status: args.status });

    await logActivity(ctx, {
      groupFileId: reservation.groupFileId,
      action: "reservation_updated",
      description: `Reservation "${reservation.supplierName}" status → ${args.status}`,
      user,
    });

    // The first time any reservation on this file is confirmed, automatically
    // email the client a link to their confirmation page (only sent once).
    if (args.status === "confirmed" && args.appOrigin) {
      if (!file.confirmationSentAt && file.clientContactEmail) {
        await ctx.db.patch("groupFiles", file._id, {
          confirmationSentAt: new Date().toISOString(),
        });
        await ctx.scheduler.runAfter(0, internal.email.send.sendConfirmationAuto, {
          groupFileId: file._id,
          appOrigin: args.appOrigin,
        });
      }
    }

    return null;
  },
});

/**
 * Passenger manifest for a transfer/activity reservation: every group
 * passenger by default, annotated with whether they're excluded from this
 * particular service (e.g. arriving separately, opted out of an excursion).
 */
export const manifest = query({
  args: { id: v.id("reservations") },
  handler: async (
    ctx,
    args,
  ): Promise<Array<Doc<"passengers"> & { included: boolean }>> => {
    await requireIdentity(ctx);
    const reservation = await requireReservation(ctx, args.id);
    const excluded = new Set(reservation.excludedPassengerIds ?? []);
    const passengers = await ctx.db
      .query("passengers")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", reservation.groupFileId))
      .order("asc")
      .collect();
    return passengers.map((p) => ({ ...p, included: !excluded.has(p._id) }));
  },
});

export const setPassengerIncluded = mutation({
  args: {
    id: v.id("reservations"),
    passengerId: v.id("passengers"),
    included: v.boolean(),
  },
  handler: async (ctx, args): Promise<null> => {
    const user = await requireUser(ctx);
    const reservation = await requireReservation(ctx, args.id);
    const file = await requireGroupFile(ctx, reservation.groupFileId);
    requireFileNotLocked(file);
    const current = new Set(reservation.excludedPassengerIds ?? []);
    if (args.included) {
      current.delete(args.passengerId);
    } else {
      current.add(args.passengerId);
    }
    await ctx.db.patch("reservations", args.id, {
      excludedPassengerIds: Array.from(current),
    });

    await logActivity(ctx, {
      groupFileId: reservation.groupFileId,
      action: "reservation_updated",
      description: `${args.included ? "Included" : "Excluded"} a passenger on "${reservation.supplierName}" manifest`,
      user,
    });

    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("reservations") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const reservation = await requireReservation(ctx, args.id);
    const file = await requireGroupFile(ctx, reservation.groupFileId);
    requireFileNotLocked(file);
    requireReservationDirectlyEditable(reservation);

    await logActivity(ctx, {
      groupFileId: reservation.groupFileId,
      action: "reservation_removed",
      description: `Removed ${reservation.type} reservation "${reservation.supplierName}"`,
      user,
    });

    await ctx.db.delete("reservations", args.id);
    return null;
  },
});

/**
 * Public, sanitized reservation list for the shareable client confirmation
 * page. Excludes internal cost data (costPerUnit) and notes, but includes
 * the client-facing sell rate so the price and its calculation are
 * disclosed alongside each booked item.
 */
export const listByFilePublic = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (
    ctx,
    args,
  ): Promise<
    Array<{
      _id: Id<"reservations">;
      type: Doc<"reservations">["type"];
      status: Doc<"reservations">["status"];
      supplierName: string;
      hotelId?: Id<"hotels">;
      description: string;
      startDate: string;
      endDate?: string;
      units: number;
      unitLabel?: string;
      board?: Doc<"reservations">["board"];
      nights?: number;
      ratePerUnit?: number;
      currency: Doc<"reservations">["currency"];
    }>
  > => {
    const reservations = await ctx.db
      .query("reservations")
      .withIndex("by_group_file_and_start", (q) =>
        q.eq("groupFileId", args.groupFileId),
      )
      .order("asc")
      .collect();

    return reservations.map((r) => ({
      _id: r._id,
      type: r.type,
      status: r.status,
      supplierName: r.supplierName,
      hotelId: r.hotelId,
      description: r.description,
      startDate: r.startDate,
      endDate: r.endDate,
      units: r.units,
      unitLabel: r.unitLabel,
      board: r.board,
      nights: r.nights,
      ratePerUnit: r.ratePerUnit,
      currency: r.currency,
    }));
  },
});
