import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { MutationCtx, QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireUser, requireIdentity } from "./lib/auth.ts";
import { clientKindValidator } from "./schema/clients.ts";

const clientFields = {
  kind: clientKindValidator,
  name: v.string(),
  parentClientId: v.optional(v.id("clients")),
  contactName: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  address: v.optional(v.string()),
  city: v.optional(v.string()),
  country: v.optional(v.string()),
  taxId: v.optional(v.string()),
  notes: v.optional(v.string()),
};

async function requireClient(
  ctx: QueryCtx | MutationCtx,
  id: Id<"clients">,
): Promise<Doc<"clients">> {
  const c = await ctx.db.get("clients", id);
  if (!c) throw new ConvexError({ code: "NOT_FOUND", message: "Client not found." });
  return c;
}

function validate(args: { kind: "individual" | "company"; parentClientId?: Id<"clients"> }) {
  if (args.kind === "company" && args.parentClientId) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: "A company client cannot belong to another company.",
    });
  }
}

/** List all clients, optionally filtered by kind. Bounded to 500. */
export const list = query({
  args: { kind: v.optional(clientKindValidator) },
  handler: async (ctx, args): Promise<Doc<"clients">[]> => {
    await requireIdentity(ctx);
    const q = args.kind
      ? ctx.db.query("clients").withIndex("by_kind", (q) => q.eq("kind", args.kind!))
      : ctx.db.query("clients");
    return await q.order("asc").take(500);
  },
});

/** Full-text search across client names. */
export const search = query({
  args: { query: v.string(), kind: v.optional(clientKindValidator) },
  handler: async (ctx, args): Promise<Doc<"clients">[]> => {
    await requireIdentity(ctx);
    if (!args.query.trim()) {
      return await ctx.db.query("clients").order("asc").take(50);
    }
    const results = await ctx.db
      .query("clients")
      .withSearchIndex("search_name", (q) => q.search("name", args.query))
      .take(50);
    return args.kind ? results.filter((c) => c.kind === args.kind) : results;
  },
});

/** Individual contacts linked to a given company client. */
export const listContacts = query({
  args: { companyId: v.id("clients") },
  handler: async (ctx, args): Promise<Doc<"clients">[]> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("clients")
      .withIndex("by_parent", (q) => q.eq("parentClientId", args.companyId))
      .order("asc")
      .collect();
  },
});

export const get = query({
  args: { id: v.id("clients") },
  handler: async (ctx, args): Promise<Doc<"clients"> | null> => {
    await requireIdentity(ctx);
    return await ctx.db.get("clients", args.id);
  },
});

export type ClientGroupFile = {
  _id: Id<"groupFiles">;
  reference: string;
  title: string;
  status: string;
  destination: string;
  startDate: string;
  endDate: string;
  pax: number;
  totalIncomeEur: number;
  totalCostEur: number;
  marginEur: number;
};

/**
 * Full detail for the client page: client + linked company/contacts + matched
 * group files (matched by exact clientName, case-insensitive — same convention
 * used for matching suppliers to reservations by name).
 */
export const getDetail = query({
  args: { id: v.id("clients") },
  handler: async (
    ctx,
    args,
  ): Promise<{
    client: Doc<"clients">;
    parent: Doc<"clients"> | null;
    contacts: Doc<"clients">[];
    groupFiles: ClientGroupFile[];
    totalIncomeEur: number;
    totalCostEur: number;
    totalMarginEur: number;
  } | null> => {
    await requireIdentity(ctx);
    const client = await ctx.db.get("clients", args.id);
    if (!client) return null;

    const parent = client.parentClientId ? await ctx.db.get("clients", client.parentClientId) : null;

    const contacts =
      client.kind === "company"
        ? await ctx.db
            .query("clients")
            .withIndex("by_parent", (q) => q.eq("parentClientId", client._id))
            .order("asc")
            .collect()
        : [];

    // Names to match against groupFiles.clientName: this client's own name, plus
    // (for a company) every linked contact's name too, so a company's grouped
    // view rolls up bookings made under a contact's own name as well.
    const namesToMatch = [client.name, ...contacts.map((c) => c.name)].map((n) =>
      n.trim().toLowerCase(),
    );

    const matchedFiles: ClientGroupFile[] = [];
    for (const name of new Set(namesToMatch)) {
      if (!name) continue;
      const candidates = await ctx.db
        .query("groupFiles")
        .withSearchIndex("search_client", (q) => q.search("clientName", name))
        .take(100);
      for (const f of candidates) {
        if (f.clientName.trim().toLowerCase() !== name) continue;
        if (matchedFiles.some((m) => m._id === f._id)) continue;

        const lines = await ctx.db
          .query("financeLines")
          .withIndex("by_group_file", (q) => q.eq("groupFileId", f._id))
          .collect();
        const totalIncomeEur = lines
          .filter((l) => l.kind === "income")
          .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);
        const totalCostEur = lines
          .filter((l) => l.kind === "cost")
          .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);

        matchedFiles.push({
          _id: f._id,
          reference: f.reference,
          title: f.title,
          status: f.status,
          destination: f.destination,
          startDate: f.startDate,
          endDate: f.endDate,
          pax: f.pax,
          totalIncomeEur: Math.round(totalIncomeEur),
          totalCostEur: Math.round(totalCostEur),
          marginEur: Math.round(totalIncomeEur - totalCostEur),
        });
      }
    }

    matchedFiles.sort((a, b) => b.startDate.localeCompare(a.startDate));

    return {
      client,
      parent,
      contacts,
      groupFiles: matchedFiles,
      totalIncomeEur: Math.round(matchedFiles.reduce((s, f) => s + f.totalIncomeEur, 0)),
      totalCostEur: Math.round(matchedFiles.reduce((s, f) => s + f.totalCostEur, 0)),
      totalMarginEur: Math.round(matchedFiles.reduce((s, f) => s + f.marginEur, 0)),
    };
  },
});

export const create = mutation({
  args: clientFields,
  handler: async (ctx, args): Promise<Id<"clients">> => {
    const user = await requireUser(ctx);
    const name = args.name.trim();
    if (!name) throw new ConvexError({ code: "BAD_REQUEST", message: "Client name is required." });
    validate(args);
    if (args.parentClientId) {
      await requireClient(ctx, args.parentClientId);
    }
    return await ctx.db.insert("clients", { ...args, name, createdById: user._id });
  },
});

export const update = mutation({
  args: { id: v.id("clients"), ...clientFields },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    await requireClient(ctx, id);
    const name = fields.name.trim();
    if (!name) throw new ConvexError({ code: "BAD_REQUEST", message: "Client name is required." });
    validate(fields);
    if (fields.parentClientId) {
      if (fields.parentClientId === id) {
        throw new ConvexError({ code: "BAD_REQUEST", message: "A client cannot be its own parent." });
      }
      await requireClient(ctx, fields.parentClientId);
    }
    await ctx.db.patch("clients", id, { ...fields, name });
    return null;
  },
});

export const bulkCreate = mutation({
  args: {
    clients: v.array(
      v.object({
        kind: clientKindValidator,
        name: v.string(),
        contactName: v.optional(v.string()),
        email: v.optional(v.string()),
        phone: v.optional(v.string()),
        address: v.optional(v.string()),
        city: v.optional(v.string()),
        country: v.optional(v.string()),
        taxId: v.optional(v.string()),
        notes: v.optional(v.string()),
      }),
    ),
  },
  handler: async (ctx, args): Promise<{ imported: number; skipped: number }> => {
    const user = await requireUser(ctx);

    const existing = await ctx.db.query("clients").take(2000);
    const existingNames = new Set(existing.map((c) => c.name.trim().toLowerCase()));

    let imported = 0;
    let skipped = 0;
    for (const client of args.clients) {
      const name = client.name.trim();
      if (!name || existingNames.has(name.toLowerCase())) {
        skipped++;
        continue;
      }
      await ctx.db.insert("clients", { ...client, name, createdById: user._id });
      existingNames.add(name.toLowerCase());
      imported++;
    }

    return { imported, skipped };
  },
});

export const remove = mutation({
  args: { id: v.id("clients") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const client = await requireClient(ctx, args.id);

    if (client.kind === "company") {
      const contacts = await ctx.db
        .query("clients")
        .withIndex("by_parent", (q) => q.eq("parentClientId", args.id))
        .take(1);
      if (contacts.length > 0) {
        throw new ConvexError({
          code: "BAD_REQUEST",
          message: "Unlink or delete this company's contacts before deleting it.",
        });
      }
    }

    await ctx.db.delete("clients", args.id);
    return null;
  },
});

// ── Combined invoice ─────────────────────────────────────────────────────────

export type CombinedInvoiceFile = {
  _id: Id<"groupFiles">;
  reference: string;
  title: string;
  destination: string;
  startDate: string;
  endDate: string;
  incomeLines: Array<{
    category: string;
    description: string;
    amount: number;
    currency: string;
    amountInBase: number;
    unitRate?: number;
    quantity?: number;
    quantityLabel?: string;
  }>;
  totalEur: number;
};

/**
 * Pricing data needed to build a combined invoice across several of a
 * client's bookings. `groupFileIds` must be a subset of files already
 * matched to this client by `getDetail`.
 */
export const getCombinedInvoiceData = query({
  args: {
    clientId: v.id("clients"),
    groupFileIds: v.array(v.id("groupFiles")),
  },
  handler: async (
    ctx,
    args,
  ): Promise<{
    clientName: string;
    clientContactName?: string;
    clientContactEmail?: string;
    files: CombinedInvoiceFile[];
    grandTotalEur: number;
  }> => {
    await requireIdentity(ctx);
    const client = await requireClient(ctx, args.clientId);

    const files: CombinedInvoiceFile[] = [];
    for (const fileId of args.groupFileIds) {
      const file = await ctx.db.get("groupFiles", fileId);
      if (!file) continue;

      const lines = await ctx.db
        .query("financeLines")
        .withIndex("by_group_file_and_kind", (q) =>
          q.eq("groupFileId", fileId).eq("kind", "income"),
        )
        .collect();

      const incomeLines = lines.map((l) => ({
        category: l.category,
        description: l.description,
        amount: l.amount,
        currency: l.currency,
        amountInBase: l.amount * l.exchangeRateToBase,
        unitRate: l.unitRate,
        quantity: l.quantity,
        quantityLabel: l.quantityLabel,
      }));
      const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);

      files.push({
        _id: file._id,
        reference: file.reference,
        title: file.title,
        destination: file.destination,
        startDate: file.startDate,
        endDate: file.endDate,
        incomeLines,
        totalEur: Math.round(totalEur),
      });
    }

    files.sort((a, b) => a.startDate.localeCompare(b.startDate));

    return {
      clientName: client.name,
      clientContactName: client.contactName,
      clientContactEmail: client.email,
      files,
      grandTotalEur: Math.round(files.reduce((s, f) => s + f.totalEur, 0)),
    };
  },
});
