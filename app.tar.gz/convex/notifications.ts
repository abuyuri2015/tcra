import { v, ConvexError } from "convex/values";
import { query, mutation, internalMutation } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireIdentity, requireUser } from "./lib/auth.ts";

// ── Queries ──────────────────────────────────────────────────────────────────

/** Recent notifications for the current user (last 50). */
export const list = query({
  args: {},
  handler: async (ctx): Promise<Doc<"notifications">[]> => {
    const identity = await requireIdentity(ctx);
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();
    if (!user) return [];

    return await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .take(50);
  },
});

/** Unread notification count for the current user. */
export const unreadCount = query({
  args: {},
  handler: async (ctx): Promise<number> => {
    const identity = await requireIdentity(ctx);
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();
    if (!user) return 0;

    const unread = await ctx.db
      .query("notifications")
      .withIndex("by_user_and_read", (q) =>
        q.eq("userId", user._id).eq("isRead", false),
      )
      .take(100);
    return unread.length;
  },
});

// ── Mutations ────────────────────────────────────────────────────────────────

/** Mark a single notification as read. */
export const markAsRead = mutation({
  args: { id: v.id("notifications") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const notif = await ctx.db.get("notifications", args.id);
    if (!notif) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Notification not found" });
    }
    await ctx.db.patch("notifications", args.id, { isRead: true });
  },
});

/** Mark all notifications for the current user as read. */
export const markAllAsRead = mutation({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    const unread = await ctx.db
      .query("notifications")
      .withIndex("by_user_and_read", (q) =>
        q.eq("userId", user._id).eq("isRead", false),
      )
      .take(200);
    await Promise.all(
      unread.map((n) => ctx.db.patch("notifications", n._id, { isRead: true })),
    );
  },
});

// ── Internal helper ──────────────────────────────────────────────────────────

/**
 * Create a notification for a specific user. Call from mutations or scheduled
 * functions.
 */
export async function createNotification(
  ctx: MutationCtx,
  opts: {
    userId: Id<"users">;
    type: Doc<"notifications">["type"];
    title: string;
    body: string;
    linkTo: string;
    relatedId?: string;
  },
) {
  await ctx.db.insert("notifications", {
    userId: opts.userId,
    type: opts.type,
    title: opts.title,
    body: opts.body,
    linkTo: opts.linkTo,
    isRead: false,
    timestamp: new Date().toISOString(),
    relatedId: opts.relatedId,
  });
}

/**
 * Broadcast a notification to all users. Useful for system-wide events.
 * Bounded to the first 50 users.
 */
export async function broadcastNotification(
  ctx: MutationCtx,
  opts: {
    type: Doc<"notifications">["type"];
    title: string;
    body: string;
    linkTo: string;
    relatedId?: string;
  },
) {
  const users = await ctx.db.query("users").take(50);
  await Promise.all(
    users.map((u) =>
      createNotification(ctx, { ...opts, userId: u._id }),
    ),
  );
}

// ── Scheduled task: generate task-due and overdue notifications ──────────────

/**
 * Internal mutation called by a cron job to generate task-due-today and
 * task-overdue notifications for all users.
 */
export const generateTaskNotifications = internalMutation({
  args: {},
  handler: async (ctx) => {
    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

    // Fetch open + in-progress tasks with due dates
    const open = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "open"))
      .take(500);
    const inProgress = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "in_progress"))
      .take(500);

    const allTasks = [...open, ...inProgress].filter((t) => !!t.dueDate);

    // Batch-fetch file info
    const fileIds = [...new Set(allTasks.map((t) => t.groupFileId))];
    const fileMap = new Map<Id<"groupFiles">, Doc<"groupFiles">>();
    await Promise.all(
      fileIds.map(async (id) => {
        const f = await ctx.db.get("groupFiles", id);
        if (f) fileMap.set(id, f);
      }),
    );

    // All users (bounded)
    const users = await ctx.db.query("users").take(50);

    // Check existing notifications to avoid duplicates
    // We key on "relatedId" which is "task:{taskId}:{date}"
    for (const task of allTasks) {
      const dueDay = task.dueDate!.slice(0, 10);
      const file = fileMap.get(task.groupFileId);
      const fileRef = file?.reference ?? "—";

      const isDueToday = dueDay === today;
      const isOverdue = dueDay < today;

      if (!isDueToday && !isOverdue) continue;

      const type = isDueToday ? "task_due_today" : "task_overdue";
      const relatedId = `task:${task._id}:${today}`;
      const title = isDueToday
        ? "Task due today"
        : "Overdue task";
      const body = isDueToday
        ? `"${task.title}" in ${fileRef} is due today`
        : `"${task.title}" in ${fileRef} was due ${dueDay}`;
      const linkTo = `/files/${task.groupFileId}`;

      // Create for all users (small team app)
      for (const user of users) {
        // Check dedup: don't create same notification twice today
        const existing = await ctx.db
          .query("notifications")
          .withIndex("by_user", (q) => q.eq("userId", user._id))
          .order("desc")
          .take(100);

        const alreadyExists = existing.some(
          (n) => n.relatedId === relatedId && n.type === type,
        );
        if (alreadyExists) continue;

        await createNotification(ctx, {
          userId: user._id,
          type,
          title,
          body,
          linkTo,
          relatedId,
        });
      }
    }
  },
});

// ── Scheduled task: daily digest of overdue tasks + upcoming departures ──────

/**
 * Internal mutation called by a cron job once a day to create a single
 * "daily digest" notification per user summarizing overdue tasks and
 * departures coming up in the next 48 hours, so nothing slips through.
 */
export const generateDailyDigest = internalMutation({
  args: {},
  handler: async (ctx) => {
    const now = new Date();
    const nowIso = now.toISOString();
    const today = nowIso.slice(0, 10); // YYYY-MM-DD, used for dedup

    const in48h = new Date(now);
    in48h.setHours(in48h.getHours() + 48);
    const in48hIso = in48h.toISOString();

    // Overdue open/in-progress tasks (bounded scan — small team app)
    const open = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "open"))
      .take(500);
    const inProgress = await ctx.db
      .query("tasks")
      .withIndex("by_status", (q) => q.eq("status", "in_progress"))
      .take(500);
    const overdueTasks = [...open, ...inProgress].filter(
      (t) => !!t.dueDate && t.dueDate < nowIso,
    );

    // Departures in the next 48 hours, excluding cancelled files
    const upcoming = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date", (q) => q.gte("startDate", nowIso).lte("startDate", in48hIso))
      .take(200);
    const departures = upcoming.filter((f) => f.status !== "cancelled");

    const overdueCount = overdueTasks.length;
    const departureCount = departures.length;

    const title = "Daily digest";
    const body =
      overdueCount === 0 && departureCount === 0
        ? "All caught up — no overdue tasks and no departures in the next 48 hours."
        : [
            overdueCount > 0
              ? `${overdueCount} overdue ${overdueCount === 1 ? "task" : "tasks"}`
              : null,
            departureCount > 0
              ? `${departureCount} ${departureCount === 1 ? "departure" : "departures"} in the next 48 hours`
              : null,
          ]
            .filter(Boolean)
            .join(" · ");

    const relatedId = `daily-digest:${today}`;

    // All users (bounded — small team app)
    const users = await ctx.db.query("users").take(50);

    for (const user of users) {
      // Dedup: skip if this user already got today's digest
      const existing = await ctx.db
        .query("notifications")
        .withIndex("by_user", (q) => q.eq("userId", user._id))
        .order("desc")
        .take(20);
      const alreadySent = existing.some(
        (n) => n.type === "daily_digest" && n.relatedId === relatedId,
      );
      if (alreadySent) continue;

      await createNotification(ctx, {
        userId: user._id,
        type: "daily_digest",
        title,
        body,
        linkTo: "/tasks",
        relatedId,
      });
    }
  },
});

// ── Scheduled task: overdue payment notifications ────────────────────────────

/**
 * Internal mutation called by a daily cron. Finds unpaid finance lines whose
 * `paymentDueDate` has passed and notifies all users, deduped per line/day.
 */
export const generatePaymentOverdueNotifications = internalMutation({
  args: {},
  handler: async (ctx) => {
    const now = new Date();
    const nowIso = now.toISOString();
    const today = nowIso.slice(0, 10);

    // Bounded scan — small team app. Finance lines are only ever queried per
    // file elsewhere, so here we scan the table directly in pages.
    const overdueLines: Doc<"financeLines">[] = [];
    let cursor: string | null = null;
    let done = false;
    while (!done && overdueLines.length < 500) {
      const result = await ctx.db
        .query("financeLines")
        .paginate({ numItems: 200, cursor });
      for (const line of result.page) {
        if (
          line.paidAt === undefined &&
          line.paymentDueDate !== undefined &&
          line.paymentDueDate < nowIso
        ) {
          overdueLines.push(line);
        }
      }
      done = result.isDone;
      cursor = result.continueCursor;
    }
    if (overdueLines.length === 0) return;

    // Batch-fetch file info for context in the notification body.
    const fileIds = [...new Set(overdueLines.map((l) => l.groupFileId))];
    const fileMap = new Map<Id<"groupFiles">, Doc<"groupFiles">>();
    await Promise.all(
      fileIds.map(async (id) => {
        const f = await ctx.db.get("groupFiles", id);
        if (f) fileMap.set(id, f);
      }),
    );

    const users = await ctx.db.query("users").take(50);

    for (const line of overdueLines) {
      const file = fileMap.get(line.groupFileId);
      const fileRef = file?.reference ?? "—";
      const who = line.kind === "income" ? "Client payment" : "Payment to supplier";
      const relatedId = `payment-overdue:${line._id}:${today}`;
      const title = "Overdue payment";
      const body = `${who} for "${line.description}" in ${fileRef} was due ${line.paymentDueDate!.slice(0, 10)}.`;
      const linkTo = `/files/${line.groupFileId}?tab=finance`;

      for (const user of users) {
        const existing = await ctx.db
          .query("notifications")
          .withIndex("by_user", (q) => q.eq("userId", user._id))
          .order("desc")
          .take(100);
        const alreadyExists = existing.some(
          (n) => n.relatedId === relatedId && n.type === "payment_overdue",
        );
        if (alreadyExists) continue;

        await createNotification(ctx, {
          userId: user._id,
          type: "payment_overdue",
          title,
          body,
          linkTo,
          relatedId,
        });
      }
    }
  },
});

