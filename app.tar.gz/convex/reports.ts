import { query } from "./_generated/server.js";
import { requireIdentity } from "./lib/auth.ts";
import type { Doc } from "./_generated/dataModel.js";

// ── Helpers ───────────────────────────────────────────────────────────────────

function monthKey(isoDate: string): string {
  // Returns "YYYY-MM" from an ISO date string
  return isoDate.slice(0, 7);
}

function last12Months(): string[] {
  const months: string[] = [];
  const now = new Date();
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  }
  return months;
}

/** Days between two ISO date strings (positive = b after a). */
function daysBetween(a: string, b: string): number {
  return Math.round(
    (new Date(b).getTime() - new Date(a).getTime()) / (1000 * 60 * 60 * 24),
  );
}

// ── Revenue dashboard query ───────────────────────────────────────────────────

export type RevenueData = {
  // KPI cards
  confirmedRevenue: number;      // total income EUR on confirmed + operating + closed files
  pipelineValue: number;         // total income EUR on enquiry + quoted files
  totalCosts: number;            // total costs EUR across all non-cancelled files
  grossMargin: number;           // (confirmedRevenue - costs on those files) / confirmedRevenue
  averageFileValue: number;      // confirmedRevenue / count of confirmed files with income

  // 12-month bar chart data
  monthly: Array<{
    month: string;      // "YYYY-MM"
    income: number;
    cost: number;
  }>;

  // File-type donut
  byFileType: Array<{
    fileType: string;
    income: number;
    count: number;
  }>;

  // Top 10 destinations
  topDestinations: Array<{
    destination: string;
    income: number;
    fileCount: number;
  }>;
};

export const revenueData = query({
  args: {},
  handler: async (ctx): Promise<RevenueData> => {
    await requireIdentity(ctx);

    // Load all non-cancelled files (bounded at 500)
    const allFiles = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date")
      .order("asc")
      .take(500);

    const activeFiles = allFiles.filter((f) => f.status !== "cancelled");
    const activeIds = new Set(activeFiles.map((f) => f._id));

    // Load all finance lines for active files
    // We batch by file to stay within query limits
    const allLines: Array<Doc<"financeLines">> = [];
    for (const file of activeFiles) {
      const lines = await ctx.db
        .query("financeLines")
        .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
        .collect();
      allLines.push(...lines);
    }

    const incomeLines = allLines.filter((l) => l.kind === "income");
    const costLines = allLines.filter((l) => l.kind === "cost");

    // Helper: EUR value
    const eur = (l: Doc<"financeLines">) => l.amount * l.exchangeRateToBase;

    // Map fileId → file for quick lookup
    const fileById = new Map(activeFiles.map((f) => [f._id, f]));

    // ── KPI cards ──────────────────────────────────────────────────────────────
    const confirmedStatuses = new Set(["confirmed", "operating", "closed"]);
    const pipelineStatuses = new Set(["enquiry", "quoted"]);

    const confirmedFiles = activeFiles.filter((f) => confirmedStatuses.has(f.status));
    const confirmedFileIds = new Set(confirmedFiles.map((f) => f._id));
    const pipelineFileIds = new Set(
      activeFiles.filter((f) => pipelineStatuses.has(f.status)).map((f) => f._id),
    );

    const confirmedRevenue = incomeLines
      .filter((l) => confirmedFileIds.has(l.groupFileId))
      .reduce((s, l) => s + eur(l), 0);

    const confirmedCosts = costLines
      .filter((l) => confirmedFileIds.has(l.groupFileId))
      .reduce((s, l) => s + eur(l), 0);

    const pipelineValue = incomeLines
      .filter((l) => pipelineFileIds.has(l.groupFileId))
      .reduce((s, l) => s + eur(l), 0);

    const totalCosts = costLines.reduce((s, l) => s + eur(l), 0);

    const grossMargin =
      confirmedRevenue > 0
        ? (confirmedRevenue - confirmedCosts) / confirmedRevenue
        : 0;

    const confirmedWithIncome = confirmedFiles.filter((f) =>
      incomeLines.some((l) => l.groupFileId === f._id),
    );
    const averageFileValue =
      confirmedWithIncome.length > 0
        ? confirmedRevenue / confirmedWithIncome.length
        : 0;

    // ── Monthly bar chart (last 12 months by file start date) ─────────────────
    const months = last12Months();
    const monthlyIncome: Record<string, number> = {};
    const monthlyCost: Record<string, number> = {};
    for (const m of months) {
      monthlyIncome[m] = 0;
      monthlyCost[m] = 0;
    }

    for (const l of incomeLines) {
      const file = fileById.get(l.groupFileId);
      if (!file) continue;
      const mk = monthKey(file.startDate);
      if (mk in monthlyIncome) monthlyIncome[mk] += eur(l);
    }
    for (const l of costLines) {
      const file = fileById.get(l.groupFileId);
      if (!file) continue;
      const mk = monthKey(file.startDate);
      if (mk in monthlyCost) monthlyCost[mk] += eur(l);
    }

    const monthly = months.map((m) => ({
      month: m,
      income: monthlyIncome[m] ?? 0,
      cost: monthlyCost[m] ?? 0,
    }));

    // ── By file type donut ────────────────────────────────────────────────────
    const typeMap = new Map<string, { income: number; count: number }>();
    for (const file of confirmedFiles) {
      if (!typeMap.has(file.fileType)) typeMap.set(file.fileType, { income: 0, count: 0 });
      const entry = typeMap.get(file.fileType)!;
      entry.count++;
    }
    for (const l of incomeLines.filter((l) => confirmedFileIds.has(l.groupFileId))) {
      const file = fileById.get(l.groupFileId);
      if (!file) continue;
      const entry = typeMap.get(file.fileType);
      if (entry) entry.income += eur(l);
    }
    const byFileType = Array.from(typeMap.entries())
      .map(([fileType, v]) => ({ fileType, ...v }))
      .sort((a, b) => b.income - a.income);

    // ── Top 10 destinations ───────────────────────────────────────────────────
    const destMap = new Map<string, { income: number; fileCount: number }>();
    for (const file of confirmedFiles) {
      const dest = file.destination;
      if (!destMap.has(dest)) destMap.set(dest, { income: 0, fileCount: 0 });
      destMap.get(dest)!.fileCount++;
    }
    for (const l of incomeLines.filter((l) => confirmedFileIds.has(l.groupFileId))) {
      const file = fileById.get(l.groupFileId);
      if (!file) continue;
      const entry = destMap.get(file.destination);
      if (entry) entry.income += eur(l);
    }
    const topDestinations = Array.from(destMap.entries())
      .map(([destination, v]) => ({ destination, ...v }))
      .sort((a, b) => b.income - a.income)
      .slice(0, 10);

    return {
      confirmedRevenue,
      pipelineValue,
      totalCosts,
      grossMargin,
      averageFileValue,
      monthly,
      byFileType,
      topDestinations,
    };
  },
});

// ── Pipeline & conversion query ───────────────────────────────────────────────

export type PipelineReportData = {
  // Funnel counts per stage
  funnel: Array<{
    status: string;
    label: string;
    count: number;
    conversionFromPrev: number | null; // % of previous stage that reached this one
  }>;

  // Cancelled / lost
  cancelledCount: number;
  cancelledPct: number; // % of all files ever created

  // Average age of files currently sitting in each stage (days since _creationTime)
  avgDaysInStage: Array<{
    status: string;
    label: string;
    avgDays: number;
  }>;

  // Stacked area: file counts by status per month (last 12 months by startDate)
  monthly: Array<{
    month: string;
    enquiry: number;
    quoted: number;
    confirmed: number;
    operating: number;
    closed: number;
    cancelled: number;
  }>;
};

const STAGE_ORDER = [
  { status: "enquiry", label: "Enquiry" },
  { status: "quoted", label: "Quoted" },
  { status: "confirmed", label: "Confirmed" },
  { status: "operating", label: "Operating" },
  { status: "closed", label: "Closed" },
] as const;

export const pipelineReportData = query({
  args: {},
  handler: async (ctx): Promise<PipelineReportData> => {
    await requireIdentity(ctx);

    // Load all files (bounded at 500)
    const allFiles = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date")
      .order("asc")
      .take(500);

    const total = allFiles.length;
    const cancelledFiles = allFiles.filter((f) => f.status === "cancelled");
    const cancelledCount = cancelledFiles.length;
    const cancelledPct = total > 0 ? (cancelledCount / total) * 100 : 0;

    // ── Funnel ────────────────────────────────────────────────────────────────
    // Count files that have EVER passed through each stage:
    // We approximate by counting files whose current status is at or past this stage.
    const stageRank: Record<string, number> = {
      enquiry: 0, quoted: 1, confirmed: 2, operating: 3, closed: 4,
    };
    const activeFiles = allFiles.filter((f) => f.status !== "cancelled");

    const stageCounts = STAGE_ORDER.map(({ status }) => {
      const rank = stageRank[status] ?? 0;
      return activeFiles.filter((f) => (stageRank[f.status] ?? -1) >= rank).length;
    });

    const funnel = STAGE_ORDER.map(({ status, label }, i) => ({
      status,
      label,
      count: stageCounts[i] ?? 0,
      conversionFromPrev:
        i === 0
          ? null
          : (stageCounts[i - 1] ?? 0) > 0
            ? ((stageCounts[i] ?? 0) / (stageCounts[i - 1] ?? 1)) * 100
            : null,
    }));

    // ── Avg days currently in each stage ──────────────────────────────────────
    const now = new Date().toISOString();
    const avgDaysInStage = STAGE_ORDER.map(({ status, label }) => {
      const filesInStage = activeFiles.filter((f) => f.status === status);
      if (filesInStage.length === 0) return { status, label, avgDays: 0 };
      const totalDays = filesInStage.reduce(
        (s, f) => s + daysBetween(new Date(f._creationTime).toISOString(), now),
        0,
      );
      return { status, label, avgDays: Math.round(totalDays / filesInStage.length) };
    });

    // ── Monthly stacked area (by file start date) ─────────────────────────────
    const months = last12Months();
    type MonthRow = { month: string; enquiry: number; quoted: number; confirmed: number; operating: number; closed: number; cancelled: number };
    const monthMap = new Map<string, MonthRow>(
      months.map((m) => [m, { month: m, enquiry: 0, quoted: 0, confirmed: 0, operating: 0, closed: 0, cancelled: 0 }]),
    );

    for (const f of allFiles) {
      const mk = monthKey(f.startDate);
      const row = monthMap.get(mk);
      if (!row) continue;
      const s = f.status as keyof Omit<MonthRow, "month">;
      if (s in row) (row[s] as number)++;
    }

    const monthly = months.map((m) => monthMap.get(m)!);

    return { funnel, cancelledCount, cancelledPct, avgDaysInStage, monthly };
  },
});

// ── Client revenue report ─────────────────────────────────────────────────────

export type ClientReportRow = {
  clientName: string;
  kind: "individual" | "company" | "unmatched";
  fileCount: number;
  totalIncomeEur: number;
  totalCostEur: number;
  marginEur: number;
  lastBookingDate: string;
};

export type ClientReportData = {
  rows: ClientReportRow[];
  totalIncomeEur: number;
};

/**
 * Revenue and margin grouped per client, rolling individual contacts up under
 * their parent company (same grouping used on the client detail page). Bounded
 * to the 500 most recent files and top 25 clients by revenue.
 */
export const clientReportData = query({
  args: {},
  handler: async (ctx): Promise<ClientReportData> => {
    await requireIdentity(ctx);

    const allClients = await ctx.db.query("clients").take(500);
    const clientByName = new Map(allClients.map((c) => [c.name.trim().toLowerCase(), c]));
    const clientById = new Map(allClients.map((c) => [c._id, c]));

    const allFiles = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date")
      .order("desc")
      .take(500);
    const activeFiles = allFiles.filter((f) => f.status !== "cancelled");

    type Agg = {
      clientName: string;
      kind: "individual" | "company" | "unmatched";
      fileCount: number;
      totalIncomeEur: number;
      totalCostEur: number;
      lastBookingDate: string;
    };
    const aggByKey = new Map<string, Agg>();

    for (const file of activeFiles) {
      const matched = clientByName.get(file.clientName.trim().toLowerCase());
      let groupKey = file.clientName;
      let kind: Agg["kind"] = "unmatched";
      if (matched) {
        if (matched.kind === "individual" && matched.parentClientId) {
          const parent = clientById.get(matched.parentClientId);
          groupKey = parent?.name ?? matched.name;
          kind = "company";
        } else {
          groupKey = matched.name;
          kind = matched.kind;
        }
      }

      const lines = await ctx.db
        .query("financeLines")
        .withIndex("by_group_file", (q) => q.eq("groupFileId", file._id))
        .collect();
      const incomeEur = lines
        .filter((l) => l.kind === "income")
        .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);
      const costEur = lines
        .filter((l) => l.kind === "cost")
        .reduce((s, l) => s + l.amount * l.exchangeRateToBase, 0);

      const key = groupKey.trim().toLowerCase();
      const existing = aggByKey.get(key);
      if (existing) {
        existing.fileCount++;
        existing.totalIncomeEur += incomeEur;
        existing.totalCostEur += costEur;
        if (file.startDate > existing.lastBookingDate) existing.lastBookingDate = file.startDate;
      } else {
        aggByKey.set(key, {
          clientName: groupKey,
          kind,
          fileCount: 1,
          totalIncomeEur: incomeEur,
          totalCostEur: costEur,
          lastBookingDate: file.startDate,
        });
      }
    }

    const rows: ClientReportRow[] = Array.from(aggByKey.values())
      .map((a) => ({
        clientName: a.clientName,
        kind: a.kind,
        fileCount: a.fileCount,
        totalIncomeEur: Math.round(a.totalIncomeEur),
        totalCostEur: Math.round(a.totalCostEur),
        marginEur: Math.round(a.totalIncomeEur - a.totalCostEur),
        lastBookingDate: a.lastBookingDate,
      }))
      .sort((a, b) => b.totalIncomeEur - a.totalIncomeEur)
      .slice(0, 25);

    return {
      rows,
      totalIncomeEur: Math.round(rows.reduce((s, r) => s + r.totalIncomeEur, 0)),
    };
  },
});

export type TeamMemberStats = {
  userId: string;
  name: string;
  email: string;
  // File counts by status
  totalFiles: number;
  enquiryFiles: number;
  quotedFiles: number;
  confirmedFiles: number;
  operatingFiles: number;
  closedFiles: number;
  cancelledFiles: number;
  // Revenue (EUR)
  confirmedRevenue: number;
  pipelineValue: number;
  // Conversion: enquiry/quoted → confirmed+operating+closed
  conversionRate: number | null; // null if no enquiry/quoted files
};

export type TeamReportData = {
  members: TeamMemberStats[];
};

export const teamReportData = query({
  args: {},
  handler: async (ctx): Promise<TeamReportData> => {
    await requireIdentity(ctx);

    // Load all files (bounded at 500)
    const allFiles = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date")
      .order("asc")
      .take(500);

    // Collect all unique owner IDs
    const ownerIds = [...new Set(allFiles.map((f) => f.ownerId))];

    // Fetch users in parallel
    const users = await Promise.all(ownerIds.map((id) => ctx.db.get(id)));

    // Build user lookup map
    const userMap = new Map<string, { name: string; email: string }>();
    for (let i = 0; i < ownerIds.length; i++) {
      const u = users[i];
      userMap.set(ownerIds[i], {
        name: u?.name ?? "Unknown",
        email: u?.email ?? "",
      });
    }

    // Load finance income lines for all files so we can sum revenue per owner
    // We need all income lines for files owned by each user.
    // Strategy: load all income lines (bounded), then group by file -> owner.
    const allIncomeLines = await ctx.db
      .query("financeLines")
      .withIndex("by_group_file_and_kind")
      .filter((q) => q.eq(q.field("kind"), "income"))
      .take(2000);

    // File id → owner id map
    const fileOwnerMap = new Map<string, string>(
      allFiles.map((f) => [f._id, f.ownerId]),
    );

    // Aggregate income per owner for confirmed/operating/closed (confirmed revenue)
    // and enquiry/quoted (pipeline value)
    const confirmedRevenueByOwner = new Map<string, number>();
    const pipelineValueByOwner = new Map<string, number>();
    const CONFIRMED_STATUSES = new Set(["confirmed", "operating", "closed"]);
    const PIPELINE_STATUSES = new Set(["enquiry", "quoted"]);

    for (const line of allIncomeLines) {
      const ownerId = fileOwnerMap.get(line.groupFileId);
      if (!ownerId) continue;
      const file = allFiles.find((f) => f._id === line.groupFileId);
      if (!file) continue;
      const eurVal = line.amount * line.exchangeRateToBase;
      if (CONFIRMED_STATUSES.has(file.status)) {
        confirmedRevenueByOwner.set(ownerId, (confirmedRevenueByOwner.get(ownerId) ?? 0) + eurVal);
      } else if (PIPELINE_STATUSES.has(file.status)) {
        pipelineValueByOwner.set(ownerId, (pipelineValueByOwner.get(ownerId) ?? 0) + eurVal);
      }
    }

    // Build per-member stats
    const members: TeamMemberStats[] = ownerIds.map((ownerId) => {
      const ownerFiles = allFiles.filter((f) => f.ownerId === ownerId);
      const byStatus = (s: string) => ownerFiles.filter((f) => f.status === s).length;

      const enquiryFiles = byStatus("enquiry");
      const quotedFiles = byStatus("quoted");
      const confirmedFiles = byStatus("confirmed");
      const operatingFiles = byStatus("operating");
      const closedFiles = byStatus("closed");
      const cancelledFiles = byStatus("cancelled");

      const topOfFunnel = enquiryFiles + quotedFiles + confirmedFiles + operatingFiles + closedFiles;
      const converted = confirmedFiles + operatingFiles + closedFiles;
      const conversionRate = topOfFunnel > 0 ? (converted / topOfFunnel) * 100 : null;

      return {
        userId: ownerId,
        name: userMap.get(ownerId)?.name ?? "Unknown",
        email: userMap.get(ownerId)?.email ?? "",
        totalFiles: ownerFiles.length,
        enquiryFiles,
        quotedFiles,
        confirmedFiles,
        operatingFiles,
        closedFiles,
        cancelledFiles,
        confirmedRevenue: confirmedRevenueByOwner.get(ownerId) ?? 0,
        pipelineValue: pipelineValueByOwner.get(ownerId) ?? 0,
        conversionRate,
      };
    });

    // Sort by confirmed revenue descending by default
    members.sort((a, b) => b.confirmedRevenue - a.confirmedRevenue);

    return { members };
  },
});

// ── Operational snapshot query ────────────────────────────────────────────────

export type OperationalFile = {
  _id: string;
  reference: string;
  title: string;
  clientName: string;
  destination: string;
  startDate: string;
  endDate: string;
  pax: number;
  status: string;
  daysUntilDeparture: number;
  // Tasks
  openTaskCount: number;
  overdueTaskCount: number;   // open/in_progress tasks with dueDate < today
};

export type OperationalSnapshotData = {
  // KPI counts
  departingIn30: number;   // files departing in next 30 days (non-cancelled)
  departingIn60: number;   // next 60 days
  departingIn90: number;   // next 90 days
  totalPaxIn30: number;
  totalPaxIn60: number;
  totalPaxIn90: number;
  operatingCount: number;  // files currently in Operating status

  // Upcoming departures (next 90 days, all non-cancelled)
  upcomingDepartures: OperationalFile[];

  // Files in Operating status (attention list)
  operatingFiles: OperationalFile[];
};

export const operationalSnapshot = query({
  args: {},
  handler: async (ctx): Promise<OperationalSnapshotData> => {
    await requireIdentity(ctx);

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString().slice(0, 10);

    const in90 = new Date(today);
    in90.setDate(in90.getDate() + 90);
    const in90Str = in90.toISOString().slice(0, 10);

    // Load files departing in next 90 days (non-cancelled) — use by_start_date index
    const upcomingRaw = await ctx.db
      .query("groupFiles")
      .withIndex("by_start_date", (q) =>
        q.gte("startDate", todayStr).lte("startDate", in90Str),
      )
      .order("asc")
      .take(200);

    const upcoming = upcomingRaw.filter((f) => f.status !== "cancelled");

    // Load files currently in Operating status (no start-date constraint)
    const operatingRaw = await ctx.db
      .query("groupFiles")
      .withIndex("by_status", (q) => q.eq("status", "operating"))
      .take(100);

    // Collect all relevant file IDs for task lookup
    const upcomingIds = new Set(upcoming.map((f) => f._id));
    const operatingIds = new Set(operatingRaw.map((f) => f._id));
    const allIds = [...new Set([...upcomingIds, ...operatingIds])];

    // Load open/in_progress tasks for these files
    // Tasks are indexed by_group_file — we fetch per-file
    type TaskSummary = { open: number; overdue: number };
    const taskSummaryMap = new Map<string, TaskSummary>();

    await Promise.all(
      allIds.map(async (fileId) => {
        const fileTasks = await ctx.db
          .query("tasks")
          .withIndex("by_group_file", (q) => q.eq("groupFileId", fileId))
          .filter((q) =>
            q.or(
              q.eq(q.field("status"), "open"),
              q.eq(q.field("status"), "in_progress"),
            ),
          )
          .collect();

        const openCount = fileTasks.length;
        const overdueCount = fileTasks.filter(
          (t) => t.dueDate && t.dueDate < todayStr,
        ).length;

        taskSummaryMap.set(fileId, { open: openCount, overdue: overdueCount });
      }),
    );

    function toOpFile(f: (typeof upcoming)[number]): OperationalFile {
      const daysUntil = daysBetween(todayStr, f.startDate);
      const tasks = taskSummaryMap.get(f._id) ?? { open: 0, overdue: 0 };
      return {
        _id: f._id,
        reference: f.reference,
        title: f.title,
        clientName: f.clientName,
        destination: f.destination,
        startDate: f.startDate,
        endDate: f.endDate,
        pax: f.pax,
        status: f.status,
        daysUntilDeparture: daysUntil,
        openTaskCount: tasks.open,
        overdueTaskCount: tasks.overdue,
      };
    }

    const upcomingFiles = upcoming.map(toOpFile);
    const operatingFiles = operatingRaw.map(toOpFile);

    // KPI aggregation
    const d30 = upcomingFiles.filter((f) => f.daysUntilDeparture <= 30);
    const d60 = upcomingFiles.filter((f) => f.daysUntilDeparture <= 60);
    const d90 = upcomingFiles; // already filtered to ≤90

    return {
      departingIn30: d30.length,
      departingIn60: d60.length,
      departingIn90: d90.length,
      totalPaxIn30: d30.reduce((s, f) => s + f.pax, 0),
      totalPaxIn60: d60.reduce((s, f) => s + f.pax, 0),
      totalPaxIn90: d90.reduce((s, f) => s + f.pax, 0),
      operatingCount: operatingRaw.length,
      upcomingDepartures: upcomingFiles,
      operatingFiles,
    };
  },
});
