import { ConvexError, v } from "convex/values";
import {
  mutation,
  query,
  internalQuery,
  internalMutation,
} from "./_generated/server";
import { internal } from "./_generated/api";
import type { Doc, Id } from "./_generated/dataModel";
import type { MutationCtx } from "./_generated/server";
import { logActivity } from "./activityLog.ts";
import { broadcastNotification } from "./notifications.ts";
import { requireIdentity, requireUser } from "./lib/auth.ts";
import { modificationRequestKindValidator } from "./schema/modificationRequests.ts";
import { isFileLocked } from "./lib/reservationLock.ts";

/**
 * Shared validation + insert logic for both the public client-submitted flow
 * and the staff in-system flow. Both funnel into the exact same hotel
 * approve/decline email — staff get no shortcut to apply changes directly.
 */
async function createModificationRequest(
  ctx: MutationCtx,
  args: {
    groupFileId: Id<"groupFiles">;
    reservationId: Id<"reservations">;
    kind: "units" | "other";
    requestedUnits?: number;
    message: string;
    appOrigin: string;
    submittedBy: "client" | "staff";
  },
): Promise<{ id: Id<"modificationRequests"> }> {
  const message = args.message.trim();
  if (args.kind === "other" && !message) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: "Please describe the change you'd like to request.",
    });
  }
  if (args.kind === "units") {
    if (
      args.requestedUnits === undefined ||
      !Number.isInteger(args.requestedUnits) ||
      args.requestedUnits < 0
    ) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "Enter a valid number of rooms/units.",
      });
    }
  }

  const reservation = await ctx.db.get("reservations", args.reservationId);
  if (!reservation || reservation.groupFileId !== args.groupFileId) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Reservation not found." });
  }
  if (args.kind === "units" && args.requestedUnits === reservation.units) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: "That's already the currently booked quantity.",
    });
  }

  const file = await ctx.db.get("groupFiles", args.groupFileId);
  if (!file) {
    throw new ConvexError({ code: "NOT_FOUND", message: "Booking not found." });
  }
  if (isFileLocked(file)) {
    throw new ConvexError({
      code: "FORBIDDEN",
      message:
        "This booking is locked for full payment and can no longer be changed. Please contact your travel team.",
    });
  }

  let hotelContactEmail: string | undefined;
  if (reservation.hotelId) {
    const hotel = await ctx.db.get("hotels", reservation.hotelId);
    hotelContactEmail = hotel?.contactEmail;
  }

  const status: Doc<"modificationRequests">["status"] = hotelContactEmail
    ? "pending_hotel"
    : "no_hotel_contact";

  const summaryMessage =
    args.kind === "units"
      ? `Change ${reservation.unitLabel || "units"} from ${reservation.units} to ${args.requestedUnits}${message ? ` — ${message}` : ""}`
      : message;

  const id = await ctx.db.insert("modificationRequests", {
    groupFileId: args.groupFileId,
    reservationId: args.reservationId,
    submittedBy: args.submittedBy,
    appOrigin: args.appOrigin,
    supplierName: reservation.supplierName,
    reservationDescription: reservation.description,
    kind: args.kind,
    previousUnits: args.kind === "units" ? reservation.units : undefined,
    requestedUnits: args.kind === "units" ? args.requestedUnits : undefined,
    unitLabel: args.kind === "units" ? reservation.unitLabel : undefined,
    message: summaryMessage,
    status,
    hotelId: reservation.hotelId,
    hotelContactEmail,
    createdAt: new Date().toISOString(),
  });

  await logActivity(ctx, {
    groupFileId: args.groupFileId,
    action: "modification_requested",
    description: `${args.submittedBy === "staff" ? "Staff" : "Client"} requested a change to "${reservation.supplierName}": ${summaryMessage}`,
    // System-attributed on behalf of the client — attribute to the file owner.
    user: await requireSystemUser(ctx, file),
  });

  if (hotelContactEmail) {
    await ctx.scheduler.runAfter(0, internal.email.send.sendModificationRequestToHotel, {
      requestId: id,
      appOrigin: args.appOrigin,
    });
  } else {
    // No automated recipient — alert staff so they can route it manually.
    await broadcastNotification(ctx, {
      type: "modification_requested",
      title: "Change requested — needs manual routing",
      body: `${args.submittedBy === "staff" ? "A team member" : file.clientName} requested a change to "${reservation.supplierName}" (${file.reference}), but it has no linked hotel contact. Please follow up manually.`,
      linkTo: `/files/${args.groupFileId}`,
      relatedId: `modreq:${id}`,
    });
  }

  return { id };
}

// ── Public: client submits a change request from the confirmation page ───────

export const submitPublic = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    reservationId: v.id("reservations"),
    kind: modificationRequestKindValidator,
    // Required when kind === "units": the newly requested booked quantity.
    requestedUnits: v.optional(v.number()),
    // Free text: required for kind "other", optional extra note for "units".
    message: v.string(),
    appOrigin: v.string(),
  },
  handler: async (ctx, args): Promise<{ id: Id<"modificationRequests"> }> => {
    return await createModificationRequest(ctx, { ...args, submittedBy: "client" });
  },
});

// ── Staff: request a change to a confirmed reservation from the back office ──
// Staff get no shortcut around hotel approval — any change to a confirmed
// reservation funnels through the exact same hotel email flow as a client
// request, and only auto-applies once the hotel approves.

export const submitByStaff = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    reservationId: v.id("reservations"),
    kind: modificationRequestKindValidator,
    requestedUnits: v.optional(v.number()),
    message: v.string(),
    appOrigin: v.string(),
  },
  handler: async (ctx, args): Promise<{ id: Id<"modificationRequests"> }> => {
    await requireUser(ctx);
    return await createModificationRequest(ctx, { ...args, submittedBy: "staff" });
  },
});


/** Attribute client-originated activity to the file's owner (or creator). */
async function requireSystemUser(
  ctx: { db: { get: (t: "users", id: Id<"users">) => Promise<Doc<"users"> | null> } },
  file: Doc<"groupFiles">,
): Promise<Doc<"users">> {
  const owner = await ctx.db.get("users", file.ownerId);
  if (owner) return owner;
  const creator = await ctx.db.get("users", file.createdById);
  if (creator) return creator;
  throw new ConvexError({ code: "NOT_FOUND", message: "No user to attribute this activity to." });
}

/** Sanitized list of modification requests for the public confirmation page. */
export const listByFilePublic = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (
    ctx,
    args,
  ): Promise<
    Array<{
      _id: Id<"modificationRequests">;
      reservationId: Id<"reservations">;
      status: Doc<"modificationRequests">["status"];
      message: string;
      createdAt: string;
    }>
  > => {
    const requests = await ctx.db
      .query("modificationRequests")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .collect();
    return requests.map((r) => ({
      _id: r._id,
      reservationId: r.reservationId,
      status: r.status,
      message: r.message,
      createdAt: r.createdAt,
    }));
  },
});

// ── Internal: staff-visible list ──────────────────────────────────────────────

export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<Doc<"modificationRequests">[]> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("modificationRequests")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("desc")
      .collect();
  },
});

// ── Internal: fetch everything the email action needs ────────────────────────

export const getForEmail = internalQuery({
  args: { requestId: v.id("modificationRequests") },
  handler: async (
    ctx,
    args,
  ): Promise<{
    request: Doc<"modificationRequests">;
    file: Doc<"groupFiles">;
    hotelName: string;
  } | null> => {
    const request = await ctx.db.get("modificationRequests", args.requestId);
    if (!request) return null;
    const file = await ctx.db.get("groupFiles", request.groupFileId);
    if (!file) return null;
    const hotel = request.hotelId ? await ctx.db.get("hotels", request.hotelId) : null;
    return { request, file, hotelName: hotel?.name ?? request.supplierName };
  },
});

export const markEmailSent = internalMutation({
  args: { requestId: v.id("modificationRequests") },
  handler: async (ctx, args) => {
    await ctx.db.patch("modificationRequests", args.requestId, {
      hotelEmailSentAt: new Date().toISOString(),
      followUpDismissedAt: undefined,
    });
  },
});

// ── Staff: resend the hotel approval email for a pending request ─────────────

/**
 * Staff-triggered resend of the approve/decline email for a request still
 * pending the hotel's response. Reuses the exact same email action as the
 * original auto-send. Restarts the "pending response" follow-up clock via
 * markEmailSent.
 */
export const resendToHotel = mutation({
  args: { requestId: v.id("modificationRequests") },
  handler: async (ctx, args): Promise<null> => {
    await requireUser(ctx);
    const request = await ctx.db.get("modificationRequests", args.requestId);
    if (!request) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Request not found." });
    }
    if (request.status !== "pending_hotel") {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "This request is no longer waiting on the hotel.",
      });
    }
    if (!request.hotelContactEmail || !request.appOrigin) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "This request has no hotel contact email to resend to.",
      });
    }
    await ctx.scheduler.runAfter(0, internal.email.send.sendModificationRequestToHotel, {
      requestId: args.requestId,
      appOrigin: request.appOrigin,
    });
    return null;
  },
});

// ── Staff: dismiss/snooze the "pending response" follow-up flag ─────────────

export const dismissFollowUp = mutation({
  args: { requestId: v.id("modificationRequests") },
  handler: async (ctx, args): Promise<null> => {
    await requireUser(ctx);
    const request = await ctx.db.get("modificationRequests", args.requestId);
    if (!request) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Request not found." });
    }
    await ctx.db.patch("modificationRequests", args.requestId, {
      followUpDismissedAt: new Date().toISOString(),
    });
    return null;
  },
});

// ── Public: hotel response page ───────────────────────────────────────────────

export const getPublicForResponse = query({
  args: { requestId: v.id("modificationRequests") },
  handler: async (
    ctx,
    args,
  ): Promise<{
    request: Doc<"modificationRequests">;
    fileTitle: string;
    fileReference: string;
    destination: string;
  } | null> => {
    const request = await ctx.db.get("modificationRequests", args.requestId);
    if (!request) return null;
    const file = await ctx.db.get("groupFiles", request.groupFileId);
    if (!file) return null;
    return {
      request,
      fileTitle: file.title,
      fileReference: file.reference,
      destination: file.destination,
    };
  },
});

/**
 * Applies an approved "units" request to the reservation (updates the booked
 * quantity) and books the resulting cost/income delta as new finance lines,
 * using the reservation's existing cost/rate per unit and the file's default
 * markup % (for income, when no sell rate is set). No-ops for kind "other"
 * beyond appending the approved note to the reservation, since free text
 * can't be applied automatically.
 */
async function applyApprovedChange(
  ctx: MutationCtx,
  request: Doc<"modificationRequests">,
): Promise<Id<"financeLines">[]> {
  const reservation = await ctx.db.get("reservations", request.reservationId);
  if (!reservation) return [];
  const file = await ctx.db.get("groupFiles", request.groupFileId);
  if (!file) return [];

  const createdFinanceLineIds: Id<"financeLines">[] = [];
  const user = await requireSystemUser(ctx, file);

  if (
    request.kind === "units" &&
    request.requestedUnits !== undefined &&
    request.previousUnits !== undefined &&
    request.requestedUnits !== request.previousUnits
  ) {
    const unitDelta = request.requestedUnits - request.previousUnits;

    await ctx.db.patch("reservations", reservation._id, {
      units: request.requestedUnits,
    });

    // Only book a cost/income impact when the reservation has rates set —
    // otherwise there's nothing to calculate automatically.
    if (reservation.costPerUnit !== undefined && unitDelta !== 0) {
      const costAmount = reservation.costPerUnit * unitDelta;
      const label = reservation.unitLabel || "units";
      const description = `${reservation.supplierName} — ${unitDelta > 0 ? "added" : "removed"} ${Math.abs(unitDelta)} ${label} (approved change)`;

      const costLineId = await ctx.db.insert("financeLines", {
        groupFileId: request.groupFileId,
        kind: "cost",
        category: "other",
        description,
        supplierName: reservation.supplierName,
        amount: costAmount,
        currency: reservation.currency,
        exchangeRateToBase: file.exchangeRateToBase,
        notes: `Auto-generated from approved modification request.`,
        createdById: user._id,
      });
      createdFinanceLineIds.push(costLineId);

      await logActivity(ctx, {
        groupFileId: request.groupFileId,
        action: "finance_line_added",
        description: `Added cost line "${description}" (${reservation.currency} ${costAmount.toFixed(2)})`,
        user,
      });

      // Mirror an income line using the sell rate if set, otherwise the
      // file's default markup % on top of cost.
      const sellRatePerUnit =
        reservation.ratePerUnit ??
        reservation.costPerUnit * (1 + (file.markupPercent ?? 0) / 100);
      const incomeAmount = sellRatePerUnit * unitDelta;
      const incomeDescription = `${reservation.supplierName} — ${unitDelta > 0 ? "added" : "removed"} ${Math.abs(unitDelta)} ${label} (approved change)`;

      const incomeLineId = await ctx.db.insert("financeLines", {
        groupFileId: request.groupFileId,
        kind: "income",
        category: "client-payment",
        description: incomeDescription,
        supplierName: reservation.supplierName,
        amount: incomeAmount,
        currency: reservation.currency,
        exchangeRateToBase: file.exchangeRateToBase,
        notes: `Auto-generated from approved modification request.`,
        createdById: user._id,
      });
      createdFinanceLineIds.push(incomeLineId);

      await logActivity(ctx, {
        groupFileId: request.groupFileId,
        action: "finance_line_added",
        description: `Added income line "${incomeDescription}" (${reservation.currency} ${incomeAmount.toFixed(2)})`,
        user,
      });
    }
  } else if (request.kind === "other") {
    // Free text can't be parsed automatically — append it to the
    // reservation's notes so staff see it was approved, without guessing at
    // what to change.
    const note = `Client change approved by ${request.supplierName}: ${request.message}`;
    const nextNotes = reservation.notes ? `${reservation.notes}\n${note}` : note;
    await ctx.db.patch("reservations", reservation._id, { notes: nextNotes });
  }

  return createdFinanceLineIds;
}

export const respondPublic = mutation({
  args: {
    requestId: v.id("modificationRequests"),
    decision: v.union(v.literal("approved"), v.literal("declined")),
    responseNote: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<null> => {
    const request = await ctx.db.get("modificationRequests", args.requestId);
    if (!request) {
      throw new ConvexError({ code: "NOT_FOUND", message: "Request not found." });
    }
    if (request.status === "approved" || request.status === "declined") {
      throw new ConvexError({
        code: "CONFLICT",
        message: "This request has already been responded to.",
      });
    }

    await ctx.db.patch("modificationRequests", args.requestId, {
      status: args.decision,
      respondedAt: new Date().toISOString(),
      responseNote: args.responseNote?.trim() || undefined,
    });

    const file = await ctx.db.get("groupFiles", request.groupFileId);
    if (file) {
      const user = await requireSystemUser(ctx, file);
      await logActivity(ctx, {
        groupFileId: request.groupFileId,
        action: args.decision === "approved" ? "modification_approved" : "modification_declined",
        description: `${request.supplierName} ${args.decision} the requested change: ${request.message}`,
        user,
      });

      let createdFinanceLineIds: Id<"financeLines">[] = [];
      if (args.decision === "approved") {
        createdFinanceLineIds = await applyApprovedChange(ctx, request);
        await ctx.db.patch("modificationRequests", args.requestId, {
          appliedAt: new Date().toISOString(),
          createdFinanceLineIds:
            createdFinanceLineIds.length > 0 ? createdFinanceLineIds : undefined,
        });

        // Let the client know their trip changed, with a fresh link to the
        // confirmation page reflecting the update — regardless of whether
        // the change was requested by them or by staff.
        if (file.clientContactEmail && request.appOrigin) {
          await ctx.scheduler.runAfter(0, internal.email.send.sendConfirmationUpdated, {
            groupFileId: request.groupFileId,
            appOrigin: request.appOrigin,
            supplierName: request.supplierName,
          });
        }
      }

      await broadcastNotification(ctx, {
        type: "modification_responded",
        title:
          args.decision === "approved"
            ? "Hotel approved a modification"
            : "Hotel declined a modification",
        body:
          args.decision === "approved" && createdFinanceLineIds.length > 0
            ? `${request.supplierName} approved the change for ${file.reference}. The reservation and finance lines were updated automatically.`
            : `${request.supplierName} ${args.decision} the change requested for ${file.reference}: "${request.message}"`,
        linkTo: `/files/${request.groupFileId}`,
        relatedId: `modreq:${request._id}`,
      });
    }

    return null;
  },
});
