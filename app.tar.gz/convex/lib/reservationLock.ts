import { ConvexError } from "convex/values";
import type { Doc } from "../_generated/dataModel";

/**
 * A group file's reservations are fully locked once finance has explicitly
 * closed the file for full payment in/out. Locking is a manual finance
 * action (never automatic from the travel date passing) — once locked,
 * existing reservations can no longer be edited, deleted, or have their
 * status changed. New reservations and credit-note finance lines can still
 * be added.
 */
export function isFileLocked(file: Doc<"groupFiles">): boolean {
  return file.financeLocked === true;
}

export function requireFileNotLocked(file: Doc<"groupFiles">): void {
  if (isFileLocked(file)) {
    throw new ConvexError({
      code: "FORBIDDEN",
      message:
        "This file is locked for full payment. Add a new item or a credit note instead of editing existing ones.",
    });
  }
}

/**
 * Once a reservation is confirmed, direct edits/removal are no longer
 * accepted from staff — every change (staff or client) must go through the
 * "Request a change" flow so the hotel approves before anything is applied.
 * This mirrors the client confirmation page's own restriction and keeps a
 * single source of truth: the hotel approval, not who is editing.
 */
export function requireReservationDirectlyEditable(reservation: Doc<"reservations">): void {
  if (reservation.status === "confirmed") {
    throw new ConvexError({
      code: "FORBIDDEN",
      message:
        "This reservation is confirmed. Use \"Request a change\" to send it to the hotel for approval instead of editing it directly.",
    });
  }
}
