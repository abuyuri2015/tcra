import type { MutationCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import type { Infer } from "convex/values";
import type { reservationTypeValidator } from "../schema/reservations.ts";
import type { currencyValidator } from "../schema/groupFiles.ts";

type ServiceType = Infer<typeof reservationTypeValidator>;
type Currency = Infer<typeof currencyValidator>;

/**
 * Keeps the reusable Suppliers / Hotels databases in sync with reservations
 * and offers entered by hand. Whenever staff type a brand-new supplier or
 * hotel name that isn't in the database yet, it's added automatically so it
 * shows up (and can be enriched later) on the Suppliers / Hotels pages.
 *
 * For hotel-type services: looks up an existing hotel by exact name match. If
 * none exists, creates a minimal hotel record and returns its id so the
 * reservation/offer stays linked to it. If a hotelId is already provided
 * (picked from the database), it's returned unchanged.
 *
 * For every other service type: ensures a matching supplier record exists in
 * the same category, creating one if not. Does not affect hotelId.
 */
export async function ensureSupplierOrHotelLinked(
  ctx: MutationCtx,
  args: {
    type: ServiceType;
    supplierName: string;
    hotelId?: Id<"hotels">;
    currency: Currency;
    createdById: Id<"users">;
  },
): Promise<Id<"hotels"> | undefined> {
  const name = args.supplierName.trim();
  if (!name) return args.hotelId;

  if (args.type === "hotel") {
    if (args.hotelId) return args.hotelId;

    const searchName = name.toLowerCase();
    const existing = await ctx.db
      .query("hotels")
      .withIndex("by_search_name", (q) => q.eq("searchName", searchName))
      .first();
    if (existing) return existing._id;

    return await ctx.db.insert("hotels", {
      name,
      searchName,
      category: "4-star",
      status: "active",
      city: "",
      country: "",
      currency: args.currency,
      imageUrls: [],
      amenities: [],
      createdById: args.createdById,
    });
  }

  const lower = name.toLowerCase();
  const existingSuppliers = await ctx.db
    .query("suppliers")
    .withIndex("by_category", (q) => q.eq("category", args.type))
    .take(1000);
  const match = existingSuppliers.some((s) => s.name.trim().toLowerCase() === lower);
  if (!match) {
    await ctx.db.insert("suppliers", {
      name,
      category: args.type,
      createdById: args.createdById,
    });
  }
  return args.hotelId;
}
