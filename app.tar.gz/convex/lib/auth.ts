import { ConvexError } from "convex/values";
import type { UserIdentity } from "convex/server";
import type { Doc, Id } from "../_generated/dataModel";
import type { MutationCtx, QueryCtx } from "../_generated/server";

/** Ensures a request is authenticated and returns the raw identity. */
export async function requireIdentity(
  ctx: QueryCtx | MutationCtx,
): Promise<UserIdentity> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({
      code: "UNAUTHENTICATED",
      message: "You must be signed in.",
    });
  }
  return identity;
}

/**
 * Returns the signed-in user document for a mutation, creating it on the fly if
 * the auth callback sync has not run yet.
 */
export async function requireUser(ctx: MutationCtx): Promise<Doc<"users">> {
  const identity = await requireIdentity(ctx);
  const existing = await ctx.db
    .query("users")
    .withIndex("by_token", (q) =>
      q.eq("tokenIdentifier", identity.tokenIdentifier),
    )
    .unique();
  if (existing) return existing;

  const id = await ctx.db.insert("users", {
    tokenIdentifier: identity.tokenIdentifier,
    name: identity.name,
    email: identity.email,
  });
  const created = await ctx.db.get("users", id);
  if (!created) {
    throw new ConvexError({
      code: "NOT_FOUND",
      message: "Could not create your user record.",
    });
  }
  return created;
}

export async function requireGroupFile(
  ctx: QueryCtx | MutationCtx,
  id: Id<"groupFiles">,
): Promise<Doc<"groupFiles">> {
  const file = await ctx.db.get("groupFiles", id);
  if (!file) {
    throw new ConvexError({
      code: "NOT_FOUND",
      message: "Group file not found.",
    });
  }
  return file;
}
