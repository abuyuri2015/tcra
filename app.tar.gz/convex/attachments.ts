import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import { requireIdentity, requireUser, requireGroupFile } from "./lib/auth.ts";
import type { Id } from "./_generated/dataModel.js";
import { logActivity } from "./activityLog.ts";

// ── Queries ───────────────────────────────────────────────────────────────────

export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args): Promise<
    Array<{
      _id: Id<"groupFileAttachments">;
      _creationTime: number;
      groupFileId: Id<"groupFiles">;
      storageId: Id<"_storage">;
      filename: string;
      contentType: string;
      size: number;
      uploadedById: Id<"users">;
      url: string | null;
    }>
  > => {
    await requireIdentity(ctx);
    const attachments = await ctx.db
      .query("groupFileAttachments")
      .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
      .order("desc")
      .collect();

    return await Promise.all(
      attachments.map(async (a) => ({
        ...a,
        url: await ctx.storage.getUrl(a.storageId),
      })),
    );
  },
});

/**
 * Resolves a storage ID to a fetchable URL. Used for transient uploads (e.g. the
 * AI file wizard) that aren't yet attached to a group file.
 */
export const resolveUploadUrl = query({
  args: { storageId: v.id("_storage") },
  handler: async (ctx, args): Promise<string | null> => {
    await requireIdentity(ctx);
    return await ctx.storage.getUrl(args.storageId);
  },
});

// ── Mutations ─────────────────────────────────────────────────────────────────

/** Step 1: generate a short-lived upload URL. */
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx): Promise<string> => {
    await requireUser(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

/** Step 3: save the storage ID + metadata returned after the POST upload. */
export const saveAttachment = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    storageId: v.id("_storage"),
    filename: v.string(),
    contentType: v.string(),
    size: v.number(),
  },
  handler: async (ctx, args): Promise<Id<"groupFileAttachments">> => {
    const user = await requireUser(ctx);
    await requireGroupFile(ctx, args.groupFileId);
    const id = await ctx.db.insert("groupFileAttachments", {
      groupFileId: args.groupFileId,
      storageId: args.storageId,
      filename: args.filename,
      contentType: args.contentType,
      size: args.size,
      uploadedById: user._id,
    });

    await logActivity(ctx, {
      groupFileId: args.groupFileId,
      action: "attachment_added",
      description: `Uploaded "${args.filename}"`,
      user,
    });

    return id;
  },
});

export const remove = mutation({
  args: { id: v.id("groupFileAttachments") },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const attachment = await ctx.db.get("groupFileAttachments", args.id);
    if (!attachment) {
      throw new ConvexError({ message: "Attachment not found", code: "NOT_FOUND" });
    }

    await logActivity(ctx, {
      groupFileId: attachment.groupFileId,
      action: "attachment_removed",
      description: `Deleted "${attachment.filename}"`,
      user,
    });

    await ctx.storage.delete(attachment.storageId);
    await ctx.db.delete("groupFileAttachments", args.id);
    return null;
  },
});
