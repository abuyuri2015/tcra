import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

async function setupFileWithOffer(t: ReturnType<typeof convexTest>) {
  const asUser = t.withIdentity({ name: "Ada" });

  const groupFileId = await asUser.mutation(api.groupFiles.create, {
    title: "Test Trip",
    fileType: "group",
    status: "confirmed",
    clientName: "Acme Co",
    destination: "Paris",
    startDate: "2027-01-01T00:00:00.000Z",
    endDate: "2027-01-05T00:00:00.000Z",
    pax: 10,
    currency: "EUR",
    exchangeRateToBase: 1,
    markupPercent: 20,
  });

  const offerId = await asUser.mutation(api.offers.create, {
    groupFileId,
    type: "hotel",
    status: "pending",
    supplierName: "Test Hotel",
    description: "Double room",
    startDate: "2027-01-01T00:00:00.000Z",
    units: 10,
    unitLabel: "rooms",
    costPerUnit: 100,
    currency: "EUR",
  });

  return { asUser, groupFileId, offerId };
}

describe("accepting an offer auto-books it as a reservation with cost/income lines", () => {
  it("converts the offer to a reservation and adds cost/income lines using the sell rate when set", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const groupFileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "confirmed",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    const offerId = await asUser.mutation(api.offers.create, {
      groupFileId,
      type: "hotel",
      status: "pending",
      supplierName: "Test Hotel",
      description: "Double room",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 10,
      unitLabel: "rooms",
      costPerUnit: 100,
      ratePerUnit: 130,
      currency: "EUR",
    });

    await asUser.mutation(api.offers.setStatus, { id: offerId, status: "accepted" });

    const offers = await asUser.query(api.offers.listByFile, { groupFileId });
    const offer = offers.find((o) => o._id === offerId);
    expect(offer?.status).toBe("accepted");
    expect(offer?.convertedReservationId).toBeDefined();

    const reservations = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservations).toHaveLength(1);
    expect(reservations[0]?.supplierName).toBe("Test Hotel");
    expect(reservations[0]?.units).toBe(10);

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    const costLine = lines.find((l) => l.kind === "cost");
    const incomeLine = lines.find((l) => l.kind === "income");
    expect(costLine?.amount).toBe(1000); // 10 rooms * 100 cost/unit
    expect(incomeLine?.amount).toBe(1300); // 10 rooms * 130 rate/unit

    // The breakdown fields let clients see how the amount was calculated.
    expect(costLine?.unitRate).toBe(100);
    expect(costLine?.quantity).toBe(10);
    expect(costLine?.quantityLabel).toBe("rooms");
    expect(incomeLine?.unitRate).toBe(130);
    expect(incomeLine?.quantity).toBe(10);
    expect(incomeLine?.quantityLabel).toBe("rooms");
  });

  it("falls back to the file's default markup % when the offer has no sell rate", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, offerId } = await setupFileWithOffer(t);

    await asUser.mutation(api.offers.setStatus, { id: offerId, status: "accepted" });

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    const costLine = lines.find((l) => l.kind === "cost");
    const incomeLine = lines.find((l) => l.kind === "income");
    expect(costLine?.amount).toBe(1000); // 10 rooms * 100 cost/unit
    expect(incomeLine?.amount).toBe(1200); // 10 rooms * (100 * 1.20) sell/unit
  });

  it("does not create finance lines when the offer has no cost per unit", async () => {
    const t = convexTest(schema, modules);
    const asUser = t.withIdentity({ name: "Ada" });

    const groupFileId = await asUser.mutation(api.groupFiles.create, {
      title: "Test Trip",
      fileType: "group",
      status: "confirmed",
      clientName: "Acme Co",
      destination: "Paris",
      startDate: "2027-01-01T00:00:00.000Z",
      endDate: "2027-01-05T00:00:00.000Z",
      pax: 10,
      currency: "EUR",
      exchangeRateToBase: 1,
    });

    const offerId = await asUser.mutation(api.offers.create, {
      groupFileId,
      type: "other",
      status: "pending",
      supplierName: "Mystery vendor",
      description: "TBD service",
      startDate: "2027-01-01T00:00:00.000Z",
      units: 1,
      currency: "EUR",
    });

    await asUser.mutation(api.offers.setStatus, { id: offerId, status: "accepted" });

    const reservations = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservations).toHaveLength(1);

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    expect(lines).toHaveLength(0);
  });

  it("does not double-book finance lines when setStatus is called again after conversion", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, offerId } = await setupFileWithOffer(t);

    await asUser.mutation(api.offers.setStatus, { id: offerId, status: "accepted" });

    await expect(
      asUser.mutation(api.offers.setStatus, { id: offerId, status: "accepted" }),
    ).rejects.toThrow();

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    expect(lines).toHaveLength(2);
  });
});
