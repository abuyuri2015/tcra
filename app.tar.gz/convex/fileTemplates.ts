import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { requireIdentity, requireUser } from "./lib/auth.ts";
import {
  currencyValidator,
  groupFileTypeValidator,
} from "./schema/groupFiles.ts";
import { itineraryItemTypeValidator } from "./schema/itinerary.ts";

// ── Validators ───────────────────────────────────────────────────────────────

const templateItineraryItemV = v.object({
  sortOrder: v.number(),
  type: itineraryItemTypeValidator,
  time: v.optional(v.string()),
  title: v.string(),
  description: v.optional(v.string()),
  location: v.optional(v.string()),
  notes: v.optional(v.string()),
});

const templateItineraryDayV = v.object({
  dayNumber: v.number(),
  title: v.optional(v.string()),
  notes: v.optional(v.string()),
  items: v.array(templateItineraryItemV),
});

const templateFinanceLineV = v.object({
  kind: v.union(v.literal("cost"), v.literal("income")),
  category: v.string(),
  description: v.string(),
  notes: v.optional(v.string()),
});

// ── Queries ──────────────────────────────────────────────────────────────────

/** List all templates, most recent first. */
export const list = query({
  args: {},
  handler: async (ctx): Promise<Doc<"fileTemplates">[]> => {
    await requireIdentity(ctx);
    return await ctx.db
      .query("fileTemplates")
      .order("desc")
      .take(100);
  },
});

export const get = query({
  args: { id: v.id("fileTemplates") },
  handler: async (ctx, args): Promise<Doc<"fileTemplates"> | null> => {
    await requireIdentity(ctx);
    return await ctx.db.get(args.id);
  },
});

// ── Mutations ────────────────────────────────────────────────────────────────

/** Save a group file as a reusable template. */
export const saveFromFile = mutation({
  args: {
    groupFileId: v.id("groupFiles"),
    name: v.string(),
    description: v.optional(v.string()),
    includeItinerary: v.boolean(),
    includeFinanceLines: v.boolean(),
  },
  handler: async (ctx, args): Promise<Id<"fileTemplates">> => {
    const user = await requireUser(ctx);
    const file = await ctx.db.get(args.groupFileId);
    if (!file) throw new ConvexError({ code: "NOT_FOUND", message: "Group file not found." });

    const name = args.name.trim();
    if (!name) throw new ConvexError({ code: "BAD_REQUEST", message: "Template name is required." });

    // Snapshot itinerary days + items
    let itineraryDays: Doc<"fileTemplates">["itineraryDays"] = [];
    if (args.includeItinerary) {
      const days = await ctx.db
        .query("itineraryDays")
        .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
        .order("asc")
        .collect();

      itineraryDays = await Promise.all(
        days.map(async (day) => {
          const items = await ctx.db
            .query("itineraryItems")
            .withIndex("by_day_and_order", (q) => q.eq("dayId", day._id))
            .order("asc")
            .collect();
          return {
            dayNumber: day.dayNumber,
            title: day.title,
            notes: day.notes,
            items: items.map((item) => ({
              sortOrder: item.sortOrder,
              type: item.type,
              time: item.time,
              title: item.title,
              description: item.description,
              location: item.location,
              notes: item.notes,
            })),
          };
        }),
      );
    }

    // Snapshot finance line categories (amounts/currencies omitted — just the structure)
    let financeLines: Doc<"fileTemplates">["financeLines"] = [];
    if (args.includeFinanceLines) {
      const lines = await ctx.db
        .query("financeLines")
        .withIndex("by_group_file", (q) => q.eq("groupFileId", args.groupFileId))
        .collect();

      financeLines = lines.map((line) => ({
        kind: line.kind,
        category: line.category,
        description: line.description,
        notes: line.notes,
      }));
    }

    return await ctx.db.insert("fileTemplates", {
      name,
      description: args.description?.trim() || undefined,
      fileType: file.fileType,
      destination: file.destination,
      pax: file.pax,
      currency: file.currency,
      notes: file.notes,
      itineraryDays,
      financeLines,
      createdById: user._id,
    });
  },
});

/** Create a template manually (without sourcing from a file). */
export const create = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    fileType: groupFileTypeValidator,
    destination: v.optional(v.string()),
    pax: v.optional(v.number()),
    currency: currencyValidator,
    notes: v.optional(v.string()),
    itineraryDays: v.array(templateItineraryDayV),
    financeLines: v.array(templateFinanceLineV),
  },
  handler: async (ctx, args): Promise<Id<"fileTemplates">> => {
    const user = await requireUser(ctx);
    const name = args.name.trim();
    if (!name) throw new ConvexError({ code: "BAD_REQUEST", message: "Template name is required." });

    return await ctx.db.insert("fileTemplates", {
      ...args,
      name,
      createdById: user._id,
    });
  },
});

/** Delete a template. */
export const remove = mutation({
  args: { id: v.id("fileTemplates") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const template = await ctx.db.get(args.id);
    if (!template) throw new ConvexError({ code: "NOT_FOUND", message: "Template not found." });
    await ctx.db.delete(args.id);
    return null;
  },
});
