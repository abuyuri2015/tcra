import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import { requireIdentity, requireUser } from "./lib/auth.ts";

/** Return the singleton agency profile (or null if not yet configured). */
export const get = query({
  args: {},
  handler: async (ctx): Promise<Doc<"agencyProfile"> | null> => {
    await requireIdentity(ctx);
    return await ctx.db.query("agencyProfile").first();
  },
});

/** Create or update the agency profile (upsert). */
export const save = mutation({
  args: {
    agencyName: v.string(),
    address: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    website: v.optional(v.string()),
    logoUrl: v.optional(v.string()),
    bankName: v.optional(v.string()),
    iban: v.optional(v.string()),
    bic: v.optional(v.string()),
    paymentTerms: v.optional(v.string()),
    termsAndConditions: v.optional(v.string()),
    taxId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const existing = await ctx.db.query("agencyProfile").first();

    if (existing) {
      await ctx.db.patch("agencyProfile", existing._id, args);
      return existing._id;
    }
    return await ctx.db.insert("agencyProfile", args);
  },
});
