import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

async function setupFileWithHotelReservation(t: ReturnType<typeof convexTest>) {
  const asUser = t.withIdentity({ name: "Ada" });

  const hotelId = await asUser.mutation(api.hotels.create, {
    name: "Test Hotel",
    category: "4-star",
    status: "active",
    city: "Paris",
    country: "France",
    currency: "EUR",
    contactEmail: "reservations@testhotel.com",
    imageUrls: [],
    amenities: [],
  });

  const groupFileId = await asUser.mutation(api.groupFiles.create, {
    title: "Test Trip",
    fileType: "group",
    status: "confirmed",
    clientName: "Acme Co",
    destination: "Paris",
    startDate: "2027-01-01T00:00:00.000Z",
    endDate: "2027-01-05T00:00:00.000Z",
    pax: 10,
    currency: "EUR",
    exchangeRateToBase: 1,
  });

  const reservationId = await asUser.mutation(api.reservations.create, {
    groupFileId,
    type: "hotel",
    status: "confirmed",
    supplierName: "Test Hotel",
    hotelId,
    description: "Double room",
    startDate: "2027-01-01T00:00:00.000Z",
    units: 10,
    unitLabel: "rooms",
    costPerUnit: 100,
    ratePerUnit: 120,
    currency: "EUR",
  });

  return { asUser, groupFileId, reservationId, hotelId };
}

describe("modificationRequests approval auto-applies changes", () => {
  it("updates the reservation's units and books cost/income finance lines when a units request is approved", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithHotelReservation(t);

    const { id: requestId } = await t.mutation(api.modificationRequests.submitPublic, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 12,
      message: "",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "approved",
    });

    const reservation = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservation[0]?.units).toBe(12);

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    const costLine = lines.find((l) => l.kind === "cost");
    const incomeLine = lines.find((l) => l.kind === "income");
    expect(costLine?.amount).toBe(200); // 2 extra rooms * 100 cost/unit
    expect(incomeLine?.amount).toBe(240); // 2 extra rooms * 120 rate/unit
  });

  it("books a negative cost/income line when units are reduced", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithHotelReservation(t);

    const { id: requestId } = await t.mutation(api.modificationRequests.submitPublic, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 8,
      message: "",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "approved",
    });

    const reservation = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservation[0]?.units).toBe(8);

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    const costLine = lines.find((l) => l.kind === "cost");
    expect(costLine?.amount).toBe(-200); // 2 fewer rooms * 100 cost/unit
  });

  it("does not change the reservation's units when the request is declined", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithHotelReservation(t);

    const { id: requestId } = await t.mutation(api.modificationRequests.submitPublic, {
      groupFileId,
      reservationId,
      kind: "units",
      requestedUnits: 12,
      message: "",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "declined",
    });

    const reservation = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservation[0]?.units).toBe(10);

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    expect(lines).toHaveLength(0);
  });

  it("appends the approved note to the reservation for a free-text request, without touching units", async () => {
    const t = convexTest(schema, modules);
    const { asUser, groupFileId, reservationId } = await setupFileWithHotelReservation(t);

    const { id: requestId } = await t.mutation(api.modificationRequests.submitPublic, {
      groupFileId,
      reservationId,
      kind: "other",
      message: "Please move check-in to a later date if possible.",
      appOrigin: "https://example.com",
    });

    await t.mutation(api.modificationRequests.respondPublic, {
      requestId,
      decision: "approved",
    });

    const reservation = await asUser.query(api.reservations.listByFile, { groupFileId });
    expect(reservation[0]?.units).toBe(10);
    expect(reservation[0]?.notes).toContain("Please move check-in to a later date if possible.");

    const lines = await asUser.query(api.financeLines.listByFile, { groupFileId });
    expect(lines).toHaveLength(0);
  });

  it("rejects a units request that matches the currently booked quantity", async () => {
    const t = convexTest(schema, modules);
    const { groupFileId, reservationId } = await setupFileWithHotelReservation(t);

    await expect(
      t.mutation(api.modificationRequests.submitPublic, {
        groupFileId,
        reservationId,
        kind: "units",
        requestedUnits: 10,
        message: "",
        appOrigin: "https://example.com",
      }),
    ).rejects.toThrow();
  });
});
