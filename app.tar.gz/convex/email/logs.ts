import { ConvexError, v } from "convex/values";
import { internalMutation, query } from "../_generated/server.js";
import { requireIdentity } from "../lib/auth.js";

/** Internal mutation — only called from Node actions after a successful send. */
export const create = internalMutation({
  args: {
    groupFileId: v.id("groupFiles"),
    to: v.string(),
    subject: v.string(),
    emailType: v.union(
      v.literal("voucher"),
      v.literal("invoice"),
      v.literal("itinerary"),
      v.literal("quote"),
      v.literal("confirmation"),
      v.literal("hotel_modification_request"),
      v.literal("offer"),
      v.literal("other"),
    ),
    refId: v.optional(v.string()),
    refLabel: v.optional(v.string()),
    herculesEmailId: v.optional(v.string()),
    senderAddress: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("emailLogs", {
      ...args,
      sentAt: new Date().toISOString(),
    });
  },
});

/** Returns all email logs for a group file, newest first. */
export const listByFile = query({
  args: { groupFileId: v.id("groupFiles") },
  handler: async (ctx, args) => {
    await requireIdentity(ctx);
    const logs = await ctx.db
      .query("emailLogs")
      .withIndex("by_file", (q) => q.eq("groupFileId", args.groupFileId))
      .collect();
    return logs.sort(
      (a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime(),
    );
  },
});

/** Removes an email log entry. */
export const remove = internalMutation({
  args: { id: v.id("emailLogs") },
  handler: async (ctx, args) => {
    const log = await ctx.db.get("emailLogs", args.id);
    if (!log) throw new ConvexError({ code: "NOT_FOUND", message: "Log entry not found." });
    await ctx.db.delete("emailLogs", args.id);
  },
});
