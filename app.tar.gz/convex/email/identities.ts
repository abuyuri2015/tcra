"use node";

import { Hercules } from "@usehercules/sdk";
import { ConvexError } from "convex/values";
import type { ActionCtx } from "../_generated/server.js";
import { action } from "../_generated/server.js";

const hercules = new Hercules({
  apiKey: process.env.HERCULES_API_KEY!,
  apiVersion: "2025-12-09",
});

async function requireAuth(ctx: ActionCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({ code: "UNAUTHENTICATED", message: "You must be signed in." });
  }
  return identity;
}

type SenderIdentity = {
  id: string;
  value: string;
  type: "email" | "domain";
  status: "pending" | "verified" | "failed";
  createdAt: string;
};

// Returns all sender identities configured for this app
export const list = action({
  args: {},
  handler: async (ctx): Promise<SenderIdentity[]> => {
    await requireAuth(ctx);
    const identities: SenderIdentity[] = [];
    for await (const identity of hercules.email.identities.list()) {
      identities.push({
        id: identity.id,
        value: identity.value,
        type: identity.type,
        status: identity.status,
        createdAt: identity.created_at,
      });
    }
    return identities;
  },
});
