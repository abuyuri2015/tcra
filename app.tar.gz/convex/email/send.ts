"use node";

import { Hercules } from "@usehercules/sdk";
import escapeHtml from "escape-html";
import { ConvexError, v } from "convex/values";
import type { ActionCtx } from "../_generated/server.js";
import { action, internalAction } from "../_generated/server.js";
import { internal } from "../_generated/api.js";

const hercules = new Hercules({
  apiKey: process.env.HERCULES_API_KEY!,
  apiVersion: "2025-12-09",
});

async function requireAuth(ctx: ActionCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({ code: "UNAUTHENTICATED", message: "You must be signed in." });
  }
  return identity;
}

// ── Send voucher ──────────────────────────────────────────────────────────────

export const sendVoucher = action({
  args: {
    groupFileId: v.id("groupFiles"),
    reservationId: v.id("reservations"),
    from: v.string(),
    to: v.string(),
    subject: v.string(),
    body: v.string(),
    pdfDataUri: v.string(),
    pdfFilename: v.string(),
    supplierName: v.string(),
  },
  handler: async (ctx, args): Promise<{ emailId: string }> => {
    await requireAuth(ctx);

    const base64Content = args.pdfDataUri.split(",")[1] ?? "";

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Service Voucher</h1>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 16px; white-space: pre-line;">${escapeHtml(args.body)}</p>
          <p style="margin: 0; color: #78828c; font-size: 13px;">The voucher PDF is attached to this email.</p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: args.from,
      to: args.to,
      subject: args.subject,
      html,
      text: `${args.body}\n\nThe voucher PDF is attached.\n\n---\nTessera Groups & MICE`,
      attachments: [{ filename: args.pdfFilename, content: base64Content, content_type: "application/pdf" }],
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: args.groupFileId,
      to: args.to,
      subject: args.subject,
      emailType: "voucher",
      refId: args.reservationId,
      refLabel: args.supplierName,
      herculesEmailId: result.id,
      senderAddress: args.from,
    });

    return { emailId: result.id };
  },
});

// ── Send invoice ──────────────────────────────────────────────────────────────

export const sendInvoice = action({
  args: {
    groupFileId: v.id("groupFiles"),
    from: v.string(),
    to: v.string(),
    subject: v.string(),
    body: v.string(),
    pdfDataUri: v.string(),
    pdfFilename: v.string(),
    invoiceNumber: v.string(),
  },
  handler: async (ctx, args): Promise<{ emailId: string }> => {
    await requireAuth(ctx);

    const base64Content = args.pdfDataUri.split(",")[1] ?? "";

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Invoice</h1>
          <p style="color: #a7d4d0; margin: 4px 0 0; font-size: 14px;">${escapeHtml(args.invoiceNumber)}</p>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 16px; white-space: pre-line;">${escapeHtml(args.body)}</p>
          <p style="margin: 0; color: #78828c; font-size: 13px;">The invoice PDF is attached to this email.</p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: args.from,
      to: args.to,
      subject: args.subject,
      html,
      text: `${args.body}\n\nThe invoice PDF is attached.\n\n---\nTessera Groups & MICE`,
      attachments: [{ filename: args.pdfFilename, content: base64Content, content_type: "application/pdf" }],
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: args.groupFileId,
      to: args.to,
      subject: args.subject,
      emailType: "invoice",
      refLabel: args.invoiceNumber,
      herculesEmailId: result.id,
      senderAddress: args.from,
    });

    return { emailId: result.id };
  },
});

// ── Send combined invoice ─────────────────────────────────────────────────────

export const sendCombinedInvoice = action({
  args: {
    from: v.string(),
    to: v.string(),
    subject: v.string(),
    body: v.string(),
    pdfDataUri: v.string(),
    pdfFilename: v.string(),
    invoiceNumber: v.string(),
    groupFileIds: v.array(v.id("groupFiles")),
  },
  handler: async (ctx, args): Promise<{ emailId: string }> => {
    await requireAuth(ctx);

    const base64Content = args.pdfDataUri.split(",")[1] ?? "";

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Combined Invoice</h1>
          <p style="color: #a7d4d0; margin: 4px 0 0; font-size: 14px;">${escapeHtml(args.invoiceNumber)}</p>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 16px; white-space: pre-line;">${escapeHtml(args.body)}</p>
          <p style="margin: 0; color: #78828c; font-size: 13px;">The invoice PDF is attached to this email.</p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: args.from,
      to: args.to,
      subject: args.subject,
      html,
      text: `${args.body}\n\nThe invoice PDF is attached.\n\n---\nTessera Groups & MICE`,
      attachments: [{ filename: args.pdfFilename, content: base64Content, content_type: "application/pdf" }],
    });

    // Log against every included group file so it shows up in each file's history.
    for (const groupFileId of args.groupFileIds) {
      await ctx.runMutation(internal.email.logs.create, {
        groupFileId,
        to: args.to,
        subject: args.subject,
        emailType: "invoice",
        refLabel: `${args.invoiceNumber} (combined)`,
        herculesEmailId: result.id,
        senderAddress: args.from,
      });
    }

    return { emailId: result.id };
  },
});

// ── Send quote ────────────────────────────────────────────────────────────────

export const sendQuote = action({
  args: {
    groupFileId: v.id("groupFiles"),
    from: v.string(),
    to: v.string(),
    subject: v.string(),
    body: v.string(),
    pdfDataUri: v.string(),
    pdfFilename: v.string(),
    quoteNumber: v.string(),
  },
  handler: async (ctx, args): Promise<{ emailId: string }> => {
    await requireAuth(ctx);

    const base64Content = args.pdfDataUri.split(",")[1] ?? "";

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Group Quote</h1>
          <p style="color: #a7d4d0; margin: 4px 0 0; font-size: 14px;">${escapeHtml(args.quoteNumber)}</p>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 16px; white-space: pre-line;">${escapeHtml(args.body)}</p>
          <p style="margin: 0; color: #78828c; font-size: 13px;">The quote PDF is attached to this email.</p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: args.from,
      to: args.to,
      subject: args.subject,
      html,
      text: `${args.body}\n\nThe quote PDF is attached.\n\n---\nTessera Groups & MICE`,
      attachments: [{ filename: args.pdfFilename, content: base64Content, content_type: "application/pdf" }],
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: args.groupFileId,
      to: args.to,
      subject: args.subject,
      emailType: "quote",
      refLabel: args.quoteNumber,
      herculesEmailId: result.id,
      senderAddress: args.from,
    });

    return { emailId: result.id };
  },
});

// ── Send confirmation link (auto-triggered when a reservation is confirmed) ────

/**
 * Auto-sent (not user-triggered) when the first reservation on a file is
 * confirmed. Emails the client a link to their public confirmation page,
 * listing every reservation on the trip. Uses the agency's default verified
 * sender — falls back to skipping the send if none is verified.
 */
export const sendConfirmationAuto = internalAction({
  args: {
    groupFileId: v.id("groupFiles"),
    appOrigin: v.string(),
  },
  handler: async (ctx, args): Promise<null> => {
    const file = await ctx.runQuery(internal.groupFiles.getInternal, {
      id: args.groupFileId,
    });
    if (!file || !file.clientContactEmail) return null;

    const identities: { value: string; status: string }[] = [];
    for await (const identity of hercules.email.identities.list()) {
      identities.push({ value: identity.value, status: identity.status });
    }
    const sender = identities.find((i) => i.status === "verified");
    if (!sender) return null;

    const confirmationUrl = `${args.appOrigin}/confirm/${args.groupFileId}`;
    const safeUrl = escapeHtml(confirmationUrl);
    const clientName = escapeHtml(file.clientContactName ?? file.clientName);
    const tripTitle = escapeHtml(file.title);

    const subject = `Your booking is confirmed – ${file.title} · ${file.reference}`;
    const body = `Dear ${file.clientContactName ?? file.clientName},

Great news — your booking for ${file.title} has been confirmed.

Click the link below to review all the details of your trip, and let us know if you'd like to request any changes.`;

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Booking Confirmed</h1>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 16px;">Dear ${clientName},</p>
          <p style="margin: 0 0 16px;">Great news — your booking for <strong>${tripTitle}</strong> has been confirmed.</p>
          <p style="margin: 0 0 20px;">Click the button below to review all the details of your trip, and let us know if you'd like to request any changes.</p>
          <a href="${safeUrl}"
             style="display: inline-block; background: #0d504b; color: #ffffff; text-decoration: none;
                    padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px;">
            View your confirmation
          </a>
          <p style="margin: 16px 0 0; color: #78828c; font-size: 12px; word-break: break-all;">
            Or copy this link: <a href="${safeUrl}" style="color: #0d504b;">${safeUrl}</a>
          </p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: sender.value,
      to: file.clientContactEmail,
      subject,
      html,
      text: `${body}\n\n${confirmationUrl}\n\n---\nTessera Groups & MICE`,
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: args.groupFileId,
      to: file.clientContactEmail,
      subject,
      emailType: "confirmation",
      herculesEmailId: result.id,
      senderAddress: sender.value,
    });

    return null;
  },
});

// ── Send updated confirmation link (auto — after an approved change) ─────────

/**
 * Auto-sent whenever a hotel approves a change to a confirmed reservation —
 * whether the change was requested by the client or by staff. Unlike
 * sendConfirmationAuto (sent once, the first time a file is confirmed),
 * this is sent every time a change is approved so the client always has a
 * fresh link reflecting the latest state of their trip.
 */
export const sendConfirmationUpdated = internalAction({
  args: {
    groupFileId: v.id("groupFiles"),
    appOrigin: v.string(),
    supplierName: v.string(),
  },
  handler: async (ctx, args): Promise<null> => {
    const file = await ctx.runQuery(internal.groupFiles.getInternal, {
      id: args.groupFileId,
    });
    if (!file || !file.clientContactEmail) return null;

    const identities: { value: string; status: string }[] = [];
    for await (const identity of hercules.email.identities.list()) {
      identities.push({ value: identity.value, status: identity.status });
    }
    const sender = identities.find((i) => i.status === "verified");
    if (!sender) return null;

    const confirmationUrl = `${args.appOrigin}/confirm/${args.groupFileId}`;
    const safeUrl = escapeHtml(confirmationUrl);
    const clientName = escapeHtml(file.clientContactName ?? file.clientName);
    const tripTitle = escapeHtml(file.title);
    const safeSupplierName = escapeHtml(args.supplierName);

    const subject = `Your booking was updated – ${file.title} · ${file.reference}`;
    const body = `Dear ${file.clientContactName ?? file.clientName},

A change to "${args.supplierName}" on your booking for ${file.title} has just been approved and applied.

Click the link below to review the latest details of your trip.`;

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Booking Updated</h1>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 16px;">Dear ${clientName},</p>
          <p style="margin: 0 0 16px;">A change to <strong>${safeSupplierName}</strong> on your booking for <strong>${tripTitle}</strong> has just been approved and applied.</p>
          <p style="margin: 0 0 20px;">Click the button below to review the latest details of your trip.</p>
          <a href="${safeUrl}"
             style="display: inline-block; background: #0d504b; color: #ffffff; text-decoration: none;
                    padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px;">
            View your updated confirmation
          </a>
          <p style="margin: 16px 0 0; color: #78828c; font-size: 12px; word-break: break-all;">
            Or copy this link: <a href="${safeUrl}" style="color: #0d504b;">${safeUrl}</a>
          </p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: sender.value,
      to: file.clientContactEmail,
      subject,
      html,
      text: `${body}\n\n${confirmationUrl}\n\n---\nTessera Groups & MICE`,
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: args.groupFileId,
      to: file.clientContactEmail,
      subject,
      emailType: "confirmation",
      herculesEmailId: result.id,
      senderAddress: sender.value,
    });

    return null;
  },
});

// ── Send modification request to hotel (auto — no staff involvement) ─────────

/**
 * Auto-sent when a client submits a "Request a change" on a reservation
 * that has a linked hotel with a contact email. Includes public
 * Approve/Decline links — the hotel needs no login.
 */
export const sendModificationRequestToHotel = internalAction({
  args: {
    requestId: v.id("modificationRequests"),
    appOrigin: v.string(),
  },
  handler: async (ctx, args): Promise<null> => {
    const data = await ctx.runQuery(internal.modificationRequests.getForEmail, {
      requestId: args.requestId,
    });
    if (!data) return null;
    const { request, file, hotelName } = data;
    const hotelContactEmail = request.hotelContactEmail;
    if (!hotelContactEmail) return null;

    const identities: { value: string; status: string }[] = [];
    for await (const identity of hercules.email.identities.list()) {
      identities.push({ value: identity.value, status: identity.status });
    }
    const sender = identities.find((i) => i.status === "verified");
    if (!sender) return null;

    const approveUrl = `${args.appOrigin}/hotel-response/${request._id}?decision=approved`;
    const declineUrl = `${args.appOrigin}/hotel-response/${request._id}?decision=declined`;
    const safeApproveUrl = escapeHtml(approveUrl);
    const safeDeclineUrl = escapeHtml(declineUrl);
    const safeHotelName = escapeHtml(hotelName);
    const safeSupplierName = escapeHtml(request.supplierName);
    const safeDescription = escapeHtml(request.reservationDescription);
    const safeMessage = escapeHtml(request.message);
    const safeReference = escapeHtml(file.reference);

    const subject = `Change requested for booking ${file.reference} — ${request.supplierName}`;

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Change Requested</h1>
          <p style="color: #a7d4d0; margin: 4px 0 0; font-size: 14px;">Booking ${safeReference}</p>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 16px;">Dear ${safeHotelName} team,</p>
          <p style="margin: 0 0 8px;">Our client has requested a change to the following reservation:</p>
          <div style="background: #ffffff; border: 1px solid #dde3e2; border-radius: 6px; padding: 14px 16px; margin: 0 0 16px;">
            <p style="margin: 0 0 4px; font-weight: bold;">${safeSupplierName}</p>
            <p style="margin: 0 0 8px; color: #78828c; font-size: 13px;">${safeDescription}</p>
            <p style="margin: 0; font-size: 14px; white-space: pre-line;">${safeMessage}</p>
          </div>
          <p style="margin: 0 0 20px;">Please let us know if you can accommodate this change:</p>
          <table role="presentation" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
            <tr>
              <td style="padding-right: 10px;">
                <a href="${safeApproveUrl}"
                   style="display: inline-block; background: #1f7a5a; color: #ffffff; text-decoration: none;
                          padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px;">
                  Approve change
                </a>
              </td>
              <td>
                <a href="${safeDeclineUrl}"
                   style="display: inline-block; background: #b3413a; color: #ffffff; text-decoration: none;
                          padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px;">
                  Decline change
                </a>
              </td>
            </tr>
          </table>
          <p style="margin: 20px 0 0; color: #78828c; font-size: 12px;">
            You can also respond via: <a href="${args.appOrigin}/hotel-response/${request._id}" style="color: #0d504b;">${args.appOrigin}/hotel-response/${request._id}</a>
          </p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const text = `Dear ${hotelName} team,

Our client has requested a change to the following reservation on booking ${file.reference}:

${request.supplierName} — ${request.reservationDescription}
"${request.message}"

Approve: ${approveUrl}
Decline: ${declineUrl}

---
Tessera Groups & MICE`;

    const result = await hercules.email.send({
      from: sender.value,
      to: hotelContactEmail,
      subject,
      html,
      text,
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: file._id,
      to: hotelContactEmail,
      subject,
      emailType: "hotel_modification_request",
      refId: request._id,
      refLabel: request.supplierName,
      herculesEmailId: result.id,
      senderAddress: sender.value,
    });

    await ctx.runMutation(internal.modificationRequests.markEmailSent, {
      requestId: request._id,
    });

    return null;
  },
});

// ── Send offer link (staff-triggered, resendable) ────────────────────────────

export const sendOfferLink = action({
  args: {
    groupFileId: v.id("groupFiles"),
    from: v.string(),
    to: v.string(),
    subject: v.string(),
    body: v.string(),
    offerUrl: v.string(),
  },
  handler: async (ctx, args): Promise<{ emailId: string }> => {
    await requireAuth(ctx);

    const safeUrl = escapeHtml(args.offerUrl);

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Your Travel Options</h1>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 20px; white-space: pre-line;">${escapeHtml(args.body)}</p>
          <a href="${safeUrl}"
             style="display: inline-block; background: #0d504b; color: #ffffff; text-decoration: none;
                    padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px;">
            View and select options
          </a>
          <p style="margin: 16px 0 0; color: #78828c; font-size: 12px; word-break: break-all;">
            Or copy this link: <a href="${safeUrl}" style="color: #0d504b;">${safeUrl}</a>
          </p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: args.from,
      to: args.to,
      subject: args.subject,
      html,
      text: `${args.body}\n\nView and select your options here:\n${args.offerUrl}\n\n---\nTessera Groups & MICE`,
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: args.groupFileId,
      to: args.to,
      subject: args.subject,
      emailType: "offer",
      herculesEmailId: result.id,
      senderAddress: args.from,
    });

    return { emailId: result.id };
  },
});

// ── Send itinerary link ───────────────────────────────────────────────────────

export const sendItinerary = action({
  args: {
    groupFileId: v.id("groupFiles"),
    from: v.string(),
    to: v.string(),
    subject: v.string(),
    body: v.string(),
    itineraryUrl: v.string(),
  },
  handler: async (ctx, args): Promise<{ emailId: string }> => {
    await requireAuth(ctx);

    const safeUrl = escapeHtml(args.itineraryUrl);

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #121820;">
        <div style="background: #0d504b; padding: 20px 24px; border-radius: 8px 8px 0 0;">
          <h1 style="color: #ffffff; margin: 0; font-size: 20px;">Your Itinerary</h1>
        </div>
        <div style="background: #f5f6f6; padding: 24px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0 0 20px; white-space: pre-line;">${escapeHtml(args.body)}</p>
          <a href="${safeUrl}"
             style="display: inline-block; background: #0d504b; color: #ffffff; text-decoration: none;
                    padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px;">
            View itinerary
          </a>
          <p style="margin: 16px 0 0; color: #78828c; font-size: 12px; word-break: break-all;">
            Or copy this link: <a href="${safeUrl}" style="color: #0d504b;">${safeUrl}</a>
          </p>
        </div>
        <p style="text-align: center; color: #78828c; font-size: 11px; margin-top: 16px;">
          Tessera Groups &amp; MICE · Sent via Tessera Backoffice
        </p>
      </div>`;

    const result = await hercules.email.send({
      from: args.from,
      to: args.to,
      subject: args.subject,
      html,
      text: `${args.body}\n\nView your itinerary here:\n${args.itineraryUrl}\n\n---\nTessera Groups & MICE`,
    });

    await ctx.runMutation(internal.email.logs.create, {
      groupFileId: args.groupFileId,
      to: args.to,
      subject: args.subject,
      emailType: "itinerary",
      herculesEmailId: result.id,
      senderAddress: args.from,
    });

    return { emailId: result.id };
  },
});
