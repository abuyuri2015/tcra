import { cronJobs } from "convex/server";
import { internal } from "./_generated/api";

const crons = cronJobs();

// Check for due/overdue tasks every day at 07:00 UTC
crons.daily(
  "generate task notifications",
  { hourUTC: 7, minuteUTC: 0 },
  internal.notifications.generateTaskNotifications,
);

// Daily digest of overdue tasks + departures in the next 48 hours, once per
// day at 07:15 UTC (offset from the task-notification cron above)
crons.daily(
  "generate daily digest",
  { hourUTC: 7, minuteUTC: 15 },
  internal.notifications.generateDailyDigest,
);

// Bell notifications for offers/hotel change requests stuck waiting on a
// response for more than FOLLOWUP_THRESHOLD_DAYS, once per day at 07:30 UTC
// (offset from the two crons above).
crons.daily(
  "generate pending response follow-up notifications",
  { hourUTC: 7, minuteUTC: 30 },
  internal.followUps.generateFollowUpNotifications,
);

// Bell notifications for finance lines that are unpaid past their due date,
// once per day at 07:45 UTC (offset from the crons above).
crons.daily(
  "generate payment overdue notifications",
  { hourUTC: 7, minuteUTC: 45 },
  internal.notifications.generatePaymentOverdueNotifications,
);

export default crons;
