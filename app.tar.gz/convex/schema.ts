import { defineSchema } from "convex/server";
import { users } from "./schema/users.ts";
import { groupFiles } from "./schema/groupFiles.ts";
import { hotels, hotelRoomTypes } from "./schema/hotels.ts";
import { reservations } from "./schema/reservations.ts";
import { financeLines } from "./schema/financeLines.ts";
import { itineraryDays, itineraryItems } from "./schema/itinerary.ts";
import { emailLogs } from "./schema/emailLogs.ts";
import { tasks } from "./schema/tasks.ts";
import { suppliers } from "./schema/suppliers.ts";
import { passengers } from "./schema/passengers.ts";
import { groupFileAttachments } from "./schema/attachments.ts";
import { activityLog } from "./schema/activityLog.ts";
import { notifications } from "./schema/notifications.ts";
import { agencyProfile } from "./schema/agencyProfile.ts";
import { fileTemplates } from "./schema/fileTemplates.ts";
import { offers } from "./schema/offers.ts";
import { offerSelections } from "./schema/offerSelections.ts";
import { clients } from "./schema/clients.ts";
import { modificationRequests } from "./schema/modificationRequests.ts";
import { paymentSchedules } from "./schema/paymentSchedules.ts";

export default defineSchema({
  users,
  groupFiles,
  hotels,
  hotelRoomTypes,
  reservations,
  offers,
  financeLines,
  itineraryDays,
  itineraryItems,
  emailLogs,
  tasks,
  suppliers,
  passengers,
  groupFileAttachments,
  activityLog,
  notifications,
  agencyProfile,
  fileTemplates,
  clients,
  modificationRequests,
  offerSelections,
  paymentSchedules,
});
