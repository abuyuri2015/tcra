/**
 * Shared CSV export helpers.
 * All exports use UTF-8 BOM so Excel opens international characters correctly.
 */
import Papa from "papaparse";

function triggerDownload(csv: string, filename: string) {
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadCsv(
  rows: Record<string, unknown>[],
  filename: string,
) {
  const csv = Papa.unparse(rows, { quotes: true, header: true });
  triggerDownload(csv, filename);
}

/**
 * Downloads a single CSV made of multiple labelled tables, each separated by
 * a title row and a blank row. Useful for reports that combine several
 * breakdowns (e.g. monthly trend + by-category summary) into one export.
 */
export function downloadMultiSectionCsv(
  sections: Array<{ title: string; rows: Record<string, unknown>[] }>,
  filename: string,
) {
  const blocks = sections
    .filter((s) => s.rows.length > 0)
    .map((s) => `${s.title}\n${Papa.unparse(s.rows, { quotes: true, header: true })}`);
  triggerDownload(blocks.join("\n\n"), filename);
}
