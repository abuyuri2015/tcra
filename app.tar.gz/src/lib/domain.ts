export const CURRENCY_OPTIONS = [
  "EUR",
  "USD",
  "GBP",
  "CHF",
  "AED",
  "SEK",
  "NOK",
  "DKK",
] as const;

export type Currency = (typeof CURRENCY_OPTIONS)[number];

export const BASE_CURRENCY: Currency = "EUR";

export function formatMoney(amount: number, currency: string): string {
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function toBase(amount: number, rateToBase: number): number {
  return amount * rateToBase;
}

export const FILE_STATUS_OPTIONS = [
  { value: "enquiry", label: "Enquiry" },
  { value: "quoted", label: "Quoted" },
  { value: "confirmed", label: "Confirmed" },
  { value: "operating", label: "Operating" },
  { value: "closed", label: "Closed" },
  { value: "cancelled", label: "Cancelled" },
] as const;

export type FileStatus = (typeof FILE_STATUS_OPTIONS)[number]["value"];

export const FILE_TYPE_OPTIONS = [
  { value: "group", label: "Group" },
  { value: "meeting", label: "Meeting" },
  { value: "incentive", label: "Incentive" },
  { value: "conference", label: "Conference" },
  { value: "event", label: "Event" },
] as const;

export type FileType = (typeof FILE_TYPE_OPTIONS)[number]["value"];

export const STATUS_STYLES: Record<FileStatus, string> = {
  enquiry: "bg-muted text-muted-foreground",
  quoted: "bg-chart-4/15 text-chart-4",
  confirmed: "bg-chart-3/15 text-chart-3",
  operating: "bg-chart-2/20 text-chart-2",
  closed: "bg-primary/12 text-primary",
  cancelled: "bg-destructive/12 text-destructive",
};

export function statusLabel(status: string): string {
  return (
    FILE_STATUS_OPTIONS.find((s) => s.value === status)?.label ?? status
  );
}

export function typeLabel(fileType: string): string {
  return FILE_TYPE_OPTIONS.find((t) => t.value === fileType)?.label ?? fileType;
}

export const HOTEL_CATEGORY_OPTIONS = [
  { value: "5-star-luxury", label: "5 star luxury" },
  { value: "5-star", label: "5 star" },
  { value: "4-star-superior", label: "4 star superior" },
  { value: "4-star", label: "4 star" },
  { value: "3-star", label: "3 star" },
  { value: "boutique", label: "Boutique" },
  { value: "resort", label: "Resort" },
  { value: "apartment", label: "Apartments" },
  { value: "venue", label: "Venue only" },
] as const;

export type HotelCategory = (typeof HOTEL_CATEGORY_OPTIONS)[number]["value"];

export const HOTEL_STATUS_OPTIONS = [
  { value: "preferred", label: "Preferred" },
  { value: "active", label: "Active" },
  { value: "archived", label: "Archived" },
] as const;

export type HotelStatus = (typeof HOTEL_STATUS_OPTIONS)[number]["value"];

export const HOTEL_STATUS_STYLES: Record<HotelStatus, string> = {
  preferred: "bg-sidebar-primary/20 text-chart-5",
  active: "bg-chart-3/15 text-chart-3",
  archived: "bg-muted text-muted-foreground",
};

export const BOARD_OPTIONS = [
  { value: "room-only", label: "Room only" },
  { value: "breakfast", label: "Bed & breakfast" },
  { value: "half-board", label: "Half board" },
  { value: "full-board", label: "Full board" },
  { value: "all-inclusive", label: "All inclusive" },
] as const;

export type BoardType = (typeof BOARD_OPTIONS)[number]["value"];

export function hotelCategoryLabel(value: string): string {
  return (
    HOTEL_CATEGORY_OPTIONS.find((c) => c.value === value)?.label ?? value
  );
}

export function hotelStatusLabel(value: string): string {
  return HOTEL_STATUS_OPTIONS.find((s) => s.value === value)?.label ?? value;
}

export function boardLabel(value: string): string {
  return BOARD_OPTIONS.find((b) => b.value === value)?.label ?? value;
}

export const RESERVATION_TYPE_OPTIONS = [
  { value: "hotel", label: "Hotel" },
  { value: "transfer", label: "Transfer" },
  { value: "restaurant", label: "Restaurant" },
  { value: "activity", label: "Activity" },
  { value: "venue", label: "Venue" },
  { value: "flight", label: "Flight" },
  { value: "other", label: "Other" },
] as const;

export type ReservationType = (typeof RESERVATION_TYPE_OPTIONS)[number]["value"];

export const RESERVATION_STATUS_OPTIONS = [
  { value: "option", label: "Option" },
  { value: "requested", label: "Requested" },
  { value: "confirmed", label: "Confirmed" },
  { value: "cancelled", label: "Cancelled" },
] as const;

export type ReservationStatus = (typeof RESERVATION_STATUS_OPTIONS)[number]["value"];

export const RESERVATION_STATUS_STYLES: Record<ReservationStatus, string> = {
  option: "bg-muted text-muted-foreground",
  requested: "bg-chart-4/15 text-chart-4",
  confirmed: "bg-chart-3/15 text-chart-3",
  cancelled: "bg-destructive/12 text-destructive",
};

export function reservationTypeLabel(value: string): string {
  return RESERVATION_TYPE_OPTIONS.find((t) => t.value === value)?.label ?? value;
}

export function reservationStatusLabel(value: string): string {
  return RESERVATION_STATUS_OPTIONS.find((s) => s.value === value)?.label ?? value;
}

// ── Offers (candidate options before booking a reservation) ────────────────────

export const OFFER_STATUS_OPTIONS = [
  { value: "pending", label: "Pending" },
  { value: "accepted", label: "Accepted" },
  { value: "rejected", label: "Rejected" },
] as const;

export type OfferStatus = (typeof OFFER_STATUS_OPTIONS)[number]["value"];

export const OFFER_STATUS_STYLES: Record<OfferStatus, string> = {
  pending: "bg-muted text-muted-foreground",
  accepted: "bg-chart-3/15 text-chart-3",
  rejected: "bg-destructive/12 text-destructive",
};

export function offerStatusLabel(value: string): string {
  return OFFER_STATUS_OPTIONS.find((s) => s.value === value)?.label ?? value;
}


// ── Finance ───────────────────────────────────────────────────────────────────

export const COST_CATEGORY_OPTIONS = [
  { value: "accommodation", label: "Accommodation" },
  { value: "transport", label: "Transport" },
  { value: "meals", label: "Meals & F&B" },
  { value: "activities", label: "Activities" },
  { value: "venue", label: "Venue & AV" },
  { value: "guides", label: "Guides & Staff" },
  { value: "flights", label: "Flights" },
  { value: "insurance", label: "Insurance" },
  { value: "fees", label: "Agency fees" },
  { value: "other", label: "Other cost" },
] as const;

export const INCOME_CATEGORY_OPTIONS = [
  { value: "client-payment", label: "Client payment" },
  { value: "deposit", label: "Deposit received" },
  { value: "management-fee", label: "Management fee" },
  { value: "markup", label: "Markup / commission" },
  { value: "other", label: "Other income" },
] as const;

export type CostCategory = (typeof COST_CATEGORY_OPTIONS)[number]["value"];
export type IncomeCategory = (typeof INCOME_CATEGORY_OPTIONS)[number]["value"];

export function costCategoryLabel(value: string): string {
  return COST_CATEGORY_OPTIONS.find((c) => c.value === value)?.label ?? value;
}

export function incomeCategoryLabel(value: string): string {
  return INCOME_CATEGORY_OPTIONS.find((c) => c.value === value)?.label ?? value;
}

/**
 * Builds a human-readable "rate × quantity" breakdown string for a finance
 * line, e.g. "€120.00 × 25 rooms". Returns null when the line has no
 * itemized breakdown (a flat one-off amount).
 */
export function financeLineBreakdown(line: {
  unitRate?: number;
  quantity?: number;
  quantityLabel?: string;
  currency: string;
}): string | null {
  if (line.unitRate === undefined || line.quantity === undefined) return null;
  const label = line.quantityLabel ? ` ${line.quantityLabel}` : "";
  return `${formatMoney(line.unitRate, line.currency)} × ${line.quantity}${label}`;
}

// ── Icons map for reservation types (lucide icon names referenced in components)
export const RESERVATION_TYPE_ICONS: Record<ReservationType, string> = {
  hotel: "BedDouble",
  transfer: "Bus",
  restaurant: "UtensilsCrossed",
  activity: "Sunset",
  venue: "Building",
  flight: "Plane",
  other: "Package",
};
