/**
 * PDF generation utilities for vouchers and invoices.
 * All generation is client-side using jsPDF + jspdf-autotable.
 */
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { formatDate, formatDateRange } from "@/lib/dates.ts";
import { formatMoney, boardLabel, reservationTypeLabel } from "@/lib/domain.ts";
import type { Doc } from "@/convex/_generated/dataModel";

// Brand colours (teal + ink)
const TEAL: [number, number, number] = [13, 80, 75];
const INK: [number, number, number] = [18, 24, 32];
const LIGHT_GREY: [number, number, number] = [245, 246, 246];
const MID_GREY: [number, number, number] = [120, 130, 140];
const AMBER: [number, number, number] = [217, 119, 6];

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type Reservation = Doc<"reservations">;
type FinanceLine = Doc<"financeLines"> & { amountInBase: number };
type ItineraryDay = Doc<"itineraryDays"> & { items: Doc<"itineraryItems">[] };

/** Optional agency profile data for PDF branding. */
export type AgencyProfilePDF = {
  agencyName: string;
  address?: string;
  phone?: string;
  email?: string;
  website?: string;
  bankName?: string;
  iban?: string;
  bic?: string;
  paymentTerms?: string;
  termsAndConditions?: string;
  taxId?: string;
} | null;

const DEFAULT_PAYMENT_TERMS =
  "Payment is due within 30 days of invoice date. Please reference the invoice number on your transfer.";

/** Appends a "Terms & Conditions" page to the document when the agency has one configured. */
function appendTermsPage(doc: jsPDF, agency?: AgencyProfilePDF): void {
  if (!agency?.termsAndConditions?.trim()) return;
  const W = doc.internal.pageSize.getWidth();
  doc.addPage();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(...TEAL);
  doc.text("TERMS & CONDITIONS", 14, 20);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  const lines = doc.splitTextToSize(agency.termsAndConditions.trim(), W - 28);
  doc.text(lines, 14, 30);
}


// ── Shared header ─────────────────────────────────────────────────────────────

function drawHeader(doc: jsPDF, title: string, subtitle: string, ref: string, agency?: AgencyProfilePDF) {
  const W = doc.internal.pageSize.getWidth();

  // Teal bar
  doc.setFillColor(...TEAL);
  doc.rect(0, 0, W, 28, "F");

  // Title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(255, 255, 255);
  doc.text(title, 14, 12);

  // Subtitle
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(subtitle, 14, 20);

  // Agency name or ref right-aligned
  if (agency?.agencyName) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text(agency.agencyName, W - 14, 12, { align: "right" });
    doc.setFont("helvetica", "normal");
    doc.text(ref, W - 14, 20, { align: "right" });
  } else {
    doc.setFontSize(9);
    doc.text(ref, W - 14, 20, { align: "right" });
  }

  doc.setTextColor(...INK);
}

function drawFooter(doc: jsPDF, pageText: string, agency?: AgencyProfilePDF) {
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  doc.setFontSize(7);
  doc.setTextColor(...MID_GREY);

  // Build agency contact line if profile exists
  const parts: string[] = [];
  if (agency?.agencyName) parts.push(agency.agencyName);
  if (agency?.phone) parts.push(agency.phone);
  if (agency?.email) parts.push(agency.email);
  if (agency?.website) parts.push(agency.website);
  const agencyLine = parts.length > 0 ? parts.join("  ·  ") : "";

  if (agencyLine) {
    doc.text(agencyLine, 14, H - 12);
    doc.text(`Generated ${new Date().toLocaleDateString()}  ·  Confidential`, 14, H - 7);
  } else {
    doc.text(`Generated ${new Date().toLocaleDateString()}  ·  Confidential`, 14, H - 8);
  }
  doc.text(pageText, W - 14, H - 8, { align: "right" });
  doc.setTextColor(...INK);
}

// ── Voucher ───────────────────────────────────────────────────────────────────

export function generateVoucherPDF(
  file: GroupFile,
  reservation: Reservation,
  agency?: AgencyProfilePDF,
): void {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  // Header
  const dateLabel =
    reservation.type === "hotel" && reservation.nights !== undefined
      ? `${formatDate(reservation.startDate)} · ${reservation.nights} night${reservation.nights > 1 ? "s" : ""}`
      : reservation.endDate
        ? formatDateRange(reservation.startDate, reservation.endDate)
        : formatDate(reservation.startDate);

  drawHeader(
    doc,
    "SERVICE VOUCHER",
    `${reservationTypeLabel(reservation.type).toUpperCase()}  ·  ${reservation.supplierName}`,
    file.reference,
    agency,
  );

  let y = 36;

  // — Group info block —
  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 28, "F");

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("GROUP", 18, y + 7);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(file.title, 18, y + 13);
  doc.setTextColor(...MID_GREY);
  doc.text(`${file.clientName}  ·  ${file.pax} pax  ·  ${file.destination}`, 18, y + 19);
  doc.setTextColor(...INK);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("DATES", W / 2, y + 7, { align: "center" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(dateLabel, W / 2, y + 13, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("FILE REF", W - 18, y + 7, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(file.reference, W - 18, y + 13, { align: "right" });

  y += 36;

  // — Supplier block —
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...TEAL);
  doc.text("SUPPLIER DETAILS", 14, y);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  y += 6;
  doc.text(reservation.supplierName, 14, y);
  y += 5;

  if (reservation.supplierRef) {
    doc.setFontSize(9);
    doc.setTextColor(...MID_GREY);
    doc.text(`Confirmation ref: ${reservation.supplierRef}`, 14, y);
    doc.setTextColor(...INK);
    y += 5;
  }

  y += 4;

  // — Service details table —
  const rows: string[][] = [
    ["Service type", reservationTypeLabel(reservation.type)],
    ["Description", reservation.description],
    ["Dates", dateLabel],
    ["Quantity", `${reservation.units} ${reservation.unitLabel ?? (reservation.type === "hotel" ? "rooms" : "pax")}`],
  ];

  if (reservation.type === "hotel" && reservation.board) {
    rows.push(["Board basis", boardLabel(reservation.board)]);
  }
  if (reservation.ratePerUnit !== undefined) {
    rows.push(["Rate per unit", formatMoney(reservation.ratePerUnit, reservation.currency)]);
    rows.push(["Total", formatMoney(reservation.ratePerUnit * reservation.units, reservation.currency)]);
  }
  if (reservation.notes) {
    rows.push(["Notes", reservation.notes]);
  }

  autoTable(doc, {
    startY: y,
    body: rows,
    theme: "plain",
    styles: { fontSize: 9, cellPadding: 3 },
    columnStyles: {
      0: { fontStyle: "bold", cellWidth: 42, textColor: MID_GREY },
      1: { cellWidth: "auto" },
    },
    alternateRowStyles: { fillColor: LIGHT_GREY },
  });

  const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  y = finalY + 10;

  // — Status badge —
  const statusText = reservation.status.toUpperCase();
  const statusColor: [number, number, number] =
    reservation.status === "confirmed"
      ? [22, 163, 74]
      : reservation.status === "cancelled"
        ? [220, 38, 38]
        : TEAL;
  doc.setFillColor(...statusColor);
  doc.roundedRect(14, y, 40, 9, 2, 2, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text(statusText, 34, y + 6, { align: "center" });
  doc.setTextColor(...INK);

  drawFooter(doc, "Page 1 of 1", agency);

  const safeName = reservation.supplierName.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  doc.save(`voucher-${file.reference}-${safeName}.pdf`);
}

/** Same as generateVoucherPDF but returns base64 string + suggested filename instead of saving. */
export function generateVoucherPDFBase64(
  file: GroupFile,
  reservation: Reservation,
  agency?: AgencyProfilePDF,
): { base64: string; filename: string } {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  const dateLabel =
    reservation.type === "hotel" && reservation.nights !== undefined
      ? `${formatDate(reservation.startDate)} · ${reservation.nights} night${reservation.nights > 1 ? "s" : ""}`
      : reservation.endDate
        ? formatDateRange(reservation.startDate, reservation.endDate)
        : formatDate(reservation.startDate);

  drawHeader(
    doc,
    "SERVICE VOUCHER",
    `${reservationTypeLabel(reservation.type).toUpperCase()}  ·  ${reservation.supplierName}`,
    file.reference,
    agency,
  );

  let y = 36;
  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 28, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("GROUP", 18, y + 7);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(file.title, 18, y + 13);
  doc.setTextColor(...MID_GREY);
  doc.text(`${file.clientName}  ·  ${file.pax} pax  ·  ${file.destination}`, 18, y + 19);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("DATES", W / 2, y + 7, { align: "center" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(dateLabel, W / 2, y + 13, { align: "center" });
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("FILE REF", W - 18, y + 7, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(file.reference, W - 18, y + 13, { align: "right" });
  y += 36;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...TEAL);
  doc.text("SUPPLIER DETAILS", 14, y);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  y += 6;
  doc.text(reservation.supplierName, 14, y);
  y += 5;
  if (reservation.supplierRef) {
    doc.setFontSize(9);
    doc.setTextColor(...MID_GREY);
    doc.text(`Confirmation ref: ${reservation.supplierRef}`, 14, y);
    doc.setTextColor(...INK);
    y += 5;
  }
  y += 4;

  const rows: string[][] = [
    ["Service type", reservationTypeLabel(reservation.type)],
    ["Description", reservation.description],
    ["Dates", dateLabel],
    ["Quantity", `${reservation.units} ${reservation.unitLabel ?? (reservation.type === "hotel" ? "rooms" : "pax")}`],
  ];
  if (reservation.type === "hotel" && reservation.board) {
    rows.push(["Board basis", boardLabel(reservation.board)]);
  }
  if (reservation.ratePerUnit !== undefined) {
    rows.push(["Rate per unit", formatMoney(reservation.ratePerUnit, reservation.currency)]);
    rows.push(["Total", formatMoney(reservation.ratePerUnit * reservation.units, reservation.currency)]);
  }
  if (reservation.notes) rows.push(["Notes", reservation.notes]);

  autoTable(doc, {
    startY: y,
    body: rows,
    theme: "plain",
    styles: { fontSize: 9, cellPadding: 3 },
    columnStyles: {
      0: { fontStyle: "bold", cellWidth: 42, textColor: MID_GREY },
      1: { cellWidth: "auto" },
    },
    alternateRowStyles: { fillColor: LIGHT_GREY },
  });

  const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  y = finalY + 10;
  const statusColor: [number, number, number] =
    reservation.status === "confirmed" ? [22, 163, 74] : reservation.status === "cancelled" ? [220, 38, 38] : TEAL;
  doc.setFillColor(...statusColor);
  doc.roundedRect(14, y, 40, 9, 2, 2, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text(reservation.status.toUpperCase(), 34, y + 6, { align: "center" });
  doc.setTextColor(...INK);
  drawFooter(doc, "Page 1 of 1", agency);

  const safeName = reservation.supplierName.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  return {
    base64: doc.output("datauristring"),
    filename: `voucher-${file.reference}-${safeName}.pdf`,
  };
}

/** Builds a jsPDF-safe description string with a "rate × qty" breakdown appended on its own line when available. */
function descriptionWithBreakdown(l: {
  description: string;
  currency: string;
  unitRate?: number;
  quantity?: number;
  quantityLabel?: string;
}): string {
  if (l.unitRate === undefined || l.quantity === undefined) return l.description;
  const label = l.quantityLabel ? ` ${l.quantityLabel}` : "";
  return `${l.description}\n${formatMoney(l.unitRate, l.currency)} × ${l.quantity}${label}`;
}

// ── Invoice ───────────────────────────────────────────────────────────────────

export function generateInvoicePDF(
  file: GroupFile,
  incomeLines: FinanceLine[],
  invoiceNumber: string,
  agency?: AgencyProfilePDF,
): void {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  drawHeader(
    doc,
    "INVOICE",
    `${file.clientName}  ·  ${file.title}`,
    invoiceNumber,
    agency,
  );

  let y = 36;

  // — Invoice meta —
  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 26, "F");

  const today = new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });

  const leftItems = [
    ["Invoice number", invoiceNumber],
    ["Date", today],
    ["Period", formatDateRange(file.startDate, file.endDate)],
  ];
  const rightItems = [
    ["Client", file.clientName],
    ["Contact", file.clientContactName ?? ""],
    ["Destination", file.destination],
  ];

  doc.setFontSize(8);
  leftItems.forEach(([label, value], i) => {
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...MID_GREY);
    doc.text(label, 18, y + 6 + i * 7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...INK);
    doc.text(value, 52, y + 6 + i * 7);
  });

  rightItems.forEach(([label, value], i) => {
    if (!value) return;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...MID_GREY);
    doc.text(label, W / 2 + 4, y + 6 + i * 7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...INK);
    doc.text(value, W / 2 + 30, y + 6 + i * 7);
  });

  y += 34;

  // — Line items table —
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...TEAL);
  doc.text("INVOICE LINES", 14, y);
  doc.setTextColor(...INK);
  y += 4;

  const tableRows = incomeLines.map((l) => [
    l.category.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    l.supplierName ?? "",
    descriptionWithBreakdown(l),
    formatMoney(l.amount, l.currency),
    l.currency !== "EUR"
      ? formatMoney(l.amountInBase, "EUR")
      : "",
  ]);

  const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);

  autoTable(doc, {
    startY: y,
    head: [["Category", "Source", "Description", "Amount", "EUR equiv."]],
    body: tableRows,
    foot: [["", "", "TOTAL", "", formatMoney(totalEur, "EUR")]],
    theme: "grid",
    headStyles: {
      fillColor: TEAL,
      textColor: [255, 255, 255],
      fontStyle: "bold",
      fontSize: 8,
    },
    bodyStyles: { fontSize: 8 },
    footStyles: {
      fillColor: LIGHT_GREY,
      fontStyle: "bold",
      fontSize: 9,
      textColor: INK,
    },
    columnStyles: {
      0: { cellWidth: 32 },
      1: { cellWidth: 30 },
      2: { cellWidth: "auto" },
      3: { cellWidth: 28, halign: "right" },
      4: { cellWidth: 28, halign: "right" },
    },
    alternateRowStyles: { fillColor: [250, 251, 251] },
  });

  const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  y = finalY + 14;

  // — Summary box —
  doc.setFillColor(...TEAL);
  doc.rect(W - 80, y, 66, 14, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text("TOTAL DUE", W - 74, y + 6);
  doc.setFontSize(11);
  doc.text(formatMoney(totalEur, "EUR"), W - 18, y + 6, { align: "right" });
  doc.setFontSize(7);
  doc.setFont("helvetica", "normal");
  doc.text("All amounts converted to EUR at agreed exchange rates", W - 18, y + 11, { align: "right" });
  doc.setTextColor(...INK);

  // — Payment terms / notes —
  y += 24;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...TEAL);
  doc.text("PAYMENT TERMS", 14, y);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(
    agency?.paymentTerms ?? DEFAULT_PAYMENT_TERMS,
    14,
    y + 5,
    { maxWidth: W - 28 },
  );

  // — Bank details —
  if (agency?.bankName || agency?.iban || agency?.bic) {
    y += 16;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(...TEAL);
    doc.text("BANK DETAILS", 14, y);
    doc.setTextColor(...INK);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    let bankY = y + 5;
    if (agency.bankName) { doc.text(`Bank: ${agency.bankName}`, 14, bankY); bankY += 4; }
    if (agency.iban) { doc.text(`IBAN: ${agency.iban}`, 14, bankY); bankY += 4; }
    if (agency.bic) { doc.text(`BIC/SWIFT: ${agency.bic}`, 14, bankY); }
  }

  drawFooter(doc, `Invoice ${invoiceNumber}`, agency);

  appendTermsPage(doc, agency);

  doc.save(`invoice-${invoiceNumber}.pdf`);
}

/** Same as generateInvoicePDF but returns base64 data URI + filename instead of saving. */
export function generateInvoicePDFBase64(
  file: GroupFile,
  incomeLines: FinanceLine[],
  invoiceNumber: string,
  agency?: AgencyProfilePDF,
): { base64: string; filename: string } {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  drawHeader(doc, "INVOICE", `${file.clientName}  ·  ${file.title}`, invoiceNumber, agency);

  let y = 36;
  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 26, "F");

  const today = new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
  const leftItems = [
    ["Invoice number", invoiceNumber],
    ["Date", today],
    ["Period", formatDateRange(file.startDate, file.endDate)],
  ];
  const rightItems = [
    ["Client", file.clientName],
    ["Contact", file.clientContactName ?? ""],
    ["Destination", file.destination],
  ];

  doc.setFontSize(8);
  leftItems.forEach(([label, value], i) => {
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...MID_GREY);
    doc.text(label, 18, y + 6 + i * 7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...INK);
    doc.text(value, 52, y + 6 + i * 7);
  });
  rightItems.forEach(([label, value], i) => {
    if (!value) return;
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...MID_GREY);
    doc.text(label, W / 2 + 4, y + 6 + i * 7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...INK);
    doc.text(value, W / 2 + 30, y + 6 + i * 7);
  });
  y += 34;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...TEAL);
  doc.text("INVOICE LINES", 14, y);
  doc.setTextColor(...INK);
  y += 4;

  const tableRows = incomeLines.map((l) => [
    l.category.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    l.supplierName ?? "",
    descriptionWithBreakdown(l),
    formatMoney(l.amount, l.currency),
    l.currency !== "EUR" ? formatMoney(l.amountInBase, "EUR") : "",
  ]);
  const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);

  autoTable(doc, {
    startY: y,
    head: [["Category", "Source", "Description", "Amount", "EUR equiv."]],
    body: tableRows,
    foot: [["", "", "TOTAL", "", formatMoney(totalEur, "EUR")]],
    theme: "grid",
    headStyles: { fillColor: TEAL, textColor: [255, 255, 255], fontStyle: "bold", fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    footStyles: { fillColor: LIGHT_GREY, fontStyle: "bold", fontSize: 9, textColor: INK },
    columnStyles: {
      0: { cellWidth: 32 },
      1: { cellWidth: 30 },
      2: { cellWidth: "auto" },
      3: { cellWidth: 28, halign: "right" },
      4: { cellWidth: 28, halign: "right" },
    },
    alternateRowStyles: { fillColor: [250, 251, 251] },
  });

  const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  y = finalY + 14;

  doc.setFillColor(...TEAL);
  doc.rect(W - 80, y, 66, 14, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text("TOTAL DUE", W - 74, y + 6);
  doc.setFontSize(11);
  doc.text(formatMoney(totalEur, "EUR"), W - 18, y + 6, { align: "right" });
  doc.setFontSize(7);
  doc.setFont("helvetica", "normal");
  doc.text("All amounts converted to EUR at agreed exchange rates", W - 18, y + 11, { align: "right" });
  doc.setTextColor(...INK);

  y += 24;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...TEAL);
  doc.text("PAYMENT TERMS", 14, y);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(
    agency?.paymentTerms ?? DEFAULT_PAYMENT_TERMS,
    14, y + 5, { maxWidth: W - 28 },
  );

  // — Bank details —
  if (agency?.bankName || agency?.iban || agency?.bic) {
    y += 16;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(...TEAL);
    doc.text("BANK DETAILS", 14, y);
    doc.setTextColor(...INK);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    let bankY = y + 5;
    if (agency.bankName) { doc.text(`Bank: ${agency.bankName}`, 14, bankY); bankY += 4; }
    if (agency.iban) { doc.text(`IBAN: ${agency.iban}`, 14, bankY); bankY += 4; }
    if (agency.bic) { doc.text(`BIC/SWIFT: ${agency.bic}`, 14, bankY); }
  }

  drawFooter(doc, `Invoice ${invoiceNumber}`, agency);

  appendTermsPage(doc, agency);

  return {
    base64: doc.output("datauristring"),
    filename: `invoice-${invoiceNumber}.pdf`,
  };
}

// ── Quote ─────────────────────────────────────────────────────────────────────

/** Shared builder for the quote PDF — returns the jsPDF document. */
function buildQuoteDoc(
  file: GroupFile,
  incomeLines: FinanceLine[],
  itineraryDays: ItineraryDay[],
  coverMessage: string,
  quoteNumber: string,
  agency?: AgencyProfilePDF,
): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  // ── Header ────────────────────────────────────────────────────────────────
  drawHeader(
    doc,
    "GROUP QUOTE",
    `${file.clientName}  ·  ${file.title}`,
    quoteNumber,
    agency,
  );

  let y = 36;

  // ── Trip overview block ───────────────────────────────────────────────────
  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 30, "F");

  const overviewItems: [string, string][] = [
    ["Reference", file.reference],
    ["Destination", file.destination],
    ["Dates", formatDateRange(file.startDate, file.endDate)],
    ["Pax", `${file.pax} passengers`],
  ];
  if (file.fileType) {
    overviewItems.push(["Programme type", file.fileType.charAt(0).toUpperCase() + file.fileType.slice(1)]);
  }

  doc.setFontSize(8);
  const half = Math.ceil(overviewItems.length / 2);
  overviewItems.slice(0, half).forEach(([label, value], i) => {
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...MID_GREY);
    doc.text(label, 18, y + 7 + i * 8);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...INK);
    doc.text(value, 52, y + 7 + i * 8);
  });
  overviewItems.slice(half).forEach(([label, value], i) => {
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...MID_GREY);
    doc.text(label, W / 2 + 4, y + 7 + i * 8);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...INK);
    doc.text(value, W / 2 + 34, y + 7 + i * 8);
  });

  y += 38;

  // ── Cover message ─────────────────────────────────────────────────────────
  if (coverMessage.trim()) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(...TEAL);
    doc.text("MESSAGE", 14, y);
    doc.setTextColor(...INK);
    y += 5;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    const lines = doc.splitTextToSize(coverMessage.trim(), W - 28);
    doc.text(lines, 14, y);
    y += lines.length * 5 + 6;
  }

  // ── Itinerary summary ─────────────────────────────────────────────────────
  if (itineraryDays.length > 0) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(...TEAL);
    doc.text("PROGRAMME OVERVIEW", 14, y);
    doc.setTextColor(...INK);
    y += 4;

    const dayRows: string[][] = itineraryDays.map((day) => {
      const dayLabel = `Day ${day.dayNumber}  ${formatDate(day.date)}`;
      const titleText = day.title ?? "";
      const itemSummary = day.items
        .map((it) => it.title)
        .filter(Boolean)
        .join("  ·  ");
      return [dayLabel, titleText, itemSummary];
    });

    autoTable(doc, {
      startY: y,
      head: [["Day", "Theme", "Activities"]],
      body: dayRows,
      theme: "grid",
      headStyles: {
        fillColor: TEAL,
        textColor: [255, 255, 255],
        fontStyle: "bold",
        fontSize: 8,
      },
      bodyStyles: { fontSize: 8 },
      columnStyles: {
        0: { cellWidth: 36, fontStyle: "bold" },
        1: { cellWidth: 44 },
        2: { cellWidth: "auto" },
      },
      alternateRowStyles: { fillColor: [250, 251, 251] },
    });

    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  // ── Pricing summary ───────────────────────────────────────────────────────
  const incomeOnly = incomeLines.filter((l) => l.kind === "income");
  if (incomeOnly.length > 0) {
    // Check if we need a new page
    const H = doc.internal.pageSize.getHeight();
    if (y > H - 60) {
      doc.addPage();
      y = 20;
    }

    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(...TEAL);
    doc.text("PRICING SUMMARY", 14, y);
    doc.setTextColor(...INK);
    y += 4;

    const priceRows = incomeOnly.map((l) => [
      l.category.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
      descriptionWithBreakdown(l),
      formatMoney(l.amount, l.currency),
    ]);

    const totalEur = incomeOnly.reduce((s, l) => s + l.amountInBase, 0);
    const fileCurrency = file.currency ?? "EUR";
    const totalInFileCurrency = incomeOnly.reduce((s, l) => s + l.amount, 0);

    autoTable(doc, {
      startY: y,
      head: [["Category", "Description", "Amount"]],
      body: priceRows,
      theme: "grid",
      headStyles: { fillColor: TEAL, textColor: [255, 255, 255], fontStyle: "bold", fontSize: 8 },
      bodyStyles: { fontSize: 8 },
      columnStyles: {
        0: { cellWidth: 44 },
        1: { cellWidth: "auto" },
        2: { cellWidth: 36, halign: "right" },
      },
      alternateRowStyles: { fillColor: [250, 251, 251] },
    });

    const afterTable = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
    y = afterTable + 8;

    // Total box
    doc.setFillColor(...TEAL);
    doc.rect(W - 82, y, 68, 16, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(255, 255, 255);
    doc.text("TOTAL QUOTE VALUE", W - 76, y + 7);
    doc.setFontSize(12);
    doc.text(
      fileCurrency !== "EUR"
        ? formatMoney(totalInFileCurrency, fileCurrency)
        : formatMoney(totalEur, "EUR"),
      W - 18,
      y + 7,
      { align: "right" },
    );
    if (fileCurrency !== "EUR") {
      doc.setFontSize(7);
      doc.setFont("helvetica", "normal");
      doc.text(`≈ ${formatMoney(totalEur, "EUR")} EUR equiv.`, W - 18, y + 13, { align: "right" });
    }
    doc.setTextColor(...INK);
    y += 24;
  }

  // ── Validity note ─────────────────────────────────────────────────────────
  const H2 = doc.internal.pageSize.getHeight();
  if (y > H2 - 30) {
    doc.addPage();
    y = 20;
  }
  doc.setFillColor(...AMBER);
  doc.rect(14, y, 4, 14, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(...TEAL);
  doc.text("VALIDITY & CONDITIONS", 22, y + 6);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.text(
    "This quote is subject to availability and valid for 14 days from the date issued. Prices may vary based on final confirmation of services.",
    22,
    y + 11,
    { maxWidth: W - 36 },
  );

  // Determine current page count for footer
  const totalPages = doc.internal.pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    drawFooter(doc, `Quote ${quoteNumber}  ·  Page ${i} of ${totalPages}`, agency);
  }

  return doc;
}

/** Download the quote PDF directly. */
export function generateQuotePDF(
  file: GroupFile,
  incomeLines: FinanceLine[],
  itineraryDays: ItineraryDay[],
  coverMessage: string,
  quoteNumber: string,
  agency?: AgencyProfilePDF,
): void {
  const doc = buildQuoteDoc(file, incomeLines, itineraryDays, coverMessage, quoteNumber, agency);
  doc.save(`quote-${quoteNumber}.pdf`);
}

/** Returns base64 data URI + filename instead of saving. */
export function generateQuotePDFBase64(
  file: GroupFile,
  incomeLines: FinanceLine[],
  itineraryDays: ItineraryDay[],
  coverMessage: string,
  quoteNumber: string,
  agency?: AgencyProfilePDF,
): { base64: string; filename: string } {
  const doc = buildQuoteDoc(file, incomeLines, itineraryDays, coverMessage, quoteNumber, agency);
  return {
    base64: doc.output("datauristring"),
    filename: `quote-${quoteNumber}.pdf`,
  };
}

// ── Rooming List ─────────────────────────────────────────────────────────────

type Passenger = Doc<"passengers">;

const ROOM_TYPE_LABELS: Record<string, string> = {
  single: "Single",
  double: "Double",
  twin: "Twin",
  triple: "Triple",
  suite: "Suite",
};

function roomLabel(type: string): string {
  return ROOM_TYPE_LABELS[type] ?? type;
}

/**
 * Generates a rooming list PDF and triggers a browser download.
 * Groups passengers by room type with summary statistics.
 */
export function generateRoomingListPDF(
  file: GroupFile,
  passengers: Passenger[],
  agency?: AgencyProfilePDF,
): void {
  const doc = buildRoomingListDoc(file, passengers, agency);
  const slug = file.reference.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  doc.save(`rooming-list-${slug}.pdf`);
}

/** Same as generateRoomingListPDF but returns base64 + filename (for email attachments). */
export function generateRoomingListPDFBase64(
  file: GroupFile,
  passengers: Passenger[],
  agency?: AgencyProfilePDF,
): { base64: string; filename: string } {
  const doc = buildRoomingListDoc(file, passengers, agency);
  const slug = file.reference.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  return {
    base64: doc.output("datauristring"),
    filename: `rooming-list-${slug}.pdf`,
  };
}

function buildRoomingListDoc(
  file: GroupFile,
  passengers: Passenger[],
  agency?: AgencyProfilePDF,
): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  // Header
  drawHeader(
    doc,
    "ROOMING LIST",
    `${file.title.toUpperCase()}  ·  ${file.clientName}`,
    file.reference,
    agency,
  );

  let y = 36;

  // — Group info block —
  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 22, "F");

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("GROUP", 18, y + 7);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(file.title, 18, y + 13);
  doc.setTextColor(...MID_GREY);
  doc.text(`${file.clientName}  ·  ${file.destination}`, 18, y + 18);
  doc.setTextColor(...INK);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("DATES", W / 2, y + 7, { align: "center" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(formatDateRange(file.startDate, file.endDate), W / 2, y + 13, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("PAX", W - 18, y + 7, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(`${passengers.length} passengers`, W - 18, y + 13, { align: "right" });

  y += 30;

  // — Room summary strip —
  const roomCounts: Record<string, number> = {};
  for (const p of passengers) {
    roomCounts[p.roomType] = (roomCounts[p.roomType] ?? 0) + 1;
  }
  const summaryParts = Object.entries(roomCounts)
    .map(([type, count]) => `${roomLabel(type)}: ${count}`)
    .join("   ·   ");
  const dietCount = passengers.filter((p) => p.dietaryRequirements).length;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(...TEAL);
  doc.text("ROOM SUMMARY", 14, y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...INK);
  doc.text(summaryParts, 14, y + 5);
  if (dietCount > 0) {
    doc.setTextColor(...AMBER);
    doc.text(`${dietCount} passenger${dietCount !== 1 ? "s" : ""} with dietary requirements`, 14, y + 10);
    doc.setTextColor(...INK);
    y += 16;
  } else {
    y += 10;
  }

  // — Passenger table —
  const sorted = [...passengers].sort((a, b) => {
    // Sort by room type then by last name
    const typeOrder = ["single", "double", "twin", "triple", "suite"];
    const aIdx = typeOrder.indexOf(a.roomType);
    const bIdx = typeOrder.indexOf(b.roomType);
    if (aIdx !== bIdx) return aIdx - bIdx;
    return a.lastName.localeCompare(b.lastName);
  });

  const tableRows = sorted.map((p, i) => [
    String(i + 1),
    `${p.lastName}, ${p.firstName}`,
    roomLabel(p.roomType),
    p.sharingWith ?? "—",
    p.dietaryRequirements ?? "—",
    p.notes ?? "—",
  ]);

  autoTable(doc, {
    startY: y,
    head: [["#", "Passenger name", "Room type", "Sharing with", "Dietary", "Notes"]],
    body: tableRows,
    theme: "grid",
    headStyles: {
      fillColor: TEAL,
      textColor: [255, 255, 255],
      fontSize: 7,
      fontStyle: "bold",
      cellPadding: 2.5,
    },
    styles: {
      fontSize: 8,
      cellPadding: 2.5,
      textColor: INK,
      lineColor: [220, 220, 220],
      lineWidth: 0.2,
    },
    alternateRowStyles: { fillColor: LIGHT_GREY },
    columnStyles: {
      0: { cellWidth: 10, halign: "center" },
      1: { cellWidth: 50 },
      2: { cellWidth: 24 },
      3: { cellWidth: 35 },
      4: { cellWidth: 32 },
      5: { cellWidth: "auto" },
    },
    didDrawPage: (data) => {
      // Redraw header on subsequent pages
      if (data.pageNumber > 1) {
        drawHeader(doc, "ROOMING LIST", `${file.title.toUpperCase()}  ·  ${file.clientName}`, file.reference, agency);
      }
      drawFooter(doc, `Page ${data.pageNumber}`, agency);
    },
  });

  // Draw footer on first page (didDrawPage fires for page 2+ mid-draw)
  const pageCount = doc.getNumberOfPages();
  if (pageCount === 1) {
    drawFooter(doc, "Page 1 of 1", agency);
  } else {
    // Update all page footers with correct total
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      // Footer is already drawn, but page count wasn't known — overlay correct text
      const H = doc.internal.pageSize.getHeight();
      doc.setFillColor(255, 255, 255);
      doc.rect(W - 40, H - 12, 40, 8, "F");
      doc.setFontSize(7);
      doc.setTextColor(...MID_GREY);
      doc.text(`Page ${i} of ${pageCount}`, W - 14, H - 8, { align: "right" });
      doc.setTextColor(...INK);
    }
  }

  return doc;
}

// ── Combined client invoice ──────────────────────────────────────────────────

export type CombinedInvoiceFileData = {
  _id: string;
  reference: string;
  title: string;
  destination: string;
  startDate: string;
  endDate: string;
  incomeLines: Array<{
    category: string;
    description: string;
    amount: number;
    currency: string;
    amountInBase: number;
    unitRate?: number;
    quantity?: number;
    quantityLabel?: string;
  }>;
  totalEur: number;
};

/** Shared builder for the combined invoice PDF across several group files for one client. */
function buildCombinedInvoiceDoc(
  clientName: string,
  files: CombinedInvoiceFileData[],
  invoiceNumber: string,
  agency?: AgencyProfilePDF,
): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  drawHeader(
    doc,
    "COMBINED INVOICE",
    `${clientName}  ·  ${files.length} booking${files.length !== 1 ? "s" : ""}`,
    invoiceNumber,
    agency,
  );

  let y = 36;
  const today = new Date().toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });

  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 20, "F");
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...MID_GREY);
  doc.text("Invoice number", 18, y + 7);
  doc.text("Date", W / 2 + 4, y + 7);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...INK);
  doc.text(invoiceNumber, 18, y + 13);
  doc.text(today, W / 2 + 4, y + 13);
  y += 28;

  const grandTotalEur = files.reduce((s, f) => s + f.totalEur, 0);

  for (const file of files) {
    const H = doc.internal.pageSize.getHeight();
    if (y > H - 50) {
      doc.addPage();
      y = 20;
    }

    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(...TEAL);
    doc.text(file.title.toUpperCase(), 14, y);
    doc.setTextColor(...MID_GREY);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(
      `${file.reference}  ·  ${file.destination}  ·  ${formatDateRange(file.startDate, file.endDate)}`,
      14,
      y + 5,
    );
    doc.setTextColor(...INK);
    y += 10;

    if (file.incomeLines.length === 0) {
      doc.setFont("helvetica", "italic");
      doc.setFontSize(8);
      doc.setTextColor(...MID_GREY);
      doc.text("No income lines recorded for this booking.", 14, y);
      doc.setTextColor(...INK);
      y += 8;
      continue;
    }

    const rows = file.incomeLines.map((l) => [
      l.category.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
      descriptionWithBreakdown(l),
      formatMoney(l.amount, l.currency),
      l.currency !== "EUR" ? formatMoney(l.amountInBase, "EUR") : "",
    ]);

    autoTable(doc, {
      startY: y,
      head: [["Category", "Description", "Amount", "EUR equiv."]],
      body: rows,
      foot: [["", "Subtotal", "", formatMoney(file.totalEur, "EUR")]],
      theme: "grid",
      headStyles: { fillColor: TEAL, textColor: [255, 255, 255], fontStyle: "bold", fontSize: 8 },
      bodyStyles: { fontSize: 8 },
      footStyles: { fillColor: LIGHT_GREY, fontStyle: "bold", fontSize: 8, textColor: INK },
      columnStyles: {
        0: { cellWidth: 34 },
        1: { cellWidth: "auto" },
        2: { cellWidth: 28, halign: "right" },
        3: { cellWidth: 28, halign: "right" },
      },
      alternateRowStyles: { fillColor: [250, 251, 251] },
    });

    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  }

  // — Grand total box —
  const H2 = doc.internal.pageSize.getHeight();
  if (y > H2 - 30) {
    doc.addPage();
    y = 20;
  }
  doc.setFillColor(...TEAL);
  doc.rect(W - 80, y, 66, 16, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text("GRAND TOTAL", W - 74, y + 7);
  doc.setFontSize(12);
  doc.text(formatMoney(grandTotalEur, "EUR"), W - 18, y + 7, { align: "right" });
  doc.setFontSize(7);
  doc.setFont("helvetica", "normal");
  doc.text(`Across ${files.length} booking${files.length !== 1 ? "s" : ""}`, W - 18, y + 12, { align: "right" });
  doc.setTextColor(...INK);
  y += 26;

  // — Payment terms —
  const H3 = doc.internal.pageSize.getHeight();
  if (y > H3 - 24) {
    doc.addPage();
    y = 20;
  }
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...TEAL);
  doc.text("PAYMENT TERMS", 14, y);
  doc.setTextColor(...INK);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(agency?.paymentTerms ?? DEFAULT_PAYMENT_TERMS, 14, y + 5, { maxWidth: W - 28 });

  if (agency?.bankName || agency?.iban || agency?.bic) {
    y += 16;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(...TEAL);
    doc.text("BANK DETAILS", 14, y);
    doc.setTextColor(...INK);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    let bankY = y + 5;
    if (agency.bankName) { doc.text(`Bank: ${agency.bankName}`, 14, bankY); bankY += 4; }
    if (agency.iban) { doc.text(`IBAN: ${agency.iban}`, 14, bankY); bankY += 4; }
    if (agency.bic) { doc.text(`BIC/SWIFT: ${agency.bic}`, 14, bankY); }
  }

  const totalPages = doc.internal.pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    drawFooter(doc, `Invoice ${invoiceNumber}  ·  Page ${i} of ${totalPages}`, agency);
  }

  return doc;
}

/** Download the combined invoice PDF directly. */
export function generateCombinedInvoicePDF(
  clientName: string,
  files: CombinedInvoiceFileData[],
  invoiceNumber: string,
  agency?: AgencyProfilePDF,
): void {
  const doc = buildCombinedInvoiceDoc(clientName, files, invoiceNumber, agency);
  doc.save(`invoice-${invoiceNumber}.pdf`);
}

/** Same as generateCombinedInvoicePDF but returns base64 data URI + filename instead of saving. */
export function generateCombinedInvoicePDFBase64(
  clientName: string,
  files: CombinedInvoiceFileData[],
  invoiceNumber: string,
  agency?: AgencyProfilePDF,
): { base64: string; filename: string } {
  const doc = buildCombinedInvoiceDoc(clientName, files, invoiceNumber, agency);
  return {
    base64: doc.output("datauristring"),
    filename: `invoice-${invoiceNumber}.pdf`,
  };
}

// ── Transfer / activity confirmation & manifest ─────────────────────────────

type ManifestPassenger = Doc<"passengers"> & { included: boolean };

/**
 * Generates a transfer/excursion confirmation sheet: pickup place & time,
 * flight details, guide contact, and the full passenger manifest (excluded
 * passengers listed separately). Triggers a browser download.
 */
export function generateManifestPDF(
  reservation: Reservation,
  passengers: ManifestPassenger[],
  file: { reference: string; title: string },
  agency?: AgencyProfilePDF,
): void {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();

  const dateLabel = reservation.endDate
    ? formatDateRange(reservation.startDate, reservation.endDate)
    : formatDate(reservation.startDate);

  drawHeader(
    doc,
    "TRANSFER / EXCURSION CONFIRMATION",
    `${reservationTypeLabel(reservation.type).toUpperCase()}  ·  ${reservation.supplierName}`,
    file.reference,
    agency,
  );

  let y = 36;

  // — Group & date block —
  doc.setFillColor(...LIGHT_GREY);
  doc.rect(14, y, W - 28, 22, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("GROUP", 18, y + 7);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(file.title, 18, y + 13);
  doc.setTextColor(...MID_GREY);
  doc.text(reservation.description, 18, y + 18);
  doc.setTextColor(...INK);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("DATE", W - 18, y + 7, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(dateLabel, W - 18, y + 13, { align: "right" });

  y += 30;

  // — Pickup / flight / guide details —
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...TEAL);
  doc.text("PICKUP & OPERATIONS", 14, y);
  doc.setTextColor(...INK);
  y += 4;

  const detailRows: string[][] = [
    ["Pickup place", reservation.pickupLocation || "Not specified"],
    ["Pickup time", reservation.pickupTime || "Not specified"],
    ["Flight details", reservation.flightDetails || "N/A"],
    ["Guide name", reservation.guideName || "Not assigned"],
    ["Guide mobile", reservation.guidePhone || "Not assigned"],
  ];

  autoTable(doc, {
    startY: y,
    body: detailRows,
    theme: "plain",
    styles: { fontSize: 9, cellPadding: 3 },
    columnStyles: {
      0: { fontStyle: "bold", cellWidth: 42, textColor: MID_GREY },
      1: { cellWidth: "auto" },
    },
    alternateRowStyles: { fillColor: LIGHT_GREY },
  });

  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;

  // — Passenger manifest —
  const included = passengers.filter((p) => p.included);
  const excluded = passengers.filter((p) => !p.included);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...TEAL);
  doc.text(`PASSENGER MANIFEST (${included.length})`, 14, y);
  doc.setTextColor(...INK);
  y += 4;

  const manifestRows = included.map((p, i) => [
    String(i + 1),
    `${p.lastName}, ${p.firstName}`,
    roomLabel(p.roomType),
    p.dietaryRequirements ?? "—",
  ]);

  autoTable(doc, {
    startY: y,
    head: [["#", "Passenger name", "Room type", "Dietary"]],
    body: manifestRows,
    theme: "grid",
    headStyles: { fillColor: TEAL, textColor: [255, 255, 255], fontStyle: "bold", fontSize: 8 },
    bodyStyles: { fontSize: 8 },
    columnStyles: {
      0: { cellWidth: 10, halign: "center" },
      1: { cellWidth: 60 },
      2: { cellWidth: 30 },
      3: { cellWidth: "auto" },
    },
    alternateRowStyles: { fillColor: LIGHT_GREY },
    didDrawPage: (data) => {
      if (data.pageNumber > 1) {
        drawHeader(
          doc,
          "TRANSFER / EXCURSION CONFIRMATION",
          `${reservationTypeLabel(reservation.type).toUpperCase()}  ·  ${reservation.supplierName}`,
          file.reference,
          agency,
        );
      }
    },
  });

  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;

  if (excluded.length > 0) {
    const H = doc.internal.pageSize.getHeight();
    if (y > H - 30) {
      doc.addPage();
      y = 20;
    }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(...MID_GREY);
    doc.text(`NOT ATTENDING (${excluded.length})`, 14, y);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    y += 5;
    doc.text(
      excluded.map((p) => `${p.firstName} ${p.lastName}`).join(", "),
      14,
      y,
      { maxWidth: W - 28 },
    );
    doc.setTextColor(...INK);
  }

  const totalPages = doc.internal.pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    drawFooter(doc, `Page ${i} of ${totalPages}`, agency);
  }

  const safeName = reservation.supplierName.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  doc.save(`manifest-${file.reference}-${safeName}.pdf`);
}

