import { format, parseISO } from "date-fns";

/** Formats an ISO UTC timestamp as a local short date, e.g. 14 Mar 2026. */
export function formatDate(iso: string): string {
  return format(parseISO(iso), "d MMM yyyy");
}

export function formatDateRange(startIso: string, endIso: string): string {
  const start = parseISO(startIso);
  const end = parseISO(endIso);
  if (format(start, "yyyy-MM") === format(end, "yyyy-MM")) {
    return `${format(start, "d")}–${format(end, "d MMM yyyy")}`;
  }
  return `${format(start, "d MMM")} – ${format(end, "d MMM yyyy")}`;
}

/** Converts a yyyy-MM-dd input value into an ISO UTC instant at midday. */
export function dateInputToIso(value: string): string {
  return new Date(`${value}T12:00:00.000Z`).toISOString();
}

/** Converts an ISO instant back into a yyyy-MM-dd input value. */
export function isoToDateInput(iso: string): string {
  return format(parseISO(iso), "yyyy-MM-dd");
}

export function nightsBetween(startIso: string, endIso: string): number {
  const ms = parseISO(endIso).getTime() - parseISO(startIso).getTime();
  return Math.max(0, Math.round(ms / 86_400_000));
}
