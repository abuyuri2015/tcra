export const ITINERARY_ITEM_TYPE_OPTIONS = [
  { value: "arrival", label: "Arrival" },
  { value: "departure", label: "Departure" },
  { value: "flight", label: "Flight" },
  { value: "transfer", label: "Transfer" },
  { value: "hotel", label: "Hotel check-in/out" },
  { value: "meal", label: "Meal" },
  { value: "activity", label: "Activity" },
  { value: "meeting", label: "Meeting / conference" },
  { value: "free-time", label: "Free time" },
  { value: "other", label: "Other" },
] as const;

export type ItineraryItemType = (typeof ITINERARY_ITEM_TYPE_OPTIONS)[number]["value"];

export function itineraryItemTypeLabel(value: string): string {
  return (
    ITINERARY_ITEM_TYPE_OPTIONS.find((t) => t.value === value)?.label ?? value
  );
}

export const ITINERARY_ITEM_TYPE_COLORS: Record<ItineraryItemType, string> = {
  arrival: "bg-chart-3/15 text-chart-3",
  departure: "bg-destructive/10 text-destructive",
  flight: "bg-chart-4/15 text-chart-4",
  transfer: "bg-chart-5/15 text-chart-5",
  hotel: "bg-sidebar-primary/15 text-sidebar-primary",
  meal: "bg-chart-2/15 text-chart-2",
  activity: "bg-chart-1/15 text-chart-1",
  meeting: "bg-primary/10 text-primary",
  "free-time": "bg-muted text-muted-foreground",
  other: "bg-muted text-muted-foreground",
};
