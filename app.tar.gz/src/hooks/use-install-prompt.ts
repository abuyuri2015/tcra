import { useEffect, useState } from "react";

const DISMISS_KEY = "tessera-install-banner-dismissed";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

function isStandalone() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    // iOS Safari exposes this instead of the display-mode media query
    (navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

function isIosDevice() {
  return /iphone|ipad|ipod/i.test(navigator.userAgent);
}

/**
 * Surfaces a home-screen install prompt.
 * - Chromium: captures `beforeinstallprompt` and exposes `promptInstall()`.
 * - iOS Safari: never fires that event, so we just flag `isIos` so the
 *   banner can show manual "Add to Home Screen" instructions instead.
 * - Hidden entirely inside the App Builder preview iframe, when already
 *   installed, or after the end user dismisses it once.
 */
export function useInstallPrompt() {
  const [deferredEvent, setDeferredEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissed, setDismissed] = useState(
    () => localStorage.getItem(DISMISS_KEY) === "1",
  );
  const [installed, setInstalled] = useState(() => isStandalone());

  useEffect(() => {
    // Never show inside the App Builder preview iframe.
    if (window.self !== window.top) return;

    const handleBeforeInstall = (event: Event) => {
      event.preventDefault();
      setDeferredEvent(event as BeforeInstallPromptEvent);
    };
    const handleInstalled = () => setInstalled(true);

    window.addEventListener("beforeinstallprompt", handleBeforeInstall);
    window.addEventListener("appinstalled", handleInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
      window.removeEventListener("appinstalled", handleInstalled);
    };
  }, []);

  const isIos = isIosDevice();
  const isEmbedded = typeof window !== "undefined" && window.self !== window.top;
  const canInstall =
    !isEmbedded && !installed && !dismissed && (deferredEvent !== null || isIos);

  const promptInstall = async () => {
    if (!deferredEvent) return;
    await deferredEvent.prompt();
    const { outcome } = await deferredEvent.userChoice;
    if (outcome === "accepted") setInstalled(true);
    setDeferredEvent(null);
  };

  const dismiss = () => {
    localStorage.setItem(DISMISS_KEY, "1");
    setDismissed(true);
  };

  return { canInstall, isIos, promptInstall, dismiss };
}
