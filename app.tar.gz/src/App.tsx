import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import AppLayout from "./components/layout/app-layout.tsx";
import InstallAppBanner from "./components/install-app-banner.tsx";
import { useServiceWorker } from "./hooks/use-service-worker.ts";
import AuthCallback from "./pages/auth/Callback.tsx";
import Index from "./pages/Index.tsx";
import FilesPage from "./pages/files/page.tsx";
import FileDetailPage from "./pages/files/detail-page.tsx";
import HotelsPage from "./pages/hotels/page.tsx";
import HotelDetailPage from "./pages/hotels/detail-page.tsx";
import PublicItineraryPage from "./pages/itinerary/public-page.tsx";
import ClientOfferPage from "./pages/offer/public-page.tsx";
import ClientConfirmationPage from "./pages/confirm/page.tsx";
import HotelResponsePage from "./pages/hotel-response/page.tsx";
import SettingsPage from "./pages/settings/page.tsx";
import FinancePage from "./pages/finance/page.tsx";
import DocumentsPage from "./pages/documents/page.tsx";
import ItinerariesPage from "./pages/itineraries/page.tsx";
import CalendarPage from "./pages/calendar/page.tsx";
import SuppliersPage from "./pages/suppliers/page.tsx";
import SupplierDetailPage from "./pages/suppliers/detail-page.tsx";
import TasksPage from "./pages/tasks/page.tsx";
import PipelinePage from "./pages/pipeline/page.tsx";
import ReportsPage from "./pages/reports/page.tsx";
import ClientsPage from "./pages/clients/page.tsx";
import ClientDetailPage from "./pages/clients/detail-page.tsx";
import NotFound from "./pages/NotFound.tsx";

export default function App() {
  useServiceWorker();

  return (
    <DefaultProviders>
      <BrowserRouter>
        <InstallAppBanner />
        <Routes>
          <Route path="/auth/callback" element={<AuthCallback />} />
          {/* Public — no layout chrome */}
          <Route path="/itinerary/:fileId" element={<PublicItineraryPage />} />
          <Route path="/offer/:fileId" element={<ClientOfferPage />} />
          <Route path="/confirm/:fileId" element={<ClientConfirmationPage />} />
          <Route path="/hotel-response/:requestId" element={<HotelResponsePage />} />
          <Route element={<AppLayout />}>
            <Route path="/" element={<Index />} />
            <Route path="/files" element={<FilesPage />} />
            <Route path="/files/:fileId" element={<FileDetailPage />} />
            <Route path="/hotels" element={<HotelsPage />} />
            <Route path="/hotels/:hotelId" element={<HotelDetailPage />} />
            <Route path="/suppliers" element={<SuppliersPage />} />
            <Route path="/suppliers/:supplierId" element={<SupplierDetailPage />} />
            <Route path="/clients" element={<ClientsPage />} />
            <Route path="/clients/:clientId" element={<ClientDetailPage />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/finance" element={<FinancePage />} />
            <Route path="/documents" element={<DocumentsPage />} />
            <Route path="/itineraries" element={<ItinerariesPage />} />
            <Route path="/pipeline" element={<PipelinePage />} />
            <Route path="/calendar" element={<CalendarPage />} />
            <Route path="/reports" element={<ReportsPage />} />
          </Route>
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </DefaultProviders>
  );
}
