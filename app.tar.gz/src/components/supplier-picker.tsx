/**
 * SupplierPicker — a compact popover that lets users search their supplier
 * database and auto-fill the supplier name field on a reservation form.
 */
import { useState } from "react";
import { useQuery } from "convex/react";
import { BookUser, Check, ChevronsUpDown, Search } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.js";
import { Button } from "@/components/ui/button.tsx";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  SUPPLIER_CATEGORY_OPTIONS,
  supplierCategoryIcon,
} from "@/pages/suppliers/page.tsx";
import type { SupplierCategory } from "@/pages/suppliers/page.tsx";
import { cn } from "@/lib/utils.ts";
import { useDebounce } from "@/hooks/use-debounce.ts";

type SupplierPickerProps = {
  /** When the user selects a supplier, this is called with the full record. */
  onSelect: (supplier: Doc<"suppliers">) => void;
  /** The reservation type — used to default-filter the category. */
  reservationType?: SupplierCategory;
};

export default function SupplierPicker({
  onSelect,
  reservationType,
}: SupplierPickerProps) {
  const [open, setOpen] = useState(false);
  const [searchInput, setSearchInput] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<SupplierCategory | "all">(
    reservationType ?? "all",
  );
  const [debouncedSearch] = useDebounce(searchInput, 200);

  const allSuppliers = useQuery(api.suppliers.list, {
    category: categoryFilter === "all" ? undefined : categoryFilter,
  });

  const searchResults = useQuery(
    api.suppliers.search,
    debouncedSearch.trim()
      ? {
          query: debouncedSearch,
          category: categoryFilter === "all" ? undefined : categoryFilter,
        }
      : "skip",
  );

  const suppliers = debouncedSearch.trim() ? searchResults : allSuppliers;

  const handleSelect = (s: Doc<"suppliers">) => {
    onSelect(s);
    setOpen(false);
    setSearchInput("");
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button type="button" variant="secondary" size="sm" className="gap-1.5">
          <BookUser className="size-3.5" />
          Pick supplier
          <ChevronsUpDown className="size-3 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="start">
        {/* Search */}
        <div className="p-2 border-b">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search suppliers…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="h-8 pl-8 text-sm"
              autoFocus
            />
          </div>
        </div>

        {/* Category filter pills */}
        <div className="flex flex-wrap gap-1 p-2 border-b">
          <button
            type="button"
            onClick={() => setCategoryFilter("all")}
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium transition-colors",
              categoryFilter === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:text-foreground",
            )}
          >
            All
          </button>
          {SUPPLIER_CATEGORY_OPTIONS.map((o) => {
            const Icon = o.icon;
            return (
              <button
                key={o.value}
                type="button"
                onClick={() => setCategoryFilter(o.value)}
                className={cn(
                  "flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium transition-colors",
                  categoryFilter === o.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="size-3" />
                {o.label}
              </button>
            );
          })}
        </div>

        {/* Results */}
        <div className="max-h-64 overflow-y-auto">
          {suppliers === undefined ? (
            <div className="space-y-1 p-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : suppliers.length === 0 ? (
            <p className="py-6 text-center text-xs text-muted-foreground">
              {debouncedSearch.trim() ? "No results" : "No suppliers in database"}
            </p>
          ) : (
            suppliers.map((s) => {
              const Icon = supplierCategoryIcon(s.category);
              return (
                <button
                  key={s._id}
                  type="button"
                  onClick={() => handleSelect(s)}
                  className="flex w-full items-start gap-2.5 px-3 py-2.5 text-left transition-colors hover:bg-secondary/60"
                >
                  <Icon className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{s.name}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {[s.city, s.country].filter(Boolean).join(", ") || s.category}
                      {s.contactPerson ? ` · ${s.contactPerson}` : ""}
                    </p>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
