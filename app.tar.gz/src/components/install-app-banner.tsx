import { useState } from "react";
import { Download, X } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { useInstallPrompt } from "@/hooks/use-install-prompt.ts";

/**
 * Bottom-center banner prompting end users to install Tessera to their home
 * screen / desktop. Chromium browsers get a real one-tap install; iOS gets
 * manual "Add to Home Screen" instructions since Safari has no install API.
 */
export default function InstallAppBanner() {
  const { canInstall, isIos, promptInstall, dismiss } = useInstallPrompt();
  const [showIosSteps, setShowIosSteps] = useState(false);

  if (!canInstall) return null;

  return (
    <div className="fixed inset-x-0 bottom-20 z-30 flex justify-center px-4 lg:bottom-6">
      <div className="flex w-full max-w-md items-start gap-3 rounded-xl border bg-card p-4 shadow-lg">
        <span className="grid size-9 shrink-0 place-items-center rounded-md bg-primary text-primary-foreground font-display text-base font-semibold">
          T
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium">Install Tessera</p>
          {showIosSteps ? (
            <p className="mt-1 text-xs text-muted-foreground">
              Tap the Share icon, then "Add to Home Screen".
            </p>
          ) : (
            <p className="mt-1 text-xs text-muted-foreground">
              Add it to your home screen for quick, full-screen access.
            </p>
          )}
          <div className="mt-3 flex gap-2">
            {isIos ? (
              <Button size="sm" variant="secondary" onClick={() => setShowIosSteps(true)}>
                How?
              </Button>
            ) : (
              <Button size="sm" onClick={promptInstall}>
                <Download className="size-4" />
                Install
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={dismiss}>
              Not now
            </Button>
          </div>
        </div>
        <button
          type="button"
          onClick={dismiss}
          aria-label="Dismiss"
          className="shrink-0 rounded-md p-1 text-muted-foreground hover:bg-secondary"
        >
          <X className="size-4" />
        </button>
      </div>
    </div>
  );
}
