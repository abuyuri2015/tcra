import { cn } from "@/lib/utils.ts";
import { STATUS_STYLES, statusLabel, type FileStatus } from "@/lib/domain.ts";

export default function StatusBadge({
  status,
  className,
}: {
  status: string;
  className?: string;
}) {
  const style =
    STATUS_STYLES[status as FileStatus] ?? "bg-muted text-muted-foreground";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        style,
        className,
      )}
    >
      {statusLabel(status)}
    </span>
  );
}
