import { Minus, Plus } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { cn } from "@/lib/utils.ts";

/**
 * A live percent control: -/+ buttons nudge the value by `step`, and the
 * number field accepts direct typed input. Every change calls `onChange`
 * immediately so callers can recalculate a derived price as the user drags.
 */
export default function PercentStepper({
  value,
  onChange,
  step = 1,
  min = 0,
  max = 999,
  className,
  size = "default",
}: {
  value: number;
  onChange: (next: number) => void;
  step?: number;
  min?: number;
  max?: number;
  className?: string;
  size?: "default" | "sm";
}) {
  const clamp = (n: number) => Math.min(max, Math.max(min, n));
  const round = (n: number) => Math.round(n * 100) / 100;

  const decrement = () => onChange(clamp(round(value - step)));
  const increment = () => onChange(clamp(round(value + step)));

  return (
    <div
      className={cn(
        "flex items-center gap-1 rounded-md border border-input bg-transparent",
        size === "sm" ? "h-8" : "h-9",
        className,
      )}
    >
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className={cn("shrink-0 rounded-r-none", size === "sm" ? "size-8" : "size-9")}
        onClick={decrement}
        aria-label="Decrease markup"
      >
        <Minus className="size-3.5" />
      </Button>
      <div className="relative flex flex-1 items-center justify-center">
        <Input
          type="number"
          value={Number.isFinite(value) ? value : ""}
          step={step}
          min={min}
          max={max}
          onChange={(e) => {
            const next = Number(e.target.value);
            if (Number.isFinite(next)) onChange(clamp(next));
          }}
          className="h-full w-full border-none text-center shadow-none focus-visible:ring-0 [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
        />
        <span className="pointer-events-none absolute right-2 text-xs text-muted-foreground">
          %
        </span>
      </div>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className={cn("shrink-0 rounded-l-none", size === "sm" ? "size-8" : "size-9")}
        onClick={increment}
        aria-label="Increase markup"
      >
        <Plus className="size-3.5" />
      </Button>
    </div>
  );
}
