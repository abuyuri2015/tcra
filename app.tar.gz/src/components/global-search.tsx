import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import { useDebounce } from "@/hooks/use-debounce.ts";
import {
  BedDouble,
  BookUser,
  Building2,
  Bus,
  Building,
  FileText,
  Plane,
  Package,
  Search,
  Sunset,
  UserRound,
  UtensilsCrossed,
  X,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { cn } from "@/lib/utils.ts";
import { Dialog, DialogContent } from "@/components/ui/dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import type { SearchResult } from "@/convex/search.ts";

// ── Icons ─────────────────────────────────────────────────────────────────────

const RESERVATION_ICONS: Record<string, typeof FileText> = {
  hotel: BedDouble,
  transfer: Bus,
  restaurant: UtensilsCrossed,
  activity: Sunset,
  venue: Building,
  flight: Plane,
  other: Package,
};

function resultIcon(result: SearchResult) {
  if (result.kind === "file") return FileText;
  if (result.kind === "hotel") return BedDouble;
  if (result.kind === "supplier") return BookUser;
  if (result.kind === "passenger") return UserRound;
  if (result.kind === "client") return result.clientKind === "company" ? Building2 : UserRound;
  return RESERVATION_ICONS[result.type] ?? Package;
}

// ── Kind badge ────────────────────────────────────────────────────────────────

const KIND_STYLES: Record<string, string> = {
  file: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  hotel: "bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300",
  supplier: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  reservation: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  passenger: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
  client: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300",
};

const KIND_LABELS: Record<string, string> = {
  file: "File",
  hotel: "Hotel",
  supplier: "Supplier",
  reservation: "Reservation",
  passenger: "Passenger",
  client: "Client",
};

// ── Status colour helper ──────────────────────────────────────────────────────

function statusCls(status: string) {
  const map: Record<string, string> = {
    confirmed: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
    operating: "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
    quoted: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
    enquiry: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
    closed: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400",
    cancelled: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
    preferred: "bg-violet-100 text-violet-800 dark:bg-violet-900/40 dark:text-violet-300",
    active: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
    archived: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400",
    option: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
    requested: "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
  };
  return map[status] ?? "bg-muted text-muted-foreground";
}

// ── Section ordering ──────────────────────────────────────────────────────────

type SectionKind = SearchResult["kind"];

const SECTION_ORDER: SectionKind[] = ["file", "client", "hotel", "supplier", "reservation", "passenger"];
const SECTION_LABELS: Record<SectionKind, string> = {
  file: "Group files",
  client: "Clients",
  hotel: "Hotels",
  supplier: "Suppliers",
  reservation: "Reservations",
  passenger: "Passengers",
};

// ── Result row ────────────────────────────────────────────────────────────────

function ResultRow({
  result,
  isActive,
  onClick,
}: {
  result: SearchResult;
  isActive: boolean;
  onClick: () => void;
}) {
  const Icon = resultIcon(result);
  const hasStatus = "status" in result;

  return (
    <button
      type="button"
      onClick={onClick}
      data-active={isActive || undefined}
      className={cn(
        "flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left transition-colors",
        isActive ? "bg-accent text-accent-foreground" : "hover:bg-muted/60",
      )}
    >
      <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
        <Icon className="size-4 text-muted-foreground" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{result.title}</p>
        <p className="truncate text-xs text-muted-foreground">{result.subtitle}</p>
      </div>
      <div className="flex shrink-0 items-center gap-1.5">
        {/* Type badge */}
        <span
          className={cn(
            "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
            KIND_STYLES[result.kind],
          )}
        >
          {KIND_LABELS[result.kind]}
        </span>
        {/* Status badge for entities that have one */}
        {hasStatus && (
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              statusCls(result.status),
            )}
          >
            {result.status}
          </span>
        )}
      </div>
    </button>
  );
}

function SectionHeader({ label }: { label: string }) {
  return (
    <p className="px-3 pb-1 pt-3 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
      {label}
    </p>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export function GlobalSearch({ open, onClose }: { open: boolean; onClose: () => void }) {
  const navigate = useNavigate();
  const [inputValue, setInputValue] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const [debouncedQ] = useDebounce(inputValue, 250);

  const results = useQuery(
    api.search.search,
    debouncedQ.trim().length >= 2 ? { q: debouncedQ.trim() } : "skip",
  );

  // Group by kind and build flat list for keyboard navigation
  const sections: { kind: SectionKind; label: string; items: SearchResult[] }[] = [];
  const flat: SearchResult[] = [];

  if (results) {
    for (const kind of SECTION_ORDER) {
      const items = results.filter((r) => r.kind === kind);
      if (items.length > 0) {
        sections.push({ kind, label: SECTION_LABELS[kind], items });
        flat.push(...items);
      }
    }
  }

  useEffect(() => {
    if (open) {
      setInputValue("");
      setActiveIdx(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  useEffect(() => {
    setActiveIdx(0);
  }, [flat.length]);

  // Scroll active item into view
  useEffect(() => {
    const container = listRef.current;
    if (!container) return;
    const active = container.querySelector("[data-active]");
    if (active) {
      active.scrollIntoView({ block: "nearest" });
    }
  }, [activeIdx]);

  const handleSelect = useCallback(
    (result: SearchResult) => {
      onClose();
      switch (result.kind) {
        case "file":
          navigate(`/files/${result.id}`);
          break;
        case "hotel":
          navigate(`/hotels/${result.id}`);
          break;
        case "supplier":
          navigate(`/suppliers/${result.id}`);
          break;
        case "client":
          navigate(`/clients/${result.id}`);
          break;
        case "passenger":
          navigate(`/files/${result.groupFileId}?tab=passengers`);
          break;
        case "reservation":
          navigate(`/files/${result.groupFileId}?tab=reservations`);
          break;
      }
    },
    [navigate, onClose],
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIdx((i) => Math.min(i + 1, flat.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIdx((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter" && flat[activeIdx]) {
      handleSelect(flat[activeIdx]);
    } else if (e.key === "Escape") {
      onClose();
    }
  };

  const isLoading = debouncedQ.trim().length >= 2 && results === undefined;
  const hasQuery = inputValue.trim().length >= 2;
  const isEmpty = hasQuery && !isLoading && flat.length === 0;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="gap-0 overflow-hidden p-0 sm:max-w-lg">
        {/* Input */}
        <div className="flex items-center gap-3 border-b px-4 py-3">
          <Search className="size-4 shrink-0 text-muted-foreground" />
          <input
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Search files, hotels, suppliers, passengers…"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          {inputValue && (
            <button
              type="button"
              onClick={() => setInputValue("")}
              className="rounded p-0.5 text-muted-foreground hover:text-foreground cursor-pointer"
            >
              <X className="size-3.5" />
            </button>
          )}
          <Badge variant="outline" className="shrink-0 text-[10px]">
            ESC
          </Badge>
        </div>

        {/* Results */}
        <div ref={listRef} className="max-h-[420px] overflow-y-auto p-2">
          {!hasQuery && (
            <div className="py-10 text-center text-sm text-muted-foreground">
              <Search className="mx-auto mb-2 size-8 opacity-30" />
              Type at least 2 characters to search
            </div>
          )}

          {isLoading && (
            <div className="space-y-1 py-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 rounded-md px-3 py-2.5">
                  <div className="size-8 animate-pulse rounded-md bg-muted" />
                  <div className="flex-1 space-y-1.5">
                    <div className="h-3 w-2/3 animate-pulse rounded bg-muted" />
                    <div className="h-2.5 w-1/2 animate-pulse rounded bg-muted" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {isEmpty && (
            <div className="py-10 text-center text-sm text-muted-foreground">
              No results for{" "}
              <span className="font-medium">{`"${debouncedQ}"`}</span>
            </div>
          )}

          {!isLoading && sections.length > 0 && (
            <div>
              {sections.map((section) => {
                // Calculate the offset for this section within flat
                let sectionOffset = 0;
                for (const s of sections) {
                  if (s.kind === section.kind) break;
                  sectionOffset += s.items.length;
                }
                return (
                  <div key={section.kind}>
                    <SectionHeader label={section.label} />
                    {section.items.map((r, i) => (
                      <ResultRow
                        key={`${r.kind}-${r.id}`}
                        result={r}
                        isActive={activeIdx === sectionOffset + i}
                        onClick={() => handleSelect(r)}
                      />
                    ))}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer hint */}
        <div className="flex items-center gap-4 border-t px-4 py-2 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Badge variant="outline" className="px-1.5 text-[10px]">{"↑↓"}</Badge>
            navigate
          </span>
          <span className="flex items-center gap-1.5">
            <Badge variant="outline" className="px-1.5 text-[10px]">{"↵"}</Badge>
            open
          </span>
          <span className="flex items-center gap-1.5">
            <Badge variant="outline" className="px-1.5 text-[10px]">ESC</Badge>
            close
          </span>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── Trigger button ────────────────────────────────────────────────────────────

export function SearchTrigger({ onClick }: { onClick: () => void }) {
  const isMac =
    typeof navigator !== "undefined" && /mac/i.test(navigator.platform);

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-2.5 rounded-md border border-sidebar-border/60 bg-sidebar-accent/30 px-3 py-2 text-left text-sm text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent/60 hover:text-sidebar-foreground cursor-pointer"
    >
      <Search className="size-3.5 shrink-0" />
      <span className="flex-1 text-xs">Search…</span>
      <kbd className="rounded border border-sidebar-border/60 bg-sidebar-accent/50 px-1.5 py-0.5 font-mono text-[10px]">
        {isMac ? "⌘K" : "Ctrl+K"}
      </kbd>
    </button>
  );
}

// ── Hook: global ⌘K / Ctrl+K listener ────────────────────────────────────────

export function useGlobalSearch() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return { open, setOpen };
}
