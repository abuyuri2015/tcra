import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { useNavigate } from "react-router-dom";
import {
  Bell,
  CalendarClock,
  AlertTriangle,
  ArrowRightLeft,
  CheckCheck,
  ClipboardList,
  MessageSquarePlus,
  Building2,
  ListChecks,
  Newspaper,
  BellRing,
  BadgeEuro,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";

type Notification = Doc<"notifications">;

// ── Icon mapping ─────────────────────────────────────────────────────────────

function notificationIcon(type: Notification["type"]) {
  switch (type) {
    case "task_due_today":
      return <CalendarClock className="size-4 text-amber-500" />;
    case "task_overdue":
      return <AlertTriangle className="size-4 text-destructive" />;
    case "file_status_changed":
      return <ArrowRightLeft className="size-4 text-blue-500" />;
    case "task_assigned":
      return <ClipboardList className="size-4 text-primary" />;
    case "modification_requested":
      return <MessageSquarePlus className="size-4 text-chart-4" />;
    case "modification_responded":
      return <Building2 className="size-4 text-chart-3" />;
    case "offer_selection_submitted":
      return <ListChecks className="size-4 text-chart-2" />;
    case "daily_digest":
      return <Newspaper className="size-4 text-chart-1" />;
    case "pending_response_followup":
      return <BellRing className="size-4 text-chart-2" />;
    case "payment_overdue":
      return <BadgeEuro className="size-4 text-destructive" />;
  }
}

// ── Notification row ─────────────────────────────────────────────────────────

function NotificationRow({
  notification,
  onNavigate,
}: {
  notification: Notification;
  onNavigate: (linkTo: string, id: Notification["_id"]) => void;
}) {
  const timeAgo = formatDistanceToNow(new Date(notification.timestamp), {
    addSuffix: true,
  });

  return (
    <button
      type="button"
      onClick={() => onNavigate(notification.linkTo, notification._id)}
      className={cn(
        "flex w-full items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-colors cursor-pointer",
        "hover:bg-muted/80",
        !notification.isRead && "bg-primary/5",
      )}
    >
      <span className="mt-0.5 shrink-0">
        {notificationIcon(notification.type)}
      </span>
      <div className="min-w-0 flex-1">
        <p
          className={cn(
            "text-sm leading-snug",
            !notification.isRead && "font-medium",
          )}
        >
          {notification.title}
        </p>
        <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">
          {notification.body}
        </p>
        <p className="mt-1 text-[11px] text-muted-foreground/70">
          {timeAgo}
        </p>
      </div>
      {!notification.isRead && (
        <span className="mt-2 size-2 shrink-0 rounded-full bg-primary" />
      )}
    </button>
  );
}

// ── Main component ───────────────────────────────────────────────────────────

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const navigate = useNavigate();

  const notifications = useQuery(api.notifications.list);
  const unreadCount = useQuery(api.notifications.unreadCount);
  const markAsRead = useMutation(api.notifications.markAsRead);
  const markAllAsRead = useMutation(api.notifications.markAllAsRead);

  // Close panel when clicking outside
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const handleNavigate = async (linkTo: string, id: Notification["_id"]) => {
    await markAsRead({ id });
    setOpen(false);
    navigate(linkTo);
  };

  const handleMarkAll = async () => {
    await markAllAsRead({});
  };

  const count = unreadCount ?? 0;

  return (
    <div className="relative">
      <button
        ref={buttonRef}
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={cn(
          "relative grid size-9 place-items-center rounded-md transition-colors cursor-pointer",
          "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
          open && "bg-sidebar-accent text-sidebar-foreground",
        )}
        aria-label={`Notifications${count > 0 ? ` (${count} unread)` : ""}`}
      >
        <Bell className="size-[18px]" />
        {count > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex size-[18px] items-center justify-center rounded-full bg-destructive text-[10px] font-semibold text-destructive-foreground">
            {count > 99 ? "99+" : count}
          </span>
        )}
      </button>

      {open && (
        <div
          ref={panelRef}
          className={cn(
            "absolute z-50 w-[360px] rounded-xl border bg-popover shadow-lg",
            // On desktop sidebar: position to the right of the bell
            "left-full top-0 ml-2",
            // Mobile: position below the bell
            "max-lg:left-auto max-lg:right-0 max-lg:top-full max-lg:ml-0 max-lg:mt-2",
          )}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b px-4 py-3">
            <h3 className="font-display text-sm font-semibold">
              Notifications
            </h3>
            {count > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="h-auto px-2 py-1 text-xs text-muted-foreground"
                onClick={handleMarkAll}
              >
                <CheckCheck className="size-3.5" />
                Mark all read
              </Button>
            )}
          </div>

          {/* Content */}
          <div className="max-h-[420px] overflow-y-auto p-1.5">
            {notifications === undefined ? (
              <div className="space-y-2 p-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full rounded-lg" />
                ))}
              </div>
            ) : notifications.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-10 text-center">
                <Bell className="size-8 text-muted-foreground/40" />
                <p className="text-sm text-muted-foreground">
                  No notifications yet
                </p>
              </div>
            ) : (
              notifications.map((n) => (
                <NotificationRow
                  key={n._id}
                  notification={n}
                  onNavigate={handleNavigate}
                />
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
