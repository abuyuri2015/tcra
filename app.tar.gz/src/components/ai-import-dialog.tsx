/**
 * Reusable AI data-import dialog.
 *
 * Usage:
 *   <AiImportDialog
 *     type="hotels"
 *     title="Import hotels with AI"
 *     placeholder="Paste hotel info, quote emails, brochure text…"
 *     onImport={async (data) => { /* call your bulk mutation *\/ }}
 *     renderPreview={(data) => <MyPreviewComponent data={data} />}
 *   />
 */

import { useState } from "react";
import { useAction } from "convex/react";
import { Sparkles, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";

type ExtractType =
  | "hotel"
  | "hotels"
  | "supplier"
  | "suppliers"
  | "passengers"
  | "itinerary"
  | "clients";

type AiImportDialogProps = {
  /** Extraction type sent to the AI backend */
  type: ExtractType;
  /** Dialog title */
  title: string;
  /** Textarea placeholder */
  placeholder: string;
  /** Called with extracted data when the user clicks Confirm */
  onImport: (data: unknown) => Promise<void>;
  /** Renders a preview of the extracted data before confirmation */
  renderPreview: (data: unknown) => React.ReactNode;
  /** Optional trigger element. If omitted, a default "Import with AI" button is rendered. */
  trigger?: React.ReactNode;
  /** Optional ISO date string used as context for itinerary extraction */
  startDate?: string;
};

type Step = "input" | "preview" | "importing";

export default function AiImportDialog({
  type,
  title,
  placeholder,
  onImport,
  renderPreview,
  trigger,
  startDate,
}: AiImportDialogProps) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("input");
  const [text, setText] = useState("");
  const [extracted, setExtracted] = useState<unknown>(null);
  const [extracting, setExtracting] = useState(false);

  const extract = useAction(api.ai.extract.extractData);

  const handleOpen = () => {
    setStep("input");
    setText("");
    setExtracted(null);
    setOpen(true);
  };

  const handleExtract = async () => {
    if (!text.trim()) return;
    setExtracting(true);
    try {
      const result = await extract({ type, text: text.trim(), startDate });
      setExtracted(result.data);
      setStep("preview");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "AI extraction failed. Please try again.";
      toast.error(msg);
    } finally {
      setExtracting(false);
    }
  };

  const handleConfirm = async () => {
    if (!extracted) return;
    setStep("importing");
    try {
      await onImport(extracted);
      setOpen(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Import failed. Please try again.";
      toast.error(msg);
      setStep("preview");
    }
  };

  const handleBack = () => {
    setStep("input");
  };

  return (
    <>
      {trigger ? (
        <div onClick={handleOpen} className="contents cursor-pointer">
          {trigger}
        </div>
      ) : (
        <Button variant="secondary" onClick={handleOpen}>
          <Sparkles className="size-4" />
          Import with AI
        </Button>
      )}

      <Dialog open={open} onOpenChange={(v) => { if (!v) setOpen(false); }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display flex items-center gap-2">
              <Sparkles className="size-4 text-primary" />
              {title}
            </DialogTitle>
          </DialogHeader>

          {step === "input" && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Paste any text — emails, quotes, brochure content, lists — and AI will extract
                  the structured data automatically.
                </p>
                <Textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder={placeholder}
                  rows={10}
                  className="resize-none font-mono text-sm"
                  autoFocus
                />
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleExtract} disabled={!text.trim() || extracting}>
                  {extracting ? (
                    <>
                      <Loader2 className="size-4 animate-spin" />
                      Extracting…
                    </>
                  ) : (
                    <>
                      <Sparkles className="size-4" />
                      Extract data
                    </>
                  )}
                </Button>
              </DialogFooter>
            </>
          )}

          {step === "preview" && extracted !== null && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Review the extracted data below. Click{" "}
                  <strong>Confirm import</strong> to save it, or go back to edit
                  the source text.
                </p>
                <div className="rounded-lg border bg-muted/30 overflow-hidden">
                  {renderPreview(extracted)}
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={handleBack}>
                  Back
                </Button>
                <Button onClick={handleConfirm}>
                  Confirm import
                </Button>
              </DialogFooter>
            </>
          )}

          {step === "importing" && (
            <div className="flex items-center justify-center py-12 gap-3">
              <Loader2 className="size-5 animate-spin text-primary" />
              <span className="text-sm text-muted-foreground">Saving…</span>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// ── Shared preview helpers ────────────────────────────────────────────────────

export function PreviewField({
  label,
  value,
}: {
  label: string;
  value: React.ReactNode;
}) {
  if (value === undefined || value === null || value === "") return null;
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[10px] uppercase tracking-wider font-medium text-muted-foreground">
        {label}
      </span>
      <span className="text-sm">{value}</span>
    </div>
  );
}

export function PreviewCard({
  title,
  subtitle,
  children,
  defaultOpen = true,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b last:border-0">
      <button
        type="button"
        className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left hover:bg-muted/50 transition-colors"
        onClick={() => setOpen((o) => !o)}
      >
        <div>
          <p className="text-sm font-medium">{title}</p>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
        </div>
        {open ? (
          <ChevronUp className="size-4 shrink-0 text-muted-foreground" />
        ) : (
          <ChevronDown className="size-4 shrink-0 text-muted-foreground" />
        )}
      </button>
      {open && <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 px-4 pb-4">{children}</div>}
    </div>
  );
}
