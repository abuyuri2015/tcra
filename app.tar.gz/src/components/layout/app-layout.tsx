import { useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import {
  Authenticated,
  AuthLoading,
  Unauthenticated,
} from "convex/react";
import {
  BedDouble,
  BookUser,
  Calendar,
  CalendarRange,
  CheckSquare,
  FileText,
  LayoutDashboard,
  Menu,
  Receipt,
  Search,
  Settings,
  Users,
  Wallet,
  KanbanSquare,
  BarChart2,
} from "lucide-react";
import { toast } from "sonner";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet.tsx";
import { cn } from "@/lib/utils.ts";
import { useAuth } from "@/hooks/use-auth.ts";
import {
  GlobalSearch,
  SearchTrigger,
  useGlobalSearch,
} from "@/components/global-search.tsx";
import NotificationBell from "@/components/notification-bell.tsx";

type NavItem = {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  ready: boolean;
  bottom?: boolean;
};

const NAV_ITEMS: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, ready: true },
  { to: "/files", label: "Group files", icon: FileText, ready: true },
  { to: "/pipeline", label: "Pipeline", icon: KanbanSquare, ready: true },
  { to: "/clients", label: "Clients", icon: Users, ready: true },
  { to: "/hotels", label: "Hotels", icon: BedDouble, ready: true },
  { to: "/suppliers", label: "Suppliers", icon: BookUser, ready: true },
  { to: "/calendar", label: "Calendar", icon: Calendar, ready: true },
  { to: "/tasks", label: "Tasks", icon: CheckSquare, ready: true },
  { to: "/itineraries", label: "Itineraries", icon: CalendarRange, ready: true },
  { to: "/finance", label: "Finance", icon: Wallet, ready: true },
  { to: "/reports", label: "Reports", icon: BarChart2, ready: true },
  { to: "/documents", label: "Vouchers & invoices", icon: Receipt, ready: true },
  { to: "/settings", label: "Settings", icon: Settings, ready: true, bottom: true },
];

function Brand() {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground font-display text-lg font-semibold">
        T
      </span>
      <span className="leading-tight">
        <span className="block font-display text-base font-semibold text-sidebar-foreground">
          Tessera
        </span>
        <span className="block text-[11px] uppercase tracking-[0.16em] text-sidebar-foreground/60">
          Groups &amp; MICE
        </span>
      </span>
    </Link>
  );
}

function NavItems({ onNavigate, items }: { onNavigate?: () => void; items: NavItem[] }) {
  return (
    <nav className="flex flex-col gap-1">
      {items.map((item) => {
        const Icon = item.icon;
        if (!item.ready) {
          return (
            <button
              key={item.to}
              type="button"
              onClick={() => toast.info("Coming soon in a future milestone!")}
              className="flex items-center gap-3 rounded-md px-3 py-2 text-sm text-sidebar-foreground/50 transition-colors hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
            >
              <Icon className="size-4 shrink-0" />
              {item.label}
            </button>
          );
        }
        return (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === "/"}
            onClick={onNavigate}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                isActive
                  ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
              )
            }
          >
            <Icon className="size-4 shrink-0" />
            {item.label}
          </NavLink>
        );
      })}
    </nav>
  );
}

function UserCard() {
  const { user } = useAuth();
  const name = user?.profile.name ?? user?.profile.email ?? "Signed in";
  return (
    <div className="space-y-3 border-t border-sidebar-border pt-4">
      <p className="truncate px-1 text-xs text-sidebar-foreground/60">{name}</p>
      <SignInButton
        variant="secondary"
        size="sm"
        className="w-full"
        signOutText="Sign out"
      />
    </div>
  );
}

function SignInScreen() {
  return (
    <div className="grid min-h-screen place-items-center bg-gradient-to-br from-background via-secondary/40 to-background px-6">
      <div className="w-full max-w-md space-y-6 rounded-xl border bg-card p-8 text-center shadow-sm">
        <span className="mx-auto grid size-12 place-items-center rounded-lg bg-primary text-primary-foreground font-display text-2xl font-semibold">
          T
        </span>
        <div className="space-y-2">
          <h1 className="font-display text-2xl font-semibold tracking-tight">
            Tessera Backoffice
          </h1>
          <p className="text-sm text-muted-foreground text-balance">
            Reservations, costs, itineraries and documents for groups, meetings
            and incentives.
          </p>
        </div>
        <SignInButton className="w-full" signInText="Sign in to continue" />
      </div>
    </div>
  );
}

// ── Mobile menu (opens from the top-right) ──────────────────────────────────

function MobileMenu({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Sheet open={open} onOpenChange={(next) => !next && onClose()}>
      <SheetContent side="right" className="bg-sidebar p-0 lg:hidden">
        <SheetHeader className="border-b border-sidebar-border">
          <SheetTitle className="text-sidebar-foreground">
            <Brand />
          </SheetTitle>
        </SheetHeader>
        <div className="flex flex-1 flex-col justify-between overflow-y-auto px-4 pb-4">
          <div className="space-y-4">
            <SearchTrigger
              onClick={() => {
                onClose();
              }}
            />
            <NavItems items={NAV_ITEMS.filter((i) => !i.bottom)} onNavigate={onClose} />
          </div>
          <div className="space-y-1 pt-4">
            <NavItems items={NAV_ITEMS.filter((i) => i.bottom)} onNavigate={onClose} />
            <UserCard />
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// ── Main layout ──────────────────────────────────────────────────────────────

export default function AppLayout() {
  const location = useLocation();
  const { open, setOpen } = useGlobalSearch();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      <AuthLoading>
        <div className="grid min-h-screen place-items-center p-6">
          <Skeleton className="h-40 w-full max-w-md" />
        </div>
      </AuthLoading>
      <Unauthenticated>
        <SignInScreen />
      </Unauthenticated>
      <Authenticated>
        <GlobalSearch open={open} onClose={() => setOpen(false)} />
        <div className="flex min-h-screen bg-background">
          <aside className="hidden w-64 shrink-0 flex-col justify-between bg-sidebar p-5 lg:flex">
            <div className="space-y-6">
              <Brand />
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <SearchTrigger onClick={() => setOpen(true)} />
                </div>
                <NotificationBell />
              </div>
              <NavItems items={NAV_ITEMS.filter((i) => !i.bottom)} />
            </div>
            <div className="space-y-1">
              <NavItems items={NAV_ITEMS.filter((i) => i.bottom)} />
              <UserCard />
            </div>
          </aside>

          <div className="flex min-w-0 flex-1 flex-col">
            <header className="flex items-center justify-between gap-3 border-b bg-card/80 px-4 py-3 backdrop-blur lg:hidden">
              <div className="rounded-md bg-sidebar px-3 py-2">
                <Brand />
              </div>
              {/* All mobile actions live together in the top-right corner */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setOpen(true)}
                  aria-label="Search"
                  className="grid size-9 place-items-center rounded-md text-foreground/80 transition-colors hover:bg-accent"
                >
                  <Search className="size-5" />
                </button>
                <NotificationBell />
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(true)}
                  aria-label="Open menu"
                  className="grid size-9 place-items-center rounded-md text-foreground/80 transition-colors hover:bg-accent"
                >
                  <Menu className="size-5" />
                </button>
              </div>
            </header>
            <main
              key={location.pathname}
              className="flex-1 overflow-x-hidden px-4 pb-6 pt-6 sm:px-6 lg:px-10 lg:pb-10"
            >
              <Outlet />
            </main>
          </div>

          <MobileMenu open={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} />
        </div>
      </Authenticated>
    </>
  );
}
