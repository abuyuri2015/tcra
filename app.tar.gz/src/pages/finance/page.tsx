import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import {
  ArrowRight,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  TrendingUp,
  TrendingDown,
  CircleDollarSign,
  Wallet,
  BarChart3,
  Filter,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { formatMoney, FILE_STATUS_OPTIONS } from "@/lib/domain.ts";
import { formatDateRange } from "@/lib/dates.ts";
import { downloadCsv } from "@/lib/csv-export.ts";
import { generateReportPDF } from "@/lib/report-pdf.ts";
import ReportExportMenu from "@/components/report-export-menu.tsx";
import type { FilePnL } from "@/convex/finance.ts";

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtEur(n: number) {
  return formatMoney(n, "EUR");
}

function MarginChip({ pct }: { pct: number | null }) {
  if (pct === null)
    return <span className="text-xs text-muted-foreground">—</span>;
  const good = pct >= 15;
  const warn = pct >= 5 && pct < 15;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        good && "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
        warn && "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
        !good && !warn && "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
      )}
    >
      {pct >= 0 ? (
        <TrendingUp className="size-3" />
      ) : (
        <TrendingDown className="size-3" />
      )}
      {pct}%
    </span>
  );
}

// ── Summary cards ─────────────────────────────────────────────────────────────

function SummaryCard({
  label,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string | undefined;
  sub?: string;
  icon: typeof Wallet;
  accent?: "teal" | "red" | "green";
}) {
  const accentClass =
    accent === "teal"
      ? "border-primary/30 bg-primary/5"
      : accent === "green"
        ? "border-emerald-300/40 bg-emerald-50/60 dark:bg-emerald-950/20"
        : accent === "red"
          ? "border-red-300/40 bg-red-50/60 dark:bg-red-950/20"
          : "";
  const iconClass =
    accent === "teal"
      ? "text-primary"
      : accent === "green"
        ? "text-emerald-600 dark:text-emerald-400"
        : accent === "red"
          ? "text-red-600 dark:text-red-400"
          : "text-muted-foreground";

  return (
    <Card className={cn("gap-2 p-5", accentClass)}>
      <div className="flex items-center justify-between">
        <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
        <Icon className={cn("size-4", iconClass)} />
      </div>
      {value === undefined ? (
        <Skeleton className="h-9 w-32" />
      ) : (
        <>
          <p className={cn("font-display text-2xl font-semibold", iconClass)}>{value}</p>
          {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
        </>
      )}
    </Card>
  );
}

// ── Sort logic ────────────────────────────────────────────────────────────────

type SortKey = "startDate" | "totalIncomeEur" | "totalCostEur" | "marginEur" | "marginPct";
type SortDir = "asc" | "desc";

function sortRows(rows: FilePnL[], key: SortKey, dir: SortDir): FilePnL[] {
  return [...rows].sort((a, b) => {
    const av = a[key] ?? -Infinity;
    const bv = b[key] ?? -Infinity;
    return dir === "asc" ? (av < bv ? -1 : 1) : av > bv ? -1 : 1;
  });
}

function SortButton({
  label,
  col,
  current,
  dir,
  onClick,
}: {
  label: string;
  col: SortKey;
  current: SortKey;
  dir: SortDir;
  onClick: (col: SortKey) => void;
}) {
  const active = current === col;
  return (
    <button
      type="button"
      onClick={() => onClick(col)}
      className={cn(
        "flex items-center gap-1 text-xs font-medium uppercase tracking-wide transition-colors",
        active ? "text-foreground" : "text-muted-foreground hover:text-foreground",
      )}
    >
      {label}
      {active ? (
        dir === "asc" ? <ArrowUp className="size-3" /> : <ArrowDown className="size-3" />
      ) : (
        <ArrowUpDown className="size-3 opacity-40" />
      )}
    </button>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function FinancePage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("startDate");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const data = useQuery(api.finance.overview, {
    status:
      statusFilter !== "all"
        ? (statusFilter as "enquiry" | "quoted" | "confirmed" | "operating" | "closed" | "cancelled")
        : undefined,
    fromDate: fromDate || undefined,
    toDate: toDate || undefined,
  });

  const rows = useMemo(
    () => (data ? sortRows(data.rows, sortKey, sortDir) : undefined),
    [data, sortKey, sortDir],
  );

  function handleSort(col: SortKey) {
    if (col === sortKey) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(col); setSortDir("desc"); }
  }

  const { totals } = data ?? {};

  const handleExport = () => {
    if (!rows || rows.length === 0) return;
    const exportRows = rows.map((r) => ({
      Reference: r.reference,
      Title: r.title,
      Client: r.clientName,
      Status: r.status,
      "Start date": r.startDate.slice(0, 10),
      "End date": r.endDate.slice(0, 10),
      "Income (EUR)": r.totalIncomeEur,
      "Cost (EUR)": r.totalCostEur,
      "Margin (EUR)": r.marginEur,
      "Margin %": r.marginPct ?? "",
    }));
    const today = new Date().toISOString().slice(0, 10);
    downloadCsv(exportRows, `finance-overview-${today}.csv`);
  };

  const handleExportPdf = () => {
    if (!rows || rows.length === 0 || !totals) return;
    generateReportPDF({
      title: "FINANCE OVERVIEW",
      subtitle: "P&L across all group files · EUR",
      filename: `finance-overview-${new Date().toISOString().slice(0, 10)}.pdf`,
      kpis: [
        { label: "Files in view", value: String(totals.fileCount) },
        { label: "Total income", value: fmtEur(totals.totalIncomeEur) },
        { label: "Total cost", value: fmtEur(totals.totalCostEur) },
        { label: "Gross margin", value: fmtEur(totals.marginEur) },
      ],
      tables: [
        {
          heading: "P&L by file",
          columns: ["Reference", "Title", "Client", "Status", "Income (EUR)", "Cost (EUR)", "Margin (EUR)"],
          rows: rows.map((r) => [
            r.reference,
            r.title,
            r.clientName,
            r.status,
            fmtEur(r.totalIncomeEur),
            fmtEur(r.totalCostEur),
            fmtEur(r.marginEur),
          ]),
          foot: [
            "",
            "",
            "",
            "Total",
            fmtEur(totals.totalIncomeEur),
            fmtEur(totals.totalCostEur),
            fmtEur(totals.marginEur),
          ],
        },
      ],
    });
  };

  return (
    <div className="mx-auto max-w-7xl space-y-8">
      <PageHeader
        eyebrow="Finance"
        title="Finance overview"
        description="P&L across all group files — costs, income and margin in EUR."
        actions={
          rows && rows.length > 0 ? (
            <ReportExportMenu onExportCsv={handleExport} onExportPdf={handleExportPdf} />
          ) : undefined
        }
      />

      {/* ── Summary cards ── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <SummaryCard
          label="Files in view"
          value={totals ? String(totals.fileCount) : undefined}
          sub="matching current filters"
          icon={BarChart3}
        />
        <SummaryCard
          label="Total income"
          value={totals ? fmtEur(totals.totalIncomeEur) : undefined}
          sub="all income lines in EUR"
          icon={CircleDollarSign}
          accent="teal"
        />
        <SummaryCard
          label="Total cost"
          value={totals ? fmtEur(totals.totalCostEur) : undefined}
          sub="all cost lines in EUR"
          icon={Wallet}
        />
        <SummaryCard
          label="Gross margin"
          value={
            totals
              ? `${fmtEur(totals.marginEur)}${totals.marginPct !== null ? ` · ${totals.marginPct}%` : ""}`
              : undefined
          }
          sub="income minus costs"
          icon={totals && totals.marginEur >= 0 ? TrendingUp : TrendingDown}
          accent={
            totals
              ? totals.marginEur >= 0
                ? "green"
                : "red"
              : undefined
          }
        />
      </div>

      {/* ── Filters ── */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <Filter className="size-4 shrink-0 text-muted-foreground" />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {FILE_STATUS_OPTIONS.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2">
            <Input
              type="date"
              className="w-40 text-sm"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              placeholder="From"
            />
            <span className="text-xs text-muted-foreground">to</span>
            <Input
              type="date"
              className="w-40 text-sm"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              placeholder="To"
            />
          </div>
          {(statusFilter !== "all" || fromDate || toDate) && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setStatusFilter("all"); setFromDate(""); setToDate(""); }}
            >
              Clear filters
            </Button>
          )}
        </div>
      </Card>

      {/* ── Table ── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="font-display text-base">P&L by file</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {rows === undefined ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : rows.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon"><BarChart3 /></EmptyMedia>
                <EmptyTitle>No files match your filters</EmptyTitle>
                <EmptyDescription>Try adjusting the status or date range.</EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button variant="secondary" onClick={() => { setStatusFilter("all"); setFromDate(""); setToDate(""); }}>
                  Clear filters
                </Button>
              </EmptyContent>
            </Empty>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40">
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-muted-foreground">
                      File
                    </th>
                    <th className="px-4 py-3 text-left">
                      <SortButton label="Departure" col="startDate" current={sortKey} dir={sortDir} onClick={handleSort} />
                    </th>
                    <th className="hidden px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-muted-foreground sm:table-cell">
                      Status
                    </th>
                    <th className="px-4 py-3 text-right">
                      <SortButton label="Income" col="totalIncomeEur" current={sortKey} dir={sortDir} onClick={handleSort} />
                    </th>
                    <th className="hidden px-4 py-3 text-right lg:table-cell">
                      <SortButton label="Cost" col="totalCostEur" current={sortKey} dir={sortDir} onClick={handleSort} />
                    </th>
                    <th className="px-4 py-3 text-right">
                      <SortButton label="Margin" col="marginEur" current={sortKey} dir={sortDir} onClick={handleSort} />
                    </th>
                    <th className="px-4 py-3 text-right">
                      <SortButton label="%" col="marginPct" current={sortKey} dir={sortDir} onClick={handleSort} />
                    </th>
                    <th className="px-4 py-3" />
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {rows.map((row) => (
                    <tr
                      key={row.fileId}
                      className="transition-colors hover:bg-muted/30"
                    >
                      <td className="px-4 py-3">
                        <p className="font-medium leading-tight">{row.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {row.reference} · {row.clientName}
                        </p>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {formatDateRange(row.startDate, row.endDate)}
                      </td>
                      <td className="hidden px-4 py-3 sm:table-cell">
                        <StatusBadge status={row.status} />
                      </td>
                      <td className="px-4 py-3 text-right font-medium tabular-nums">
                        {row.totalIncomeEur > 0 ? fmtEur(row.totalIncomeEur) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="hidden px-4 py-3 text-right tabular-nums text-muted-foreground lg:table-cell">
                        {row.totalCostEur > 0 ? fmtEur(row.totalCostEur) : (
                          <span>—</span>
                        )}
                      </td>
                      <td className={cn(
                        "px-4 py-3 text-right font-medium tabular-nums",
                        row.marginEur < 0 && "text-red-600 dark:text-red-400",
                        row.marginEur > 0 && "text-emerald-700 dark:text-emerald-400",
                      )}>
                        {row.totalIncomeEur > 0 || row.totalCostEur > 0
                          ? fmtEur(row.marginEur)
                          : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <MarginChip pct={row.totalIncomeEur > 0 || row.totalCostEur > 0 ? row.marginPct : null} />
                      </td>
                      <td className="px-4 py-3">
                        <Button asChild variant="ghost" size="sm" className="cursor-pointer">
                          <Link to={`/files/${row.fileId}?tab=finance`}>
                            <ArrowRight className="size-4" />
                          </Link>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
                {/* Totals footer */}
                {rows.length > 1 && totals && (
                  <tfoot>
                    <tr className="border-t-2 bg-muted/50 font-semibold">
                      <td className="px-4 py-3 text-xs uppercase tracking-wide text-muted-foreground" colSpan={3}>
                        Total ({totals.fileCount} files)
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums">
                        {fmtEur(totals.totalIncomeEur)}
                      </td>
                      <td className="hidden px-4 py-3 text-right tabular-nums text-muted-foreground lg:table-cell">
                        {fmtEur(totals.totalCostEur)}
                      </td>
                      <td className={cn(
                        "px-4 py-3 text-right tabular-nums",
                        totals.marginEur < 0 && "text-red-600 dark:text-red-400",
                        totals.marginEur >= 0 && "text-emerald-700 dark:text-emerald-400",
                      )}>
                        {fmtEur(totals.marginEur)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <MarginChip pct={totals.marginPct} />
                      </td>
                      <td />
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
