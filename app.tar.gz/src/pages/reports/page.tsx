import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { Authenticated, AuthLoading } from "convex/react";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import PageHeader from "@/components/page-header.tsx";
import RevenueDashboard from "./_components/revenue-dashboard.tsx";
import PipelineReport from "./_components/pipeline-report.tsx";
import TeamReport from "./_components/team-report.tsx";
import OpsSnapshot from "./_components/ops-snapshot.tsx";
import ClientReport from "./_components/client-report.tsx";

export default function ReportsPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader
        eyebrow="Analytics"
        title="Reports"
        description="Revenue, pipeline, team performance and operational health across all files."
      />

      <AuthLoading>
        <Skeleton className="h-96 w-full" />
      </AuthLoading>

      <Authenticated>
        <Tabs defaultValue="revenue">
          <TabsList className="mb-6">
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
            <TabsTrigger value="clients">Clients</TabsTrigger>
            <TabsTrigger value="team">Team</TabsTrigger>
            <TabsTrigger value="operations">Operations</TabsTrigger>
          </TabsList>

          <TabsContent value="revenue">
            <RevenueDashboard />
          </TabsContent>

          <TabsContent value="pipeline">
            <PipelineReport />
          </TabsContent>

          <TabsContent value="clients">
            <ClientReport />
          </TabsContent>

          <TabsContent value="team">
            <TeamReport />
          </TabsContent>

          <TabsContent value="operations">
            <OpsSnapshot />
          </TabsContent>
        </Tabs>
      </Authenticated>
    </div>
  );
}
