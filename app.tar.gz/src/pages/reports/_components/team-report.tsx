import { useState } from "react";
import { useQuery } from "convex/react";
import {
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Users,
  TrendingUp,
  BarChart2,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { TeamMemberStats } from "@/convex/reports.ts";
import { formatMoney } from "@/lib/domain.ts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { cn } from "@/lib/utils.ts";
import { downloadCsv } from "@/lib/csv-export.ts";
import { generateReportPDF } from "@/lib/report-pdf.ts";
import ReportExportMenu from "@/components/report-export-menu.tsx";

// ── Helpers ───────────────────────────────────────────────────────────────────

function shortEur(value: number) {
  if (value >= 1_000_000) return `€${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `€${(value / 1_000).toFixed(0)}K`;
  return `€${value.toFixed(0)}`;
}

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0] ?? "")
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

// Consistent colour per member index (cycles through chart colours)
const AVATAR_COLOURS = [
  "bg-chart-1/20 text-chart-1",
  "bg-chart-2/20 text-chart-2",
  "bg-chart-3/20 text-chart-3",
  "bg-chart-4/20 text-chart-4",
  "bg-chart-5/20 text-chart-5",
];

// ── Sort types ────────────────────────────────────────────────────────────────

type SortKey =
  | "name"
  | "totalFiles"
  | "confirmedRevenue"
  | "pipelineValue"
  | "conversionRate";

type SortDir = "asc" | "desc";

function sortMembers(
  members: TeamMemberStats[],
  key: SortKey,
  dir: SortDir,
): TeamMemberStats[] {
  return [...members].sort((a, b) => {
    let diff = 0;
    if (key === "name") {
      diff = a.name.localeCompare(b.name);
    } else if (key === "conversionRate") {
      diff = (a.conversionRate ?? -1) - (b.conversionRate ?? -1);
    } else {
      diff = (a[key] as number) - (b[key] as number);
    }
    return dir === "asc" ? diff : -diff;
  });
}

// ── Skeleton ──────────────────────────────────────────────────────────────────

function TeamSkeletons() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        {[0, 1, 2].map((i) => <Skeleton key={i} className="h-24 w-full" />)}
      </div>
      <Skeleton className="h-80 w-full" />
    </div>
  );
}

// ── Sort header cell ──────────────────────────────────────────────────────────

function SortTh({
  label,
  sortKey,
  current,
  dir,
  onSort,
  className,
}: {
  label: string;
  sortKey: SortKey;
  current: SortKey;
  dir: SortDir;
  onSort: (k: SortKey) => void;
  className?: string;
}) {
  const active = current === sortKey;
  return (
    <th
      className={cn(
        "cursor-pointer select-none whitespace-nowrap px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-muted-foreground hover:text-foreground transition-colors",
        className,
      )}
      onClick={() => onSort(sortKey)}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {active ? (
          dir === "asc" ? (
            <ChevronUp className="size-3" />
          ) : (
            <ChevronDown className="size-3" />
          )
        ) : (
          <ChevronsUpDown className="size-3 opacity-40" />
        )}
      </span>
    </th>
  );
}

// ── Status breakdown mini-bar ─────────────────────────────────────────────────

function StatusBar({ member }: { member: TeamMemberStats }) {
  const total =
    member.enquiryFiles +
    member.quotedFiles +
    member.confirmedFiles +
    member.operatingFiles +
    member.closedFiles +
    member.cancelledFiles;

  if (total === 0) return <span className="text-xs text-muted-foreground">—</span>;

  const segments = [
    { count: member.closedFiles, colour: "var(--color-chart-1)" },
    { count: member.operatingFiles, colour: "var(--color-chart-2)" },
    { count: member.confirmedFiles, colour: "var(--color-chart-3)" },
    { count: member.quotedFiles, colour: "var(--color-chart-4)" },
    { count: member.enquiryFiles, colour: "var(--color-muted-foreground)" },
    { count: member.cancelledFiles, colour: "var(--color-destructive)" },
  ].filter((s) => s.count > 0);

  return (
    <div className="flex h-2 w-32 overflow-hidden rounded-full gap-px">
      {segments.map((s, i) => (
        <div
          key={i}
          style={{
            width: `${(s.count / total) * 100}%`,
            background: s.colour,
          }}
        />
      ))}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function TeamReport() {
  const data = useQuery(api.reports.teamReportData, {});

  const [sortKey, setSortKey] = useState<SortKey>("confirmedRevenue");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  if (data === undefined) return <TeamSkeletons />;

  const members = data.members;
  const sorted = sortMembers(members, sortKey, sortDir);

  const totalFiles = members.reduce((s, m) => s + m.totalFiles, 0);
  const totalRevenue = members.reduce((s, m) => s + m.confirmedRevenue, 0);
  const totalPipeline = members.reduce((s, m) => s + m.pipelineValue, 0);

  function handleSort(key: SortKey) {
    if (key === sortKey) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  }

  const handleExportCsv = () => {
    downloadCsv(
      sorted.map((m) => ({
        Member: m.name,
        Email: m.email,
        Files: m.totalFiles,
        "Confirmed revenue (EUR)": Math.round(m.confirmedRevenue),
        "Pipeline value (EUR)": Math.round(m.pipelineValue),
        "Conversion %": m.conversionRate !== null ? m.conversionRate.toFixed(0) : "",
        Enquiry: m.enquiryFiles,
        Quoted: m.quotedFiles,
        Confirmed: m.confirmedFiles,
        Operating: m.operatingFiles,
        Closed: m.closedFiles,
        Cancelled: m.cancelledFiles,
      })),
      `team-report-${new Date().toISOString().slice(0, 10)}.csv`,
    );
  };

  const handleExportPdf = () => {
    generateReportPDF({
      title: "TEAM REPORT",
      subtitle: "Leaderboard by confirmed revenue and pipeline · EUR",
      filename: `team-report-${new Date().toISOString().slice(0, 10)}.pdf`,
      kpis: [
        { label: "Team size", value: String(members.length) },
        { label: "Confirmed revenue", value: shortEur(totalRevenue) },
        { label: "Pipeline value", value: shortEur(totalPipeline) },
      ],
      tables: [
        {
          heading: "Team leaderboard",
          columns: ["Member", "Files", "Confirmed revenue (EUR)", "Pipeline (EUR)", "Conversion"],
          rows: sorted.map((m) => [
            m.name,
            m.totalFiles,
            Math.round(m.confirmedRevenue),
            Math.round(m.pipelineValue),
            m.conversionRate !== null ? `${m.conversionRate.toFixed(0)}%` : "—",
          ]),
        },
      ],
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <ReportExportMenu onExportCsv={handleExportCsv} onExportPdf={handleExportPdf} />
      </div>

      {/* Summary KPIs */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Team size</p>
                <p className="font-display text-2xl font-bold tabular-nums">{members.length}</p>
                <p className="text-xs text-muted-foreground">{totalFiles} files assigned</p>
              </div>
              <div className="rounded-lg bg-muted p-2 shrink-0">
                <Users className="size-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Total confirmed revenue</p>
                <p className="font-display text-2xl font-bold tabular-nums text-chart-3">{shortEur(totalRevenue)}</p>
                <p className="text-xs text-muted-foreground">{formatMoney(totalRevenue, "EUR")}</p>
              </div>
              <div className="rounded-lg bg-chart-3/10 p-2 shrink-0">
                <TrendingUp className="size-5 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Total pipeline value</p>
                <p className="font-display text-2xl font-bold tabular-nums">{shortEur(totalPipeline)}</p>
                <p className="text-xs text-muted-foreground">Enquiry + quoted</p>
              </div>
              <div className="rounded-lg bg-muted p-2 shrink-0">
                <BarChart2 className="size-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Leaderboard table */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base">Team leaderboard</CardTitle>
          <CardDescription>
            Click any column header to sort · all team members · EUR
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {members.length === 0 ? (
            <div className="flex h-40 items-center justify-center text-sm text-muted-foreground">
              No files assigned to any team member yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-muted-foreground w-8">#</th>
                    <SortTh label="Member" sortKey="name" current={sortKey} dir={sortDir} onSort={handleSort} />
                    <SortTh label="Files" sortKey="totalFiles" current={sortKey} dir={sortDir} onSort={handleSort} className="text-right" />
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-muted-foreground">Status mix</th>
                    <SortTh label="Confirmed revenue" sortKey="confirmedRevenue" current={sortKey} dir={sortDir} onSort={handleSort} className="text-right" />
                    <SortTh label="Pipeline" sortKey="pipelineValue" current={sortKey} dir={sortDir} onSort={handleSort} className="text-right" />
                    <SortTh label="Conversion" sortKey="conversionRate" current={sortKey} dir={sortDir} onSort={handleSort} className="text-right" />
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {sorted.map((member, idx) => {
                    const colourClass = AVATAR_COLOURS[idx % AVATAR_COLOURS.length];
                    const isTop = idx === 0 && sortKey === "confirmedRevenue" && sortDir === "desc" && member.confirmedRevenue > 0;

                    return (
                      <tr key={member.userId} className="hover:bg-muted/30 transition-colors">
                        {/* Rank */}
                        <td className="px-4 py-3 text-xs text-muted-foreground tabular-nums">{idx + 1}</td>

                        {/* Name / email */}
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className={cn("flex size-8 shrink-0 items-center justify-center rounded-full text-xs font-bold", colourClass)}>
                              {initials(member.name)}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="font-medium truncate">{member.name}</span>
                                {isTop && (
                                  <Badge className="text-[10px] px-1.5 py-0 bg-chart-3/20 text-chart-3 border-chart-3/30">
                                    Top earner
                                  </Badge>
                                )}
                              </div>
                              {member.email && (
                                <p className="text-xs text-muted-foreground truncate">{member.email}</p>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* File count */}
                        <td className="px-4 py-3 text-right tabular-nums font-medium">
                          {member.totalFiles}
                        </td>

                        {/* Status mini-bar */}
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <StatusBar member={member} />
                            <span className="text-xs text-muted-foreground hidden sm:inline">
                              {member.confirmedFiles + member.operatingFiles + member.closedFiles} confirmed
                            </span>
                          </div>
                        </td>

                        {/* Confirmed revenue */}
                        <td className="px-4 py-3 text-right tabular-nums">
                          <span className={cn("font-medium", member.confirmedRevenue > 0 ? "text-chart-3" : "text-muted-foreground")}>
                            {member.confirmedRevenue > 0 ? shortEur(member.confirmedRevenue) : "—"}
                          </span>
                        </td>

                        {/* Pipeline value */}
                        <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">
                          {member.pipelineValue > 0 ? shortEur(member.pipelineValue) : "—"}
                        </td>

                        {/* Conversion rate */}
                        <td className="px-4 py-3 text-right tabular-nums">
                          {member.conversionRate !== null ? (
                            <span className={cn(
                              "font-medium",
                              member.conversionRate >= 50 ? "text-chart-3" : "text-chart-5",
                            )}>
                              {member.conversionRate.toFixed(0)}%
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Legend */}
      <div className="flex flex-wrap gap-3 px-1">
        {[
          { label: "Closed", colour: "var(--color-chart-1)" },
          { label: "Operating", colour: "var(--color-chart-2)" },
          { label: "Confirmed", colour: "var(--color-chart-3)" },
          { label: "Quoted", colour: "var(--color-chart-4)" },
          { label: "Enquiry", colour: "var(--color-muted-foreground)" },
          { label: "Cancelled", colour: "var(--color-destructive)" },
        ].map((s) => (
          <div key={s.label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="size-2.5 rounded-full shrink-0" style={{ background: s.colour }} />
            {s.label}
          </div>
        ))}
      </div>
    </div>
  );
}
