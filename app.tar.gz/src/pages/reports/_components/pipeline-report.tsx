import { useQuery } from "convex/react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import { TrendingDown, Clock, ArrowRight } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import { downloadMultiSectionCsv } from "@/lib/csv-export.ts";
import { generateReportPDF } from "@/lib/report-pdf.ts";
import ReportExportMenu from "@/components/report-export-menu.tsx";

// ── Helpers ───────────────────────────────────────────────────────────────────

function shortMonth(yyyymm: string) {
  const [y, m] = yyyymm.split("-");
  const d = new Date(Number(y), Number(m) - 1, 1);
  return d.toLocaleString(undefined, { month: "short", year: "2-digit" });
}

// Colour per stage
const STAGE_COLOURS: Record<string, string> = {
  enquiry:   "var(--color-muted-foreground)",
  quoted:    "var(--color-chart-4)",
  confirmed: "var(--color-chart-3)",
  operating: "var(--color-chart-2)",
  closed:    "var(--color-chart-1)",
  cancelled: "var(--color-destructive)",
};

// ── Skeleton ──────────────────────────────────────────────────────────────────

function PipelineSkeletons() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        {[0, 1, 2].map((i) => <Skeleton key={i} className="h-28 w-full" />)}
      </div>
      <Skeleton className="h-72 w-full" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}

// ── Custom area tooltip ───────────────────────────────────────────────────────

function AreaTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  const total = payload.reduce((s, p) => s + (p.value ?? 0), 0);
  return (
    <div className="rounded-lg border bg-popover px-3 py-2 shadow-md text-sm min-w-[140px]">
      <p className="mb-1.5 font-medium text-popover-foreground">{label}</p>
      {[...payload].reverse().map((p) => (
        <div key={p.name} className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-1.5">
            <span className="size-2 rounded-full" style={{ background: p.color }} />
            <span className="text-muted-foreground">{p.name}</span>
          </div>
          <span className="font-medium tabular-nums">{p.value}</span>
        </div>
      ))}
      <div className="mt-1.5 border-t pt-1.5 flex justify-between text-xs">
        <span className="text-muted-foreground">Total</span>
        <span className="font-medium tabular-nums">{total}</span>
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function PipelineReport() {
  const data = useQuery(api.reports.pipelineReportData, {});

  if (data === undefined) return <PipelineSkeletons />;

  const topStageCount = data.funnel[0]?.count ?? 0;
  const confirmedCount = data.funnel.find((s) => s.status === "confirmed")?.count ?? 0;
  const overallConversion = topStageCount > 0 ? (confirmedCount / topStageCount) * 100 : 0;

  const avgConfirmDays = data.avgDaysInStage.find((s) => s.status === "confirmed")?.avgDays ?? 0;

  const hasArea = data.monthly.some((m) =>
    m.enquiry + m.quoted + m.confirmed + m.operating + m.closed + m.cancelled > 0,
  );

  const handleExportCsv = () => {
    downloadMultiSectionCsv(
      [
        {
          title: "Summary",
          rows: [
            { Metric: "Enquiry → Confirmed conversion %", Value: overallConversion.toFixed(1) },
            { Metric: "Avg. days to confirm", Value: avgConfirmDays },
            { Metric: "Cancelled / lost files", Value: data.cancelledCount },
            { Metric: "Cancelled % of all files", Value: data.cancelledPct.toFixed(1) },
          ],
        },
        {
          title: "Stage funnel",
          rows: data.funnel.map((s) => ({
            Stage: s.label,
            Count: s.count,
            "Conversion from previous %": s.conversionFromPrev !== null ? s.conversionFromPrev.toFixed(1) : "",
          })),
        },
        {
          title: "Avg. days in stage",
          rows: data.avgDaysInStage.map((s) => ({ Stage: s.label, "Avg. days": s.avgDays })),
        },
        {
          title: "Files by status per month",
          rows: data.monthly.map((m) => ({
            Month: m.month,
            Enquiry: m.enquiry,
            Quoted: m.quoted,
            Confirmed: m.confirmed,
            Operating: m.operating,
            Closed: m.closed,
            Cancelled: m.cancelled,
          })),
        },
      ],
      `pipeline-report-${new Date().toISOString().slice(0, 10)}.csv`,
    );
  };

  const handleExportPdf = () => {
    generateReportPDF({
      title: "PIPELINE REPORT",
      subtitle: "Conversion funnel and stage ageing · all files",
      filename: `pipeline-report-${new Date().toISOString().slice(0, 10)}.pdf`,
      kpis: [
        { label: "Enquiry → Confirmed", value: `${overallConversion.toFixed(1)}%` },
        { label: "Avg. days to confirm", value: String(avgConfirmDays) },
        { label: "Cancelled / lost", value: String(data.cancelledCount) },
      ],
      tables: [
        {
          heading: "Stage funnel",
          columns: ["Stage", "Count", "Conversion from previous"],
          rows: data.funnel.map((s) => [
            s.label,
            s.count,
            s.conversionFromPrev !== null ? `${s.conversionFromPrev.toFixed(1)}%` : "—",
          ]),
        },
        {
          heading: "Avg. days currently in stage",
          columns: ["Stage", "Avg. days"],
          rows: data.avgDaysInStage.map((s) => [s.label, s.avgDays > 0 ? s.avgDays : "—"]),
        },
        {
          heading: "Files by status per month",
          columns: ["Month", "Enquiry", "Quoted", "Confirmed", "Operating", "Closed", "Cancelled"],
          rows: data.monthly.map((m) => [
            m.month,
            m.enquiry,
            m.quoted,
            m.confirmed,
            m.operating,
            m.closed,
            m.cancelled,
          ]),
        },
      ],
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <ReportExportMenu onExportCsv={handleExportCsv} onExportPdf={handleExportPdf} />
      </div>

      {/* Summary KPI row */}
      <div className="grid gap-4 sm:grid-cols-3">
        {/* Overall conversion */}
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Enquiry → Confirmed
                </p>
                <p className="font-display text-2xl font-bold tabular-nums text-chart-3">
                  {overallConversion.toFixed(1)}%
                </p>
                <p className="text-xs text-muted-foreground">Overall conversion rate</p>
              </div>
              <div className="rounded-lg bg-chart-3/10 p-2 shrink-0">
                <TrendingDown className="size-5 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Avg days to confirm */}
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Avg. days to confirm
                </p>
                <p className="font-display text-2xl font-bold tabular-nums">
                  {avgConfirmDays}
                </p>
                <p className="text-xs text-muted-foreground">Files currently confirmed</p>
              </div>
              <div className="rounded-lg bg-muted p-2 shrink-0">
                <Clock className="size-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cancelled */}
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Cancelled / lost
                </p>
                <p className="font-display text-2xl font-bold tabular-nums text-destructive">
                  {data.cancelledCount}
                </p>
                <p className="text-xs text-muted-foreground">
                  {data.cancelledPct.toFixed(1)}% of all files
                </p>
              </div>
              <div className="rounded-lg bg-destructive/10 p-2 shrink-0">
                <TrendingDown className="size-5 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Funnel */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base">Stage funnel</CardTitle>
          <CardDescription>
            Files that have reached or passed each stage · active files only
          </CardDescription>
        </CardHeader>
        <CardContent>
          {topStageCount === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-muted-foreground">
              No files yet.
            </div>
          ) : (
            <div className="space-y-3">
              {data.funnel.map((stage, i) => {
                const barPct = topStageCount > 0 ? (stage.count / topStageCount) * 100 : 0;
                return (
                  <div key={stage.status}>
                    <div className="flex items-center gap-3">
                      {/* Stage label + count */}
                      <div className="w-24 shrink-0 text-right">
                        <span className="text-xs font-medium text-muted-foreground">
                          {stage.label}
                        </span>
                      </div>
                      {/* Bar */}
                      <div className="flex flex-1 items-center gap-3">
                        <div className="relative flex-1 overflow-hidden rounded-full bg-muted h-8">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${barPct}%`,
                              background: STAGE_COLOURS[stage.status] ?? "var(--color-primary)",
                              opacity: 0.85,
                            }}
                          />
                          <span className="absolute inset-0 flex items-center pl-3 text-xs font-semibold text-foreground mix-blend-multiply dark:mix-blend-screen">
                            {stage.count}
                          </span>
                        </div>
                        {/* Conversion arrow */}
                        {stage.conversionFromPrev !== null && (
                          <div className="flex w-20 shrink-0 items-center gap-1 text-xs text-muted-foreground">
                            <ArrowRight className="size-3 shrink-0" />
                            <span className={cn("tabular-nums font-medium",
                              (stage.conversionFromPrev ?? 0) >= 50
                                ? "text-chart-3"
                                : "text-chart-5",
                            )}>
                              {(stage.conversionFromPrev ?? 0).toFixed(0)}%
                            </span>
                          </div>
                        )}
                        {i === 0 && <div className="w-20 shrink-0" />}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Avg days row */}
              <div className="mt-4 border-t pt-4">
                <p className="mb-3 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Avg. age of files currently at each stage
                </p>
                <div className="flex flex-wrap gap-3">
                  {data.avgDaysInStage.map((s) => (
                    <div
                      key={s.status}
                      className="flex items-center gap-2 rounded-lg border px-3 py-2"
                    >
                      <span
                        className="size-2.5 shrink-0 rounded-full"
                        style={{ background: STAGE_COLOURS[s.status] ?? "var(--color-muted)" }}
                      />
                      <span className="text-xs text-muted-foreground">{s.label}</span>
                      <span className="text-sm font-semibold tabular-nums">
                        {s.avgDays > 0 ? `${s.avgDays}d` : "—"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stacked area — files by status over time */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base">Files by status — last 12 months</CardTitle>
          <CardDescription>By file departure month · all files</CardDescription>
        </CardHeader>
        <CardContent>
          {hasArea ? (
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart
                data={data.monthly.map((m) => ({
                  name: shortMonth(m.month),
                  Enquiry: m.enquiry,
                  Quoted: m.quoted,
                  Confirmed: m.confirmed,
                  Operating: m.operating,
                  Closed: m.closed,
                  Cancelled: m.cancelled,
                }))}
                margin={{ top: 4, right: 4, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  axisLine={false}
                  tickLine={false}
                  width={28}
                />
                <Tooltip content={<AreaTooltip />} cursor={{ stroke: "var(--color-border)" }} />
                <Legend wrapperStyle={{ fontSize: 12, paddingTop: 12 }} iconType="circle" iconSize={8} />
                {(["Enquiry","Quoted","Confirmed","Operating","Closed","Cancelled"] as const).map((key) => (
                  <Area
                    key={key}
                    type="monotone"
                    dataKey={key}
                    stackId="1"
                    stroke={STAGE_COLOURS[key.toLowerCase()] ?? "var(--color-primary)"}
                    fill={STAGE_COLOURS[key.toLowerCase()] ?? "var(--color-primary)"}
                    fillOpacity={0.55}
                    strokeWidth={1.5}
                  />
                ))}
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
              No files yet in the last 12 months.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
