import { useQuery } from "convex/react";
import { Link } from "react-router-dom";
import {
  Plane,
  Users,
  AlertTriangle,
  CheckSquare,
  ArrowRight,
  CalendarDays,
  Activity,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { OperationalFile } from "@/convex/reports.ts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import { downloadCsv } from "@/lib/csv-export.ts";
import { generateReportPDF } from "@/lib/report-pdf.ts";
import ReportExportMenu from "@/components/report-export-menu.tsx";

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtDate(iso: string) {
  return new Date(iso).toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function urgencyColour(days: number) {
  if (days <= 7) return "text-destructive";
  if (days <= 14) return "text-chart-5";
  if (days <= 30) return "text-chart-4";
  return "text-muted-foreground";
}

function urgencyBg(days: number) {
  if (days <= 7) return "bg-destructive/10 border-destructive/30";
  if (days <= 14) return "bg-chart-5/10 border-chart-5/30";
  if (days <= 30) return "bg-chart-4/10 border-chart-4/30";
  return "bg-muted/50 border-border";
}

// ── Skeleton ──────────────────────────────────────────────────────────────────

function OpsSkeletons() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28 w-full" />)}
      </div>
      <Skeleton className="h-72 w-full" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}

// ── File row ──────────────────────────────────────────────────────────────────

function FileRow({ file, showStatus }: { file: OperationalFile; showStatus?: boolean }) {
  const hasOverdue = file.overdueTaskCount > 0;
  const hasOpen = file.openTaskCount > 0;

  return (
    <tr className="border-b last:border-0 hover:bg-muted/30 transition-colors group">
      {/* Days / urgency */}
      <td className="px-4 py-3 w-20 shrink-0">
        <span className={cn("text-sm font-bold tabular-nums", urgencyColour(file.daysUntilDeparture))}>
          {file.daysUntilDeparture === 0
            ? "Today"
            : file.daysUntilDeparture < 0
              ? `${Math.abs(file.daysUntilDeparture)}d ago`
              : `${file.daysUntilDeparture}d`}
        </span>
      </td>

      {/* File details */}
      <td className="px-4 py-3 min-w-0">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-xs text-muted-foreground">{file.reference}</span>
            {showStatus && (
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 capitalize">
                {file.status}
              </Badge>
            )}
          </div>
          <p className="font-medium text-sm truncate">{file.title}</p>
          <p className="text-xs text-muted-foreground truncate">{file.clientName} · {file.destination}</p>
        </div>
      </td>

      {/* Dates */}
      <td className="px-4 py-3 hidden md:table-cell whitespace-nowrap text-xs text-muted-foreground">
        <div>{fmtDate(file.startDate)}</div>
        <div className="text-muted-foreground/60">→ {fmtDate(file.endDate)}</div>
      </td>

      {/* Pax */}
      <td className="px-4 py-3 text-right tabular-nums">
        <div className="flex items-center justify-end gap-1 text-sm">
          <Users className="size-3.5 text-muted-foreground" />
          <span className="font-medium">{file.pax}</span>
        </div>
      </td>

      {/* Tasks */}
      <td className="px-4 py-3 text-right">
        {hasOpen ? (
          <div className="flex items-center justify-end gap-1.5">
            {hasOverdue && (
              <Badge variant="destructive" className="text-[10px] px-1.5 py-0 gap-1">
                <AlertTriangle className="size-2.5" />
                {file.overdueTaskCount} overdue
              </Badge>
            )}
            {!hasOverdue && (
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                {file.openTaskCount} open
              </Badge>
            )}
          </div>
        ) : (
          <CheckSquare className="size-4 text-chart-3 ml-auto" />
        )}
      </td>

      {/* Link */}
      <td className="px-4 py-3 text-right">
        <Link
          to={`/files/${file._id}`}
          className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100"
        >
          Open <ArrowRight className="size-3" />
        </Link>
      </td>
    </tr>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function OpsSnapshot() {
  const data = useQuery(api.reports.operationalSnapshot, {});

  if (data === undefined) return <OpsSkeletons />;

  const toCsvRow = (f: OperationalFile) => ({
    Reference: f.reference,
    Title: f.title,
    Client: f.clientName,
    Destination: f.destination,
    Status: f.status,
    "Start date": f.startDate.slice(0, 10),
    "End date": f.endDate.slice(0, 10),
    "Days until departure": f.daysUntilDeparture,
    Pax: f.pax,
    "Open tasks": f.openTaskCount,
    "Overdue tasks": f.overdueTaskCount,
  });

  const handleExportCsv = () => {
    downloadCsv(
      [...data.upcomingDepartures.map(toCsvRow), ...data.operatingFiles.map(toCsvRow)],
      `operations-report-${new Date().toISOString().slice(0, 10)}.csv`,
    );
  };

  const handleExportPdf = () => {
    generateReportPDF({
      title: "OPERATIONS SNAPSHOT",
      subtitle: "Upcoming departures and files in operation",
      filename: `operations-report-${new Date().toISOString().slice(0, 10)}.pdf`,
      kpis: [
        { label: "Next 30 days", value: String(data.departingIn30) },
        { label: "Next 60 days", value: String(data.departingIn60) },
        { label: "Next 90 days", value: String(data.departingIn90) },
        { label: "In operation", value: String(data.operatingCount) },
      ],
      tables: [
        {
          heading: "Upcoming departures (next 90 days)",
          columns: ["Reference", "Title", "Client", "Departs", "Pax", "Open tasks"],
          rows: data.upcomingDepartures.map((f) => [
            f.reference,
            f.title,
            f.clientName,
            fmtDate(f.startDate),
            f.pax,
            f.openTaskCount,
          ]),
        },
        {
          heading: "Files in operation now",
          columns: ["Reference", "Title", "Client", "Departs", "Pax", "Open tasks"],
          rows: data.operatingFiles.map((f) => [
            f.reference,
            f.title,
            f.clientName,
            fmtDate(f.startDate),
            f.pax,
            f.openTaskCount,
          ]),
        },
      ],
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <ReportExportMenu onExportCsv={handleExportCsv} onExportPdf={handleExportPdf} />
      </div>

      {/* KPI strip */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {/* Departing in 30 */}
        <Card className={cn("border", data.departingIn30 > 0 ? "border-chart-5/40" : "")}>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Next 30 days</p>
                <p className={cn("font-display text-2xl font-bold tabular-nums", data.departingIn30 > 0 ? "text-chart-5" : "")}>
                  {data.departingIn30}
                </p>
                <p className="text-xs text-muted-foreground">{data.totalPaxIn30} pax departing</p>
              </div>
              <div className={cn("rounded-lg p-2 shrink-0", data.departingIn30 > 0 ? "bg-chart-5/10" : "bg-muted")}>
                <Plane className={cn("size-5", data.departingIn30 > 0 ? "text-chart-5" : "text-muted-foreground")} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Departing in 60 */}
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Next 60 days</p>
                <p className="font-display text-2xl font-bold tabular-nums">{data.departingIn60}</p>
                <p className="text-xs text-muted-foreground">{data.totalPaxIn60} pax departing</p>
              </div>
              <div className="rounded-lg bg-muted p-2 shrink-0">
                <CalendarDays className="size-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Departing in 90 */}
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Next 90 days</p>
                <p className="font-display text-2xl font-bold tabular-nums">{data.departingIn90}</p>
                <p className="text-xs text-muted-foreground">{data.totalPaxIn90} pax departing</p>
              </div>
              <div className="rounded-lg bg-muted p-2 shrink-0">
                <CalendarDays className="size-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Currently operating */}
        <Card className={cn("border", data.operatingCount > 0 ? "border-chart-3/40" : "")}>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">In operation</p>
                <p className={cn("font-display text-2xl font-bold tabular-nums", data.operatingCount > 0 ? "text-chart-3" : "")}>
                  {data.operatingCount}
                </p>
                <p className="text-xs text-muted-foreground">Files live right now</p>
              </div>
              <div className={cn("rounded-lg p-2 shrink-0", data.operatingCount > 0 ? "bg-chart-3/10" : "bg-muted")}>
                <Activity className={cn("size-5", data.operatingCount > 0 ? "text-chart-3" : "text-muted-foreground")} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming departures table */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base flex items-center gap-2">
            <Plane className="size-4 text-muted-foreground" />
            Upcoming departures — next 90 days
          </CardTitle>
          <CardDescription>
            All non-cancelled files · sorted by departure date
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {data.upcomingDepartures.length === 0 ? (
            <div className="flex h-40 items-center justify-center text-sm text-muted-foreground">
              No departures in the next 90 days.
            </div>
          ) : (
            <div className="overflow-x-auto">
              {/* Day-range section headers */}
              {(["≤ 7 days", "8 – 30 days", "31 – 60 days", "61 – 90 days"] as const).map((label, i) => {
                const [min, max] = [
                  [0, 7],
                  [8, 30],
                  [31, 60],
                  [61, 90],
                ][i] as [number, number];
                const bucket = data.upcomingDepartures.filter(
                  (f) => f.daysUntilDeparture >= min && f.daysUntilDeparture <= max,
                );
                if (bucket.length === 0) return null;
                return (
                  <div key={label}>
                    <div className={cn("flex items-center gap-2 px-4 py-2 border-b border-t mt-0 first:border-t-0 text-xs font-semibold uppercase tracking-wide", urgencyBg(min))}>
                      <span className={urgencyColour(min)}>{label}</span>
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                        {bucket.length} file{bucket.length !== 1 ? "s" : ""}
                      </Badge>
                      <span className="text-muted-foreground font-normal">
                        {bucket.reduce((s, f) => s + f.pax, 0)} pax
                      </span>
                    </div>
                    <table className="w-full text-sm">
                      <tbody>
                        {bucket.map((f) => (
                          <FileRow key={f._id} file={f} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Currently operating */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base flex items-center gap-2">
            <Activity className="size-4 text-chart-3" />
            Files in operation now
          </CardTitle>
          <CardDescription>
            All files with status "Operating" · check tasks and outstanding actions
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {data.operatingFiles.length === 0 ? (
            <div className="flex h-36 items-center justify-center text-sm text-muted-foreground">
              No files currently in operating status.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <tbody>
                  {data.operatingFiles.map((f) => (
                    <FileRow key={f._id} file={f} showStatus />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
