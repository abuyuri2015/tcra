import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { Building2, TrendingUp, UserRound, Users } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { ClientReportRow } from "@/convex/reports.ts";
import { formatMoney } from "@/lib/domain.ts";
import { formatDate } from "@/lib/dates.ts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { cn } from "@/lib/utils.ts";
import { downloadMultiSectionCsv } from "@/lib/csv-export.ts";
import { generateReportPDF } from "@/lib/report-pdf.ts";
import ReportExportMenu from "@/components/report-export-menu.tsx";

// ── Helpers ───────────────────────────────────────────────────────────────────

function shortEur(value: number) {
  if (value >= 1_000_000) return `€${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `€${(value / 1_000).toFixed(0)}K`;
  return `€${value.toFixed(0)}`;
}

const KIND_ICON: Record<ClientReportRow["kind"], typeof Building2> = {
  company: Building2,
  individual: UserRound,
  unmatched: Users,
};

const KIND_LABEL: Record<ClientReportRow["kind"], string> = {
  company: "Company",
  individual: "Individual",
  unmatched: "Unlinked",
};

// ── Skeleton ──────────────────────────────────────────────────────────────────

function ClientReportSkeletons() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2">
        {[0, 1].map((i) => <Skeleton key={i} className="h-24 w-full" />)}
      </div>
      <Skeleton className="h-80 w-full" />
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function ClientReport() {
  const data = useQuery(api.reports.clientReportData, {});

  if (data === undefined) return <ClientReportSkeletons />;

  const { rows, totalIncomeEur } = data;
  const totalMargin = rows.reduce((s, r) => s + r.marginEur, 0);
  const maxIncome = rows[0]?.totalIncomeEur ?? 1;

  const handleExportCsv = () => {
    downloadMultiSectionCsv(
      [
        {
          title: "Summary",
          rows: [
            { Metric: "Revenue across top clients (EUR)", Value: totalIncomeEur },
            { Metric: "Combined margin (EUR)", Value: totalMargin },
          ],
        },
        {
          title: "Top clients by revenue",
          rows: rows.map((r) => ({
            Client: r.clientName,
            Type: KIND_LABEL[r.kind],
            Bookings: r.fileCount,
            "Income (EUR)": r.totalIncomeEur,
            "Cost (EUR)": r.totalCostEur,
            "Margin (EUR)": r.marginEur,
            "Last booking": r.lastBookingDate.slice(0, 10),
          })),
        },
      ],
      `client-report-${new Date().toISOString().slice(0, 10)}.csv`,
    );
  };

  const handleExportPdf = () => {
    generateReportPDF({
      title: "CLIENT REPORT",
      subtitle: "Top clients by revenue and margin · EUR",
      filename: `client-report-${new Date().toISOString().slice(0, 10)}.pdf`,
      kpis: [
        { label: "Revenue across top clients", value: shortEur(totalIncomeEur) },
        { label: "Combined margin", value: shortEur(totalMargin) },
      ],
      tables: [
        {
          heading: "Top clients by revenue",
          columns: ["Client", "Type", "Bookings", "Income (EUR)", "Margin (EUR)", "Last booking"],
          rows: rows.map((r) => [
            r.clientName,
            KIND_LABEL[r.kind],
            r.fileCount,
            r.totalIncomeEur,
            r.marginEur,
            formatDate(r.lastBookingDate),
          ]),
        },
      ],
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <ReportExportMenu onExportCsv={handleExportCsv} onExportPdf={handleExportPdf} />
      </div>

      {/* Summary KPIs */}
      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Revenue across top clients
                </p>
                <p className="font-display text-2xl font-bold tabular-nums text-chart-3">
                  {shortEur(totalIncomeEur)}
                </p>
                <p className="text-xs text-muted-foreground">{formatMoney(totalIncomeEur, "EUR")}</p>
              </div>
              <div className="rounded-lg bg-chart-3/10 p-2 shrink-0">
                <TrendingUp className="size-5 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Combined margin
                </p>
                <p className={cn(
                  "font-display text-2xl font-bold tabular-nums",
                  totalMargin >= 0 ? "text-chart-3" : "text-destructive",
                )}>
                  {shortEur(totalMargin)}
                </p>
                <p className="text-xs text-muted-foreground">{formatMoney(totalMargin, "EUR")}</p>
              </div>
              <div className={cn("rounded-lg p-2 shrink-0", totalMargin >= 0 ? "bg-chart-3/10" : "bg-destructive/10")}>
                <Users className={cn("size-5", totalMargin >= 0 ? "text-chart-3" : "text-destructive")} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base">Top clients by revenue</CardTitle>
          <CardDescription>
            Individual contacts roll up under their company · non-cancelled bookings · EUR
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <div className="flex h-40 items-center justify-center text-sm text-muted-foreground">
              No client bookings yet.
            </div>
          ) : (
            <div className="divide-y">
              {rows.map((row, i) => {
                const Icon = KIND_ICON[row.kind];
                const pct = maxIncome > 0 ? (row.totalIncomeEur / maxIncome) * 100 : 0;
                return (
                  <div key={row.clientName} className="flex items-center gap-3 px-4 py-3">
                    <span className="w-5 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
                      {i + 1}
                    </span>
                    <Icon className="size-4 shrink-0 text-muted-foreground" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-sm font-medium">{row.clientName}</span>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {KIND_LABEL[row.kind]}
                        </Badge>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {row.fileCount} {row.fileCount === 1 ? "booking" : "bookings"}
                        </Badge>
                      </div>
                      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-chart-3 transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        Last booking {formatDate(row.lastBookingDate)}
                      </p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-sm font-semibold tabular-nums">{shortEur(row.totalIncomeEur)}</p>
                      <p className={cn(
                        "text-xs tabular-nums",
                        row.marginEur >= 0 ? "text-chart-3" : "text-destructive",
                      )}>
                        {shortEur(row.marginEur)} margin
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <p className="text-center text-xs text-muted-foreground">
        Manage clients and combined invoices from the{" "}
        <Link to="/clients" className="text-primary hover:underline">
          Client directory
        </Link>
        .
      </p>
    </div>
  );
}
