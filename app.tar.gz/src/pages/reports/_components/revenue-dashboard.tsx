import { useQuery } from "convex/react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import { TrendingUp, DollarSign, Percent, BarChart2, MapPin } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { RevenueData } from "@/convex/reports.ts";
import { formatMoney } from "@/lib/domain.ts";
import PageHeader from "@/components/page-header.tsx";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { cn } from "@/lib/utils.ts";
import { downloadMultiSectionCsv } from "@/lib/csv-export.ts";
import { generateReportPDF } from "@/lib/report-pdf.ts";
import ReportExportMenu from "@/components/report-export-menu.tsx";

// ── Colour palette (matches app chart vars) ───────────────────────────────────

const CHART_INCOME = "var(--color-chart-3)";   // teal-green
const CHART_COST   = "var(--color-chart-5)";   // amber-red
const CHART_DONUT  = [
  "var(--color-chart-1)",
  "var(--color-chart-3)",
  "var(--color-chart-2)",
  "var(--color-chart-4)",
  "var(--color-chart-5)",
];

const FILE_TYPE_LABELS: Record<string, string> = {
  group: "Group",
  meeting: "Meeting",
  incentive: "Incentive",
  conference: "Conference",
  event: "Event",
};

// ── Formatters ────────────────────────────────────────────────────────────────

function shortEur(value: number) {
  if (value >= 1_000_000) return `€${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `€${(value / 1_000).toFixed(0)}K`;
  return `€${value.toFixed(0)}`;
}

function shortMonth(yyyymm: string) {
  const [y, m] = yyyymm.split("-");
  const d = new Date(Number(y), Number(m) - 1, 1);
  return d.toLocaleString(undefined, { month: "short", year: "2-digit" });
}

// ── KPI card ──────────────────────────────────────────────────────────────────

function KpiCard({
  label,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: typeof TrendingUp;
  accent?: string;
}) {
  return (
    <Card>
      <CardContent className="pt-5">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1 min-w-0">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {label}
            </p>
            <p className={cn("font-display text-2xl font-bold tabular-nums", accent)}>
              {value}
            </p>
            {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
          </div>
          <div className={cn("rounded-lg p-2 shrink-0", accent ? "bg-chart-3/10" : "bg-muted")}>
            <Icon className={cn("size-5", accent ?? "text-muted-foreground")} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Skeleton layout ───────────────────────────────────────────────────────────

function RevenueSkeletons() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28 w-full" />)}
      </div>
      <Skeleton className="h-72 w-full" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    </div>
  );
}

// ── Custom tooltip ────────────────────────────────────────────────────────────

function BarTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border bg-popover px-3 py-2 shadow-md text-sm">
      <p className="mb-1.5 font-medium text-popover-foreground">{label}</p>
      {payload.map((p) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="size-2 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-medium tabular-nums">{shortEur(p.value)}</span>
        </div>
      ))}
    </div>
  );
}

// ── Donut tooltip ─────────────────────────────────────────────────────────────

function DonutTooltip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number }>;
}) {
  if (!active || !payload?.length) return null;
  const p = payload[0];
  return (
    <div className="rounded-lg border bg-popover px-3 py-2 shadow-md text-sm">
      <p className="font-medium text-popover-foreground">{p.name}</p>
      <p className="tabular-nums text-muted-foreground">{formatMoney(p.value, "EUR")}</p>
    </div>
  );
}

// ── Revenue tab content ───────────────────────────────────────────────────────

export default function RevenueDashboard() {
  const data = useQuery(api.reports.revenueData, {});

  if (data === undefined) return <RevenueSkeletons />;

  const marginPct = (data.grossMargin * 100).toFixed(1);
  const marginPositive = data.grossMargin >= 0;

  const barData = data.monthly.map((m) => ({
    name: shortMonth(m.month),
    Income: Math.round(m.income),
    Costs: Math.round(m.cost),
  }));

  const donutData = data.byFileType.map((t) => ({
    name: FILE_TYPE_LABELS[t.fileType] ?? t.fileType,
    value: Math.round(t.income),
    count: t.count,
  }));

  const hasBar = barData.some((m) => m.Income > 0 || m.Costs > 0);
  const hasDonut = donutData.some((d) => d.value > 0);

  const handleExportCsv = () => {
    downloadMultiSectionCsv(
      [
        {
          title: "Summary",
          rows: [
            { Metric: "Confirmed revenue (EUR)", Value: Math.round(data.confirmedRevenue) },
            { Metric: "Pipeline value (EUR)", Value: Math.round(data.pipelineValue) },
            { Metric: "Gross margin %", Value: marginPct },
            { Metric: "Average file value (EUR)", Value: Math.round(data.averageFileValue) },
          ],
        },
        {
          title: "Revenue vs costs by month",
          rows: data.monthly.map((m) => ({
            Month: m.month,
            "Income (EUR)": Math.round(m.income),
            "Cost (EUR)": Math.round(m.cost),
          })),
        },
        {
          title: "Revenue by file type",
          rows: data.byFileType.map((t) => ({
            "File type": FILE_TYPE_LABELS[t.fileType] ?? t.fileType,
            "Income (EUR)": Math.round(t.income),
            "File count": t.count,
          })),
        },
        {
          title: "Top destinations",
          rows: data.topDestinations.map((d) => ({
            Destination: d.destination,
            "Income (EUR)": Math.round(d.income),
            "File count": d.fileCount,
          })),
        },
      ],
      `revenue-report-${new Date().toISOString().slice(0, 10)}.csv`,
    );
  };

  const handleExportPdf = () => {
    generateReportPDF({
      title: "REVENUE REPORT",
      subtitle: "Confirmed revenue, pipeline value and margin · EUR",
      filename: `revenue-report-${new Date().toISOString().slice(0, 10)}.pdf`,
      kpis: [
        { label: "Confirmed revenue", value: shortEur(data.confirmedRevenue) },
        { label: "Pipeline value", value: shortEur(data.pipelineValue) },
        { label: "Gross margin", value: `${marginPct}%` },
        { label: "Avg. file value", value: shortEur(data.averageFileValue) },
      ],
      tables: [
        {
          heading: "Revenue vs costs by month",
          columns: ["Month", "Income (EUR)", "Cost (EUR)"],
          rows: data.monthly.map((m) => [m.month, Math.round(m.income), Math.round(m.cost)]),
        },
        {
          heading: "Revenue by file type",
          columns: ["File type", "Income (EUR)", "File count"],
          rows: data.byFileType.map((t) => [
            FILE_TYPE_LABELS[t.fileType] ?? t.fileType,
            Math.round(t.income),
            t.count,
          ]),
        },
        {
          heading: "Top destinations",
          columns: ["Destination", "Income (EUR)", "File count"],
          rows: data.topDestinations.map((d) => [d.destination, Math.round(d.income), d.fileCount]),
        },
      ],
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <ReportExportMenu onExportCsv={handleExportCsv} onExportPdf={handleExportPdf} />
      </div>

      {/* KPI cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard
          label="Confirmed revenue"
          value={shortEur(data.confirmedRevenue)}
          sub={formatMoney(data.confirmedRevenue, "EUR")}
          icon={TrendingUp}
          accent="text-chart-3"
        />
        <KpiCard
          label="Pipeline value"
          value={shortEur(data.pipelineValue)}
          sub="Enquiry + Quoted stages"
          icon={BarChart2}
        />
        <KpiCard
          label="Gross margin"
          value={`${marginPct}%`}
          sub="Confirmed files"
          icon={Percent}
          accent={marginPositive ? "text-chart-3" : "text-destructive"}
        />
        <KpiCard
          label="Avg. file value"
          value={shortEur(data.averageFileValue)}
          sub="Confirmed files with income"
          icon={DollarSign}
        />
      </div>

      {/* 12-month bar chart */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base">Revenue vs costs — last 12 months</CardTitle>
          <CardDescription>By file departure month · EUR</CardDescription>
        </CardHeader>
        <CardContent>
          {hasBar ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={barData} barGap={3} barCategoryGap="28%">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={shortEur}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  axisLine={false}
                  tickLine={false}
                  width={56}
                />
                <Tooltip content={<BarTooltip />} cursor={{ fill: "var(--color-muted)", opacity: 0.5 }} />
                <Legend
                  wrapperStyle={{ fontSize: 12, paddingTop: 12 }}
                  iconType="circle"
                  iconSize={8}
                />
                <Bar dataKey="Income" fill={CHART_INCOME} radius={[3, 3, 0, 0]} />
                <Bar dataKey="Costs" fill={CHART_COST} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
              No finance data yet for the last 12 months.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Donut + top destinations */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* By file type */}
        <Card>
          <CardHeader>
            <CardTitle className="font-display text-base">Revenue by file type</CardTitle>
            <CardDescription>Confirmed files only · EUR</CardDescription>
          </CardHeader>
          <CardContent>
            {hasDonut ? (
              <div className="flex flex-col items-center gap-4 sm:flex-row">
                <ResponsiveContainer width={200} height={180}>
                  <PieChart>
                    <Pie
                      data={donutData}
                      cx="50%"
                      cy="50%"
                      innerRadius={52}
                      outerRadius={80}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {donutData.map((_, i) => (
                        <Cell
                          key={i}
                          fill={CHART_DONUT[i % CHART_DONUT.length]}
                          stroke="transparent"
                        />
                      ))}
                    </Pie>
                    <Tooltip content={<DonutTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-1 flex-col gap-2">
                  {donutData.map((d, i) => (
                    <div key={d.name} className="flex items-center justify-between gap-3 text-sm">
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="size-2.5 shrink-0 rounded-full"
                          style={{ background: CHART_DONUT[i % CHART_DONUT.length] }}
                        />
                        <span className="truncate">{d.name}</span>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {d.count}
                        </Badge>
                      </div>
                      <span className="shrink-0 tabular-nums font-medium">
                        {shortEur(d.value)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex h-40 items-center justify-center text-sm text-muted-foreground">
                No confirmed revenue yet.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top destinations */}
        <Card>
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2 text-base">
              <MapPin className="size-4 text-muted-foreground" />
              Top destinations
            </CardTitle>
            <CardDescription>By confirmed revenue · EUR</CardDescription>
          </CardHeader>
          <CardContent>
            {data.topDestinations.length === 0 ? (
              <div className="flex h-40 items-center justify-center text-sm text-muted-foreground">
                No confirmed revenue yet.
              </div>
            ) : (
              <div className="space-y-2">
                {data.topDestinations.map((d, i) => {
                  const max = data.topDestinations[0]?.income ?? 1;
                  const pct = max > 0 ? (d.income / max) * 100 : 0;
                  return (
                    <div key={d.destination} className="space-y-1">
                      <div className="flex items-center justify-between gap-3 text-sm">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="w-4 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
                            {i + 1}
                          </span>
                          <span className="truncate">{d.destination}</span>
                          <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                            {d.fileCount} {d.fileCount === 1 ? "file" : "files"}
                          </Badge>
                        </div>
                        <span className="shrink-0 tabular-nums font-medium">
                          {shortEur(d.income)}
                        </span>
                      </div>
                      <div className="ml-6 h-1.5 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-chart-3 transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
