import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import {
  AlertTriangle,
  ArrowRight,
  BadgeEuro,
  BedDouble,
  CalendarDays,
  CalendarRange,
  CheckCircle2,
  CircleDollarSign,
  Clock,
  FileText,
  MapPin,
  MessageSquareText,
  Plane,
  Plus,
  TrendingUp,
  Users,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import GroupFileFormDialog from "./files/_components/group-file-form-dialog.tsx";
import DashboardTasksPanel from "./Index/_components/dashboard-tasks-panel.tsx";
import NeedsFollowUpPanel from "./Index/_components/needs-follow-up-panel.tsx";
import DashboardNotificationsPanel from "./Index/_components/dashboard-notifications-panel.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover.tsx";
import { formatDateRange } from "@/lib/dates.ts";
import { useAuth } from "@/hooks/use-auth.ts";
import { formatRelative } from "date-fns";
import { cn } from "@/lib/utils.ts";

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmtEur(n: number) {
  if (n >= 1_000_000) return `€${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `€${Math.round(n / 1_000)}K`;
  return `€${n.toLocaleString()}`;
}

function relativeTime(isoOrMs: string | number) {
  try {
    return formatRelative(new Date(isoOrMs), new Date());
  } catch {
    return String(isoOrMs);
  }
}

// ── Stat card ─────────────────────────────────────────────────────────────────

function StatCardBody({
  label,
  value,
  sub,
  icon: Icon,
  accent,
  alert,
}: {
  label: string;
  value: string | undefined;
  sub?: string;
  icon: typeof Users;
  accent?: boolean;
  alert?: boolean;
}) {
  return (
    <>
      <div className="flex items-center justify-between">
        <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
        <Icon
          className={cn(
            "size-4",
            alert ? "text-destructive" : accent ? "text-primary" : "text-muted-foreground",
          )}
        />
      </div>
      {value === undefined ? (
        <Skeleton className="h-9 w-24" />
      ) : (
        <>
          <p
            className={cn(
              "font-display text-3xl font-semibold",
              alert ? "text-destructive" : accent ? "text-primary" : "",
            )}
          >
            {value}
          </p>
          {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
        </>
      )}
    </>
  );
}

function StatCard({
  label,
  value,
  sub,
  icon,
  accent,
  alert,
  href,
}: {
  label: string;
  value: string | undefined;
  sub?: string;
  icon: typeof Users;
  accent?: boolean;
  alert?: boolean;
  href?: string;
}) {
  const inner = (
    <Card
      className={cn(
        "gap-2 p-5 transition-colors",
        accent && "border-primary/30 bg-primary/5",
        alert && "border-destructive/30 bg-destructive/5",
        href && "hover:bg-secondary/40 cursor-pointer",
      )}
    >
      <StatCardBody label={label} value={value} sub={sub} icon={icon} accent={accent} alert={alert} />
    </Card>
  );

  if (href) {
    return <Link to={href}>{inner}</Link>;
  }
  return inner;
}

// ── Open enquiries stat card (with popover listing the waiting files) ────────

function EnquiriesStatCard({
  value,
  files,
}: {
  value: string | undefined;
  files:
    | Array<{
        _id: string;
        title: string;
        reference: string;
        clientName: string;
        status: string;
      }>
    | undefined;
}) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button type="button" className="cursor-pointer text-left">
          <Card className="gap-2 p-5 transition-colors hover:bg-secondary/40">
            <StatCardBody
              label="Open enquiries"
              value={value}
              sub="awaiting quote or response"
              icon={MessageSquareText}
            />
          </Card>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-2" align="start">
        {!files || files.length === 0 ? (
          <p className="px-2 py-3 text-center text-sm text-muted-foreground">
            No open enquiries.
          </p>
        ) : (
          <div className="max-h-80 space-y-0.5 overflow-y-auto">
            {files.map((f) => (
              <Link
                key={f._id}
                to={`/files/${f._id}`}
                className="flex items-center justify-between gap-3 rounded-md px-2 py-2 transition-colors hover:bg-secondary/60"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{f.clientName}</p>
                  <p className="truncate text-xs text-muted-foreground">{f.reference}</p>
                </div>
                <StatusBadge status={f.status} className="shrink-0" />
              </Link>
            ))}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

// ── Status breakdown pill ─────────────────────────────────────────────────────

const STATUS_COLORS: Record<string, string> = {
  enquiry: "bg-slate-400",
  quoted: "bg-amber-400",
  confirmed: "bg-emerald-500",
  operating: "bg-teal-600",
  closed: "bg-slate-300",
  cancelled: "bg-red-400",
};

function StatusBar({ byStatus }: { byStatus: Record<string, number> }) {
  const total = Object.values(byStatus).reduce((s, n) => s + n, 0);
  if (total === 0) return null;
  const order = ["enquiry", "quoted", "confirmed", "operating", "closed", "cancelled"];
  return (
    <div className="space-y-2">
      <div className="flex h-2 w-full overflow-hidden rounded-full bg-muted">
        {order.map((s) => {
          const count = byStatus[s] ?? 0;
          if (!count) return null;
          return (
            <div
              key={s}
              className={`${STATUS_COLORS[s] ?? "bg-slate-400"}`}
              style={{ width: `${(count / total) * 100}%` }}
            />
          );
        })}
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1">
        {order.map((s) => {
          const count = byStatus[s];
          if (!count) return null;
          return (
            <span key={s} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className={`inline-block size-2 rounded-full ${STATUS_COLORS[s]}`} />
              <span className="capitalize">{s}</span>
              <span className="font-medium text-foreground">{count}</span>
            </span>
          );
        })}
      </div>
    </div>
  );
}

// ── Quick action button ──────────────────────────────────────────────────────

function QuickAction({
  icon: Icon,
  label,
  to,
}: {
  icon: typeof Plus;
  label: string;
  to: string;
}) {
  return (
    <Button asChild variant="secondary" className="gap-2">
      <Link to={to}>
        <Icon className="size-4" />
        {label}
      </Link>
    </Button>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────

export default function Index() {
  const { user } = useAuth();
  const data = useQuery(api.dashboard.stats, {});
  const firstName = user?.profile.name?.split(" ")[0];

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <PageHeader
        eyebrow="Dashboard"
        title={firstName ? `Welcome back, ${firstName}` : "Welcome back"}
        description="A snapshot of what your team is operating right now."
        actions={
          <GroupFileFormDialog
            trigger={
              <Button>
                <Plus className="size-4" />
                New file
              </Button>
            }
          />
        }
      />

      {/* ── Primary KPIs ── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Active files"
          value={data ? String(data.activeCount) : undefined}
          sub="upcoming & not cancelled"
          icon={CalendarRange}
          href="/files"
        />
        <StatCard
          label="Departures this month"
          value={data ? String(data.departuresThisMonth) : undefined}
          sub={data ? `${new Date().toLocaleString("default", { month: "long" })}` : undefined}
          icon={CalendarDays}
          href="/calendar"
        />
        <StatCard
          label="Pipeline revenue"
          value={data ? fmtEur(data.pipelineRevenueEur) : undefined}
          sub="all active income lines"
          icon={CircleDollarSign}
          accent
          href="/finance"
        />
        <StatCard
          label="Confirmed revenue"
          value={data ? fmtEur(data.confirmedRevenueEur) : undefined}
          sub={data?.marginPct != null ? `${data.marginPct}% avg margin` : "confirmed + operating"}
          icon={TrendingUp}
          href="/finance"
        />
      </div>

      {/* ── Secondary KPIs ── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Travellers ahead"
          value={data ? data.upcomingPax.toLocaleString() : undefined}
          sub="across active files"
          icon={Users}
        />
        <EnquiriesStatCard
          value={data ? String(data.openEnquiries) : undefined}
          files={data?.openEnquiryFiles}
        />
        <StatCard
          label="Overdue tasks"
          value={data ? String(data.overdueTasks) : undefined}
          sub={data && data.overdueTasks > 0 ? "need attention" : "all caught up"}
          icon={AlertTriangle}
          alert={!!data && data.overdueTasks > 0}
        />
        <StatCard
          label="Overdue payments"
          value={data ? String(data.overduePayments) : undefined}
          sub={data && data.overduePayments > 0 ? "past due date, unpaid" : "all caught up"}
          icon={BadgeEuro}
          alert={!!data && data.overduePayments > 0}
          href="/finance"
        />
      </div>

      {/* ── Status breakdown ── */}
      {data && Object.keys(data.byStatus).length > 0 && (
        <Card className="p-5">
          <p className="mb-4 text-xs uppercase tracking-[0.14em] text-muted-foreground">
            Files by status
          </p>
          <StatusBar byStatus={data.byStatus} />
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        {/* ── Next departures (14 days) ── */}
        <Card>
          <CardHeader className="flex-row items-center justify-between pb-3">
            <CardTitle className="flex items-center gap-2 font-display text-base">
              <Plane className="size-4 text-muted-foreground" />
              Next 14 days
            </CardTitle>
            <Button asChild variant="ghost" size="sm">
              <Link to="/calendar">
                Calendar <ArrowRight className="size-3.5" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-1">
            {data === undefined ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))
            ) : data.nextDepartures.length === 0 ? (
              <div className="flex flex-col items-center gap-3 py-8 text-center">
                <p className="text-sm text-muted-foreground">No departures in the next 14 days.</p>
                <GroupFileFormDialog
                  trigger={
                    <Button size="sm" variant="secondary">
                      <Plus className="size-4" /> New file
                    </Button>
                  }
                />
              </div>
            ) : (
              data.nextDepartures.map((file) => (
                <Link
                  key={file._id}
                  to={`/files/${file._id}`}
                  className="flex items-center justify-between gap-3 rounded-md px-3 py-2.5 transition-colors hover:bg-secondary/50"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{file.title}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {file.reference} · {file.clientName}
                      {file.ownerName ? ` · ${file.ownerName}` : ""}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <StatusBadge status={file.status} />
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      {formatDateRange(file.startDate, file.endDate)}
                    </span>
                  </div>
                </Link>
              ))
            )}
          </CardContent>
        </Card>

        {/* ── Recent activity ── */}
        <Card>
          <CardHeader className="flex-row items-center justify-between pb-3">
            <CardTitle className="flex items-center gap-2 font-display text-base">
              <Clock className="size-4 text-muted-foreground" />
              Recent activity
            </CardTitle>
            <Button asChild variant="ghost" size="sm">
              <Link to="/files">
                All files <ArrowRight className="size-3.5" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-1">
            {data === undefined ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))
            ) : data.recentFiles.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                No files yet.
              </p>
            ) : (
              data.recentFiles.map((file) => (
                <Link
                  key={file._id}
                  to={`/files/${file._id}`}
                  className="flex items-center justify-between gap-3 rounded-md px-3 py-2.5 transition-colors hover:bg-secondary/50"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{file.title}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {file.reference} · {file.destination}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <StatusBadge status={file.status} />
                    <span className="text-xs text-muted-foreground">
                      {relativeTime(file._creationTime)}
                    </span>
                  </div>
                </Link>
              ))
            )}
          </CardContent>
        </Card>

        {/* ── Notifications panel (full width, highlighted) ── */}
        <div className="lg:col-span-2">
          <DashboardNotificationsPanel />
        </div>

        {/* ── Tasks panel (full width) ── */}
        <div className="lg:col-span-2">
          <DashboardTasksPanel />
        </div>

        {/* ── Needs follow-up panel (full width) ── */}
        <div className="lg:col-span-2">
          <NeedsFollowUpPanel />
        </div>
      </div>

      {/* ── Quick actions ── */}
      <Card className="p-5">
        <p className="mb-4 text-xs uppercase tracking-[0.14em] text-muted-foreground">
          Quick actions
        </p>
        <div className="flex flex-wrap gap-3">
          <GroupFileFormDialog
            trigger={
              <Button variant="secondary">
                <Plus className="size-4" /> New group file
              </Button>
            }
          />
          <QuickAction icon={CalendarRange} label="All group files" to="/files" />
          <QuickAction icon={BedDouble} label="Hotel database" to="/hotels" />
          <QuickAction icon={Users} label="Suppliers" to="/suppliers" />
          <QuickAction icon={CalendarDays} label="Calendar" to="/calendar" />
          <QuickAction icon={FileText} label="Finance" to="/finance" />
          <QuickAction icon={MapPin} label="Pipeline" to="/pipeline" />
        </div>
      </Card>
    </div>
  );
}
