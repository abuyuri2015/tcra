/**
 * AI import panel for Suppliers page.
 */
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import AiImportDialog, { PreviewCard, PreviewField } from "@/components/ai-import-dialog.tsx";

type SupplierData = {
  name: string;
  category: string;
  country?: string;
  city?: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  notes?: string;
};

function SuppliersPreview({ suppliers }: { suppliers: SupplierData[] }) {
  if (!suppliers || suppliers.length === 0) {
    return <p className="px-4 py-4 text-sm text-muted-foreground">No suppliers extracted.</p>;
  }
  return (
    <>
      {suppliers.map((s, i) => (
        <PreviewCard
          key={i}
          title={s.name || "Unnamed supplier"}
          subtitle={[s.category, s.city, s.country].filter(Boolean).join(" · ")}
          defaultOpen={suppliers.length === 1}
        >
          <PreviewField label="Category" value={s.category} />
          <PreviewField label="City" value={s.city} />
          <PreviewField label="Country" value={s.country} />
          <PreviewField label="Contact" value={s.contactPerson} />
          <PreviewField label="Email" value={s.email} />
          <PreviewField label="Phone" value={s.phone} />
          <PreviewField label="Notes" value={s.notes} />
        </PreviewCard>
      ))}
    </>
  );
}

export default function SupplierAiImport() {
  const bulkCreate = useMutation(api.suppliers.bulkCreate);

  const handleImport = async (data: SupplierData | SupplierData[]) => {
    const suppliers = Array.isArray(data) ? data : [data];
    if (suppliers.length === 0) {
      toast.error("No suppliers to import.");
      return;
    }

    // Validate categories
    const valid = [
      "hotel",
      "transfer",
      "restaurant",
      "activity",
      "venue",
      "flight",
      "other",
    ] as const;
    type ValidCategory = (typeof valid)[number];
    const sanitised = suppliers.map((s) => ({
      ...s,
      category: (valid.includes(s.category as ValidCategory)
        ? s.category
        : "other") as ValidCategory,
    }));

    const result = await bulkCreate({ suppliers: sanitised });
    if (result.imported === 0 && result.skipped > 0) {
      toast.info(`All ${result.skipped} supplier(s) already exist — nothing imported.`);
    } else {
      toast.success(
        `Imported ${result.imported} supplier${result.imported !== 1 ? "s" : ""}` +
          (result.skipped > 0 ? ` (${result.skipped} skipped — already exist)` : ""),
      );
    }
  };

  return (
    <AiImportDialog
      type="suppliers"
      title="Import suppliers with AI"
      placeholder={`Paste supplier info — one or many:

Eurocar Transfers — private transfers across Spain
Contact: Juan García · info@eurocar.es · +34 91 000 1234
Madrid-based. Specialises in group airport transfers and city tours.

---

La Boqueria Restaurant, Barcelona
Maria Torres · laboqueria@restaurant.es · +34 93 302 1234`}
      onImport={async (data) => handleImport(data as SupplierData | SupplierData[])}
      renderPreview={(data) => (
        <SuppliersPreview suppliers={Array.isArray(data) ? (data as SupplierData[]) : [(data as SupplierData)]} />
      )}
    />
  );
}
