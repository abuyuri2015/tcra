/**
 * Import a single supplier by pulling its public website and letting AI extract
 * structured details (name, category, city, country, contact info).
 */
import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { Globe, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { PreviewField } from "@/components/ai-import-dialog.tsx";
import {
  type SupplierCategory,
  SUPPLIER_CATEGORY_OPTIONS,
  supplierCategoryLabel,
} from "../_lib/categories.ts";

type SupplierData = {
  name: string;
  category: SupplierCategory;
  country?: string;
  city?: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  notes?: string;
  website: string;
};

const validCategories: string[] = SUPPLIER_CATEGORY_OPTIONS.map((o) => o.value);

type Step = "input" | "loading" | "preview" | "saving";

export default function SupplierWebsiteImport() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("input");
  const [url, setUrl] = useState("");
  const [data, setData] = useState<SupplierData | null>(null);

  const extractFromUrl = useAction(api.ai.extract.extractSupplierFromUrl);
  const bulkCreate = useMutation(api.suppliers.bulkCreate);

  const handleOpen = () => {
    setStep("input");
    setUrl("");
    setData(null);
    setOpen(true);
  };

  const handleFetch = async () => {
    const trimmed = url.trim();
    if (!trimmed) return;
    const withProtocol = /^https?:\/\//i.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    setStep("loading");
    try {
      const result = await extractFromUrl({ url: withProtocol });
      const s = result.data;
      setData({
        ...s,
        category: (validCategories.includes(s.category)
          ? s.category
          : "other") as SupplierCategory,
      });
      setStep("preview");
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : "Couldn't import that website. Please try again.";
      toast.error(msg);
      setStep("input");
    }
  };

  const handleConfirm = async () => {
    if (!data) return;
    setStep("saving");
    try {
      const { website, ...supplier } = data;
      // Store website URL in notes if there are no existing notes
      const notes = supplier.notes
        ? `${supplier.notes}\nWebsite: ${website}`
        : `Website: ${website}`;
      const result = await bulkCreate({
        suppliers: [{ ...supplier, notes }],
      });
      if (result.imported === 0) {
        toast.info(
          "A supplier with that name already exists — nothing imported.",
        );
      } else {
        toast.success(`Imported ${data.name}`);
      }
      setOpen(false);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Import failed. Please try again.";
      toast.error(msg);
      setStep("preview");
    }
  };

  return (
    <>
      <Button variant="secondary" onClick={handleOpen}>
        <Globe className="size-4" />
        Import from website
      </Button>

      <Dialog
        open={open}
        onOpenChange={(v) => {
          if (!v) setOpen(false);
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-display">
              <Globe className="size-4 text-primary" />
              Import supplier from website
            </DialogTitle>
          </DialogHeader>

          {step === "input" && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Paste the supplier's website address. AI will read the page and
                  extract the company name, category, location, and contact
                  details.
                </p>
                <Input
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://www.transfermallorca.com"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleFetch();
                    }
                  }}
                />
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleFetch} disabled={!url.trim()}>
                  <Sparkles className="size-4" />
                  Fetch & extract
                </Button>
              </DialogFooter>
            </>
          )}

          {step === "loading" && (
            <div className="flex flex-col items-center justify-center gap-3 py-12">
              <Loader2 className="size-6 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">
                Reading the website and extracting supplier details…
              </p>
            </div>
          )}

          {step === "preview" && data && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Review the extracted details below. Click{" "}
                  <strong>Confirm import</strong> to save this supplier, or go
                  back to try a different link.
                </p>
                <div className="grid grid-cols-2 gap-3 rounded-lg border bg-muted/30 px-4 py-4">
                  <PreviewField label="Name" value={data.name} />
                  <PreviewField
                    label="Category"
                    value={supplierCategoryLabel(data.category)}
                  />
                  <PreviewField label="City" value={data.city} />
                  <PreviewField label="Country" value={data.country} />
                  <PreviewField label="Contact" value={data.contactPerson} />
                  <PreviewField label="Email" value={data.email} />
                  <PreviewField label="Phone" value={data.phone} />
                  <PreviewField label="Website" value={data.website} />
                  {data.notes && (
                    <div className="col-span-full">
                      <PreviewField label="Notes" value={data.notes} />
                    </div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setStep("input")}>
                  Back
                </Button>
                <Button onClick={handleConfirm}>Confirm import</Button>
              </DialogFooter>
            </>
          )}

          {step === "saving" && (
            <div className="flex items-center justify-center gap-3 py-12">
              <Loader2 className="size-5 animate-spin text-primary" />
              <span className="text-sm text-muted-foreground">Saving…</span>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
