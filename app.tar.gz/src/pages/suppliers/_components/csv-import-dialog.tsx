import { useState, useCallback } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import Papa from "papaparse";
import {
  AlertCircle,
  CheckCircle2,
  FileSpreadsheet,
  Loader2,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { cn } from "@/lib/utils.ts";
import type { SupplierCategory } from "../_lib/categories.ts";
import { SUPPLIER_CATEGORY_OPTIONS, supplierCategoryLabel } from "../_lib/categories.ts";

// ── Types ────────────────────────────────────────────────────────────────────

type ParsedRow = {
  name: string;
  category: SupplierCategory;
  country?: string;
  city?: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  notes?: string;
};

type RowResult = {
  row: number;
  raw: Record<string, string>;
  parsed?: ParsedRow;
  errors: string[];
};

const VALID_CATEGORIES = new Set<string>(
  SUPPLIER_CATEGORY_OPTIONS.map((o) => o.value),
);

// Mapping from common CSV header variations to our field names
const HEADER_MAP: Record<string, keyof ParsedRow> = {
  name: "name",
  supplier: "name",
  "supplier name": "name",
  "supplier_name": "name",
  suppliername: "name",
  category: "category",
  type: "category",
  "supplier type": "category",
  "supplier_type": "category",
  suppliertype: "category",
  country: "country",
  city: "city",
  town: "city",
  contact: "contactPerson",
  "contact person": "contactPerson",
  "contact_person": "contactPerson",
  contactperson: "contactPerson",
  "contact name": "contactPerson",
  email: "email",
  "e-mail": "email",
  "email address": "email",
  phone: "phone",
  telephone: "phone",
  tel: "phone",
  mobile: "phone",
  notes: "notes",
  note: "notes",
  comments: "notes",
  comment: "notes",
};

function normaliseCategory(raw: string): SupplierCategory | null {
  const lower = raw.trim().toLowerCase();
  if (VALID_CATEGORIES.has(lower)) return lower as SupplierCategory;
  // Common aliases
  if (lower === "transport" || lower === "transfers") return "transfer";
  if (lower === "restaurants" || lower === "dining") return "restaurant";
  if (lower === "hotels" || lower === "accommodation") return "hotel";
  if (lower === "activities" || lower === "excursion" || lower === "tour") return "activity";
  if (lower === "venues" || lower === "meeting room") return "venue";
  if (lower === "flights" || lower === "airline") return "flight";
  return null;
}

function parseRows(rawRows: Record<string, string>[]): RowResult[] {
  return rawRows.map((raw, idx) => {
    const errors: string[] = [];

    // Map headers to our field names
    const mapped: Partial<Record<keyof ParsedRow, string>> = {};
    for (const [header, value] of Object.entries(raw)) {
      const normalHeader = header.trim().toLowerCase();
      const field = HEADER_MAP[normalHeader];
      if (field && typeof value === "string") {
        mapped[field] = value.trim();
      }
    }

    // Validate name (required)
    const name = mapped.name?.trim();
    if (!name) {
      errors.push("Name is required");
    }

    // Validate / default category
    let category: SupplierCategory = "other";
    if (mapped.category) {
      const normalised = normaliseCategory(mapped.category);
      if (normalised) {
        category = normalised;
      } else {
        errors.push(`Unknown category "${mapped.category}"`);
      }
    }

    // Validate email if present
    if (mapped.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mapped.email)) {
      errors.push(`Invalid email "${mapped.email}"`);
    }

    const parsed: ParsedRow | undefined =
      name && errors.length === 0
        ? {
            name,
            category,
            country: mapped.country || undefined,
            city: mapped.city || undefined,
            contactPerson: mapped.contactPerson || undefined,
            email: mapped.email || undefined,
            phone: mapped.phone || undefined,
            notes: mapped.notes || undefined,
          }
        : undefined;

    return { row: idx + 2, raw, parsed, errors };
  });
}

// ── Component ────────────────────────────────────────────────────────────────

export default function CsvImportDialog({
  trigger,
}: {
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<"upload" | "preview" | "done">("upload");
  const [results, setResults] = useState<RowResult[]>([]);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    imported: number;
    skipped: number;
  } | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);

  const bulkCreate = useMutation(api.suppliers.bulkCreate);

  const validRows = results.filter((r) => r.parsed);
  const errorRows = results.filter((r) => r.errors.length > 0);

  const reset = () => {
    setStep("upload");
    setResults([]);
    setImportResult(null);
    setParseError(null);
  };

  const handleFile = useCallback((file: File) => {
    setParseError(null);
    setResults([]);

    if (!file.name.endsWith(".csv") && !file.name.endsWith(".txt")) {
      setParseError("Please select a CSV file (.csv)");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setParseError("File is too large (max 5 MB)");
      return;
    }

    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (h) => h.trim(),
      complete: (res) => {
        if (res.errors.length > 0) {
          setParseError(
            `Could not parse CSV: ${res.errors[0].message}`,
          );
          return;
        }
        if (res.data.length === 0) {
          setParseError("The file contains no data rows.");
          return;
        }
        const parsed = parseRows(res.data);
        setResults(parsed);
        setStep("preview");
      },
      error: (err) => {
        setParseError(`Could not read file: ${err.message}`);
      },
    });
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile],
  );

  const handleConfirm = async () => {
    const toImport = validRows.map((r) => r.parsed!);
    if (toImport.length === 0) return;

    setImporting(true);
    try {
      const result = await bulkCreate({ suppliers: toImport });
      setImportResult(result);
      setStep("done");
      toast.success(
        `Imported ${result.imported} supplier${result.imported !== 1 ? "s" : ""}${result.skipped > 0 ? ` (${result.skipped} skipped)` : ""}`,
      );
    } catch (err) {
      const message =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Import failed. Please try again.";
      toast.error(message);
    } finally {
      setImporting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) reset();
      }}
    >
      <DialogTrigger asChild>
        {trigger ?? (
          <Button variant="secondary" size="sm">
            <Upload className="size-4" />
            Import CSV
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-hidden flex flex-col sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <FileSpreadsheet className="size-4 text-muted-foreground" />
            {step === "upload" && "Import suppliers from CSV"}
            {step === "preview" && "Preview import"}
            {step === "done" && "Import complete"}
          </DialogTitle>
          <DialogDescription>
            {step === "upload" &&
              "Upload a CSV file with columns: name, category, city, country, contact, email, phone, notes."}
            {step === "preview" &&
              `${validRows.length} valid row${validRows.length !== 1 ? "s" : ""} ready to import${errorRows.length > 0 ? `, ${errorRows.length} with errors` : ""}. Duplicates by name will be skipped.`}
            {step === "done" && "Your suppliers have been imported."}
          </DialogDescription>
        </DialogHeader>

        {/* ── Upload step ── */}
        {step === "upload" && (
          <div className="flex-1">
            <div
              onDrop={handleDrop}
              onDragOver={(e) => e.preventDefault()}
              className="flex flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed border-muted-foreground/25 bg-muted/30 px-6 py-10 text-center transition-colors hover:border-muted-foreground/40"
            >
              <Upload className="size-8 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">
                  Drag and drop a CSV file here
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  or click below to browse
                </p>
              </div>
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept=".csv,.txt"
                  className="sr-only"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleFile(f);
                  }}
                />
                <span className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground transition-colors hover:bg-primary/90">
                  Choose file
                </span>
              </label>
            </div>

            {parseError && (
              <div className="mt-4 flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
                <AlertCircle className="mt-0.5 size-4 shrink-0" />
                {parseError}
              </div>
            )}

            <div className="mt-4 rounded-lg border bg-muted/40 p-3">
              <p className="text-xs font-medium text-muted-foreground mb-1.5">
                Expected columns (name is required):
              </p>
              <div className="flex flex-wrap gap-1.5">
                {["name", "category", "city", "country", "contact", "email", "phone", "notes"].map(
                  (col) => (
                    <Badge key={col} variant="secondary" className="text-[10px]">
                      {col}
                      {col === "name" && " *"}
                    </Badge>
                  ),
                )}
              </div>
              <p className="mt-2 text-[11px] text-muted-foreground">
                Category accepts: hotel, transfer, restaurant, activity, venue, flight, other. Defaults to "other" if omitted.
              </p>
            </div>
          </div>
        )}

        {/* ── Preview step ── */}
        {step === "preview" && (
          <div className="flex-1 overflow-y-auto -mx-6 px-6">
            {/* Error summary */}
            {errorRows.length > 0 && (
              <div className="mb-3 rounded-lg border border-amber-200 bg-amber-50 p-3 dark:border-amber-800 dark:bg-amber-950/40">
                <p className="text-xs font-medium text-amber-800 dark:text-amber-300 mb-1">
                  {errorRows.length} row{errorRows.length !== 1 ? "s" : ""} with
                  errors (will be skipped):
                </p>
                <ul className="space-y-0.5 text-xs text-amber-700 dark:text-amber-400 max-h-24 overflow-y-auto">
                  {errorRows.slice(0, 20).map((r) => (
                    <li key={r.row}>
                      Row {r.row}: {r.errors.join(", ")}
                    </li>
                  ))}
                  {errorRows.length > 20 && (
                    <li className="italic">
                      …and {errorRows.length - 20} more
                    </li>
                  )}
                </ul>
              </div>
            )}

            {/* Preview table */}
            <div className="rounded-lg border overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground w-8">
                      #
                    </th>
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground">
                      Name
                    </th>
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground">
                      Category
                    </th>
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground">
                      City
                    </th>
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground">
                      Country
                    </th>
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground">
                      Contact
                    </th>
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground">
                      Email
                    </th>
                    <th className="px-2 py-2 text-left font-medium text-muted-foreground w-8">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {results.slice(0, 100).map((r) => {
                    const hasError = r.errors.length > 0;
                    return (
                      <tr
                        key={r.row}
                        className={cn(
                          "border-b last:border-0",
                          hasError && "bg-destructive/5",
                        )}
                      >
                        <td className="px-2 py-1.5 text-muted-foreground">
                          {r.row}
                        </td>
                        <td className="px-2 py-1.5 font-medium max-w-32 truncate">
                          {r.parsed?.name ?? r.raw["name"] ?? r.raw["Name"] ?? "—"}
                        </td>
                        <td className="px-2 py-1.5">
                          {r.parsed
                            ? supplierCategoryLabel(r.parsed.category)
                            : "—"}
                        </td>
                        <td className="px-2 py-1.5 text-muted-foreground max-w-24 truncate">
                          {r.parsed?.city ?? "—"}
                        </td>
                        <td className="px-2 py-1.5 text-muted-foreground max-w-24 truncate">
                          {r.parsed?.country ?? "—"}
                        </td>
                        <td className="px-2 py-1.5 text-muted-foreground max-w-24 truncate">
                          {r.parsed?.contactPerson ?? "—"}
                        </td>
                        <td className="px-2 py-1.5 text-muted-foreground max-w-32 truncate">
                          {r.parsed?.email ?? "—"}
                        </td>
                        <td className="px-2 py-1.5 text-center">
                          {hasError ? (
                            <X className="size-3.5 text-destructive" />
                          ) : (
                            <CheckCircle2 className="size-3.5 text-chart-3" />
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {results.length > 100 && (
                <p className="px-3 py-2 text-[11px] text-muted-foreground border-t">
                  Showing first 100 of {results.length} rows
                </p>
              )}
            </div>
          </div>
        )}

        {/* ── Done step ── */}
        {step === "done" && importResult && (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 py-6">
            <div className="flex size-14 items-center justify-center rounded-full bg-chart-3/10">
              <CheckCircle2 className="size-7 text-chart-3" />
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold">
                {importResult.imported} supplier{importResult.imported !== 1 ? "s" : ""} imported
              </p>
              {importResult.skipped > 0 && (
                <p className="mt-1 text-sm text-muted-foreground">
                  {importResult.skipped} skipped (duplicates or invalid rows)
                </p>
              )}
            </div>
          </div>
        )}

        {/* ── Footer ── */}
        <DialogFooter>
          {step === "upload" && (
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
          )}
          {step === "preview" && (
            <>
              <Button variant="ghost" onClick={reset} disabled={importing}>
                Back
              </Button>
              <Button
                onClick={handleConfirm}
                disabled={importing || validRows.length === 0}
              >
                {importing ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Importing…
                  </>
                ) : (
                  <>
                    Import {validRows.length} supplier{validRows.length !== 1 ? "s" : ""}
                  </>
                )}
              </Button>
            </>
          )}
          {step === "done" && (
            <Button onClick={() => setOpen(false)}>Done</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
