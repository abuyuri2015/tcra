import { useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import {
  ArrowLeft,
  CalendarDays,
  FileText,
  Mail,
  MapPin,
  Package,
  Pencil,
  Phone,
  Trash2,
  User,
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import type { SupplierReservation } from "@/convex/suppliers.ts";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  ErrorState,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import {
  supplierCategoryLabel,
  supplierCategoryIcon,
  SUPPLIER_CATEGORY_OPTIONS,
  type SupplierCategory,
} from "../suppliers/page.tsx";
import { reservationTypeLabel, reservationStatusLabel } from "@/lib/domain.ts";

// Re-use the form dialog from the suppliers page
import SupplierFormDialogInner from "./_components/supplier-form-dialog.tsx";

// ── Detail row ───────────────────────────────────────────────────────────────

function DetailRow({
  icon: Icon,
  label,
  value,
  href,
}: {
  icon: typeof User;
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        {href ? (
          <a
            href={href}
            className="break-words text-sm font-medium text-primary hover:underline"
          >
            {value}
          </a>
        ) : (
          <p className="break-words text-sm font-medium">{value}</p>
        )}
      </div>
    </div>
  );
}

// ── Category chip colors ─────────────────────────────────────────────────────

const CATEGORY_CHIP: Record<SupplierCategory, string> = {
  hotel: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  transfer: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  restaurant: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
  activity: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  venue: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300",
  flight: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300",
  other: "bg-muted text-muted-foreground",
};

// ── Reservation row ──────────────────────────────────────────────────────────

function ReservationRow({ r }: { r: SupplierReservation }) {
  const dateStr = (() => {
    try {
      const start = format(parseISO(r.startDate), "d MMM yyyy");
      const end = r.endDate ? format(parseISO(r.endDate), "d MMM yyyy") : null;
      return end && end !== start ? `${start} – ${end}` : start;
    } catch {
      return r.startDate;
    }
  })();

  return (
    <Link
      to={`/files/${r.groupFileId}?tab=reservations`}
      className="flex items-center justify-between gap-3 rounded-md px-3 py-2.5 transition-colors hover:bg-secondary/50"
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{r.description}</p>
        <p className="truncate text-xs text-muted-foreground">
          {r.groupFileReference} · {r.groupFileTitle} · {reservationTypeLabel(r.type)}
        </p>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1">
        <StatusBadge status={r.status} />
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <CalendarDays className="size-3" />
          {dateStr}
        </span>
      </div>
    </Link>
  );
}

// ── Main page ────────────────────────────────────────────────────────────────

export default function SupplierDetailPage() {
  const { supplierId } = useParams<{ supplierId: string }>();
  const navigate = useNavigate();
  const [editOpen, setEditOpen] = useState(false);

  const data = useQuery(
    api.suppliers.getDetail,
    supplierId ? { id: supplierId as Id<"suppliers"> } : "skip",
  );
  const remove = useMutation(api.suppliers.remove);

  // Loading
  if (data === undefined) {
    return (
      <div className="mx-auto max-w-5xl space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  // Not found
  if (data === null) {
    return (
      <div className="mx-auto max-w-xl py-10">
        <ErrorState>
          <ErrorStateHeader>
            <ErrorStateMedia variant="icon">
              <Package />
            </ErrorStateMedia>
            <ErrorStateTitle>Supplier not found</ErrorStateTitle>
            <ErrorStateDescription>
              This supplier may have been deleted.
            </ErrorStateDescription>
          </ErrorStateHeader>
        </ErrorState>
      </div>
    );
  }

  const { supplier, reservations } = data;
  const Icon = supplierCategoryIcon(supplier.category);

  const handleDelete = async () => {
    try {
      await remove({ id: supplier._id });
      toast.success("Supplier deleted");
      navigate("/suppliers");
    } catch (error) {
      const msg =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not delete supplier.";
      toast.error(msg);
    }
  };

  const location = [supplier.city, supplier.country].filter(Boolean).join(", ");

  return (
    <>
      <SupplierFormDialogInner
        supplier={supplier}
        open={editOpen}
        onClose={() => setEditOpen(false)}
      />

      <div className="mx-auto max-w-5xl">
        <Link
          to="/suppliers"
          className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          All suppliers
        </Link>

        <PageHeader
          eyebrow={location || "Supplier"}
          title={supplier.name}
          actions={
            <>
              <Button variant="secondary" onClick={() => setEditOpen(true)}>
                <Pencil className="size-4" />
                Edit
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="icon" aria-label="Delete supplier">
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete {supplier.name}?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently remove the supplier from your database.
                      Existing reservations will not be affected.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          }
        />

        {/* Category badge */}
        <div className="mb-6">
          <span
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium",
              CATEGORY_CHIP[supplier.category],
            )}
          >
            <Icon className="size-3" />
            {supplierCategoryLabel(supplier.category)}
          </span>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {/* Contact info */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display text-base">Contact details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {location && <DetailRow icon={MapPin} label="Location" value={location} />}
              {supplier.contactPerson && (
                <DetailRow icon={User} label="Contact person" value={supplier.contactPerson} />
              )}
              {supplier.email && (
                <DetailRow
                  icon={Mail}
                  label="Email"
                  value={supplier.email}
                  href={`mailto:${supplier.email}`}
                />
              )}
              {supplier.phone && (
                <DetailRow
                  icon={Phone}
                  label="Phone"
                  value={supplier.phone}
                  href={`tel:${supplier.phone}`}
                />
              )}
              {!location && !supplier.contactPerson && !supplier.email && !supplier.phone && (
                <p className="text-sm text-muted-foreground">No contact details added yet.</p>
              )}
            </CardContent>
          </Card>

          {/* Notes + quick actions */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display text-base">Notes & actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {supplier.notes ? (
                <div className="rounded-md bg-muted/60 p-3 text-sm whitespace-pre-wrap">
                  {supplier.notes}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">No notes.</p>
              )}
              <div className="flex flex-wrap gap-2 pt-1">
                {supplier.email && (
                  <Button asChild variant="secondary" size="sm">
                    <a href={`mailto:${supplier.email}`}>
                      <Mail className="size-3.5" />
                      Email
                    </a>
                  </Button>
                )}
                {supplier.phone && (
                  <Button asChild variant="secondary" size="sm">
                    <a href={`tel:${supplier.phone}`}>
                      <Phone className="size-3.5" />
                      Call
                    </a>
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Linked reservations */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 font-display text-base">
                <FileText className="size-4 text-muted-foreground" />
                Linked reservations
                {reservations.length > 0 && (
                  <span className="ml-1 rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                    {reservations.length}
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {reservations.length === 0 ? (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon">
                      <FileText />
                    </EmptyMedia>
                    <EmptyTitle>No reservations yet</EmptyTitle>
                    <EmptyDescription>
                      When you create reservations using this supplier name, they will appear here.
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ) : (
                <div className="space-y-1">
                  {reservations.map((r) => (
                    <ReservationRow key={r._id} r={r} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
