import {
  BedDouble,
  Building,
  Bus,
  Package,
  Plane,
  Sunset,
  UtensilsCrossed,
} from "lucide-react";

export type SupplierCategory =
  | "hotel"
  | "transfer"
  | "restaurant"
  | "activity"
  | "venue"
  | "flight"
  | "other";

export const SUPPLIER_CATEGORY_OPTIONS: {
  value: SupplierCategory;
  label: string;
  icon: typeof BedDouble;
}[] = [
  { value: "hotel", label: "Hotel", icon: BedDouble },
  { value: "transfer", label: "Transfer", icon: Bus },
  { value: "restaurant", label: "Restaurant", icon: UtensilsCrossed },
  { value: "activity", label: "Activity", icon: Sunset },
  { value: "venue", label: "Venue", icon: Building },
  { value: "flight", label: "Flight", icon: Plane },
  { value: "other", label: "Other", icon: Package },
];

export function supplierCategoryLabel(cat: SupplierCategory): string {
  return SUPPLIER_CATEGORY_OPTIONS.find((o) => o.value === cat)?.label ?? cat;
}

export function supplierCategoryIcon(cat: SupplierCategory): typeof BedDouble {
  return SUPPLIER_CATEGORY_OPTIONS.find((o) => o.value === cat)?.icon ?? Package;
}

export const CATEGORY_CHIP: Record<SupplierCategory, string> = {
  hotel: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  transfer: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  restaurant: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
  activity: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  venue: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300",
  flight: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300",
  other: "bg-muted text-muted-foreground",
};
