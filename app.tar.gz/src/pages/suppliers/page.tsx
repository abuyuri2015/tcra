import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ConvexError } from "convex/values";
import {
  Mail,
  MoreHorizontal,
  Package,
  Pencil,
  Phone,
  Plus,
  Search,
  Trash2,
  User,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.js";
import PageHeader from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Card,
  CardContent,
} from "@/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { useDebounce } from "@/hooks/use-debounce.ts";
import CsvImportDialog from "./_components/csv-import-dialog.tsx";
import SupplierAiImport from "./_components/supplier-ai-import.tsx";
import SupplierWebsiteImport from "./_components/supplier-website-import.tsx";
import HotelFormDialog from "@/pages/hotels/_components/hotel-form-dialog.tsx";
import {
  type SupplierCategory,
  SUPPLIER_CATEGORY_OPTIONS,
  supplierCategoryLabel,
  supplierCategoryIcon,
  CATEGORY_CHIP,
} from "./_lib/categories.ts";

// Re-export for other consumers
export {
  type SupplierCategory,
  SUPPLIER_CATEGORY_OPTIONS,
  supplierCategoryLabel,
  supplierCategoryIcon,
  CATEGORY_CHIP,
};

// ── Form schema ───────────────────────────────────────────────────────────────

const supplierSchema = z.object({
  name: z.string().min(1, "Name is required"),
  category: z.enum([
    "hotel",
    "transfer",
    "restaurant",
    "activity",
    "venue",
    "flight",
    "other",
  ]),
  country: z.string(),
  city: z.string(),
  contactPerson: z.string(),
  email: z.string().email("Invalid email").or(z.literal("")),
  phone: z.string(),
  notes: z.string(),
});

type SupplierFormValues = z.infer<typeof supplierSchema>;

function defaultValues(s?: Doc<"suppliers">): SupplierFormValues {
  return {
    name: s?.name ?? "",
    category: s?.category ?? "hotel",
    country: s?.country ?? "",
    city: s?.city ?? "",
    contactPerson: s?.contactPerson ?? "",
    email: s?.email ?? "",
    phone: s?.phone ?? "",
    notes: s?.notes ?? "",
  };
}

// ── Supplier form dialog ──────────────────────────────────────────────────────

function SupplierFormDialog({
  supplier,
  open,
  onClose,
}: {
  supplier?: Doc<"suppliers">;
  open: boolean;
  onClose: () => void;
}) {
  const create = useMutation(api.suppliers.create);
  const update = useMutation(api.suppliers.update);

  const form = useForm<SupplierFormValues>({
    resolver: zodResolver(supplierSchema),
    defaultValues: defaultValues(supplier),
  });

  const handleOpenChange = (v: boolean) => {
    if (!v) onClose();
    else form.reset(defaultValues(supplier));
  };

  // Reset when supplier changes (open dialog with different record)
  const onSubmit = async (values: SupplierFormValues) => {
    try {
      const payload = {
        name: values.name.trim(),
        category: values.category,
        country: values.country.trim() || undefined,
        city: values.city.trim() || undefined,
        contactPerson: values.contactPerson.trim() || undefined,
        email: values.email.trim() || undefined,
        phone: values.phone.trim() || undefined,
        notes: values.notes.trim() || undefined,
      };
      if (supplier) {
        await update({ id: supplier._id, ...payload });
        toast.success("Supplier updated");
      } else {
        await create(payload);
        toast.success("Supplier added");
      }
      onClose();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not save supplier.";
      toast.error(msg);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">
            {supplier ? "Edit supplier" : "Add supplier"}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            {/* Name */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Hotel Arts Barcelona" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Category */}
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {SUPPLIER_CATEGORY_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* City */}
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <FormControl>
                    <Input placeholder="Barcelona" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Country */}
            <FormField
              control={form.control}
              name="country"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Country</FormLabel>
                  <FormControl>
                    <Input placeholder="Spain" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Contact person */}
            <FormField
              control={form.control}
              name="contactPerson"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact person</FormLabel>
                  <FormControl>
                    <Input placeholder="María López" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Email */}
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="groups@hotel.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Phone */}
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input placeholder="+34 93 123 4567" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={2} placeholder="Internal notes…" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button type="button" variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {supplier ? "Save changes" : "Add supplier"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── Supplier card ─────────────────────────────────────────────────────────────

function SupplierCard({
  supplier,
  onEdit,
}: {
  supplier: Doc<"suppliers">;
  onEdit: (s: Doc<"suppliers">) => void;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const remove = useMutation(api.suppliers.remove);
  const Icon = supplierCategoryIcon(supplier.category);

  const handleDelete = async () => {
    try {
      await remove({ id: supplier._id });
      toast.success("Supplier deleted");
    } catch {
      toast.error("Could not delete supplier");
    }
  };

  return (
    <>
      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {supplier.name}?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the supplier from your database. Existing reservations that reference this supplier will not be affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Link to={`/suppliers/${supplier._id}`}>
        <Card className="group transition-shadow hover:shadow-md cursor-pointer">
          <CardContent className="p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex min-w-0 items-start gap-3">
              <div className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg bg-muted">
                <Icon className="size-4 text-muted-foreground" />
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate text-sm font-semibold">{supplier.name}</p>
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                      CATEGORY_CHIP[supplier.category],
                    )}
                  >
                    {supplierCategoryLabel(supplier.category)}
                  </span>
                </div>

                {(supplier.city || supplier.country) && (
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {[supplier.city, supplier.country].filter(Boolean).join(", ")}
                  </p>
                )}

                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  {supplier.contactPerson && (
                    <span className="flex items-center gap-1">
                      <User className="size-3 shrink-0" />
                      {supplier.contactPerson}
                    </span>
                  )}
                  {supplier.email && (
                    <a
                      href={`mailto:${supplier.email}`}
                      className="flex items-center gap-1 hover:text-foreground hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Mail className="size-3 shrink-0" />
                      {supplier.email}
                    </a>
                  )}
                  {supplier.phone && (
                    <a
                      href={`tel:${supplier.phone}`}
                      className="flex items-center gap-1 hover:text-foreground hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Phone className="size-3 shrink-0" />
                      {supplier.phone}
                    </a>
                  )}
                </div>

                {supplier.notes && (
                  <p className="mt-1.5 text-xs text-muted-foreground italic line-clamp-2">
                    {supplier.notes}
                  </p>
                )}
              </div>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-7 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreHorizontal className="size-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(supplier)}>
                  <Pencil className="size-4" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => setConfirmDelete(true)}
                >
                  <Trash2 className="size-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          </CardContent>
        </Card>
      </Link>
    </>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function SuppliersPage() {
  const [searchInput, setSearchInput] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<SupplierCategory | "all">("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Doc<"suppliers"> | undefined>();

  const [debouncedSearch] = useDebounce(searchInput, 300);

  const allSuppliers = useQuery(api.suppliers.list, {
    category: categoryFilter === "all" ? undefined : categoryFilter,
  });

  const searchResults = useQuery(
    api.suppliers.search,
    debouncedSearch.trim()
      ? {
          query: debouncedSearch,
          category: categoryFilter === "all" ? undefined : categoryFilter,
        }
      : "skip",
  );

  const suppliers = debouncedSearch.trim() ? searchResults : allSuppliers;

  const openCreate = () => {
    setEditingSupplier(undefined);
    setDialogOpen(true);
  };

  const openEdit = (s: Doc<"suppliers">) => {
    setEditingSupplier(s);
    setDialogOpen(true);
  };

  return (
    <>
      <SupplierFormDialog
        key={editingSupplier?._id ?? "new"}
        supplier={editingSupplier}
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
      />

      <div className="space-y-6">
        <PageHeader
          eyebrow="Operations"
          title="Suppliers"
          description="Your reusable contact database for hotels, transfers, venues, and other service providers."
          actions={
            <div className="flex flex-wrap gap-2">
              <CsvImportDialog />
              <SupplierWebsiteImport />
              <SupplierAiImport />
              <HotelFormDialog
                trigger={
                  <Button variant="secondary">
                    <Plus className="size-4" />
                    Add hotel
                  </Button>
                }
              />
              <Button onClick={openCreate}>
                <Plus className="size-4" />
                Add supplier
              </Button>
            </div>
          }
        />

        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search suppliers…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pl-9"
            />
          </div>

          {/* Category pills */}
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setCategoryFilter("all")}
              className={cn(
                "rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                categoryFilter === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:text-foreground",
              )}
            >
              All
            </button>
            {SUPPLIER_CATEGORY_OPTIONS.map((o) => {
              const Icon = o.icon;
              return (
                <button
                  key={o.value}
                  type="button"
                  onClick={() => setCategoryFilter(o.value)}
                  className={cn(
                    "flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                    categoryFilter === o.value
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:text-foreground",
                  )}
                >
                  <Icon className="size-3" />
                  {o.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Count */}
        {suppliers !== undefined && suppliers.length > 0 && (
          <p className="text-xs text-muted-foreground">
            {suppliers.length} supplier{suppliers.length !== 1 ? "s" : ""}
            {categoryFilter !== "all" && ` · ${supplierCategoryLabel(categoryFilter)}`}
          </p>
        )}

        {/* List */}
        {suppliers === undefined ? (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-28 w-full" />
            ))}
          </div>
        ) : suppliers.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Package />
              </EmptyMedia>
              <EmptyTitle>
                {debouncedSearch.trim() ? "No suppliers found" : "No suppliers yet"}
              </EmptyTitle>
              <EmptyDescription>
                {debouncedSearch.trim()
                  ? "Try a different search term or clear the filters."
                  : "Add hotels, transfers, restaurants and other service providers to your supplier database."}
              </EmptyDescription>
            </EmptyHeader>
            {!debouncedSearch.trim() && (
              <EmptyContent>
                <Button size="sm" onClick={openCreate}>
                  <Plus className="size-4" />
                  Add first supplier
                </Button>
              </EmptyContent>
            )}
          </Empty>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {suppliers.map((s) => (
              <SupplierCard key={s._id} supplier={s} onEdit={openEdit} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}
