import { useState } from "react";
import { Link } from "react-router-dom";
import { usePaginatedQuery, useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import {
  BedDouble,
  Building2,
  CheckSquare,
  ChevronDown,
  Download,
  MapPin,
  Plus,
  Search,
  Square,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.js";
import PageHeader from "@/components/page-header.tsx";
import HotelFormDialog from "./_components/hotel-form-dialog.tsx";
import HotelAiImport from "./_components/hotel-ai-import.tsx";
import HotelWebsiteImport from "./_components/hotel-website-import.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import { cn } from "@/lib/utils.ts";
import {
  HOTEL_CATEGORY_OPTIONS,
  HOTEL_STATUS_OPTIONS,
  HOTEL_STATUS_STYLES,
  hotelCategoryLabel,
  hotelStatusLabel,
} from "@/lib/domain.ts";
import type { HotelStatus } from "@/lib/domain.ts";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { downloadCsv } from "@/lib/csv-export.ts";

// ── Hotel card ──────────────────────────────────────────────────────────────

function HotelCard({
  hotel,
  selected,
  onToggle,
}: {
  hotel: Doc<"hotels">;
  selected: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="group relative">
      {/* Checkbox */}
      <div className="absolute left-2.5 top-2.5 z-10">
        <Checkbox
          checked={selected}
          onCheckedChange={onToggle}
          onClick={(e) => e.stopPropagation()}
          className={cn(
            "border-background/60 bg-background/70 backdrop-blur transition-opacity",
            selected ? "opacity-100" : "opacity-0 group-hover:opacity-100",
          )}
          aria-label={`Select ${hotel.name}`}
        />
      </div>

      <Link
        to={`/hotels/${hotel._id}`}
        className="block"
        onClick={(e) => selected && e.preventDefault()}
      >
        <Card
          className={cn(
            "h-full gap-0 overflow-hidden pt-0 transition-colors",
            selected
              ? "border-primary/60 ring-1 ring-primary/30"
              : "hover:border-ring/60 hover:bg-secondary/30",
          )}
        >
          {hotel.imageUrls.length > 0 ? (
            <img
              src={hotel.imageUrls[0]}
              alt={hotel.name}
              className="h-36 w-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = "none";
              }}
            />
          ) : (
            <div className="flex h-36 items-center justify-center bg-muted/50">
              <Building2 className="size-10 text-muted-foreground/40" />
            </div>
          )}
          <div className="space-y-2 p-4">
            <div className="flex items-start justify-between gap-2">
              <h2 className="line-clamp-2 font-display text-base font-semibold leading-tight">
                {hotel.name}
              </h2>
              <span
                className={cn(
                  "shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium",
                  HOTEL_STATUS_STYLES[hotel.status],
                )}
              >
                {hotelStatusLabel(hotel.status)}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="size-3.5 shrink-0" />
              <span className="truncate">
                {hotel.city}, {hotel.country}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Star className="size-3.5 shrink-0" />
              <span>{hotelCategoryLabel(hotel.category)}</span>
              {hotel.totalRooms ? (
                <>
                  <span className="text-border">·</span>
                  <BedDouble className="size-3.5 shrink-0" />
                  <span>{hotel.totalRooms} rooms</span>
                </>
              ) : null}
            </div>
            {hotel.amenities.length > 0 ? (
              <p className="truncate text-xs text-muted-foreground">
                {hotel.amenities.slice(0, 4).join(" · ")}
              </p>
            ) : null}
          </div>
        </Card>
      </Link>
    </div>
  );
}

// ── Bulk actions toolbar ────────────────────────────────────────────────────

function BulkToolbar({
  count,
  total,
  onSelectAll,
  onDeselectAll,
  onExport,
  onChangeStatus,
  onDelete,
}: {
  count: number;
  total: number;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onExport: () => void;
  onChangeStatus: (status: HotelStatus) => void;
  onDelete: () => void;
}) {
  const allSelected = count === total && total > 0;

  return (
    <div className="sticky top-14 z-20 mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-primary/30 bg-card px-4 py-2.5 shadow-sm">
      <Button
        variant="ghost"
        size="sm"
        className="gap-2 text-sm"
        onClick={allSelected ? onDeselectAll : onSelectAll}
      >
        {allSelected ? (
          <CheckSquare className="size-4 text-primary" />
        ) : (
          <Square className="size-4" />
        )}
        {allSelected ? "Deselect all" : `Select all ${total}`}
      </Button>

      <div className="h-4 w-px bg-border" />

      <span className="text-sm font-medium text-primary">
        {count} selected
      </span>

      <div className="ml-auto flex flex-wrap items-center gap-2">
        <Button variant="secondary" size="sm" onClick={onExport}>
          <Download className="size-4" />
          Export CSV
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="sm">
              Change status
              <ChevronDown className="size-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {HOTEL_STATUS_OPTIONS.map((o) => (
              <DropdownMenuItem
                key={o.value}
                onClick={() => onChangeStatus(o.value as HotelStatus)}
              >
                {o.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="destructive" size="sm" onClick={onDelete}>
          <Trash2 className="size-4" />
          Delete
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="size-8"
          onClick={onDeselectAll}
        >
          <X className="size-4" />
          <span className="sr-only">Clear selection</span>
        </Button>
      </div>
    </div>
  );
}

// ── Page ────────────────────────────────────────────────────────────────────

export default function HotelsPage() {
  const [statusFilter, setStatusFilter] = useState<HotelStatus | "all">("all");
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [debouncedSearch] = useDebounce(search, 250);

  // Multi-select
  const [selectedIds, setSelectedIds] = useState<Set<Id<"hotels">>>(new Set());
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);

  const { results, status, loadMore } = usePaginatedQuery(
    api.hotels.list,
    statusFilter === "all" ? {} : { status: statusFilter },
    { initialNumItems: 30 },
  );

  const bulkUpdateStatus = useMutation(api.hotels.bulkUpdateStatus);
  const bulkDelete = useMutation(api.hotels.bulkDelete);

  const term = debouncedSearch.trim().toLowerCase();
  const visible = results.filter((h) => {
    const matchesSearch =
      !term ||
      [h.name, h.city, h.country].join(" ").toLowerCase().includes(term);
    const matchesCategory =
      categoryFilter === "all" || h.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const isFirstLoad = status === "LoadingFirstPage";
  const hasSelection = selectedIds.size > 0;

  // ── Helpers ────────────────────────────────────────────────────────────

  const toggleSelect = (id: Id<"hotels">) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAll = () => setSelectedIds(new Set(visible.map((h) => h._id)));
  const deselectAll = () => setSelectedIds(new Set());

  const handleExport = (subset?: Doc<"hotels">[]) => {
    const hotels = subset ?? visible;
    if (hotels.length === 0) return;
    const rows = hotels.map((h) => ({
      Name: h.name,
      Category: hotelCategoryLabel(h.category),
      Status: hotelStatusLabel(h.status),
      City: h.city,
      Country: h.country,
      Address: h.address ?? "",
      Website: h.website ?? "",
      "Contact name": h.contactName ?? "",
      "Contact email": h.contactEmail ?? "",
      "Contact phone": h.contactPhone ?? "",
      "Total rooms": h.totalRooms ?? "",
      "Meeting rooms": h.meetingRooms ?? "",
      "Largest meeting capacity": h.largestMeetingCapacity ?? "",
      Currency: h.currency,
      Amenities: h.amenities.join(", "),
      Notes: h.notes ?? "",
    }));
    const today = new Date().toISOString().slice(0, 10);
    downloadCsv(rows, `hotels-${today}.csv`);
  };

  const handleBulkExport = () => {
    const selected = visible.filter((h) => selectedIds.has(h._id));
    handleExport(selected);
  };

  const handleBulkChangeStatus = async (newStatus: HotelStatus) => {
    try {
      await bulkUpdateStatus({
        ids: Array.from(selectedIds),
        status: newStatus,
      });
      toast.success(
        `Updated ${selectedIds.size} hotel${selectedIds.size !== 1 ? "s" : ""} to "${hotelStatusLabel(newStatus)}"`,
      );
      deselectAll();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not update hotels.";
      toast.error(msg);
    }
  };

  const handleBulkDelete = async () => {
    try {
      await bulkDelete({ ids: Array.from(selectedIds) });
      toast.success(
        `Deleted ${selectedIds.size} hotel${selectedIds.size !== 1 ? "s" : ""}`,
      );
      deselectAll();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not delete hotels.";
      toast.error(msg);
    } finally {
      setBulkDeleteOpen(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        eyebrow="Content"
        title="Hotels"
        description="Your contracted properties, venues and suppliers in one database."
        actions={
          <div className="flex gap-2">
            {!hasSelection && visible.length > 0 && (
              <Button variant="secondary" onClick={() => handleExport()}>
                <Download className="size-4" />
                Export CSV
              </Button>
            )}
            <HotelWebsiteImport />
            <HotelAiImport />
            <HotelFormDialog
              trigger={
                <Button>
                  <Plus className="size-4" />
                  Add hotel
                </Button>
              }
            />
          </div>
        }
      />

      <div className="flex flex-col gap-3 pb-5 sm:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, city or country"
            className="pl-9"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="sm:w-48">
            <SelectValue placeholder="All categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {HOTEL_CATEGORY_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={statusFilter}
          onValueChange={(v) => setStatusFilter(v as HotelStatus | "all")}
        >
          <SelectTrigger className="sm:w-40">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {HOTEL_STATUS_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Bulk actions toolbar */}
      {hasSelection && (
        <BulkToolbar
          count={selectedIds.size}
          total={visible.length}
          onSelectAll={selectAll}
          onDeselectAll={deselectAll}
          onExport={handleBulkExport}
          onChangeStatus={handleBulkChangeStatus}
          onDelete={() => setBulkDeleteOpen(true)}
        />
      )}

      {isFirstLoad ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-48 w-full" />
          ))}
        </div>
      ) : visible.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <BedDouble />
            </EmptyMedia>
            <EmptyTitle>
              {term || statusFilter !== "all" || categoryFilter !== "all"
                ? "No hotels match your filters"
                : "No hotels yet"}
            </EmptyTitle>
            <EmptyDescription>
              {term || statusFilter !== "all" || categoryFilter !== "all"
                ? "Try adjusting your search or filters."
                : "Add your first property to start building your hotel database."}
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <HotelFormDialog
              trigger={
                <Button size="sm">
                  <Plus className="size-4" />
                  Add hotel
                </Button>
              }
            />
          </EmptyContent>
        </Empty>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((hotel) => (
            <HotelCard
              key={hotel._id}
              hotel={hotel}
              selected={selectedIds.has(hotel._id)}
              onToggle={() => toggleSelect(hotel._id)}
            />
          ))}

          {status === "CanLoadMore" || status === "LoadingMore" ? (
            <div className="pt-2 text-center sm:col-span-2 lg:col-span-3">
              <Button
                variant="secondary"
                onClick={() => loadMore(30)}
                disabled={status === "LoadingMore"}
              >
                Load more
              </Button>
            </div>
          ) : null}
        </div>
      )}

      {/* Bulk delete confirmation */}
      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete {selectedIds.size} hotel
              {selectedIds.size !== 1 ? "s" : ""}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the selected hotels and all their
              room types. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleBulkDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
