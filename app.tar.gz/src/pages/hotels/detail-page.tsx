import { useNavigate, useParams, Link } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import {
  ArrowLeft,
  BedDouble,
  Building2,
  Globe,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  Star,
  Trash2,
  User,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import PageHeader from "@/components/page-header.tsx";
import HotelFormDialog from "./_components/hotel-form-dialog.tsx";
import RoomTypeFormDialog from "./_components/room-type-form-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  ErrorState,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import {
  HOTEL_STATUS_OPTIONS,
  HOTEL_STATUS_STYLES,
  boardLabel,
  formatMoney,
  hotelCategoryLabel,
  hotelStatusLabel,
} from "@/lib/domain.ts";
import type { HotelStatus } from "@/lib/domain.ts";

function DetailRow({
  icon: Icon,
  label,
  value,
  href,
}: {
  icon: typeof User;
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        {href ? (
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="break-words text-sm font-medium text-primary hover:underline"
          >
            {value}
          </a>
        ) : (
          <p className="break-words text-sm font-medium">{value}</p>
        )}
      </div>
    </div>
  );
}

function RoomTypeRow({
  room,
  hotelId,
  currency,
}: {
  room: Doc<"hotelRoomTypes">;
  hotelId: Id<"hotels">;
  currency: string;
}) {
  const remove = useMutation(api.hotels.removeRoomType);

  const handleRemove = async () => {
    try {
      await remove({ id: room._id });
      toast.success("Room type removed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not remove room type.";
      toast.error(message);
    }
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border px-3 py-2.5">
      <div className="min-w-0 space-y-0.5">
        <p className="text-sm font-medium">{room.name}</p>
        <p className="text-xs text-muted-foreground">
          {room.occupancy} guest{room.occupancy > 1 ? "s" : ""} ·{" "}
          {boardLabel(room.board)}
          {room.nightlyRate !== undefined
            ? ` · ${formatMoney(room.nightlyRate, currency)}/night`
            : ""}
        </p>
        {room.notes ? (
          <p className="text-xs text-muted-foreground">{room.notes}</p>
        ) : null}
      </div>
      <div className="flex items-center gap-1.5 shrink-0">
        <RoomTypeFormDialog
          hotelId={hotelId}
          room={room}
          trigger={
            <Button variant="ghost" size="icon" aria-label="Edit room type">
              <Pencil className="size-3.5" />
            </Button>
          }
        />
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Remove room type">
              <Trash2 className="size-3.5 text-destructive" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Remove this room type?</AlertDialogTitle>
              <AlertDialogDescription>
                {"\""}
                {room.name}
                {"\""}
                will be permanently removed from this hotel.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleRemove}>
                Remove
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

export default function HotelDetailPage() {
  const { hotelId } = useParams<{ hotelId: string }>();
  const navigate = useNavigate();
  const data = useQuery(
    api.hotels.get,
    hotelId ? { id: hotelId as Id<"hotels"> } : "skip",
  );
  const setStatus = useMutation(api.hotels.setStatus);
  const remove = useMutation(api.hotels.remove);

  if (data === undefined) {
    return (
      <div className="mx-auto max-w-5xl space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  if (data === null) {
    return (
      <div className="mx-auto max-w-xl py-10">
        <ErrorState>
          <ErrorStateHeader>
            <ErrorStateMedia variant="icon">
              <BedDouble />
            </ErrorStateMedia>
            <ErrorStateTitle>Hotel not found</ErrorStateTitle>
            <ErrorStateDescription>
              This hotel may have been deleted.
            </ErrorStateDescription>
          </ErrorStateHeader>
        </ErrorState>
      </div>
    );
  }

  const { hotel, roomTypes } = data;

  const handleStatus = async (value: string) => {
    try {
      await setStatus({ id: hotel._id, status: value as HotelStatus });
      toast.success("Status updated");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update status.";
      toast.error(message);
    }
  };

  const handleDelete = async () => {
    try {
      await remove({ id: hotel._id });
      toast.success("Hotel deleted");
      navigate("/hotels");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not delete the hotel.";
      toast.error(message);
    }
  };

  return (
    <div className="mx-auto max-w-5xl">
      <Link
        to="/hotels"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" />
        All hotels
      </Link>

      <PageHeader
        eyebrow={`${hotel.city}, ${hotel.country} · ${hotelCategoryLabel(hotel.category)}`}
        title={hotel.name}
        description={hotel.address ?? ""}
        actions={
          <>
            <Select value={hotel.status} onValueChange={handleStatus}>
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {HOTEL_STATUS_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <HotelFormDialog
              hotel={hotel}
              trigger={
                <Button variant="secondary">
                  <Pencil className="size-4" />
                  Edit
                </Button>
              }
            />
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Delete hotel">
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this hotel?</AlertDialogTitle>
                  <AlertDialogDescription>
                    {hotel.name} and all its room types will be permanently
                    removed. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete}>
                    Delete hotel
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </>
        }
      />

      {/* Status badge */}
      <div className="mb-6">
        <span
          className={cn(
            "inline-block rounded-full px-3 py-1 text-xs font-medium",
            HOTEL_STATUS_STYLES[hotel.status],
          )}
        >
          {hotelStatusLabel(hotel.status)}
        </span>
      </div>

      {/* Image gallery */}
      {hotel.imageUrls.length > 0 ? (
        <div
          className={cn(
            "mb-6 grid gap-2 overflow-hidden rounded-xl",
            hotel.imageUrls.length === 1
              ? "grid-cols-1"
              : "grid-cols-2 sm:grid-cols-3",
          )}
        >
          {hotel.imageUrls.slice(0, 3).map((url, i) => (
            <img
              key={i}
              src={url}
              alt={`${hotel.name} ${i + 1}`}
              className={cn(
                "w-full object-cover",
                i === 0 && hotel.imageUrls.length > 1
                  ? "col-span-2 row-span-1 h-56 sm:col-span-1 sm:h-64"
                  : "h-36 sm:h-64",
              )}
              onError={(e) => {
                e.currentTarget.parentElement?.removeChild(e.currentTarget);
              }}
            />
          ))}
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Location & contact */}
        <Card>
          <CardHeader>
            <CardTitle className="font-display text-base">
              Location &amp; contact
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <DetailRow
              icon={MapPin}
              label="Location"
              value={`${hotel.city}, ${hotel.country}`}
            />
            {hotel.address ? (
              <DetailRow
                icon={Building2}
                label="Address"
                value={hotel.address}
              />
            ) : null}
            {hotel.website ? (
              <DetailRow
                icon={Globe}
                label="Website"
                value={hotel.website}
                href={hotel.website}
              />
            ) : null}
            {hotel.contactName ? (
              <DetailRow icon={User} label="Sales contact" value={hotel.contactName} />
            ) : null}
            {hotel.contactEmail ? (
              <DetailRow
                icon={Mail}
                label="Email"
                value={hotel.contactEmail}
                href={`mailto:${hotel.contactEmail}`}
              />
            ) : null}
            {hotel.contactPhone ? (
              <DetailRow icon={Phone} label="Phone" value={hotel.contactPhone} />
            ) : null}
          </CardContent>
        </Card>

        {/* Property details */}
        <Card>
          <CardHeader>
            <CardTitle className="font-display text-base">
              Property details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <DetailRow
              icon={Star}
              label="Category"
              value={hotelCategoryLabel(hotel.category)}
            />
            {hotel.totalRooms !== undefined ? (
              <DetailRow
                icon={BedDouble}
                label="Total rooms"
                value={String(hotel.totalRooms)}
              />
            ) : null}
            {hotel.meetingRooms !== undefined ? (
              <DetailRow
                icon={Users}
                label="Meeting rooms"
                value={String(hotel.meetingRooms)}
              />
            ) : null}
            {hotel.largestMeetingCapacity !== undefined ? (
              <DetailRow
                icon={Users}
                label="Largest capacity"
                value={`${hotel.largestMeetingCapacity} pax`}
              />
            ) : null}
            {hotel.amenities.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {hotel.amenities.map((a) => (
                  <span
                    key={a}
                    className="rounded-full bg-secondary px-2 py-0.5 text-xs text-secondary-foreground"
                  >
                    {a}
                  </span>
                ))}
              </div>
            ) : null}
            {hotel.notes ? (
              <div className="rounded-md bg-muted/60 p-3 text-sm whitespace-pre-wrap">
                {hotel.notes}
              </div>
            ) : null}
          </CardContent>
        </Card>

        {/* Room types */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle className="font-display text-base">Room types</CardTitle>
            <RoomTypeFormDialog
              hotelId={hotel._id}
              trigger={
                <Button variant="secondary" size="sm">
                  <Plus className="size-4" />
                  Add room type
                </Button>
              }
            />
          </CardHeader>
          <CardContent>
            {roomTypes.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <BedDouble />
                  </EmptyMedia>
                  <EmptyTitle>No room types yet</EmptyTitle>
                  <EmptyDescription>
                    Add room types and indicative rates for this property.
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <RoomTypeFormDialog
                    hotelId={hotel._id}
                    trigger={
                      <Button size="sm">
                        <Plus className="size-4" />
                        Add room type
                      </Button>
                    }
                  />
                </EmptyContent>
              </Empty>
            ) : (
              <div className="space-y-2">
                {roomTypes.map((room) => (
                  <RoomTypeRow
                    key={room._id}
                    room={room}
                    hotelId={hotel._id}
                    currency={hotel.currency}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
