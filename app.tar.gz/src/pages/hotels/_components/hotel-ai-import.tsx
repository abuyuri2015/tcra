/**
 * AI import panel for Hotels page.
 * Handles both single-hotel and multi-hotel extraction.
 */
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import AiImportDialog, { PreviewCard, PreviewField } from "@/components/ai-import-dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";

type RoomType = {
  name: string;
  occupancy: number;
  board: string;
  nightlyRate?: number;
  notes?: string;
};

type HotelData = {
  name: string;
  category: string;
  status: string;
  city: string;
  country: string;
  address?: string;
  website?: string;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
  totalRooms?: number;
  meetingRooms?: number;
  largestMeetingCapacity?: number;
  currency: string;
  imageUrls?: string[];
  amenities: string[];
  notes?: string;
  roomTypes: RoomType[];
};

function HotelsPreview({ hotels }: { hotels: HotelData[] }) {
  if (!hotels || hotels.length === 0) {
    return <p className="px-4 py-4 text-sm text-muted-foreground">No hotels extracted.</p>;
  }
  return (
    <>
      {hotels.map((h, i) => (
        <PreviewCard
          key={i}
          title={h.name || "Unnamed hotel"}
          subtitle={`${h.city}, ${h.country} · ${h.category}`}
          defaultOpen={hotels.length === 1}
        >
          <PreviewField label="Category" value={h.category} />
          <PreviewField label="Status" value={h.status} />
          <PreviewField label="City" value={h.city} />
          <PreviewField label="Country" value={h.country} />
          <PreviewField label="Address" value={h.address} />
          <PreviewField label="Website" value={h.website} />
          <PreviewField label="Contact" value={h.contactName} />
          <PreviewField label="Email" value={h.contactEmail} />
          <PreviewField label="Phone" value={h.contactPhone} />
          <PreviewField label="Total rooms" value={h.totalRooms} />
          <PreviewField label="Meeting rooms" value={h.meetingRooms} />
          <PreviewField label="Currency" value={h.currency} />
          {h.amenities?.length > 0 && (
            <div className="col-span-full flex flex-wrap gap-1">
              {h.amenities.map((a) => (
                <Badge key={a} variant="secondary" className="text-[10px]">
                  {a}
                </Badge>
              ))}
            </div>
          )}
          <PreviewField label="Notes" value={h.notes} />
          {h.roomTypes?.length > 0 && (
            <div className="col-span-full space-y-1">
              <span className="text-[10px] uppercase tracking-wider font-medium text-muted-foreground">
                Room types ({h.roomTypes.length})
              </span>
              {h.roomTypes.map((rt, j) => (
                <div key={j} className="rounded border bg-background px-3 py-2 text-xs space-y-0.5">
                  <p className="font-medium">{rt.name}</p>
                  <p className="text-muted-foreground">
                    {rt.occupancy} guest{rt.occupancy !== 1 ? "s" : ""} · {rt.board}
                    {rt.nightlyRate ? ` · ${h.currency} ${rt.nightlyRate}/night` : ""}
                  </p>
                </div>
              ))}
            </div>
          )}
        </PreviewCard>
      ))}
    </>
  );
}

export default function HotelAiImport() {
  const bulkCreate = useMutation(api.hotels.bulkCreate);

  const handleImport = async (data: HotelData | HotelData[]) => {
    const hotels = Array.isArray(data) ? data : [data];
    if (hotels.length === 0) {
      toast.error("No hotels to import.");
      return;
    }
    const validCategories = [
      "5-star-luxury",
      "5-star",
      "4-star-superior",
      "4-star",
      "3-star",
      "boutique",
      "resort",
      "apartment",
      "venue",
    ] as const;
    const validStatuses = ["preferred", "active", "archived"] as const;
    const validBoards = [
      "room-only",
      "breakfast",
      "half-board",
      "full-board",
      "all-inclusive",
    ] as const;
    const validCurrencies = ["EUR", "USD", "GBP", "CHF", "AED", "SEK", "NOK", "DKK"] as const;
    type HotelCategory = (typeof validCategories)[number];
    type HotelStatus = (typeof validStatuses)[number];
    type BoardType = (typeof validBoards)[number];
    type Currency = (typeof validCurrencies)[number];

    const sanitised = hotels.map((h) => ({
      ...h,
      imageUrls: h.imageUrls ?? [],
      amenities: h.amenities ?? [],
      category: (validCategories.includes(h.category as HotelCategory)
        ? h.category
        : "4-star") as HotelCategory,
      status: (validStatuses.includes(h.status as HotelStatus)
        ? h.status
        : "active") as HotelStatus,
      currency: (validCurrencies.includes(h.currency as Currency)
        ? h.currency
        : "EUR") as Currency,
      roomTypes: (h.roomTypes ?? []).map((rt) => ({
        ...rt,
        board: (validBoards.includes(rt.board as BoardType)
          ? rt.board
          : "room-only") as BoardType,
      })),
    }));
    const result = await bulkCreate({ hotels: sanitised });
    if (result.imported === 0 && result.skipped > 0) {
      toast.info(`All ${result.skipped} hotel(s) already exist — nothing imported.`);
    } else {
      toast.success(
        `Imported ${result.imported} hotel${result.imported !== 1 ? "s" : ""}` +
          (result.skipped > 0 ? ` (${result.skipped} skipped — already exist)` : ""),
      );
    }
  };

  return (
    <AiImportDialog
      type="hotels"
      title="Import hotels with AI"
      placeholder={`Paste hotel info — one or many:

The Hotel Arts Barcelona is a 5-star hotel located at Carrer de la Marina 19-21, Barcelona, Spain.
Contact: Maria López · groups@hotelarts.es · +34 93 221 1000
483 rooms, 12 meeting rooms (max 500 pax). Amenities: pool, spa, gym, restaurant, bar.
Room types: Superior (2 guests, breakfast, €220/night), Junior Suite (2 guests, half-board, €380/night)`}
      onImport={async (data) => handleImport(data as HotelData | HotelData[])}
      renderPreview={(data) => (
        <HotelsPreview hotels={Array.isArray(data) ? (data as HotelData[]) : [(data as HotelData)]} />
      )}
    />
  );
}
