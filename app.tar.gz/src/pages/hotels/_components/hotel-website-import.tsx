/**
 * Import a single hotel by pulling its public website and letting AI extract
 * structured details (name, contact info, amenities, room types, images).
 */
import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { Globe, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { PreviewField } from "@/components/ai-import-dialog.tsx";
import {
  BOARD_OPTIONS,
  CURRENCY_OPTIONS,
  HOTEL_CATEGORY_OPTIONS,
  HOTEL_STATUS_OPTIONS,
} from "@/lib/domain.ts";
import type { BoardType, Currency, HotelCategory, HotelStatus } from "@/lib/domain.ts";

type RoomType = {
  name: string;
  occupancy: number;
  board: BoardType;
  nightlyRate?: number;
  notes?: string;
};

type HotelData = {
  name: string;
  category: HotelCategory;
  status: HotelStatus;
  city: string;
  country: string;
  address?: string;
  website?: string;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
  totalRooms?: number;
  meetingRooms?: number;
  largestMeetingCapacity?: number;
  currency: Currency;
  imageUrls: string[];
  amenities: string[];
  notes?: string;
  roomTypes: RoomType[];
};

const validCategories: string[] = HOTEL_CATEGORY_OPTIONS.map((o) => o.value);
const validStatuses: string[] = HOTEL_STATUS_OPTIONS.map((o) => o.value);
const validBoards: string[] = BOARD_OPTIONS.map((o) => o.value);

type Step = "input" | "loading" | "preview" | "saving";

export default function HotelWebsiteImport() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("input");
  const [url, setUrl] = useState("");
  const [data, setData] = useState<HotelData | null>(null);

  const extractFromUrl = useAction(api.ai.extract.extractHotelFromUrl);
  const bulkCreate = useMutation(api.hotels.bulkCreate);

  const handleOpen = () => {
    setStep("input");
    setUrl("");
    setData(null);
    setOpen(true);
  };

  const handleFetch = async () => {
    const trimmed = url.trim();
    if (!trimmed) return;
    const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    setStep("loading");
    try {
      const result = await extractFromUrl({ url: withProtocol });
      const hotel = result.data;
      setData({
        ...hotel,
        status: (validStatuses.includes(hotel.status) ? hotel.status : "active") as HotelStatus,
        category: (validCategories.includes(hotel.category)
          ? hotel.category
          : "4-star") as HotelCategory,
        currency: ((CURRENCY_OPTIONS as readonly string[]).includes(hotel.currency)
          ? hotel.currency
          : "EUR") as Currency,
        imageUrls: hotel.imageUrls ?? [],
        amenities: hotel.amenities ?? [],
        roomTypes: (hotel.roomTypes ?? []).map((rt) => ({
          ...rt,
          board: (validBoards.includes(rt.board) ? rt.board : "room-only") as BoardType,
        })),
      });
      setStep("preview");
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Couldn't import that website. Please try again.";
      toast.error(msg);
      setStep("input");
    }
  };

  const handleConfirm = async () => {
    if (!data) return;
    setStep("saving");
    try {
      const { roomTypes, ...hotel } = data;
      const result = await bulkCreate({ hotels: [{ ...hotel, roomTypes }] });
      if (result.imported === 0) {
        toast.info("A hotel with that name already exists — nothing imported.");
      } else {
        toast.success(`Imported ${data.name}`);
      }
      setOpen(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Import failed. Please try again.";
      toast.error(msg);
      setStep("preview");
    }
  };

  return (
    <>
      <Button variant="secondary" onClick={handleOpen}>
        <Globe className="size-4" />
        Import from website
      </Button>

      <Dialog open={open} onOpenChange={(v) => { if (!v) setOpen(false); }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display flex items-center gap-2">
              <Globe className="size-4 text-primary" />
              Import hotel from website
            </DialogTitle>
          </DialogHeader>

          {step === "input" && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Paste the hotel's website address. AI will read the page and pull out its
                  details, amenities, room types and cover image automatically.
                </p>
                <Input
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://www.hotelarts.es"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleFetch();
                    }
                  }}
                />
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleFetch} disabled={!url.trim()}>
                  <Sparkles className="size-4" />
                  Fetch & extract
                </Button>
              </DialogFooter>
            </>
          )}

          {step === "loading" && (
            <div className="flex flex-col items-center justify-center gap-3 py-12">
              <Loader2 className="size-6 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">
                Reading the website and extracting hotel details…
              </p>
            </div>
          )}

          {step === "preview" && data && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Review the extracted details below. Click <strong>Confirm import</strong> to
                  save this hotel, or go back to try a different link.
                </p>
                <div className="rounded-lg border bg-muted/30 overflow-hidden">
                  {data.imageUrls.length > 0 && (
                    <div
                      className={
                        data.imageUrls.length === 1
                          ? "grid grid-cols-1"
                          : "grid grid-cols-3 gap-0.5"
                      }
                    >
                      {data.imageUrls.slice(0, 5).map((imgUrl, i) => (
                        <img
                          key={imgUrl}
                          src={imgUrl}
                          alt={`${data.name} ${i + 1}`}
                          className={
                            data.imageUrls.length === 1
                              ? "h-40 w-full object-cover"
                              : i === 0
                                ? "col-span-3 h-28 w-full object-cover sm:col-span-1 sm:row-span-2 sm:h-full"
                                : "h-14 w-full object-cover sm:h-full"
                          }
                          onError={(e) => {
                            e.currentTarget.style.display = "none";
                          }}
                        />
                      ))}
                    </div>
                  )}
                  <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 px-4 py-4">
                    <PreviewField label="Name" value={data.name} />
                    <PreviewField label="Category" value={data.category} />
                    <PreviewField label="City" value={data.city} />
                    <PreviewField label="Country" value={data.country} />
                    <PreviewField label="Address" value={data.address} />
                    <PreviewField label="Website" value={data.website} />
                    <PreviewField label="Contact" value={data.contactName} />
                    <PreviewField label="Email" value={data.contactEmail} />
                    <PreviewField label="Phone" value={data.contactPhone} />
                    <PreviewField label="Total rooms" value={data.totalRooms} />
                    <PreviewField label="Meeting rooms" value={data.meetingRooms} />
                    <PreviewField label="Currency" value={data.currency} />
                    {data.amenities.length > 0 && (
                      <div className="col-span-full flex flex-wrap gap-1">
                        {data.amenities.map((a) => (
                          <Badge key={a} variant="secondary" className="text-[10px]">
                            {a}
                          </Badge>
                        ))}
                      </div>
                    )}
                    <PreviewField label="Notes" value={data.notes} />
                    {data.roomTypes.length > 0 && (
                      <div className="col-span-full space-y-1">
                        <span className="text-[10px] uppercase tracking-wider font-medium text-muted-foreground">
                          Room types ({data.roomTypes.length})
                        </span>
                        {data.roomTypes.map((rt, j) => (
                          <div
                            key={j}
                            className="rounded border bg-background px-3 py-2 text-xs space-y-0.5"
                          >
                            <p className="font-medium">{rt.name}</p>
                            <p className="text-muted-foreground">
                              {rt.occupancy} guest{rt.occupancy !== 1 ? "s" : ""} · {rt.board}
                              {rt.nightlyRate ? ` · ${data.currency} ${rt.nightlyRate}/night` : ""}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setStep("input")}>
                  Back
                </Button>
                <Button onClick={handleConfirm}>Confirm import</Button>
              </DialogFooter>
            </>
          )}

          {step === "saving" && (
            <div className="flex items-center justify-center py-12 gap-3">
              <Loader2 className="size-5 animate-spin text-primary" />
              <span className="text-sm text-muted-foreground">Saving…</span>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
