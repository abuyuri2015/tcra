import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { BOARD_OPTIONS } from "@/lib/domain.ts";
import type { ReactNode } from "react";

const schema = z.object({
  name: z.string().min(2, "Room name is required"),
  occupancy: z
    .string()
    .refine((v) => Number.isInteger(Number(v)) && Number(v) >= 1, {
      message: "At least 1 guest",
    }),
  board: z.enum([
    "room-only",
    "breakfast",
    "half-board",
    "full-board",
    "all-inclusive",
  ]),
  nightlyRate: z
    .string()
    .refine((v) => v === "" || Number(v) >= 0, {
      message: "Enter a positive rate",
    }),
  notes: z.string(),
});

type FormValues = z.output<typeof schema>;

function defaultsFor(room?: Doc<"hotelRoomTypes">): FormValues {
  if (!room) {
    return {
      name: "",
      occupancy: "2",
      board: "breakfast",
      nightlyRate: "",
      notes: "",
    };
  }
  return {
    name: room.name,
    occupancy: String(room.occupancy),
    board: room.board,
    nightlyRate: room.nightlyRate === undefined ? "" : String(room.nightlyRate),
    notes: room.notes ?? "",
  };
}

export default function RoomTypeFormDialog({
  hotelId,
  room,
  trigger,
}: {
  hotelId: Id<"hotels">;
  room?: Doc<"hotelRoomTypes">;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const add = useMutation(api.hotels.addRoomType);
  const update = useMutation(api.hotels.updateRoomType);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFor(room),
  });

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) form.reset(defaultsFor(room));
  };

  const onSubmit = async (values: FormValues) => {
    const payload = {
      name: values.name.trim(),
      occupancy: Number(values.occupancy),
      board: values.board,
      nightlyRate:
        values.nightlyRate.trim() === ""
          ? undefined
          : Number(values.nightlyRate),
      notes: values.notes.trim() || undefined,
    };
    try {
      if (room) {
        await update({ id: room._id, ...payload });
        toast.success("Room type updated");
      } else {
        await add({ hotelId, ...payload });
        toast.success("Room type added");
      }
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save. Please try again.";
      toast.error(message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">
            {room ? "Edit room type" : "Add room type"}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Room type</FormLabel>
                  <FormControl>
                    <Input placeholder="Superior double" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="occupancy"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Occupancy</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="board"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Board basis</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {BOARD_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="nightlyRate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nightly rate</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                {room ? "Save changes" : "Add room type"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
