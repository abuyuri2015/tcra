import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  CURRENCY_OPTIONS,
  HOTEL_CATEGORY_OPTIONS,
  HOTEL_STATUS_OPTIONS,
} from "@/lib/domain.ts";
import type { ReactNode } from "react";

const optionalCount = z.string().refine(
  (v) => v === "" || (Number.isInteger(Number(v)) && Number(v) >= 0),
  { message: "Enter a whole number" },
);

const schema = z.object({
  name: z.string().min(2, "Hotel name is required"),
  category: z.enum([
    "5-star-luxury",
    "5-star",
    "4-star-superior",
    "4-star",
    "3-star",
    "boutique",
    "resort",
    "apartment",
    "venue",
  ]),
  status: z.enum(["preferred", "active", "archived"]),
  city: z.string().min(2, "City is required"),
  country: z.string().min(2, "Country is required"),
  address: z.string(),
  website: z.string(),
  contactName: z.string(),
  contactEmail: z
    .string()
    .refine((v) => v === "" || z.string().email().safeParse(v).success, {
      message: "Enter a valid email",
    }),
  contactPhone: z.string(),
  totalRooms: optionalCount,
  meetingRooms: optionalCount,
  largestMeetingCapacity: optionalCount,
  currency: z.enum(CURRENCY_OPTIONS),
  imageUrls: z.string(),
  amenities: z.string(),
  notes: z.string(),
});

type FormValues = z.output<typeof schema>;

/** Splits a comma or newline separated textarea value into clean entries. */
function splitList(value: string): string[] {
  return value
    .split(/[\n,]/)
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
}

function numberOrUndefined(value: string): number | undefined {
  const trimmed = value.trim();
  return trimmed === "" ? undefined : Number(trimmed);
}

function defaultsFor(hotel?: Doc<"hotels">): FormValues {
  if (!hotel) {
    return {
      name: "",
      category: "4-star",
      status: "active",
      city: "",
      country: "",
      address: "",
      website: "",
      contactName: "",
      contactEmail: "",
      contactPhone: "",
      totalRooms: "",
      meetingRooms: "",
      largestMeetingCapacity: "",
      currency: "EUR",
      imageUrls: "",
      amenities: "",
      notes: "",
    };
  }

  return {
    name: hotel.name,
    category: hotel.category,
    status: hotel.status,
    city: hotel.city,
    country: hotel.country,
    address: hotel.address ?? "",
    website: hotel.website ?? "",
    contactName: hotel.contactName ?? "",
    contactEmail: hotel.contactEmail ?? "",
    contactPhone: hotel.contactPhone ?? "",
    totalRooms: hotel.totalRooms === undefined ? "" : String(hotel.totalRooms),
    meetingRooms:
      hotel.meetingRooms === undefined ? "" : String(hotel.meetingRooms),
    largestMeetingCapacity:
      hotel.largestMeetingCapacity === undefined
        ? ""
        : String(hotel.largestMeetingCapacity),
    currency: hotel.currency,
    imageUrls: hotel.imageUrls.join("\n"),
    amenities: hotel.amenities.join(", "),
    notes: hotel.notes ?? "",
  };
}

export default function HotelFormDialog({
  hotel,
  trigger,
}: {
  hotel?: Doc<"hotels">;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const create = useMutation(api.hotels.create);
  const update = useMutation(api.hotels.update);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFor(hotel),
  });

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) form.reset(defaultsFor(hotel));
  };

  const onSubmit = async (values: FormValues) => {
    const payload = {
      name: values.name.trim(),
      category: values.category,
      status: values.status,
      city: values.city.trim(),
      country: values.country.trim(),
      address: values.address.trim() || undefined,
      website: values.website.trim() || undefined,
      contactName: values.contactName.trim() || undefined,
      contactEmail: values.contactEmail.trim() || undefined,
      contactPhone: values.contactPhone.trim() || undefined,
      totalRooms: numberOrUndefined(values.totalRooms),
      meetingRooms: numberOrUndefined(values.meetingRooms),
      largestMeetingCapacity: numberOrUndefined(values.largestMeetingCapacity),
      currency: values.currency,
      imageUrls: splitList(values.imageUrls),
      amenities: splitList(values.amenities),
      notes: values.notes.trim() || undefined,
    };
    try {
      if (hotel) {
        await update({ id: hotel._id, ...payload });
        toast.success("Hotel updated");
      } else {
        await create(payload);
        toast.success("Hotel added");
      }
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save the hotel. Please try again.";
      toast.error(message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display">
            {hotel ? "Edit hotel" : "Add hotel"}
          </DialogTitle>
          <DialogDescription>
            Your own contracted properties and venues.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Hotel name</FormLabel>
                  <FormControl>
                    <Input placeholder="Hotel Arts Barcelona" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {HOTEL_CATEGORY_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {HOTEL_STATUS_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <FormControl>
                    <Input placeholder="Barcelona" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="country"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Country</FormLabel>
                  <FormControl>
                    <Input placeholder="Spain" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Address</FormLabel>
                  <FormControl>
                    <Input placeholder="Carrer de la Marina 19" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="website"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Website</FormLabel>
                  <FormControl>
                    <Input placeholder="https://example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="contactName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Sales contact</FormLabel>
                  <FormControl>
                    <Input placeholder="John Smith" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="contactEmail"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact email</FormLabel>
                  <FormControl>
                    <Input placeholder="example@gmail.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="contactPhone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact phone</FormLabel>
                  <FormControl>
                    <Input placeholder="+34 600 000 000" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rate currency</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {CURRENCY_OPTIONS.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="totalRooms"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Total rooms</FormLabel>
                  <FormControl>
                    <Input type="number" min={0} placeholder="450" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="meetingRooms"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Meeting rooms</FormLabel>
                  <FormControl>
                    <Input type="number" min={0} placeholder="12" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="largestMeetingCapacity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Largest capacity</FormLabel>
                  <FormControl>
                    <Input type="number" min={0} placeholder="800" {...field} />
                  </FormControl>
                  <FormDescription>Guests in the biggest room</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amenities"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Amenities</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Spa, Rooftop pool, Beachfront"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>Separate with commas</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="imageUrls"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Image links</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="https://example.com/lobby.jpg"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>One link per line</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="Contracted rates, release periods, group policies"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                {hotel ? "Save changes" : "Add hotel"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
