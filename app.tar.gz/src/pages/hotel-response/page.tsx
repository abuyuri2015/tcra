import { useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import {
  Building2,
  CalendarDays,
  CheckCircle2,
  Loader2,
  MapPin,
  XCircle,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { toast } from "sonner";
import { formatDate } from "@/lib/dates.ts";

export default function HotelResponsePage() {
  const { requestId } = useParams<{ requestId: string }>();
  const [searchParams] = useSearchParams();
  const preselected = searchParams.get("decision");

  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState<"approved" | "declined" | null>(null);

  const data = useQuery(
    api.modificationRequests.getPublicForResponse,
    requestId ? { requestId: requestId as Id<"modificationRequests"> } : "skip",
  );
  const respond = useMutation(api.modificationRequests.respondPublic);

  if (data === undefined) {
    return (
      <div className="mx-auto max-w-xl px-4 py-12 space-y-4">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4">
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            This request could not be found.
          </CardContent>
        </Card>
      </div>
    );
  }

  const { request, fileTitle, fileReference, destination } = data;
  const alreadyResponded =
    request.status === "approved" || request.status === "declined";

  const handleRespond = async (decision: "approved" | "declined") => {
    setSubmitting(decision);
    try {
      await respond({
        requestId: request._id,
        decision,
        responseNote: note.trim() || undefined,
      });
      toast.success(
        decision === "approved" ? "Change approved" : "Change declined",
      );
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not submit your response.";
      toast.error(message);
    } finally {
      setSubmitting(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-sidebar text-sidebar-foreground">
        <div className="mx-auto max-w-xl px-4 py-10">
          <div className="mb-2 flex items-center gap-2">
            <Building2 className="size-5 text-sidebar-primary" />
            <p className="text-xs font-medium uppercase tracking-widest opacity-70">
              Change requested
            </p>
          </div>
          <h1 className="font-display text-2xl font-bold">{fileTitle}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-4 text-sm opacity-80">
            <span className="flex items-center gap-1.5">
              <MapPin className="size-4" />
              {destination}
            </span>
            <span className="flex items-center gap-1.5">
              <CalendarDays className="size-4" />
              {fileReference}
            </span>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-xl px-4 py-10 space-y-6">
        <Card>
          <CardContent className="space-y-1 py-5">
            <p className="text-sm font-semibold">{request.supplierName}</p>
            <p className="text-sm text-muted-foreground">
              {request.reservationDescription}
            </p>
            <div className="mt-3 rounded-lg bg-muted px-4 py-3">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-1">
                Requested change
              </p>
              <p className="text-sm whitespace-pre-line">{request.message}</p>
            </div>
          </CardContent>
        </Card>

        {alreadyResponded ? (
          <Card>
            <CardContent className="flex items-center gap-3 py-6">
              {request.status === "approved" ? (
                <CheckCircle2 className="size-6 text-chart-3" />
              ) : (
                <XCircle className="size-6 text-destructive" />
              )}
              <div>
                <p className="text-sm font-medium">
                  This request was already{" "}
                  {request.status === "approved" ? "approved" : "declined"}
                </p>
                {request.respondedAt ? (
                  <p className="text-xs text-muted-foreground">
                    Responded on {formatDate(request.respondedAt)}
                  </p>
                ) : null}
                {request.responseNote ? (
                  <p className="mt-2 text-sm">{request.responseNote}</p>
                ) : null}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="space-y-4 py-5">
              {request.kind === "units" ? (
                <p className="rounded-lg bg-primary/5 px-3 py-2 text-xs text-muted-foreground">
                  Approving will automatically update the booking to the new
                  quantity and adjust the cost.
                </p>
              ) : null}
              <div>
                <p className="mb-1.5 text-sm font-medium">
                  Add a note (optional)
                </p>
                <Textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Any additional details for our team…"
                  rows={3}
                />
              </div>
              <div className="flex flex-wrap gap-3">
                <Button
                  className="flex-1 bg-chart-3 text-white hover:bg-chart-3/90"
                  disabled={submitting !== null}
                  onClick={() => handleRespond("approved")}
                >
                  {submitting === "approved" ? (
                    <Loader2 className="size-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="size-4" />
                  )}
                  Approve change
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1"
                  disabled={submitting !== null}
                  onClick={() => handleRespond("declined")}
                >
                  {submitting === "declined" ? (
                    <Loader2 className="size-4 animate-spin" />
                  ) : (
                    <XCircle className="size-4" />
                  )}
                  Decline change
                </Button>
              </div>
              {preselected && (
                <p className="text-center text-xs text-muted-foreground">
                  Confirm your decision above to submit your response.
                </p>
              )}
            </CardContent>
          </Card>
        )}

        <footer className="border-t pt-6 text-center text-xs text-muted-foreground">
          Tessera Groups &amp; MICE
        </footer>
      </div>
    </div>
  );
}
