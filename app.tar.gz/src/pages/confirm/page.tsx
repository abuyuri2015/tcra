import { useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import {
  BedDouble,
  Building,
  Bus,
  CalendarDays,
  CheckCircle2,
  Clock,
  Loader2,
  MapPin,
  MessageSquarePlus,
  Package,
  Plane,
  Sunset,
  Users,
  UtensilsCrossed,
  XCircle,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { cn } from "@/lib/utils.ts";
import { formatDate, formatDateRange } from "@/lib/dates.ts";
import {
  boardLabel,
  formatMoney,
  reservationStatusLabel,
  reservationTypeLabel,
} from "@/lib/domain.ts";
import type { ReservationType } from "@/lib/domain.ts";

const TYPE_ICONS: Record<ReservationType, typeof BedDouble> = {
  hotel: BedDouble,
  transfer: Bus,
  restaurant: UtensilsCrossed,
  activity: Sunset,
  venue: Building,
  flight: Plane,
  other: Package,
};

const STATUS_STYLES: Record<string, string> = {
  option: "bg-muted text-muted-foreground",
  requested: "bg-chart-4/15 text-chart-4",
  confirmed: "bg-chart-3/15 text-chart-3",
  cancelled: "bg-destructive/12 text-destructive",
};

const MOD_REQUEST_STYLES: Record<string, string> = {
  pending_hotel: "bg-chart-4/15 text-chart-4",
  no_hotel_contact: "bg-chart-4/15 text-chart-4",
  approved: "bg-chart-3/15 text-chart-3",
  declined: "bg-destructive/12 text-destructive",
};

const MOD_REQUEST_LABELS: Record<string, string> = {
  pending_hotel: "Change requested — awaiting hotel",
  no_hotel_contact: "Change requested — awaiting team",
  approved: "Change approved",
  declined: "Change declined",
};

type PublicReservation = {
  _id: Id<"reservations">;
  type: ReservationType;
  status: "option" | "requested" | "confirmed" | "cancelled";
  supplierName: string;
  description: string;
  startDate: string;
  endDate?: string;
  units: number;
  unitLabel?: string;
  board?: string;
  nights?: number;
  ratePerUnit?: number;
  currency: string;
};

type PublicModRequest = {
  _id: Id<"modificationRequests">;
  reservationId: Id<"reservations">;
  status: "pending_hotel" | "no_hotel_contact" | "approved" | "declined";
  message: string;
  createdAt: string;
};

function RequestChangeDialog({
  groupFileId,
  reservation,
}: {
  groupFileId: Id<"groupFiles">;
  reservation: PublicReservation;
}) {
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<"units" | "other">("units");
  const [requestedUnits, setRequestedUnits] = useState(String(reservation.units));
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const submit = useMutation(api.modificationRequests.submitPublic);

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      setKind("units");
      setRequestedUnits(String(reservation.units));
      setMessage("");
    }
  };

  const handleSubmit = async () => {
    if (kind === "other" && !message.trim()) {
      toast.error("Please describe the change you'd like to request.");
      return;
    }
    const unitsNum = Number(requestedUnits);
    if (kind === "units") {
      if (!Number.isInteger(unitsNum) || unitsNum < 0) {
        toast.error("Enter a valid number of rooms/units.");
        return;
      }
      if (unitsNum === reservation.units) {
        toast.error("That's already the currently booked quantity.");
        return;
      }
    }
    setSubmitting(true);
    try {
      await submit({
        groupFileId,
        reservationId: reservation._id,
        kind,
        requestedUnits: kind === "units" ? unitsNum : undefined,
        message: message.trim(),
        appOrigin: window.location.origin,
      });
      toast.success("Your request has been sent.");
      setOpen(false);
    } catch (error) {
      const msg =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not submit your request.";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const unitLabel = reservation.unitLabel || (reservation.type === "hotel" ? "rooms" : "units");

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <Button variant="secondary" size="sm" onClick={() => setOpen(true)}>
        <MessageSquarePlus className="size-3.5" />
        Request a change
      </Button>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Request a change</DialogTitle>
          <DialogDescription>
            {reservation.supplierName} — {reservation.description}
          </DialogDescription>
        </DialogHeader>

        <Tabs value={kind} onValueChange={(v) => setKind(v as "units" | "other")}>
          <TabsList className="w-full">
            <TabsTrigger value="units" className="flex-1">
              Change {unitLabel}
            </TabsTrigger>
            <TabsTrigger value="other" className="flex-1">
              Other request
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {kind === "units" ? (
          <div className="space-y-3">
            <div>
              <p className="mb-1.5 text-sm font-medium">
                Requested number of {unitLabel}
              </p>
              <Input
                type="number"
                min={0}
                value={requestedUnits}
                onChange={(e) => setRequestedUnits(e.target.value)}
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Currently booked: {reservation.units} {unitLabel}
              </p>
            </div>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Any additional details (optional)…"
              rows={2}
            />
          </div>
        ) : (
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Describe the change you'd like, e.g. move to a later date, change room type…"
            rows={4}
            autoFocus
          />
        )}

        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)} disabled={submitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? <Loader2 className="size-4 animate-spin" /> : null}
            Send request
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ReservationRow({
  res,
  groupFileId,
  modRequests,
  locked,
}: {
  res: PublicReservation;
  groupFileId: Id<"groupFiles">;
  modRequests: PublicModRequest[];
  locked: boolean;
}) {
  const Icon = TYPE_ICONS[res.type] ?? Package;
  // Most recent request for this reservation, if any.
  const activeRequest = modRequests
    .filter((r) => r.reservationId === res._id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];
  const pendingRequest =
    activeRequest && (activeRequest.status === "pending_hotel" || activeRequest.status === "no_hotel_contact")
      ? activeRequest
      : undefined;

  const dateLabel = (() => {
    if (res.type === "hotel" && res.nights !== undefined) {
      return `${formatDate(res.startDate)} · ${res.nights} night${res.nights > 1 ? "s" : ""}`;
    }
    if (res.endDate) {
      return `${formatDate(res.startDate)} – ${formatDate(res.endDate)}`;
    }
    return formatDate(res.startDate);
  })();

  const unitLabel = res.unitLabel || (res.type === "hotel" ? "rooms" : "pax");
  const total = res.ratePerUnit !== undefined ? res.ratePerUnit * res.units : undefined;

  return (
    <div className="flex flex-wrap items-start justify-between gap-3 rounded-lg border px-4 py-3">
      <div className="flex min-w-0 gap-3">
        <div className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
          <Icon className="size-4 text-muted-foreground" />
        </div>
        <div className="min-w-0 space-y-0.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">{res.supplierName}</span>
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                STATUS_STYLES[res.status],
              )}
            >
              {reservationStatusLabel(res.status)}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">{res.description}</p>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
            <span>{dateLabel}</span>
            <span>
              {res.units} {unitLabel}
            </span>
            {res.board ? <span>{boardLabel(res.board)}</span> : null}
          </div>
          {activeRequest ? (
            <span
              className={cn(
                "mt-1 inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                MOD_REQUEST_STYLES[activeRequest.status],
              )}
            >
              {MOD_REQUEST_LABELS[activeRequest.status]}
            </span>
          ) : null}
        </div>
      </div>

      <div className="flex shrink-0 flex-col items-end gap-2">
        {total !== undefined ? (
          <div className="text-right">
            <p className="text-sm font-semibold">{formatMoney(total, res.currency)}</p>
            <p className="text-xs text-muted-foreground">
              {formatMoney(res.ratePerUnit!, res.currency)} × {res.units} {unitLabel}
            </p>
          </div>
        ) : null}
        {pendingRequest ? (
          <Button variant="secondary" size="sm" disabled>
            <Clock className="size-3.5" />
            Request pending
          </Button>
        ) : locked ? null : (
          <RequestChangeDialog groupFileId={groupFileId} reservation={res} />
        )}
      </div>
    </div>
  );
}

export default function ClientConfirmationPage() {
  const { fileId } = useParams<{ fileId: string }>();

  const file = useQuery(
    api.groupFiles.getPublic,
    fileId ? { id: fileId as Id<"groupFiles"> } : "skip",
  );
  const reservations = useQuery(
    api.reservations.listByFilePublic,
    fileId ? { groupFileId: fileId as Id<"groupFiles"> } : "skip",
  );
  const modRequests = useQuery(
    api.modificationRequests.listByFilePublic,
    fileId ? { groupFileId: fileId as Id<"groupFiles"> } : "skip",
  );

  if (file === undefined || reservations === undefined || modRequests === undefined) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-12 space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-6 w-40" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
    );
  }

  if (!file) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Confirmation not found.</p>
      </div>
    );
  }

  const order: ReservationType[] = [
    "hotel",
    "flight",
    "transfer",
    "venue",
    "restaurant",
    "activity",
    "other",
  ];
  const byType = order.reduce<Partial<Record<ReservationType, PublicReservation[]>>>(
    (acc, t) => {
      const items = reservations.filter((r) => r.type === t);
      if (items.length > 0) acc[t] = items as PublicReservation[];
      return acc;
    },
    {},
  );

  const confirmedCount = reservations.filter((r) => r.status === "confirmed").length;
  const allConfirmed = reservations.length > 0 && confirmedCount === reservations.length;

  // Grand total per currency across all active (non-cancelled) reservations —
  // shown so the client can see the full price, not just each line item.
  const totalsByCurrency = reservations
    .filter((r) => r.status !== "cancelled" && r.ratePerUnit !== undefined)
    .reduce<Record<string, number>>((acc, r) => {
      acc[r.currency] = (acc[r.currency] ?? 0) + r.ratePerUnit! * r.units;
      return acc;
    }, {});
  const totalCurrencies = Object.keys(totalsByCurrency);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-sidebar text-sidebar-foreground">
        <div className="mx-auto max-w-2xl px-4 py-10">
          <div className="mb-2 flex items-center gap-2">
            {allConfirmed ? (
              <CheckCircle2 className="size-5 text-sidebar-primary" />
            ) : (
              <Clock className="size-5 text-sidebar-primary" />
            )}
            <p className="text-xs font-medium uppercase tracking-widest opacity-70">
              {allConfirmed ? "Booking confirmed" : "Booking status"}
            </p>
          </div>
          <h1 className="font-display text-3xl font-bold">{file.title}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-4 text-sm opacity-80">
            <span className="flex items-center gap-1.5">
              <MapPin className="size-4" />
              {file.destination}
            </span>
            <span className="flex items-center gap-1.5">
              <CalendarDays className="size-4" />
              {formatDateRange(file.startDate, file.endDate)}
            </span>
            <span className="flex items-center gap-1.5">
              <Users className="size-4" />
              {file.pax} travellers
            </span>
          </div>
        </div>
      </div>

      {/* Reservations */}
      <div className="mx-auto max-w-2xl px-4 py-10 space-y-8">
        {reservations.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              <XCircle className="mx-auto mb-2 size-6 text-muted-foreground" />
              No booking details are available yet. Check back soon.
            </CardContent>
          </Card>
        ) : (
          (Object.entries(byType) as [ReservationType, PublicReservation[]][]).map(
            ([type, items]) => {
              const Icon = TYPE_ICONS[type] ?? Package;
              return (
                <div key={type}>
                  <div className="mb-2 flex items-center gap-2">
                    <Icon className="size-4 text-muted-foreground" />
                    <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                      {reservationTypeLabel(type)}
                    </h3>
                    <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                      {items.length}
                    </span>
                  </div>
                  <div className="space-y-2">
                    {items.map((res) => (
                      <ReservationRow
                        key={res._id}
                        res={res}
                        groupFileId={file._id}
                        modRequests={modRequests}
                        locked={file.financeLocked === true}
                      />
                    ))}
                  </div>
                </div>
              );
            },
          )
        )}

        {/* Total */}
        {totalCurrencies.length > 0 ? (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 py-4">
              <p className="text-sm font-medium">Total booking value</p>
              <div className="flex flex-wrap gap-4">
                {totalCurrencies.map((cur) => (
                  <span key={cur} className="font-display text-lg font-semibold">
                    {formatMoney(totalsByCurrency[cur], cur)}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : null}

        {/* Footer */}
        <footer className="border-t pt-8 text-center text-xs text-muted-foreground">
          <p>Prepared by {file.clientName ? `${file.clientName} · ` : ""}your travel team</p>
          <p className="mt-1">
            {file.financeLocked
              ? "This booking is fully settled. Contact your travel team for any further changes."
              : "Questions? Use \"Request a change\" on any item above, or reply to your confirmation email."}
          </p>
        </footer>
      </div>
    </div>
  );
}
