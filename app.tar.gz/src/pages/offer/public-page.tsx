import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import {
  BedDouble,
  Building,
  Bus,
  CalendarDays,
  Check,
  Loader2,
  MapPin,
  Minus,
  Package,
  Plane,
  Plus,
  Sunset,
  Users,
  UtensilsCrossed,
  XCircle,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { cn } from "@/lib/utils.ts";
import { formatDate, formatDateRange } from "@/lib/dates.ts";
import { boardLabel, formatMoney, reservationTypeLabel } from "@/lib/domain.ts";
import type { ReservationType } from "@/lib/domain.ts";

const TYPE_ICONS: Record<ReservationType, typeof BedDouble> = {
  hotel: BedDouble,
  transfer: Bus,
  restaurant: UtensilsCrossed,
  activity: Sunset,
  venue: Building,
  flight: Plane,
  other: Package,
};

type SelectionState = Record<string, { selected: boolean; units: number }>;

function OfferOptionCard({
  offer,
  fileCurrency,
  selected,
  units,
  onToggle,
  onUnitsChange,
}: {
  offer: Doc<"offers">;
  fileCurrency: string;
  selected: boolean;
  units: number;
  onToggle: () => void;
  onUnitsChange: (units: number) => void;
}) {
  const Icon = TYPE_ICONS[offer.type] ?? Package;
  const total = offer.ratePerUnit !== undefined ? offer.ratePerUnit * units : undefined;

  const dateLabel = (() => {
    if (offer.type === "hotel" && offer.nights !== undefined) {
      return `${formatDate(offer.startDate)} · ${offer.nights} night${offer.nights > 1 ? "s" : ""}`;
    }
    if (offer.endDate) {
      return `${formatDate(offer.startDate)} – ${formatDate(offer.endDate)}`;
    }
    return formatDate(offer.startDate);
  })();

  const unitLabel = offer.unitLabel || (offer.type === "hotel" ? "rooms" : "pax");

  return (
    <div
      className={cn(
        "rounded-lg border px-4 py-3 transition-colors",
        selected ? "border-primary bg-primary/5" : "border-border",
      )}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <button
          type="button"
          onClick={onToggle}
          className="flex min-w-0 flex-1 items-start gap-3 text-left"
        >
          <div
            className={cn(
              "mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md",
              selected ? "bg-primary text-primary-foreground" : "bg-muted",
            )}
          >
            {selected ? <Check className="size-4" /> : <Icon className="size-4 text-muted-foreground" />}
          </div>
          <div className="min-w-0 space-y-0.5">
            <span className="text-sm font-medium">{offer.supplierName}</span>
            <p className="text-sm text-muted-foreground">{offer.description}</p>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
              <span>{dateLabel}</span>
              <span>
                {offer.units} {unitLabel} offered
              </span>
              {offer.board ? <span>{boardLabel(offer.board)}</span> : null}
            </div>
            {offer.notes ? (
              <p className="text-xs text-muted-foreground italic">{offer.notes}</p>
            ) : null}
          </div>
        </button>

        {total !== undefined ? (
          <div className="shrink-0 text-right">
            <p className="text-sm font-semibold">{formatMoney(total, fileCurrency)}</p>
            <p className="text-xs text-muted-foreground">
              {formatMoney(offer.ratePerUnit!, fileCurrency)} ×{units}
            </p>
          </div>
        ) : null}
      </div>

      {selected ? (
        <div className="mt-3 flex items-center gap-2 border-t pt-3">
          <span className="text-xs text-muted-foreground">Requested {unitLabel}:</span>
          <Button
            type="button"
            variant="secondary"
            size="icon"
            className="size-6"
            onClick={() => onUnitsChange(Math.max(1, units - 1))}
          >
            <Minus className="size-3" />
          </Button>
          <span className="w-6 text-center text-sm font-medium">{units}</span>
          <Button
            type="button"
            variant="secondary"
            size="icon"
            className="size-6"
            onClick={() => onUnitsChange(units + 1)}
          >
            <Plus className="size-3" />
          </Button>
        </div>
      ) : null}
    </div>
  );
}

export default function ClientOfferPage() {
  const { fileId } = useParams<{ fileId: string }>();
  const [selection, setSelection] = useState<SelectionState>({});
  const [clientNote, setClientNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const file = useQuery(
    api.groupFiles.getPublic,
    fileId ? { id: fileId as Id<"groupFiles"> } : "skip",
  );
  const offers = useQuery(
    api.offerSelections.listOffersPublic,
    fileId ? { groupFileId: fileId as Id<"groupFiles"> } : "skip",
  );
  const submit = useMutation(api.offerSelections.submitPublic);

  const order: ReservationType[] = [
    "hotel",
    "flight",
    "transfer",
    "venue",
    "restaurant",
    "activity",
    "other",
  ];

  const byType = useMemo(() => {
    if (!offers) return {};
    return order.reduce<Partial<Record<ReservationType, Doc<"offers">[]>>>((acc, t) => {
      const items = offers.filter((o) => o.type === t);
      if (items.length > 0) acc[t] = items;
      return acc;
    }, {});
  }, [offers]);

  const toggleOffer = (offer: Doc<"offers">) => {
    setSelection((prev) => {
      const current = prev[offer._id];
      if (current?.selected) {
        return { ...prev, [offer._id]: { selected: false, units: current.units } };
      }
      return { ...prev, [offer._id]: { selected: true, units: current?.units ?? offer.units } };
    });
  };

  const setUnits = (offerId: Id<"offers">, units: number) => {
    setSelection((prev) => ({
      ...prev,
      [offerId]: { selected: true, units },
    }));
  };

  const selectedCount = Object.values(selection).filter((s) => s.selected).length;

  const handleSubmit = async () => {
    if (!fileId) return;
    const items = Object.entries(selection)
      .filter(([, v]) => v.selected)
      .map(([offerId, v]) => ({
        offerId: offerId as Id<"offers">,
        requestedUnits: v.units,
      }));
    if (items.length === 0) {
      toast.error("Select at least one option before submitting.");
      return;
    }
    setSubmitting(true);
    try {
      await submit({
        groupFileId: fileId as Id<"groupFiles">,
        items,
        clientNote: clientNote.trim() || undefined,
      });
      setSubmitted(true);
      toast.success("Your selection has been sent to your travel team.");
    } catch (error) {
      const msg =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not submit your selection.";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (file === undefined || offers === undefined) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-12 space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-6 w-40" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
    );
  }

  if (!file) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Offer not found.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-sidebar text-sidebar-foreground">
        <div className="mx-auto max-w-2xl px-4 py-10">
          <p className="mb-2 text-xs font-medium uppercase tracking-widest opacity-70">
            Your travel options
          </p>
          <h1 className="font-display text-3xl font-bold">{file.title}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-4 text-sm opacity-80">
            <span className="flex items-center gap-1.5">
              <MapPin className="size-4" />
              {file.destination}
            </span>
            <span className="flex items-center gap-1.5">
              <CalendarDays className="size-4" />
              {formatDateRange(file.startDate, file.endDate)}
            </span>
            <span className="flex items-center gap-1.5">
              <Users className="size-4" />
              {file.pax} travellers
            </span>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-2xl px-4 py-10 space-y-8">
        {submitted ? (
          <Card>
            <CardContent className="py-10 text-center">
              <Check className="mx-auto mb-3 size-8 text-chart-3" />
              <p className="text-base font-medium">Thanks — your selection was sent</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Your travel team will review your choices and confirm your booking shortly.
              </p>
            </CardContent>
          </Card>
        ) : offers.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              <XCircle className="mx-auto mb-2 size-6 text-muted-foreground" />
              No options are available yet. Check back soon.
            </CardContent>
          </Card>
        ) : (
          <>
            <p className="text-sm text-muted-foreground">
              Choose one or more options below — you can pick several of the same
              type (e.g. two restaurants) and adjust the quantity requested for
              each. Submit when you're ready and your travel team will follow up.
            </p>

            {(Object.entries(byType) as [ReservationType, Doc<"offers">[]][]).map(
              ([type, items]) => {
                const Icon = TYPE_ICONS[type] ?? Package;
                return (
                  <div key={type}>
                    <div className="mb-2 flex items-center gap-2">
                      <Icon className="size-4 text-muted-foreground" />
                      <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                        {reservationTypeLabel(type)}
                      </h3>
                      <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                        {items.length}
                      </span>
                    </div>
                    <div className="space-y-2">
                      {items.map((offer) => (
                        <OfferOptionCard
                          key={offer._id}
                          offer={offer}
                          fileCurrency={file.currency}
                          selected={selection[offer._id]?.selected ?? false}
                          units={selection[offer._id]?.units ?? offer.units}
                          onToggle={() => toggleOffer(offer)}
                          onUnitsChange={(units) => setUnits(offer._id, units)}
                        />
                      ))}
                    </div>
                  </div>
                );
              },
            )}

            <div className="space-y-3 border-t pt-6">
              <p className="text-sm font-medium">Anything else we should know? (optional)</p>
              <Textarea
                value={clientNote}
                onChange={(e) => setClientNote(e.target.value)}
                placeholder="e.g. dietary requirements, room preferences…"
                rows={3}
              />
              <Button
                className="w-full"
                size="lg"
                disabled={selectedCount === 0 || submitting}
                onClick={handleSubmit}
              >
                {submitting ? <Loader2 className="size-4 animate-spin" /> : null}
                Submit selection{selectedCount > 0 ? ` (${selectedCount})` : ""}
              </Button>
            </div>
          </>
        )}

        <footer className="border-t pt-8 text-center text-xs text-muted-foreground">
          <p>Prepared by {file.clientName ? `${file.clientName} · ` : ""}your travel team</p>
        </footer>
      </div>
    </div>
  );
}
