import { useCallback, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  type DragStartEvent,
  type DragEndEvent,
  useDroppable,
  useDraggable,
} from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import { CalendarDays, Users, TrendingUp, ExternalLink, Clock } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.js";
import type { FileStatus } from "@/lib/domain.ts";
import { FILE_STATUS_OPTIONS, STATUS_STYLES, formatMoney } from "@/lib/domain.ts";
import { formatDateRange } from "@/lib/dates.ts";
import PageHeader from "@/components/page-header.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { cn } from "@/lib/utils.ts";

// ── Types ─────────────────────────────────────────────────────────────────────

type PipelineFile = Doc<"groupFiles"> & { totalIncome: number; lastActivityAt: string };

// Enquiries/quotes with no activity in this many days are flagged as stale so
// nothing quietly falls through the cracks early in the pipeline.
const STALE_DAYS = 7;
const STALE_STATUSES: FileStatus[] = ["enquiry", "quoted"];

function isStale(file: PipelineFile): boolean {
  if (!STALE_STATUSES.includes(file.status as FileStatus)) return false;
  const daysSinceActivity =
    (Date.now() - new Date(file.lastActivityAt).getTime()) / (1000 * 60 * 60 * 24);
  return daysSinceActivity >= STALE_DAYS;
}


// Pipeline shows all statuses, including cancelled
const PIPELINE_STATUSES: { value: FileStatus; label: string }[] = FILE_STATUS_OPTIONS.map(
  (s) => ({ value: s.value, label: s.label }),
);

// Column accent colours (top border)
const COLUMN_ACCENTS: Record<string, string> = {
  enquiry: "border-t-muted-foreground/30",
  quoted: "border-t-chart-4",
  confirmed: "border-t-chart-3",
  operating: "border-t-chart-2",
  closed: "border-t-primary/60",
  cancelled: "border-t-destructive/50",
};

// ── Card ──────────────────────────────────────────────────────────────────────

function PipelineCard({
  file,
  isDragging = false,
  isOverlay = false,
}: {
  file: PipelineFile;
  isDragging?: boolean;
  isOverlay?: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: file._id,
    data: { status: file.status },
  });

  const style = transform
    ? { transform: CSS.Translate.toString(transform) }
    : undefined;

  const stale = isStale(file);
  const daysIdle = Math.floor(
    (Date.now() - new Date(file.lastActivityAt).getTime()) / (1000 * 60 * 60 * 24),
  );

  return (
    <div
      ref={isOverlay ? undefined : setNodeRef}
      style={isOverlay ? undefined : style}
      {...(isOverlay ? {} : { ...attributes, ...listeners })}
      className={cn(
        "group select-none rounded-lg border bg-card px-3.5 py-3 transition-shadow",
        isDragging && "opacity-40",
        isOverlay &&
          "rotate-1 shadow-2xl ring-2 ring-primary/40 cursor-grabbing",
        !isDragging && !isOverlay && "cursor-grab hover:shadow-md hover:border-ring/60",
        stale && !isOverlay && "border-chart-2/50 bg-chart-2/[0.04]",
      )}
    >
      {/* Top row: reference + open link */}
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <span className="font-mono text-[10px] text-muted-foreground">
          {file.reference}
        </span>
        {!isOverlay && (
          <Link
            to={`/files/${file._id}`}
            onClick={(e) => e.stopPropagation()}
            className="hidden shrink-0 text-muted-foreground/0 transition-colors group-hover:text-muted-foreground/60 hover:!text-foreground group-hover:flex"
          >
            <ExternalLink className="size-3" />
          </Link>
        )}
      </div>

      {/* Title */}
      <p className="mb-2 line-clamp-2 text-sm font-semibold leading-snug">
        {file.title}
      </p>

      {/* Client */}
      <p className="mb-3 truncate text-xs text-muted-foreground">
        {file.clientName}
      </p>

      {stale && (
        <div className="mb-2.5 flex items-center gap-1.5 rounded-md bg-chart-2/15 px-2 py-1 text-xs font-medium text-chart-2">
          <Clock className="size-3 shrink-0" />
          <span>No activity in {daysIdle} days</span>
        </div>
      )}

      {/* Meta row */}
      <div className="space-y-1">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <CalendarDays className="size-3 shrink-0" />
          <span className="truncate">{formatDateRange(file.startDate, file.endDate)}</span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Users className="size-3 shrink-0" />
            <span>{file.pax} pax</span>
          </div>
          {file.totalIncome > 0 && (
            <div className="flex items-center gap-1 text-xs font-medium text-chart-3">
              <TrendingUp className="size-3 shrink-0" />
              <span>{formatMoney(file.totalIncome, "EUR")}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Column ────────────────────────────────────────────────────────────────────

function PipelineColumn({
  status,
  label,
  files,
  isOver,
}: {
  status: FileStatus;
  label: string;
  files: PipelineFile[];
  isOver: boolean;
}) {
  const { setNodeRef } = useDroppable({ id: status });

  return (
    <div className="flex min-w-[240px] flex-1 flex-col">
      {/* Column header */}
      <div className="mb-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
              STATUS_STYLES[status],
            )}
          >
            {label}
          </span>
        </div>
        <span className="text-xs tabular-nums text-muted-foreground">
          {files.length}
        </span>
      </div>

      {/* Drop zone */}
      <div
        ref={setNodeRef}
        className={cn(
          "flex flex-1 flex-col gap-2.5 rounded-xl border-2 border-dashed p-2.5 transition-colors min-h-[120px]",
          isOver
            ? "border-primary/60 bg-primary/5"
            : "border-transparent bg-secondary/30",
        )}
      >
        {files.map((f) => (
          <PipelineCard key={f._id} file={f} />
        ))}
      </div>
    </div>
  );
}

// ── Mobile list ───────────────────────────────────────────────────────────────

function MobileList({ files }: { files: PipelineFile[] }) {
  const grouped = useMemo(() => {
    const map = new Map<FileStatus, PipelineFile[]>();
    for (const s of PIPELINE_STATUSES) map.set(s.value, []);
    for (const f of files) {
      const col = map.get(f.status as FileStatus);
      if (col) col.push(f);
    }
    return map;
  }, [files]);

  return (
    <div className="space-y-6">
      {PIPELINE_STATUSES.map(({ value, label }) => {
        const col = grouped.get(value) ?? [];
        if (col.length === 0) return null;
        return (
          <div key={value}>
            <div className="mb-2 flex items-center gap-2">
              <span
                className={cn(
                  "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
                  STATUS_STYLES[value],
                )}
              >
                {label}
              </span>
              <span className="text-xs text-muted-foreground">{col.length}</span>
            </div>
            <div className="space-y-2">
              {col.map((f) => (
                <Link key={f._id} to={`/files/${f._id}`} className="block">
                  <div className="rounded-lg border bg-card px-3.5 py-3 transition-colors hover:border-ring/60 hover:bg-secondary/40">
                    <div className="mb-1 flex items-start justify-between gap-2">
                      <p className="font-semibold leading-snug">{f.title}</p>
                      {f.totalIncome > 0 && (
                        <span className="shrink-0 text-xs font-medium text-chart-3">
                          {formatMoney(f.totalIncome, "EUR")}
                        </span>
                      )}
                    </div>
                    <p className="mb-2 text-xs text-muted-foreground">{f.clientName}</p>
                    {isStale(f) && (
                      <div className="mb-2 flex items-center gap-1.5 rounded-md bg-chart-2/15 px-2 py-1 text-xs font-medium text-chart-2">
                        <Clock className="size-3 shrink-0" />
                        <span>
                          No activity in{" "}
                          {Math.floor(
                            (Date.now() - new Date(f.lastActivityAt).getTime()) /
                              (1000 * 60 * 60 * 24),
                          )}{" "}
                          days
                        </span>
                      </div>
                    )}
                    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <CalendarDays className="size-3" />
                        {formatDateRange(f.startDate, f.endDate)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="size-3" />
                        {f.pax} pax
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────

export default function PipelinePage() {
  const files = useQuery(api.groupFiles.listForPipeline, {});
  const setStatus = useMutation(api.groupFiles.setStatus);

  const [activeId, setActiveId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
  );

  // Group files by status (with optimistic local reorder while dragging)
  const [optimisticStatus, setOptimisticStatus] = useState<
    Record<string, FileStatus>
  >({});

  const grouped = useMemo(() => {
    const map = new Map<FileStatus, PipelineFile[]>();
    for (const s of PIPELINE_STATUSES) map.set(s.value, []);
    if (!files) return map;
    for (const f of files) {
      const status = (optimisticStatus[f._id] ?? f.status) as FileStatus;
      const col = map.get(status);
      if (col) col.push({ ...f, status });
    }
    return map;
  }, [files, optimisticStatus]);

  const activeFile = useMemo(
    () => files?.find((f) => f._id === activeId),
    [files, activeId],
  );

  const handleDragStart = useCallback((e: DragStartEvent) => {
    setActiveId(String(e.active.id));
  }, []);

  const handleDragOver = useCallback((e: { over: { id: unknown } | null }) => {
    setOverId(e.over ? String(e.over.id) : null);
  }, []);

  const handleDragEnd = useCallback(
    async (e: DragEndEvent) => {
      const fileId = String(e.active.id);
      const newStatus = e.over ? (String(e.over.id) as FileStatus) : null;
      const oldStatus = (e.active.data.current?.status as FileStatus) ?? null;

      setActiveId(null);
      setOverId(null);

      if (!newStatus || newStatus === oldStatus) return;
      if (!PIPELINE_STATUSES.find((s) => s.value === newStatus)) return;

      // Optimistic update
      setOptimisticStatus((prev) => ({ ...prev, [fileId]: newStatus }));

      try {
        await setStatus({
          id: fileId as Doc<"groupFiles">["_id"],
          status: newStatus,
        });
        toast.success(`Moved to ${newStatus}`);
      } catch {
        // Revert
        setOptimisticStatus((prev) => {
          const next = { ...prev };
          delete next[fileId];
          return next;
        });
        toast.error("Could not update status.");
      }
    },
    [setStatus],
  );

  const totalActive =
    files?.filter((f) => f.status !== "closed" && f.status !== "cancelled").length ?? 0;
  const totalValue =
    files
      ?.filter((f) => f.status !== "cancelled")
      .reduce((s, f) => s + f.totalIncome, 0) ?? 0;
  const staleCount = files?.filter(isStale).length ?? 0;

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Operations"
        title="Pipeline"
        description="Drag files between stages to update their status."
        actions={
          <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span>
              <span className="font-semibold tabular-nums text-foreground">
                {totalActive}
              </span>{" "}
              active files
            </span>
            {totalValue > 0 && (
              <Badge variant="secondary" className="tabular-nums">
                {formatMoney(totalValue, "EUR")} pipeline
              </Badge>
            )}
            {staleCount > 0 && (
              <Badge className="gap-1 border-transparent bg-chart-2/15 text-chart-2 tabular-nums hover:bg-chart-2/15">
                <Clock className="size-3" />
                {staleCount} stale {staleCount === 1 ? "enquiry" : "enquiries"}
              </Badge>
            )}
          </div>
        }
      />

      {/* Skeleton */}
      {files === undefined && (
        <>
          {/* Desktop skeleton */}
          <div className="hidden gap-4 lg:flex">
            {PIPELINE_STATUSES.map((s) => (
              <div key={s.value} className="flex-1 space-y-2.5">
                <Skeleton className="h-6 w-24" />
                <Skeleton className="h-28 w-full" />
                <Skeleton className="h-28 w-full" />
              </div>
            ))}
          </div>
          {/* Mobile skeleton */}
          <div className="space-y-3 lg:hidden">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </>
      )}

      {/* Mobile list */}
      {files !== undefined && (
        <div className="lg:hidden">
          <MobileList files={files} />
        </div>
      )}

      {/* Desktop Kanban */}
      {files !== undefined && (
        <DndContext
          sensors={sensors}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
        >
          <div className="hidden overflow-x-auto lg:block">
            <div
              className="grid gap-4 pb-6"
              style={{ gridTemplateColumns: `repeat(${PIPELINE_STATUSES.length}, minmax(200px, 1fr))` }}
            >
              {PIPELINE_STATUSES.map(({ value, label }) => (
                <div
                  key={value}
                  className={cn(
                    "rounded-xl border-t-2 pt-3",
                    COLUMN_ACCENTS[value] ?? "border-t-border",
                  )}
                >
                  <PipelineColumn
                    status={value}
                    label={label}
                    files={grouped.get(value) ?? []}
                    isOver={overId === value}
                  />
                </div>
              ))}
            </div>
          </div>

          <DragOverlay dropAnimation={null}>
            {activeFile && (
              <PipelineCard
                file={{
                  ...activeFile,
                  status:
                    (optimisticStatus[activeFile._id] as FileStatus) ??
                    activeFile.status,
                }}
                isOverlay
              />
            )}
          </DragOverlay>
        </DndContext>
      )}
    </div>
  );
}
