import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useQuery, useAction } from "convex/react";
import {
  BedDouble,
  Bus,
  Building,
  Download,
  FileText,
  Filter,
  Mail,
  Package,
  Plane,
  Receipt,
  Send,
  Sunset,
  UtensilsCrossed,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from "@/components/ui/empty.tsx";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import { cn } from "@/lib/utils.ts";
import {
  formatMoney,
  reservationTypeLabel,
  reservationStatusLabel,
  RESERVATION_STATUS_STYLES,
  RESERVATION_TYPE_OPTIONS,
  FILE_STATUS_OPTIONS,
} from "@/lib/domain.ts";
import { formatDate, formatDateRange } from "@/lib/dates.ts";
import {
  generateVoucherPDF,
  generateInvoicePDF,
} from "@/lib/pdf-generators.ts";
import SendVoucherDialog from "@/pages/files/_components/send-voucher-dialog.tsx";
import SendInvoiceDialog from "@/pages/files/_components/send-invoice-dialog.tsx";
import type { VoucherRow, InvoiceRow } from "@/convex/documents.ts";
import type { ReservationType } from "@/lib/domain.ts";

// ── Type icon map ─────────────────────────────────────────────────────────────

const TYPE_ICONS: Record<ReservationType, typeof BedDouble> = {
  hotel: BedDouble,
  transfer: Bus,
  restaurant: UtensilsCrossed,
  activity: Sunset,
  venue: Building,
  flight: Plane,
  other: Package,
};

// ── Helpers ───────────────────────────────────────────────────────────────────

type SenderIdentity = { id: string; value: string; type: string; status: string };

// ── Voucher card ──────────────────────────────────────────────────────────────

function VoucherCard({
  row,
  senderIdentities,
}: {
  row: VoucherRow;
  senderIdentities: SenderIdentity[];
}) {
  const [loading, setLoading] = useState(false);
  const Icon = TYPE_ICONS[row.type as ReservationType] ?? Package;

  const handleDownload = async () => {
    setLoading(true);
    try {
      // Build the minimal file shape the PDF generator needs
      generateVoucherPDF(row.file as Parameters<typeof generateVoucherPDF>[0], row);
      toast.success("Voucher downloaded");
    } catch {
      toast.error("Could not generate voucher.");
    } finally {
      setLoading(false);
    }
  };

  const dateLabel =
    row.type === "hotel" && row.nights !== undefined
      ? `${formatDate(row.startDate)} · ${row.nights}n`
      : formatDate(row.startDate);

  return (
    <div className="flex flex-col gap-3 rounded-lg border bg-card p-4 shadow-sm sm:flex-row sm:items-start sm:justify-between">
      {/* Left — reservation info */}
      <div className="flex min-w-0 items-start gap-3">
        <div className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
          <Icon className="size-4 text-muted-foreground" />
        </div>
        <div className="min-w-0 space-y-0.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">{row.supplierName}</span>
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                RESERVATION_STATUS_STYLES[row.status],
              )}
            >
              {reservationStatusLabel(row.status)}
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            {reservationTypeLabel(row.type)} · {row.description} · {dateLabel}
          </p>
          {/* File link */}
          <Link
            to={`/files/${row.file._id}?tab=documents`}
            className="text-xs text-primary hover:underline"
          >
            {row.file.reference} · {row.file.title}
          </Link>
          <div className="flex items-center gap-2">
            <StatusBadge status={row.file.status} />
            <span className="text-xs text-muted-foreground">
              {formatDateRange(row.file.startDate, row.file.endDate)}
            </span>
          </div>
        </div>
      </div>
      {/* Right — actions */}
      <div className="flex shrink-0 flex-wrap gap-2">
        <Button size="sm" variant="secondary" onClick={handleDownload} disabled={loading}>
          <Download className="size-4" />
          {loading ? "Generating…" : "PDF"}
        </Button>
        <SendVoucherDialog
          file={row.file as Parameters<typeof SendVoucherDialog>[0]["file"]}
          reservation={row}
          senderIdentities={senderIdentities}
          trigger={
            <Button size="sm" variant="secondary">
              <Mail className="size-4" />
              Email
            </Button>
          }
        />
      </div>
    </div>
  );
}

// ── Invoice card ──────────────────────────────────────────────────────────────

function InvoiceCard({
  row,
  senderIdentities,
}: {
  row: InvoiceRow;
  senderIdentities: SenderIdentity[];
}) {
  const [loading, setLoading] = useState(false);

  const handleDownload = async () => {
    setLoading(true);
    try {
      generateInvoicePDF(row.file, row.incomeLines, row.invoiceNumber);
      toast.success("Invoice downloaded");
    } catch {
      toast.error("Could not generate invoice.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-3 rounded-lg border bg-card p-4 shadow-sm sm:flex-row sm:items-start sm:justify-between">
      {/* Left — file info */}
      <div className="min-w-0 space-y-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-medium">{row.file.title}</span>
          <StatusBadge status={row.file.status} />
        </div>
        <p className="text-xs text-muted-foreground">
          {row.file.reference} · {row.file.clientName} · {row.file.destination}
        </p>
        <p className="text-xs text-muted-foreground">
          {formatDateRange(row.file.startDate, row.file.endDate)}
        </p>
        <div className="flex flex-wrap items-center gap-3 pt-1">
          <span className="font-mono text-xs text-muted-foreground">{row.invoiceNumber}</span>
          {row.incomeLines.length > 0 ? (
            <Badge variant="secondary">
              {formatMoney(row.totalEur, "EUR")}
            </Badge>
          ) : (
            <span className="text-xs text-muted-foreground italic">No income lines</span>
          )}
        </div>
      </div>
      {/* Right — actions */}
      {row.incomeLines.length > 0 && (
        <div className="flex shrink-0 flex-wrap gap-2">
          <Button size="sm" variant="secondary" onClick={handleDownload} disabled={loading}>
            <Download className="size-4" />
            {loading ? "Generating…" : "PDF"}
          </Button>
          <SendInvoiceDialog
            file={row.file}
            incomeLines={row.incomeLines}
            invoiceNumber={row.invoiceNumber}
            senderIdentities={senderIdentities}
            trigger={
              <Button size="sm" variant="secondary">
                <Send className="size-4" />
                Email
              </Button>
            }
          />
        </div>
      )}
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function DocumentsPage() {
  const [fileStatus, setFileStatus] = useState<string>("all");
  const [reservationType, setReservationType] = useState<string>("all");
  const [senderIdentities, setSenderIdentities] = useState<SenderIdentity[]>([]);
  const listIdentities = useAction(api.email.identities.list);

  useEffect(() => {
    listIdentities({}).then(setSenderIdentities).catch(() => setSenderIdentities([]));
  }, []);

  const data = useQuery(api.documents.overview, {
    fileStatus:
      fileStatus !== "all"
        ? (fileStatus as "enquiry" | "quoted" | "confirmed" | "operating" | "closed" | "cancelled")
        : undefined,
    reservationType:
      reservationType !== "all"
        ? (reservationType as "venue" | "hotel" | "transfer" | "restaurant" | "activity" | "flight" | "other")
        : undefined,
  });

  const vouchers = data?.vouchers;
  const invoices = data?.invoices;

  const invoicesWithLines = invoices?.filter((r) => r.incomeLines.length > 0);

  return (
    <div className="mx-auto max-w-5xl space-y-8">
      <PageHeader
        eyebrow="Documents"
        title="Vouchers & invoices"
        description="Download or email supplier vouchers and client invoices across all group files."
      />

      {/* ── Filter bar ── */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <Filter className="size-4 shrink-0 text-muted-foreground" />
          <Select value={fileStatus} onValueChange={setFileStatus}>
            <SelectTrigger className="w-44">
              <SelectValue placeholder="All file statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All file statuses</SelectItem>
              {FILE_STATUS_OPTIONS.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={reservationType} onValueChange={setReservationType}>
            <SelectTrigger className="w-44">
              <SelectValue placeholder="All service types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All service types</SelectItem>
              {RESERVATION_TYPE_OPTIONS.map((t) => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {(fileStatus !== "all" || reservationType !== "all") && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setFileStatus("all"); setReservationType("all"); }}
            >
              Clear filters
            </Button>
          )}
        </div>
      </Card>

      {/* ── Tabs ── */}
      <Tabs defaultValue="vouchers">
        <TabsList>
          <TabsTrigger value="vouchers" className="flex items-center gap-2">
            <FileText className="size-4" />
            Vouchers
            {vouchers !== undefined && (
              <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">
                {vouchers.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="invoices" className="flex items-center gap-2">
            <Receipt className="size-4" />
            Invoices
            {invoicesWithLines !== undefined && (
              <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">
                {invoicesWithLines.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ── Vouchers ── */}
        <TabsContent value="vouchers" className="pt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 font-display text-base">
                <FileText className="size-4 text-muted-foreground" />
                Supplier vouchers
              </CardTitle>
            </CardHeader>
            <CardContent>
              {vouchers === undefined ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-24 w-full" />
                  ))}
                </div>
              ) : vouchers.length === 0 ? (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon"><FileText /></EmptyMedia>
                    <EmptyTitle>No vouchers found</EmptyTitle>
                    <EmptyDescription>
                      {fileStatus !== "all" || reservationType !== "all"
                        ? "No reservations match the current filters."
                        : "Add reservations to group files to generate vouchers here."}
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ) : (
                <div className="space-y-3">
                  {vouchers.map((row) => (
                    <VoucherCard
                      key={row._id}
                      row={row}
                      senderIdentities={senderIdentities}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Invoices ── */}
        <TabsContent value="invoices" className="pt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 font-display text-base">
                <Receipt className="size-4 text-muted-foreground" />
                Client invoices
              </CardTitle>
            </CardHeader>
            <CardContent>
              {invoices === undefined ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-24 w-full" />
                  ))}
                </div>
              ) : invoicesWithLines!.length === 0 ? (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon"><Receipt /></EmptyMedia>
                    <EmptyTitle>No invoices found</EmptyTitle>
                    <EmptyDescription>
                      {fileStatus !== "all"
                        ? "No files with income lines match the current filters."
                        : "Add income lines to group files to generate invoices here."}
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ) : (
                <div className="space-y-3">
                  {invoicesWithLines!.map((row) => (
                    <InvoiceCard
                      key={row.file._id}
                      row={row}
                      senderIdentities={senderIdentities}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
