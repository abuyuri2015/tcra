import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "convex/react";
import {
  addMonths,
  subMonths,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  format,
  isSameMonth,
  isToday,
  parseISO,
  isBefore,
  isAfter,
  max,
  min,
} from "date-fns";
import { ChevronLeft, ChevronRight, Users, MapPin, CalendarDays } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { cn } from "@/lib/utils.ts";
import type { CalendarFile } from "@/convex/calendar.ts";
import type { FileStatus } from "@/lib/domain.ts";

// ── Status palette ─────────────────────────────────────────────────────────────

const STATUS_BG: Record<string, string> = {
  enquiry:   "bg-slate-400/80 dark:bg-slate-500/80",
  quoted:    "bg-amber-400/90 dark:bg-amber-500/90",
  confirmed: "bg-emerald-500/90 dark:bg-emerald-600/90",
  operating: "bg-blue-500/90 dark:bg-blue-600/90",
  closed:    "bg-primary/60",
};

const STATUS_TEXT: Record<string, string> = {
  enquiry:   "text-white",
  quoted:    "text-amber-950 dark:text-white",
  confirmed: "text-white",
  operating: "text-white",
  closed:    "text-primary-foreground",
};

const STATUS_LABELS: Record<string, string> = {
  enquiry: "Enquiry", quoted: "Quoted", confirmed: "Confirmed",
  operating: "Operating", closed: "Closed",
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function clampToMonth(date: Date, monthStart: Date, monthEnd: Date) {
  return {
    clamped: max([date, monthStart]),
    clampedEnd: min([date, monthEnd]),
  };
}

/** How many calendar columns a file spans on a given week row [weekStart, weekEnd] */
function fileSpanInWeek(
  file: CalendarFile,
  weekStart: Date,
  weekEnd: Date,
): { colStart: number; colSpan: number } | null {
  const fileStart = parseISO(file.startDate);
  const fileEnd = parseISO(file.endDate);
  if (isAfter(fileStart, weekEnd) || isBefore(fileEnd, weekStart)) return null;

  const visStart = max([fileStart, weekStart]);
  const visEnd = min([fileEnd, weekEnd]);

  const colStart = visStart.getDay(); // 0=Sun
  const colSpan = Math.round((visEnd.getTime() - visStart.getTime()) / 86_400_000) + 1;

  return { colStart, colSpan: Math.min(colSpan, 7 - colStart) };
}

// ── Day cell ──────────────────────────────────────────────────────────────────

function DayCell({
  day,
  inMonth,
}: {
  day: Date;
  inMonth: boolean;
}) {
  const today = isToday(day);
  return (
    <div
      className={cn(
        "relative h-8 border-b border-r text-right",
        inMonth ? "bg-background" : "bg-muted/30",
      )}
    >
      <span
        className={cn(
          "absolute right-1.5 top-1 text-xs leading-none",
          today
            ? "flex size-5 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold"
            : inMonth
              ? "text-foreground"
              : "text-muted-foreground/50",
        )}
      >
        {format(day, "d")}
      </span>
    </div>
  );
}

// ── File block ────────────────────────────────────────────────────────────────

function FileBlock({
  file,
  colStart,
  colSpan,
  row,
  onClick,
}: {
  file: CalendarFile;
  colStart: number;
  colSpan: number;
  row: number; // stacking offset within the week
  onClick: () => void;
}) {
  const bg = STATUS_BG[file.status] ?? "bg-muted";
  const txt = STATUS_TEXT[file.status] ?? "text-foreground";
  const isStart = parseISO(file.startDate).getDay() === colStart || colStart === 0;

  return (
    <button
      type="button"
      onClick={onClick}
      title={`${file.title} · ${file.clientName} · ${file.destination}`}
      className={cn(
        "absolute z-10 flex h-5 items-center overflow-hidden rounded-sm px-1.5 text-left text-[10px] font-medium shadow-sm cursor-pointer transition-opacity hover:opacity-80",
        bg,
        txt,
      )}
      style={{
        left: `calc(${(colStart / 7) * 100}% + 1px)`,
        width: `calc(${(colSpan / 7) * 100}% - 2px)`,
        top: `${38 + row * 22}px`,
      }}
    >
      {isStart ? (
        <span className="truncate">{file.title}</span>
      ) : (
        <span className="truncate opacity-70">{file.title}</span>
      )}
    </button>
  );
}

// ── Week row ──────────────────────────────────────────────────────────────────

function WeekRow({
  days,
  files,
  currentMonth,
  onFileClick,
}: {
  days: Date[];
  files: CalendarFile[];
  currentMonth: Date;
  onFileClick: (fileId: string) => void;
}) {
  const weekStart = days[0];
  const weekEnd = days[days.length - 1];

  // Assign stacking rows to avoid overlap
  const blocks: Array<{ file: CalendarFile; colStart: number; colSpan: number; row: number }> = [];
  const rowOccupied: boolean[][] = Array.from({ length: 8 }, () => Array(7).fill(false));

  for (const file of files) {
    const span = fileSpanInWeek(file, weekStart, weekEnd);
    if (!span) continue;
    const { colStart, colSpan } = span;

    // Find first unoccupied row
    let rowIdx = 0;
    while (rowOccupied[rowIdx]?.slice(colStart, colStart + colSpan).some(Boolean)) {
      rowIdx++;
      if (rowIdx >= 8) break;
    }
    if (rowIdx < 8) {
      for (let c = colStart; c < colStart + colSpan && c < 7; c++) {
        if (rowOccupied[rowIdx]) rowOccupied[rowIdx][c] = true;
      }
      blocks.push({ file, colStart, colSpan, row: rowIdx });
    }
  }

  const maxRow = blocks.reduce((m, b) => Math.max(m, b.row), -1);
  const height = 38 + (maxRow + 1) * 22 + 6;

  return (
    <div className="relative grid grid-cols-7" style={{ minHeight: `${height}px` }}>
      {days.map((day) => (
        <DayCell
          key={day.toISOString()}
          day={day}
          inMonth={isSameMonth(day, currentMonth)}
        />
      ))}
      {blocks.map(({ file, colStart, colSpan, row }) => (
        <FileBlock
          key={`${file.id}-${weekStart.toISOString()}`}
          file={file}
          colStart={colStart}
          colSpan={colSpan}
          row={row}
          onClick={() => onFileClick(file.id)}
        />
      ))}
    </div>
  );
}

// ── Legend ────────────────────────────────────────────────────────────────────

function Legend() {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
      {Object.entries(STATUS_LABELS).map(([status, label]) => (
        <span key={status} className="flex items-center gap-1.5">
          <span className={cn("inline-block size-2.5 rounded-sm", STATUS_BG[status])} />
          {label}
        </span>
      ))}
    </div>
  );
}

// ── Summary bar ───────────────────────────────────────────────────────────────

function SummaryBar({ files }: { files: CalendarFile[] }) {
  const totalPax = files.reduce((s, f) => s + f.pax, 0);
  const byStatus = files.reduce<Record<string, number>>((acc, f) => {
    acc[f.status] = (acc[f.status] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div className="flex flex-wrap items-center gap-4 rounded-lg border bg-card px-4 py-3 text-sm">
      <span className="flex items-center gap-1.5 font-medium">
        <CalendarDays className="size-4 text-muted-foreground" />
        {files.length} departure{files.length !== 1 ? "s" : ""} this month
      </span>
      {totalPax > 0 && (
        <span className="flex items-center gap-1.5 text-muted-foreground">
          <Users className="size-4" />
          {totalPax.toLocaleString()} pax
        </span>
      )}
      <div className="ml-auto flex flex-wrap gap-2">
        {Object.entries(byStatus).map(([status, count]) => (
          <Badge
            key={status}
            variant="secondary"
            className={cn(
              "text-[10px]",
              STATUS_BG[status],
              STATUS_TEXT[status],
            )}
          >
            {count} {STATUS_LABELS[status] ?? status}
          </Badge>
        ))}
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────

const DAY_HEADERS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function CalendarPage() {
  const navigate = useNavigate();
  const [currentMonth, setCurrentMonth] = useState(() => startOfMonth(new Date()));

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);

  // Expand to full weeks for the grid
  const gridStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const gridEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const allDays = eachDayOfInterval({ start: gridStart, end: gridEnd });

  // Split into weeks
  const weeks: Date[][] = [];
  for (let i = 0; i < allDays.length; i += 7) {
    weeks.push(allDays.slice(i, i + 7));
  }

  const rangeStart = format(gridStart, "yyyy-MM-dd");
  const rangeEnd = format(gridEnd, "yyyy-MM-dd");

  const files = useQuery(api.calendar.filesInRange, { rangeStart, rangeEnd });

  // Files that actually start within this calendar month (for summary)
  const monthFiles = useMemo(
    () => files?.filter((f) => {
      const s = parseISO(f.startDate);
      return s >= monthStart && s <= monthEnd;
    }) ?? [],
    [files, monthStart.toISOString(), monthEnd.toISOString()],
  );

  const handlePrev = () => setCurrentMonth((m) => subMonths(m, 1));
  const handleNext = () => setCurrentMonth((m) => addMonths(m, 1));
  const handleToday = () => setCurrentMonth(startOfMonth(new Date()));

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <PageHeader
        eyebrow="Calendar"
        title="Departures calendar"
        description="Visual overview of all group departures by travel dates."
      />

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3">
        <Button variant="secondary" size="sm" onClick={handleToday}>
          Today
        </Button>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={handlePrev} className="px-2">
            <ChevronLeft className="size-4" />
          </Button>
          <span className="min-w-[11rem] text-center font-display text-lg font-semibold">
            {format(currentMonth, "MMMM yyyy")}
          </span>
          <Button variant="ghost" size="sm" onClick={handleNext} className="px-2">
            <ChevronRight className="size-4" />
          </Button>
        </div>
        <div className="ml-auto">
          <Legend />
        </div>
      </div>

      {/* Summary */}
      {files === undefined ? (
        <Skeleton className="h-12 w-full rounded-lg" />
      ) : (
        <SummaryBar files={monthFiles} />
      )}

      {/* Calendar grid */}
      <div className="overflow-hidden rounded-xl border bg-card shadow-sm">
        {/* Day headers */}
        <div className="grid grid-cols-7 border-b bg-muted/40">
          {DAY_HEADERS.map((d) => (
            <div
              key={d}
              className="py-2 text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground"
            >
              {d}
            </div>
          ))}
        </div>

        {/* Weeks */}
        {files === undefined ? (
          <div className="space-y-px">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="grid grid-cols-7">
                {Array.from({ length: 7 }).map((_, j) => (
                  <Skeleton key={j} className="h-20 rounded-none" />
                ))}
              </div>
            ))}
          </div>
        ) : (
          <div>
            {weeks.map((days) => (
              <WeekRow
                key={days[0].toISOString()}
                days={days}
                files={files}
                currentMonth={currentMonth}
                onFileClick={(id) => navigate(`/files/${id}`)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Mobile fallback note */}
      <p className="text-xs text-muted-foreground">
        Click any departure block to open the group file.
      </p>
    </div>
  );
}
