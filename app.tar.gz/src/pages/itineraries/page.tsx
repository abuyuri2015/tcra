import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import {
  CalendarDays,
  ExternalLink,
  MapPin,
  Plus,
  Users,
  ListChecks,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import GroupFileFormDialog from "@/pages/files/_components/group-file-form-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import { formatDateRange } from "@/lib/dates.ts";
import type { ItineraryOverviewRow } from "@/convex/itineraries.ts";

// ── Card ──────────────────────────────────────────────────────────────────────

function ItineraryCard({ row }: { row: ItineraryOverviewRow }) {
  const clientUrl = `${window.location.origin}/itinerary/${row.fileId}`;

  return (
    <Card className="flex flex-col gap-0 overflow-hidden p-0 transition-shadow hover:shadow-md">
      {/* Coloured top bar based on status */}
      <div
        className={`h-1 w-full ${
          row.status === "confirmed" || row.status === "operating"
            ? "bg-emerald-500"
            : row.status === "quoted"
              ? "bg-amber-400"
              : row.status === "closed"
                ? "bg-primary/60"
                : row.status === "cancelled"
                  ? "bg-red-400"
                  : "bg-muted-foreground/30"
        }`}
      />

      <CardContent className="flex flex-col gap-4 p-5">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge status={row.status} />
              <span className="text-xs text-muted-foreground">{row.reference}</span>
            </div>
            <h3 className="mt-1 truncate font-display font-semibold leading-tight">
              {row.title}
            </h3>
            <p className="truncate text-sm text-muted-foreground">{row.clientName}</p>
          </div>
        </div>

        {/* Meta pills */}
        <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <MapPin className="size-3.5 shrink-0" />
            {row.destination}
          </span>
          <span className="flex items-center gap-1.5">
            <CalendarDays className="size-3.5 shrink-0" />
            {formatDateRange(row.startDate, row.endDate)}
          </span>
          <span className="flex items-center gap-1.5">
            <Users className="size-3.5 shrink-0" />
            {row.pax} pax
          </span>
        </div>

        {/* Day / item counts */}
        <div className="flex gap-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            <CalendarDays className="size-3" />
            {row.dayCount} day{row.dayCount !== 1 ? "s" : ""}
          </Badge>
          {row.itemCount > 0 && (
            <Badge variant="outline" className="flex items-center gap-1">
              <ListChecks className="size-3" />
              {row.itemCount} item{row.itemCount !== 1 ? "s" : ""}
            </Badge>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-2 border-t pt-4">
          <Button asChild size="sm">
            <Link to={`/files/${row.fileId}?tab=itinerary`}>
              <CalendarDays className="size-4" />
              Edit itinerary
            </Link>
          </Button>
          <Button asChild size="sm" variant="secondary">
            <a href={clientUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="size-4" />
              Client view
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function ItinerariesPage() {
  const rows = useQuery(api.itineraries.overview, {});

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <PageHeader
        eyebrow="Itineraries"
        title="Itineraries overview"
        description="Every group file with a built itinerary — staff view and shareable client link."
        actions={
          <GroupFileFormDialog
            trigger={
              <Button>
                <Plus className="size-4" />
                New file
              </Button>
            }
          />
        }
      />

      {rows === undefined ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-56 w-full rounded-xl" />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <CalendarDays />
            </EmptyMedia>
            <EmptyTitle>No itineraries yet</EmptyTitle>
            <EmptyDescription>
              Open a group file and go to the Itinerary tab to start building a
              programme. It will appear here once it has at least one day.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <GroupFileFormDialog
              trigger={
                <Button size="sm">
                  <Plus className="size-4" />
                  New group file
                </Button>
              }
            />
            <Button asChild variant="secondary" size="sm">
              <Link to="/files">View all files</Link>
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <>
          <p className="text-sm text-muted-foreground">
            {rows.length} file{rows.length !== 1 ? "s" : ""} with an itinerary
          </p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {rows.map((row) => (
              <ItineraryCard key={row.fileId} row={row} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
