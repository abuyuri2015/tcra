import { useParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { CalendarDays, MapPin } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import { formatDate } from "@/lib/dates.ts";
import {
  ITINERARY_ITEM_TYPE_COLORS,
  itineraryItemTypeLabel,
} from "@/lib/itinerary.ts";

export default function PublicItineraryPage() {
  const { fileId } = useParams<{ fileId: string }>();

  const file = useQuery(
    api.groupFiles.getPublic,
    fileId ? { id: fileId as Id<"groupFiles"> } : "skip",
  );

  const days = useQuery(
    api.itinerary.listByFilePublic,
    fileId ? { groupFileId: fileId as Id<"groupFiles"> } : "skip",
  );

  if (file === undefined || days === undefined) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-12 space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-6 w-40" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  if (!file) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-muted-foreground">Itinerary not found.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-sidebar text-sidebar-foreground">
        <div className="mx-auto max-w-2xl px-4 py-10">
          <p className="mb-1 text-xs font-medium uppercase tracking-widest opacity-70">
            Your itinerary
          </p>
          <h1 className="font-display text-3xl font-bold">{file.title}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-4 text-sm opacity-80">
            <span className="flex items-center gap-1.5">
              <MapPin className="size-4" />
              {file.destination}
            </span>
            <span className="flex items-center gap-1.5">
              <CalendarDays className="size-4" />
              {formatDate(file.startDate)} – {formatDate(file.endDate)}
            </span>
            <span>{file.pax} travellers</span>
          </div>
        </div>
      </div>

      {/* Days */}
      <div className="mx-auto max-w-2xl px-4 py-10 space-y-10">
        {days.length === 0 ? (
          <p className="text-center text-muted-foreground">
            The itinerary is being prepared. Check back soon.
          </p>
        ) : (
          days.map((day) => (
            <section key={day._id}>
              {/* Day header */}
              <div className="mb-4 flex items-center gap-4">
                <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-sidebar-primary text-sidebar-primary-foreground font-bold text-sm">
                  {day.dayNumber}
                </div>
                <div>
                  <h2 className="font-display text-xl font-semibold">
                    {day.title ?? `Day ${day.dayNumber}`}
                  </h2>
                  <p className="text-sm text-muted-foreground">{formatDate(day.date)}</p>
                </div>
              </div>

              {/* Items timeline */}
              {day.items.length === 0 ? (
                <p className="ml-14 text-sm text-muted-foreground italic">
                  Details coming soon.
                </p>
              ) : (
                <div className="ml-14 space-y-0">
                  {day.items.map((item, idx) => {
                    const colorClass =
                      ITINERARY_ITEM_TYPE_COLORS[item.type] ??
                      "bg-muted text-muted-foreground";
                    const isLast = idx === day.items.length - 1;
                    return (
                      <div key={item._id} className="relative flex gap-4">
                        {/* Vertical line */}
                        {!isLast && (
                          <div className="absolute left-[11px] top-6 bottom-0 w-px bg-border" />
                        )}

                        {/* Dot */}
                        <div className="relative mt-1.5 size-5 shrink-0 flex items-center justify-center">
                          <div className="size-2.5 rounded-full border-2 border-sidebar-primary bg-background" />
                        </div>

                        {/* Content */}
                        <div className={cn("pb-6 min-w-0 flex-1", isLast && "pb-0")}>
                          <div className="flex flex-wrap items-center gap-2 mb-1">
                            {item.time && (
                              <span className="text-xs font-mono text-muted-foreground w-10 shrink-0">
                                {item.time}
                              </span>
                            )}
                            <span
                              className={cn(
                                "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                                colorClass,
                              )}
                            >
                              {itineraryItemTypeLabel(item.type)}
                            </span>
                            <span className="font-medium text-sm">{item.title}</span>
                          </div>
                          {item.location && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                              <MapPin className="size-3" />
                              {item.location}
                            </div>
                          )}
                          {item.description && (
                            <p className="text-sm text-muted-foreground">
                              {item.description}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          ))
        )}

        {/* Footer */}
        <footer className="border-t pt-8 text-center text-xs text-muted-foreground">
          <p>Prepared by {file.clientName ? `${file.clientName} · ` : ""}your travel team</p>
        </footer>
      </div>
    </div>
  );
}
