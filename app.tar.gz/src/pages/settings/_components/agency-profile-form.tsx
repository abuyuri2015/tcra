import { useQuery, useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Building2,
  Globe,
  Landmark,
  Loader2,
  Save,
} from "lucide-react";
import { toast } from "sonner";
import { useEffect } from "react";
import { api } from "@/convex/_generated/api.js";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Separator } from "@/components/ui/separator.tsx";

const schema = z.object({
  agencyName: z.string().min(1, "Agency name is required"),
  address: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  website: z.string().url("Invalid URL").optional().or(z.literal("")),
  logoUrl: z.string().url("Invalid URL").optional().or(z.literal("")),
  bankName: z.string().optional(),
  iban: z.string().optional(),
  bic: z.string().optional(),
  paymentTerms: z.string().optional(),
  termsAndConditions: z.string().optional(),
  taxId: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

const DEFAULTS: FormValues = {
  agencyName: "",
  address: "",
  phone: "",
  email: "",
  website: "",
  logoUrl: "",
  bankName: "",
  iban: "",
  bic: "",
  paymentTerms: "Payment is due within 30 days of invoice date. Please reference the invoice number on your transfer.",
  termsAndConditions: "",
  taxId: "",
};

export default function AgencyProfileForm() {
  const profile = useQuery(api.agencyProfile.get);
  const saveProfile = useMutation(api.agencyProfile.save);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: DEFAULTS,
  });

  // Populate form when data loads
  useEffect(() => {
    if (profile) {
      form.reset({
        agencyName: profile.agencyName,
        address: profile.address ?? "",
        phone: profile.phone ?? "",
        email: profile.email ?? "",
        website: profile.website ?? "",
        logoUrl: profile.logoUrl ?? "",
        bankName: profile.bankName ?? "",
        iban: profile.iban ?? "",
        bic: profile.bic ?? "",
        paymentTerms: profile.paymentTerms ?? DEFAULTS.paymentTerms,
        termsAndConditions: profile.termsAndConditions ?? "",
        taxId: profile.taxId ?? "",
      });
    }
  }, [profile]);

  const onSubmit = async (values: FormValues) => {
    try {
      // Strip empty strings to undefined for optional fields
      const cleaned = {
        agencyName: values.agencyName,
        address: values.address || undefined,
        phone: values.phone || undefined,
        email: values.email || undefined,
        website: values.website || undefined,
        logoUrl: values.logoUrl || undefined,
        bankName: values.bankName || undefined,
        iban: values.iban || undefined,
        bic: values.bic || undefined,
        paymentTerms: values.paymentTerms || undefined,
        termsAndConditions: values.termsAndConditions || undefined,
        taxId: values.taxId || undefined,
      };
      await saveProfile(cleaned);
      toast.success("Agency profile saved");
    } catch {
      toast.error("Failed to save profile");
    }
  };

  if (profile === undefined) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-48" />
          <Skeleton className="mt-1 h-4 w-72" />
        </CardHeader>
        <CardContent className="space-y-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display flex items-center gap-2 text-base">
          <Building2 className="size-4 text-muted-foreground" />
          Agency profile
        </CardTitle>
        <CardDescription>
          Your agency details appear on vouchers, invoices, quotes, and email
          signatures.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* General info */}
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="agencyName"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Agency name *</FormLabel>
                    <FormControl>
                      <Input placeholder="Tessera Travel DMC" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={"Calle Ejemplo 12\n28001 Madrid, Spain"}
                        rows={2}
                        {...field}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl>
                      <Input placeholder="+34 91 123 4567" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="info@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="website"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Website</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="taxId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tax / VAT ID</FormLabel>
                    <FormControl>
                      <Input placeholder="ES B12345678" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="logoUrl"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Logo URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://cdn.example.com/logo.png" {...field} />
                    </FormControl>
                    <FormDescription>
                      Paste a link to your agency logo. Upload it in Files &amp;
                      Media and paste the CDN URL here.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Separator />

            {/* Bank details */}
            <div>
              <div className="mb-4 flex items-center gap-2">
                <Landmark className="size-4 text-muted-foreground" />
                <h3 className="font-display text-sm font-semibold">
                  Bank details
                </h3>
              </div>
              <p className="mb-4 text-xs text-muted-foreground">
                Shown on invoices so clients know where to send payment.
              </p>
              <div className="grid gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="bankName"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Bank name</FormLabel>
                      <FormControl>
                        <Input placeholder="Banco Santander" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="iban"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IBAN</FormLabel>
                      <FormControl>
                        <Input placeholder="ES12 3456 7890 1234 5678 90" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="bic"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>BIC / SWIFT</FormLabel>
                      <FormControl>
                        <Input placeholder="BSCHESMMXXX" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Separator />

            {/* Payment terms */}
            <div>
              <div className="mb-4 flex items-center gap-2">
                <Globe className="size-4 text-muted-foreground" />
                <h3 className="font-display text-sm font-semibold">
                  Invoice defaults
                </h3>
              </div>
              <FormField
                control={form.control}
                name="paymentTerms"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Default payment terms</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Payment is due within 30 days of invoice date..."
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      This text appears on every invoice PDF.
                    </FormDescription>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="termsAndConditions"
                render={({ field }) => (
                  <FormItem className="mt-4">
                    <FormLabel>Booking terms &amp; conditions</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Cancellation policy, deposit conditions, liability, etc."
                        rows={6}
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Attached to deposit and installment invoices generated
                      from a file&apos;s payment schedule.
                    </FormDescription>
                  </FormItem>
                )}
              />
            </div>

            {/* Save button */}
            <div className="flex justify-end">
              <Button
                type="submit"
                disabled={form.formState.isSubmitting}
              >
                {form.formState.isSubmitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Saving…
                  </>
                ) : (
                  <>
                    <Save className="size-4" />
                    Save profile
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
