import { useAction } from "convex/react";
import { useEffect, useState } from "react";
import { CheckCircle2, Clock, XCircle, RefreshCw, Mail, ExternalLink } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import PageHeader from "@/components/page-header.tsx";
import AgencyProfileForm from "./_components/agency-profile-form.tsx";

type SenderIdentity = {
  id: string;
  value: string;
  type: "email" | "domain";
  status: "pending" | "verified" | "failed";
  createdAt: string;
};

const STATUS_CONFIG = {
  verified: {
    icon: CheckCircle2,
    label: "Verified",
    className: "text-green-600 dark:text-green-400",
    bg: "bg-green-50 dark:bg-green-950/40",
    border: "border-green-200 dark:border-green-800",
  },
  pending: {
    icon: Clock,
    label: "Pending verification",
    className: "text-amber-600 dark:text-amber-400",
    bg: "bg-amber-50 dark:bg-amber-950/40",
    border: "border-amber-200 dark:border-amber-800",
  },
  failed: {
    icon: XCircle,
    label: "Verification failed",
    className: "text-destructive",
    bg: "bg-destructive/5",
    border: "border-destructive/20",
  },
} as const;

function IdentityCard({ identity }: { identity: SenderIdentity }) {
  const cfg = STATUS_CONFIG[identity.status];
  const StatusIcon = cfg.icon;

  return (
    <div
      className={cn(
        "flex flex-wrap items-center justify-between gap-3 rounded-lg border p-4",
        cfg.bg,
        cfg.border,
      )}
    >
      <div className="flex items-center gap-3">
        <StatusIcon className={cn("size-5 shrink-0", cfg.className)} />
        <div>
          <p className="font-medium">{identity.value}</p>
          <p className="text-xs text-muted-foreground capitalize">
            {identity.type} · Added{" "}
            {new Date(identity.createdAt).toLocaleDateString()}
          </p>
        </div>
      </div>
      <span
        className={cn(
          "rounded-full px-2.5 py-1 text-xs font-medium",
          cfg.className,
          cfg.bg,
        )}
      >
        {cfg.label}
      </span>
    </div>
  );
}

export default function SettingsPage() {
  const listIdentities = useAction(api.email.identities.list);
  const [identities, setIdentities] = useState<SenderIdentity[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    try {
      const result = await listIdentities({});
      setIdentities(result);
    } catch {
      setIdentities([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const verifiedCount = identities?.filter((i) => i.status === "verified").length ?? 0;
  const hasVerified = verifiedCount > 0;

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        eyebrow="Configuration"
        title="Settings"
        description="Manage email sender addresses and app configuration."
      />

      <div className="space-y-6">
        {/* Agency profile */}
        <AgencyProfileForm />

        {/* Email sender card */}
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div>
                <CardTitle className="font-display flex items-center gap-2 text-base">
                  <Mail className="size-4 text-muted-foreground" />
                  Email sender identities
                </CardTitle>
                <CardDescription className="mt-1">
                  Emails (vouchers, invoices, itineraries) are sent from a
                  verified address. At least one verified identity is required
                  to send emails.
                </CardDescription>
              </div>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => load(true)}
                disabled={loading || refreshing}
                className="shrink-0"
              >
                <RefreshCw
                  className={cn("size-4", refreshing && "animate-spin")}
                />
                Refresh
              </Button>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* Status summary */}
            {!loading && identities !== null && (
              <div
                className={cn(
                  "flex items-center gap-2 rounded-md p-3 text-sm",
                  hasVerified
                    ? "bg-green-50 text-green-800 dark:bg-green-950/40 dark:text-green-300"
                    : "bg-amber-50 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300",
                )}
              >
                {hasVerified ? (
                  <CheckCircle2 className="size-4 shrink-0" />
                ) : (
                  <Clock className="size-4 shrink-0" />
                )}
                {hasVerified
                  ? `${verifiedCount} verified sender${verifiedCount > 1 ? "s" : ""} — emails are ready to send.`
                  : identities.length === 0
                    ? "No sender identities found. Add one in the Emails tab to start sending."
                    : "No verified senders yet. Check your inbox for the verification link."}
              </div>
            )}

            {/* Identity list */}
            {loading ? (
              <div className="space-y-3">
                <Skeleton className="h-14 w-full" />
                <Skeleton className="h-14 w-full" />
              </div>
            ) : identities && identities.length > 0 ? (
              <div className="space-y-2">
                {identities.map((identity) => (
                  <IdentityCard key={identity.id} identity={identity} />
                ))}
              </div>
            ) : null}

            {/* CTA to platform */}
            <div className="rounded-md border border-dashed p-4 text-center">
              <p className="text-sm text-muted-foreground">
                Add or manage sender addresses in the Hercules platform.
              </p>
              <a
                href="https://hercules.app"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
              >
                Open Emails settings
                <ExternalLink className="size-3.5" />
              </a>
            </div>
          </CardContent>
        </Card>

        {/* About card */}
        <Card>
          <CardHeader>
            <CardTitle className="font-display text-base">About Tessera</CardTitle>
            <CardDescription>Groups &amp; MICE backoffice</CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="space-y-2 text-sm">
              {[
                ["Version", "1.0.0"],
                ["Environment", "Production"],
                ["Base currency", "EUR"],
              ].map(([label, value]) => (
                <div key={label} className="flex gap-4">
                  <dt className="w-36 shrink-0 text-muted-foreground">{label}</dt>
                  <dd className="font-medium">{value}</dd>
                </div>
              ))}
            </dl>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
