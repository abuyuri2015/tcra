import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { CheckCircle2, Circle, Loader2, StickyNote } from "lucide-react";
import { format, parseISO, isPast } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { cn } from "@/lib/utils.ts";
import type { DashboardTask } from "@/convex/tasks.ts";

function TaskItem({ task, overdue }: { task: DashboardTask; overdue?: boolean }) {
  return (
    <Link
      to={`/files/${task.fileId}?tab=tasks`}
      className="flex items-start gap-3 rounded-md px-3 py-2.5 transition-colors hover:bg-secondary/50"
    >
      <div className="mt-0.5 shrink-0">
        {task.status === "in_progress" ? (
          <Loader2 className="size-4 text-blue-500 animate-spin" />
        ) : (
          <Circle className="size-4 text-muted-foreground" />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{task.title}</p>
        <p className="truncate text-xs text-muted-foreground">
          {task.fileReference} · {task.fileTitle}
        </p>
        {overdue && task.notes && (
          <div className="mt-1 flex items-start gap-1 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive">
            <StickyNote className="mt-0.5 size-3 shrink-0" />
            <span className="line-clamp-2">{task.notes}</span>
          </div>
        )}
      </div>
      {task.dueDate && (
        <span
          className={cn(
            "shrink-0 text-xs",
            overdue ? "text-destructive font-medium" : "text-muted-foreground",
          )}
        >
          {format(parseISO(task.dueDate), "d MMM")}
        </span>
      )}
    </Link>
  );
}

export default function DashboardTasksPanel() {
  const data = useQuery(api.tasks.upcoming, {});

  const hasTasks =
    data !== undefined &&
    (data.overdue.length > 0 || data.upcoming.length > 0);

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between pb-3">
        <CardTitle className="flex items-center gap-2 font-display text-base">
          <CheckCircle2 className="size-4 text-muted-foreground" />
          Tasks &amp; follow-ups
        </CardTitle>
        {hasTasks && (
          <Button asChild variant="ghost" size="sm">
            <Link to="/files">All files</Link>
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-1">
        {data === undefined ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))
        ) : !hasTasks ? (
          <p className="py-8 text-center text-sm text-muted-foreground">
            No upcoming tasks.
          </p>
        ) : (
          <>
            {data.overdue.length > 0 && (
              <div>
                <p className="px-3 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-widest text-destructive">
                  Overdue · {data.overdue.length}
                </p>
                {data.overdue.map((t) => (
                  <TaskItem key={t._id} task={t} overdue />
                ))}
              </div>
            )}
            {data.upcoming.length > 0 && (
              <div>
                <p className="px-3 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                  Upcoming · {data.upcoming.length}
                </p>
                {data.upcoming.map((t) => (
                  <TaskItem key={t._id} task={t} />
                ))}
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
