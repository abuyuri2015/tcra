import { useNavigate } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import {
  BadgeEuro,
  Bell,
  BellRing,
  CalendarClock,
  AlertTriangle,
  ArrowRightLeft,
  ClipboardList,
  MessageSquarePlus,
  Building2,
  ListChecks,
  Newspaper,
  CheckCheck,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Button } from "@/components/ui/button.tsx";
import { cn } from "@/lib/utils.ts";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";

type Notification = Doc<"notifications">;

function notificationIcon(type: Notification["type"]) {
  switch (type) {
    case "task_due_today":
      return <CalendarClock className="size-4 text-amber-500" />;
    case "task_overdue":
      return <AlertTriangle className="size-4 text-destructive" />;
    case "file_status_changed":
      return <ArrowRightLeft className="size-4 text-blue-500" />;
    case "task_assigned":
      return <ClipboardList className="size-4 text-primary" />;
    case "modification_requested":
      return <MessageSquarePlus className="size-4 text-chart-4" />;
    case "modification_responded":
      return <Building2 className="size-4 text-chart-3" />;
    case "offer_selection_submitted":
      return <ListChecks className="size-4 text-chart-2" />;
    case "daily_digest":
      return <Newspaper className="size-4 text-chart-1" />;
    case "pending_response_followup":
      return <BellRing className="size-4 text-chart-2" />;
    case "payment_overdue":
      return <BadgeEuro className="size-4 text-destructive" />;
  }
}

function NotificationRow({
  notification,
  onNavigate,
}: {
  notification: Notification;
  onNavigate: (linkTo: string, id: Notification["_id"]) => void;
}) {
  const timeAgo = formatDistanceToNow(new Date(notification.timestamp), {
    addSuffix: true,
  });

  return (
    <button
      type="button"
      onClick={() => onNavigate(notification.linkTo, notification._id)}
      className={cn(
        "flex w-full items-start gap-3 rounded-md border px-3 py-2.5 text-left transition-colors cursor-pointer",
        !notification.isRead
          ? "border-destructive/30 bg-destructive/5 hover:bg-destructive/10"
          : "hover:bg-secondary/50",
      )}
    >
      <span className="mt-0.5 shrink-0">{notificationIcon(notification.type)}</span>
      <div className="min-w-0 flex-1">
        <p className={cn("text-sm leading-snug", !notification.isRead && "font-medium")}>
          {notification.title}
        </p>
        <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">
          {notification.body}
        </p>
        <p className="mt-1 text-[11px] text-muted-foreground/70">{timeAgo}</p>
      </div>
      {!notification.isRead && (
        <span className="mt-2 size-2 shrink-0 rounded-full bg-destructive" />
      )}
    </button>
  );
}

export default function DashboardNotificationsPanel() {
  const notifications = useQuery(api.notifications.list);
  const markAsRead = useMutation(api.notifications.markAsRead);
  const markAllAsRead = useMutation(api.notifications.markAllAsRead);
  const navigate = useNavigate();

  const unread = notifications?.filter((n) => !n.isRead) ?? [];
  const unreadCount = unread.length;
  // Show unread first; if there are none, show a handful of recent read ones
  // so the panel isn't empty right after everything's been cleared.
  const toShow = notifications
    ? unreadCount > 0
      ? unread.slice(0, 8)
      : notifications.slice(0, 5)
    : undefined;

  const handleNavigate = async (linkTo: string, id: Notification["_id"]) => {
    await markAsRead({ id });
    navigate(linkTo);
  };

  return (
    <Card className={cn(unreadCount > 0 && "border-destructive/30 bg-destructive/5")}>
      <CardHeader className="flex-row items-center justify-between pb-3">
        <CardTitle className="flex items-center gap-2 font-display text-base">
          <Bell className={cn("size-4", unreadCount > 0 ? "text-destructive" : "text-muted-foreground")} />
          Notifications
          {unreadCount > 0 && (
            <span className="rounded-full bg-destructive/15 px-2 py-0.5 text-xs font-medium text-destructive">
              {unreadCount}
            </span>
          )}
        </CardTitle>
        {unreadCount > 0 && (
          <Button variant="ghost" size="sm" onClick={() => markAllAsRead({})}>
            <CheckCheck className="size-3.5" />
            Mark all read
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-2">
        {toShow === undefined ? (
          Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)
        ) : toShow.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <Bell className="size-6 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">No notifications yet.</p>
          </div>
        ) : (
          toShow.map((n) => (
            <NotificationRow key={n._id} notification={n} onNavigate={handleNavigate} />
          ))
        )}
      </CardContent>
    </Card>
  );
}
