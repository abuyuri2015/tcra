import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import {
  BellRing,
  Building2,
  Clock,
  Loader2,
  MailWarning,
  Send,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

// ── Offer follow-up row ──────────────────────────────────────────────────────

function OfferFollowUpRow({
  file,
}: {
  file: {
    _id: Id<"groupFiles">;
    reference: string;
    title: string;
    clientName: string;
    lastOfferLinkSentAt?: string;
  };
}) {
  const [dismissing, setDismissing] = useState(false);
  const dismiss = useMutation(api.followUps.dismissOfferFollowUp);

  const handleDismiss = async () => {
    setDismissing(true);
    try {
      await dismiss({ groupFileId: file._id });
      toast.success("Follow-up dismissed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not dismiss this follow-up.";
      toast.error(message);
    } finally {
      setDismissing(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border px-3 py-2.5">
      <Link to={`/files/${file._id}?tab=offers`} className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <MailWarning className="size-3.5 shrink-0 text-chart-2" />
          <p className="truncate text-sm font-medium">{file.clientName}</p>
        </div>
        <p className="truncate text-xs text-muted-foreground">
          {file.reference} · {file.title}
          {file.lastOfferLinkSentAt
            ? ` · sent ${formatDistanceToNow(new Date(file.lastOfferLinkSentAt), { addSuffix: true })}`
            : ""}
        </p>
      </Link>
      <div className="flex shrink-0 items-center gap-1.5">
        <Button asChild size="sm" variant="secondary">
          <Link to={`/files/${file._id}?tab=offers`}>
            <Send className="size-3.5" />
            Resend
          </Link>
        </Button>
        <Button
          size="sm"
          variant="ghost"
          disabled={dismissing}
          onClick={handleDismiss}
          aria-label="Dismiss follow-up"
        >
          {dismissing ? <Loader2 className="size-3.5 animate-spin" /> : <X className="size-3.5" />}
        </Button>
      </div>
    </div>
  );
}

// ── Modification-request follow-up row ───────────────────────────────────────

function ModificationFollowUpRow({
  request,
}: {
  request: {
    _id: Id<"modificationRequests">;
    groupFileId: Id<"groupFiles">;
    fileReference: string;
    fileTitle: string;
    supplierName: string;
    hotelEmailSentAt?: string;
  };
}) {
  const [resending, setResending] = useState(false);
  const [dismissing, setDismissing] = useState(false);
  const resend = useMutation(api.modificationRequests.resendToHotel);
  const dismiss = useMutation(api.modificationRequests.dismissFollowUp);

  const handleResend = async () => {
    setResending(true);
    try {
      await resend({ requestId: request._id });
      toast.success(`Resent the request to ${request.supplierName}`);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not resend this request.";
      toast.error(message);
    } finally {
      setResending(false);
    }
  };

  const handleDismiss = async () => {
    setDismissing(true);
    try {
      await dismiss({ requestId: request._id });
      toast.success("Follow-up dismissed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not dismiss this follow-up.";
      toast.error(message);
    } finally {
      setDismissing(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border px-3 py-2.5">
      <Link to={`/files/${request.groupFileId}`} className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <Building2 className="size-3.5 shrink-0 text-chart-2" />
          <p className="truncate text-sm font-medium">{request.supplierName}</p>
        </div>
        <p className="truncate text-xs text-muted-foreground">
          {request.fileReference} · {request.fileTitle}
          {request.hotelEmailSentAt
            ? ` · sent ${formatDistanceToNow(new Date(request.hotelEmailSentAt), { addSuffix: true })}`
            : ""}
        </p>
      </Link>
      <div className="flex shrink-0 items-center gap-1.5">
        <Button size="sm" variant="secondary" disabled={resending} onClick={handleResend}>
          {resending ? <Loader2 className="size-3.5 animate-spin" /> : <Send className="size-3.5" />}
          Resend
        </Button>
        <Button
          size="sm"
          variant="ghost"
          disabled={dismissing}
          onClick={handleDismiss}
          aria-label="Dismiss follow-up"
        >
          {dismissing ? <Loader2 className="size-3.5 animate-spin" /> : <X className="size-3.5" />}
        </Button>
      </div>
    </div>
  );
}

// ── Main panel ────────────────────────────────────────────────────────────────

export default function NeedsFollowUpPanel() {
  const data = useQuery(api.followUps.listPending, {});

  const totalCount = data ? data.offers.length + data.modifications.length : undefined;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between pb-3">
        <CardTitle className="flex items-center gap-2 font-display text-base">
          <BellRing className="size-4 text-muted-foreground" />
          Needs follow-up
        </CardTitle>
        {totalCount !== undefined && totalCount > 0 && (
          <span className="rounded-full bg-chart-2/15 px-2 py-0.5 text-xs font-medium text-chart-2">
            {totalCount}
          </span>
        )}
      </CardHeader>
      <CardContent className="space-y-2">
        {data === undefined ? (
          Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)
        ) : totalCount === 0 ? (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <Clock className="size-6 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">
              Nothing waiting more than 7 days — all caught up.
            </p>
          </div>
        ) : (
          <>
            {data.offers.map((file) => (
              <OfferFollowUpRow key={file._id} file={file} />
            ))}
            {data.modifications.map((request) => (
              <ModificationFollowUpRow key={request._id} request={request} />
            ))}
          </>
        )}
      </CardContent>
    </Card>
  );
}
