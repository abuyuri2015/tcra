import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import {
  AlertTriangle,
  CheckCircle2,
  Circle,
  Clock,
  Filter,
  ListTodo,
  Loader2,
  StickyNote,
  User,
} from "lucide-react";
import { format, parseISO, isPast, isToday } from "date-fns";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { DashboardTask } from "@/convex/tasks.ts";
import PageHeader from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";

// ── Types ────────────────────────────────────────────────────────────────────

type TaskStatus = "open" | "in_progress" | "done";
type StatusFilter = "active" | "open" | "in_progress" | "done" | "overdue";

// ── Status helpers ───────────────────────────────────────────────────────────

function StatusIcon({ status }: { status: TaskStatus }) {
  if (status === "done")
    return <CheckCircle2 className="size-4 shrink-0 text-emerald-500" />;
  if (status === "in_progress")
    return <Loader2 className="size-4 shrink-0 animate-spin text-blue-500" />;
  return <Circle className="size-4 shrink-0 text-muted-foreground" />;
}

const STATUS_RING: Record<TaskStatus, string> = {
  open: "border-l-muted-foreground/40",
  in_progress: "border-l-blue-400",
  done: "border-l-emerald-400",
};

function isOverdue(task: DashboardTask): boolean {
  return task.status !== "done" && !!task.dueDate && isPast(parseISO(task.dueDate));
}

function isDueToday(task: DashboardTask): boolean {
  return task.status !== "done" && !!task.dueDate && isToday(parseISO(task.dueDate));
}

// ── Summary card ─────────────────────────────────────────────────────────────

function StatCard({
  label,
  value,
  accent,
  icon: Icon,
  active,
  onClick,
}: {
  label: string;
  value: number | undefined;
  accent?: "red" | "blue" | "green" | "amber";
  icon: typeof ListTodo;
  active?: boolean;
  onClick?: () => void;
}) {
  const accentClass =
    accent === "red"
      ? "border-red-300/40 bg-red-50/60 dark:bg-red-950/20"
      : accent === "blue"
        ? "border-blue-300/40 bg-blue-50/60 dark:bg-blue-950/20"
        : accent === "green"
          ? "border-emerald-300/40 bg-emerald-50/60 dark:bg-emerald-950/20"
          : accent === "amber"
            ? "border-amber-300/40 bg-amber-50/60 dark:bg-amber-950/20"
            : "";
  const iconClass =
    accent === "red"
      ? "text-red-600 dark:text-red-400"
      : accent === "blue"
        ? "text-blue-600 dark:text-blue-400"
        : accent === "green"
          ? "text-emerald-600 dark:text-emerald-400"
          : accent === "amber"
            ? "text-amber-600 dark:text-amber-400"
            : "text-muted-foreground";

  return (
    <Card
      className={cn(
        "cursor-pointer gap-2 p-4 transition-all",
        accentClass,
        active && "ring-2 ring-ring ring-offset-2",
      )}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <p className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
        <Icon className={cn("size-4", iconClass)} />
      </div>
      {value === undefined ? (
        <Skeleton className="h-8 w-16" />
      ) : (
        <p className={cn("font-display text-2xl font-semibold", iconClass)}>{value}</p>
      )}
    </Card>
  );
}

// ── Task row ─────────────────────────────────────────────────────────────────

function TaskRow({ task }: { task: DashboardTask }) {
  const setStatus = useMutation(api.tasks.setStatus);

  const overdue = isOverdue(task);
  const dueToday = isDueToday(task);

  const cycleStatus = async () => {
    const next: Record<TaskStatus, TaskStatus> = {
      open: "in_progress",
      in_progress: "done",
      done: "open",
    };
    try {
      await setStatus({ id: task._id, status: next[task.status] });
      if (next[task.status] === "done") {
        toast.success("Task completed");
      }
    } catch {
      toast.error("Could not update task");
    }
  };

  return (
    <div
      className={cn(
        "flex items-start gap-3 rounded-md border-l-2 bg-card px-3 py-3 shadow-sm transition-colors",
        STATUS_RING[task.status],
        overdue && "border-l-red-500 bg-red-50/40 dark:bg-red-950/15",
        task.status === "done" && "opacity-60",
      )}
    >
      {/* Status toggle */}
      <button
        type="button"
        onClick={cycleStatus}
        title="Click to advance status"
        className="mt-0.5 cursor-pointer transition-transform hover:scale-110"
      >
        <StatusIcon status={task.status} />
      </button>

      {/* Content */}
      <div className="min-w-0 flex-1">
        <p
          className={cn(
            "text-sm font-medium leading-snug",
            task.status === "done" && "line-through text-muted-foreground",
          )}
        >
          {task.title}
        </p>
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
          {/* File link */}
          <Link
            to={`/files/${task.fileId}?tab=tasks`}
            className="flex items-center gap-1 text-primary hover:underline"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="font-mono">{task.fileReference}</span>
            <span className="max-w-[160px] truncate">{task.fileTitle}</span>
          </Link>

          {/* Due date */}
          {task.dueDate && (
            <span
              className={cn(
                "flex items-center gap-1",
                overdue && "font-medium text-red-600 dark:text-red-400",
                dueToday && !overdue && "font-medium text-amber-600 dark:text-amber-400",
              )}
            >
              <Clock className="size-3" />
              {format(parseISO(task.dueDate), "d MMM yyyy")}
              {overdue && " · overdue"}
              {dueToday && !overdue && " · today"}
            </span>
          )}

          {/* Assignee */}
          {task.assignee && (
            <span className="flex items-center gap-1">
              <User className="size-3" />
              {task.assignee}
            </span>
          )}
        </div>

        {/* Note */}
        {task.notes && (
          <div className="mt-1.5 flex items-start gap-1.5 rounded-md bg-muted/60 px-2 py-1.5 text-xs text-muted-foreground">
            <StickyNote className="mt-0.5 size-3 shrink-0" />
            <span className="whitespace-pre-wrap">{task.notes}</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Page ─────────────────────────────────────────────────────────────────────

export default function TasksPage() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("active");
  const [assigneeFilter, setAssigneeFilter] = useState("all");

  // Fetch all tasks for "active" (open + in_progress) or a specific status
  const queryStatus = statusFilter === "active" || statusFilter === "overdue"
    ? undefined
    : statusFilter;
  const tasks = useQuery(api.tasks.listAll, { status: queryStatus });

  // Derive counts and unique assignees
  const { filtered, counts, assignees } = useMemo(() => {
    if (!tasks) return { filtered: undefined, counts: undefined, assignees: [] };

    const now = new Date().toISOString();
    const openCount = tasks.filter((t) => t.status === "open").length;
    const inProgressCount = tasks.filter((t) => t.status === "in_progress").length;
    const doneCount = tasks.filter((t) => t.status === "done").length;
    const overdueCount = tasks.filter(
      (t) => t.status !== "done" && t.dueDate && t.dueDate < now,
    ).length;

    // Apply client-side filters
    let result = tasks;

    if (statusFilter === "active") {
      result = result.filter((t) => t.status !== "done");
    } else if (statusFilter === "overdue") {
      result = result.filter(
        (t) => t.status !== "done" && t.dueDate && t.dueDate < now,
      );
    }

    if (assigneeFilter !== "all") {
      if (assigneeFilter === "unassigned") {
        result = result.filter((t) => !t.assignee);
      } else {
        result = result.filter((t) => t.assignee === assigneeFilter);
      }
    }

    const uniqueAssignees = [
      ...new Set(tasks.map((t) => t.assignee).filter(Boolean) as string[]),
    ].sort();

    return {
      filtered: result,
      counts: {
        active: openCount + inProgressCount,
        open: openCount,
        inProgress: inProgressCount,
        done: doneCount,
        overdue: overdueCount,
      },
      assignees: uniqueAssignees,
    };
  }, [tasks, statusFilter, assigneeFilter]);

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <PageHeader
        eyebrow="Operations"
        title="Tasks"
        description="All tasks across every group file. Track follow-ups, deadlines, and assignments."
      />

      {/* Summary stat cards */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Active"
          value={counts?.active}
          icon={ListTodo}
          active={statusFilter === "active"}
          onClick={() => setStatusFilter("active")}
        />
        <StatCard
          label="Overdue"
          value={counts?.overdue}
          icon={AlertTriangle}
          accent={counts && counts.overdue > 0 ? "red" : undefined}
          active={statusFilter === "overdue"}
          onClick={() => setStatusFilter("overdue")}
        />
        <StatCard
          label="In progress"
          value={counts?.inProgress}
          icon={Loader2}
          accent="blue"
          active={statusFilter === "in_progress"}
          onClick={() => setStatusFilter("in_progress")}
        />
        <StatCard
          label="Done"
          value={counts?.done}
          icon={CheckCircle2}
          accent="green"
          active={statusFilter === "done"}
          onClick={() => setStatusFilter("done")}
        />
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <Filter className="size-4 shrink-0 text-muted-foreground" />
          <Select
            value={statusFilter}
            onValueChange={(v) => setStatusFilter(v as StatusFilter)}
          >
            <SelectTrigger className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active (open + in progress)</SelectItem>
              <SelectItem value="overdue">Overdue only</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in_progress">In progress</SelectItem>
              <SelectItem value="done">Done</SelectItem>
            </SelectContent>
          </Select>
          <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
            <SelectTrigger className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All assignees</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {assignees.map((a) => (
                <SelectItem key={a} value={a}>
                  {a}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {(statusFilter !== "active" || assigneeFilter !== "all") && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setStatusFilter("active");
                setAssigneeFilter("all");
              }}
            >
              Clear filters
            </Button>
          )}
        </div>
      </Card>

      {/* Task list */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="font-display text-base">
            {statusFilter === "active"
              ? "Active tasks"
              : statusFilter === "overdue"
                ? "Overdue tasks"
                : statusFilter === "open"
                  ? "Open tasks"
                  : statusFilter === "in_progress"
                    ? "In-progress tasks"
                    : "Done tasks"}
            {filtered && (
              <span className="ml-2 text-sm font-normal text-muted-foreground">
                ({filtered.length})
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filtered === undefined ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  {statusFilter === "overdue" ? <AlertTriangle /> : <CheckCircle2 />}
                </EmptyMedia>
                <EmptyTitle>
                  {statusFilter === "overdue"
                    ? "No overdue tasks"
                    : statusFilter === "done"
                      ? "No completed tasks yet"
                      : "No tasks found"}
                </EmptyTitle>
                <EmptyDescription>
                  {statusFilter === "overdue"
                    ? "Great, all your tasks are on schedule."
                    : "Tasks are created from within a group file. Open a file and add tasks there."}
                </EmptyDescription>
              </EmptyHeader>
              {statusFilter !== "overdue" && statusFilter !== "done" && (
                <EmptyContent>
                  <Button asChild size="sm" variant="secondary">
                    <Link to="/files">Go to group files</Link>
                  </Button>
                </EmptyContent>
              )}
            </Empty>
          ) : (
            <div className="space-y-2">
              {filtered.map((task) => (
                <TaskRow key={task._id} task={task} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
