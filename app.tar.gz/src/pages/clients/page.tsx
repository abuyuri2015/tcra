import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import {
  Mail,
  MoreHorizontal,
  Pencil,
  Phone,
  Plus,
  Search,
  Trash2,
  Users,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.js";
import PageHeader from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { useDebounce } from "@/hooks/use-debounce.ts";
import ClientFormDialog from "./_components/client-form-dialog.tsx";
import ClientAiImport from "./_components/client-ai-import.tsx";
import ClientWebsiteImport from "./_components/client-website-import.tsx";
import {
  type ClientKind,
  CLIENT_KIND_OPTIONS,
  clientKindLabel,
  ClientKindIcon,
  CLIENT_KIND_CHIP,
} from "./_lib/categories.tsx";

// ── Client card ───────────────────────────────────────────────────────────────

function ClientCard({
  client,
  onEdit,
}: {
  client: Doc<"clients">;
  onEdit: (c: Doc<"clients">) => void;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const remove = useMutation(api.clients.remove);

  const handleDelete = async () => {
    try {
      await remove({ id: client._id });
      toast.success("Client deleted");
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not delete client.";
      toast.error(msg);
    }
  };

  return (
    <>
      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {client.name}?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove this client from your directory. Existing group
              files will not be affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Link to={`/clients/${client._id}`}>
        <Card className="group transition-shadow hover:shadow-md cursor-pointer">
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-start gap-3">
                <div className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg bg-muted">
                  <ClientKindIcon kind={client.kind} className="size-4 text-muted-foreground" />
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="truncate text-sm font-semibold">{client.name}</p>
                    <span
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                        CLIENT_KIND_CHIP[client.kind as ClientKind],
                      )}
                    >
                      {clientKindLabel(client.kind)}
                    </span>
                  </div>

                  {(client.city || client.country) && (
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {[client.city, client.country].filter(Boolean).join(", ")}
                    </p>
                  )}

                  <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    {client.contactName && (
                      <span className="flex items-center gap-1">
                        <UserRound className="size-3 shrink-0" />
                        {client.contactName}
                      </span>
                    )}
                    {client.email && (
                      <a
                        href={`mailto:${client.email}`}
                        className="flex items-center gap-1 hover:text-foreground hover:underline"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Mail className="size-3 shrink-0" />
                        {client.email}
                      </a>
                    )}
                    {client.phone && (
                      <a
                        href={`tel:${client.phone}`}
                        className="flex items-center gap-1 hover:text-foreground hover:underline"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Phone className="size-3 shrink-0" />
                        {client.phone}
                      </a>
                    )}
                  </div>

                  {client.notes && (
                    <p className="mt-1.5 text-xs text-muted-foreground italic line-clamp-2">
                      {client.notes}
                    </p>
                  )}
                </div>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-7 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <MoreHorizontal className="size-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="end"
                  onClick={(e) => e.stopPropagation()}
                >
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.preventDefault();
                      onEdit(client);
                    }}
                  >
                    <Pencil className="size-4" />
                    Edit
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive"
                    onClick={(e) => {
                      e.preventDefault();
                      setConfirmDelete(true);
                    }}
                  >
                    <Trash2 className="size-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardContent>
        </Card>
      </Link>
    </>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function ClientsPage() {
  const [searchInput, setSearchInput] = useState("");
  const [kindFilter, setKindFilter] = useState<ClientKind | "all">("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Doc<"clients"> | undefined>();

  const [debouncedSearch] = useDebounce(searchInput, 300);

  const allClients = useQuery(api.clients.list, {
    kind: kindFilter === "all" ? undefined : kindFilter,
  });

  const searchResults = useQuery(
    api.clients.search,
    debouncedSearch.trim()
      ? { query: debouncedSearch, kind: kindFilter === "all" ? undefined : kindFilter }
      : "skip",
  );

  const clients = debouncedSearch.trim() ? searchResults : allClients;

  const openCreate = () => {
    setEditingClient(undefined);
    setDialogOpen(true);
  };

  const openEdit = (c: Doc<"clients">) => {
    setEditingClient(c);
    setDialogOpen(true);
  };

  return (
    <>
      <ClientFormDialog
        key={editingClient?._id ?? "new"}
        client={editingClient}
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
      />

      <div className="space-y-6">
        <PageHeader
          eyebrow="Clients"
          title="Client directory"
          description="Individuals and companies you work with. Link contacts under companies to see grouped bookings and invoices."
          actions={
            <div className="flex gap-2">
              <ClientWebsiteImport />
              <ClientAiImport />
              <Button onClick={openCreate}>
                <Plus className="size-4" />
                Add client
              </Button>
            </div>
          }
        />

        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search clients…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pl-9"
            />
          </div>

          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setKindFilter("all")}
              className={cn(
                "rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                kindFilter === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:text-foreground",
              )}
            >
              All
            </button>
            {CLIENT_KIND_OPTIONS.map((o) => (
              <button
                key={o.value}
                type="button"
                onClick={() => setKindFilter(o.value)}
                className={cn(
                  "flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                  kindFilter === o.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
              >
                <ClientKindIcon kind={o.value} className="size-3" />
                {o.label}
              </button>
            ))}
          </div>
        </div>

        {/* Count */}
        {clients !== undefined && clients.length > 0 && (
          <p className="text-xs text-muted-foreground">
            {clients.length} client{clients.length !== 1 ? "s" : ""}
            {kindFilter !== "all" && ` · ${clientKindLabel(kindFilter)}`}
          </p>
        )}

        {/* List */}
        {clients === undefined ? (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-28 w-full" />
            ))}
          </div>
        ) : clients.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Users />
              </EmptyMedia>
              <EmptyTitle>
                {debouncedSearch.trim() ? "No clients found" : "No clients yet"}
              </EmptyTitle>
              <EmptyDescription>
                {debouncedSearch.trim()
                  ? "Try a different search term or clear the filters."
                  : "Add individuals or companies to build your client directory."}
              </EmptyDescription>
            </EmptyHeader>
            {!debouncedSearch.trim() && (
              <EmptyContent>
                <Button size="sm" onClick={openCreate}>
                  <Plus className="size-4" />
                  Add first client
                </Button>
              </EmptyContent>
            )}
          </Empty>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {clients.map((c) => (
              <ClientCard key={c._id} client={c} onEdit={openEdit} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}
