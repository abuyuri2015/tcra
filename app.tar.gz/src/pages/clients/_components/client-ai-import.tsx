/**
 * AI import panel for the Clients page.
 *
 * Lets the user paste any text — an email thread, a spreadsheet dump, a list
 * of names and contact details — and have AI extract structured client
 * records for bulk import, previewing them before confirming.
 */
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import AiImportDialog, { PreviewCard, PreviewField } from "@/components/ai-import-dialog.tsx";
import { clientKindLabel } from "../_lib/categories.tsx";

type ClientData = {
  kind: "individual" | "company";
  name: string;
  contactName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
  taxId?: string;
  notes?: string;
};

function ClientsPreview({ clients }: { clients: ClientData[] }) {
  if (!clients || clients.length === 0) {
    return <p className="px-4 py-4 text-sm text-muted-foreground">No clients extracted.</p>;
  }
  return (
    <>
      {clients.map((c, i) => (
        <PreviewCard
          key={i}
          title={c.name || "Unnamed client"}
          subtitle={[clientKindLabel(c.kind), c.city, c.country].filter(Boolean).join(" · ")}
          defaultOpen={clients.length === 1}
        >
          <PreviewField label="Type" value={clientKindLabel(c.kind)} />
          <PreviewField label="Contact" value={c.contactName} />
          <PreviewField label="Email" value={c.email} />
          <PreviewField label="Phone" value={c.phone} />
          <PreviewField label="City" value={c.city} />
          <PreviewField label="Country" value={c.country} />
          <PreviewField label="Address" value={c.address} />
          <PreviewField label="Tax ID" value={c.taxId} />
          <PreviewField label="Notes" value={c.notes} />
        </PreviewCard>
      ))}
    </>
  );
}

export default function ClientAiImport() {
  const bulkCreate = useMutation(api.clients.bulkCreate);

  const handleImport = async (data: ClientData | ClientData[]) => {
    const clients = Array.isArray(data) ? data : [data];
    if (clients.length === 0) {
      toast.error("No clients to import.");
      return;
    }

    const sanitised = clients
      .filter((c) => c.name?.trim())
      .map((c) => ({
        kind: (c.kind === "company" ? "company" : "individual") as "individual" | "company",
        name: c.name,
        contactName: c.contactName,
        email: c.email,
        phone: c.phone,
        address: c.address,
        city: c.city,
        country: c.country,
        taxId: c.taxId,
        notes: c.notes,
      }));

    const result = await bulkCreate({ clients: sanitised });
    if (result.imported === 0 && result.skipped > 0) {
      toast.info(`All ${result.skipped} client(s) already exist — nothing imported.`);
    } else {
      toast.success(
        `Imported ${result.imported} client${result.imported !== 1 ? "s" : ""}` +
          (result.skipped > 0 ? ` (${result.skipped} skipped — already exist)` : ""),
      );
    }
  };

  return (
    <AiImportDialog
      type="clients"
      title="Import clients with AI"
      placeholder={`Paste client info — one or many:

John Smith — john.smith@gmail.com · +1 555 0100
Individual traveler, based in Chicago, IL.

---

Acme Corporate Events Ltd
Contact: Sarah Lee · sarah@acmecorp.com · +44 20 7000 0000
London, UK. Books annual incentive trips for their sales team.`}
      onImport={async (data) => handleImport(data as ClientData | ClientData[])}
      renderPreview={(data) => (
        <ClientsPreview clients={Array.isArray(data) ? (data as ClientData[]) : [data as ClientData]} />
      )}
    />
  );
}
