/**
 * Combined invoice dialog — pick multiple bookings for one client, preview
 * the combined totals, then download or email a single invoice PDF covering
 * all of them.
 */
import { useEffect, useState } from "react";
import { useAction, useQuery } from "convex/react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { AlertCircle, Loader2, Receipt, Send } from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import type { ClientGroupFile } from "@/convex/clients.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  generateCombinedInvoicePDF,
  generateCombinedInvoicePDFBase64,
  type AgencyProfilePDF,
  type CombinedInvoiceFileData,
} from "@/lib/pdf-generators.ts";
import { formatMoney } from "@/lib/domain.ts";
import { formatDateRange } from "@/lib/dates.ts";

type SenderIdentity = { id: string; value: string; type: string; status: string };

const emailSchema = z.object({
  from: z.string().min(1, "Select a sender address"),
  to: z.string().email("Enter a valid email address"),
  subject: z.string().min(1, "Subject is required"),
  body: z.string().min(1, "Message body is required"),
});
type EmailValues = z.output<typeof emailSchema>;

// ── Email step (mounted fresh each time it's shown, so default values are current) ──

function EmailStep({
  clientName,
  clientContactName,
  clientContactEmail,
  invoiceNumber,
  files,
  grandTotalEur,
  groupFileIds,
  senderIdentities,
  agency,
  onBack,
  onSent,
}: {
  clientName: string;
  clientContactName?: string;
  clientContactEmail?: string;
  invoiceNumber: string;
  files: CombinedInvoiceFileData[];
  grandTotalEur: number;
  groupFileIds: Id<"groupFiles">[];
  senderIdentities: SenderIdentity[];
  agency: AgencyProfilePDF;
  onBack: () => void;
  onSent: () => void;
}) {
  const [sending, setSending] = useState(false);
  const sendCombinedInvoice = useAction(api.email.send.sendCombinedInvoice);
  const verifiedSenders = senderIdentities.filter((s) => s.status === "verified");

  const defaultBody = `Dear ${clientContactName ?? clientName},

Please find attached a combined invoice covering ${files.length} booking${files.length !== 1 ? "s" : ""} for a total of ${formatMoney(grandTotalEur, "EUR")}.

Payment is due within 30 days. Please reference the invoice number on your bank transfer.

Kind regards,
Tessera Groups & MICE Team`;

  const form = useForm<EmailValues>({
    resolver: zodResolver(emailSchema),
    defaultValues: {
      from: verifiedSenders[0]?.value ?? "",
      to: clientContactEmail ?? "",
      subject: `Invoice ${invoiceNumber} – ${clientName}`,
      body: defaultBody,
    },
  });

  if (verifiedSenders.length === 0) {
    return (
      <>
        <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
          <AlertCircle className="mt-0.5 size-4 shrink-0" />
          <p>
            No verified sender found. Go to <strong>Settings → Email sender identities</strong> to verify one.
          </p>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onBack}>
            Back
          </Button>
        </DialogFooter>
      </>
    );
  }

  const onSubmit = async (values: EmailValues) => {
    setSending(true);
    try {
      const { base64, filename } = generateCombinedInvoicePDFBase64(
        clientName,
        files,
        invoiceNumber,
        agency,
      );
      await sendCombinedInvoice({
        from: values.from,
        to: values.to,
        subject: values.subject,
        body: values.body,
        pdfDataUri: base64,
        pdfFilename: filename,
        invoiceNumber,
        groupFileIds,
      });
      toast.success(`Invoice sent to ${values.to}`);
      onSent();
    } catch (err) {
      const message =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Failed to send email. Please try again.";
      toast.error(message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="from"
          render={({ field }) => (
            <FormItem>
              <FormLabel>From</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select sender address" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {verifiedSenders.map((s) => (
                    <SelectItem key={s.id} value={s.value}>{s.value}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="to"
          render={({ field }) => (
            <FormItem>
              <FormLabel>To (client email)</FormLabel>
              <FormControl>
                <Input placeholder="client@company.com" type="email" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="subject"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Subject</FormLabel>
              <FormControl><Input {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="body"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Message</FormLabel>
              <FormControl>
                <Textarea rows={7} className="resize-none text-sm" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={onBack} disabled={sending}>
            Back
          </Button>
          <Button type="submit" disabled={sending}>
            {sending ? (
              <><Loader2 className="size-4 animate-spin" />Sending…</>
            ) : (
              <><Send className="size-4" />Send invoice</>
            )}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

// ── Selection step ────────────────────────────────────────────────────────────

function SelectionStep({
  groupFiles,
  selected,
  onToggle,
  grandTotalEur,
  hasInvoiceData,
  onCancel,
  onDownload,
  onNext,
}: {
  groupFiles: ClientGroupFile[];
  selected: Set<Id<"groupFiles">>;
  onToggle: (id: Id<"groupFiles">) => void;
  grandTotalEur: number;
  hasInvoiceData: boolean;
  onCancel: () => void;
  onDownload: () => void;
  onNext: () => void;
}) {
  const selectedCount = selected.size;
  return (
    <>
      <div className="max-h-64 space-y-1 overflow-y-auto rounded-md border p-2">
        {groupFiles.map((f) => (
          <label
            key={f._id}
            className="flex cursor-pointer items-start gap-3 rounded-md px-2 py-2 hover:bg-muted/50"
          >
            <Checkbox
              checked={selected.has(f._id)}
              onCheckedChange={() => onToggle(f._id)}
              className="mt-0.5"
            />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{f.title}</p>
              <p className="truncate text-xs text-muted-foreground">
                {f.reference} · {formatDateRange(f.startDate, f.endDate)}
              </p>
            </div>
            <span className="shrink-0 text-sm font-medium tabular-nums">
              {formatMoney(f.totalIncomeEur, "EUR")}
            </span>
          </label>
        ))}
      </div>

      {selectedCount > 0 && hasInvoiceData && (
        <div className="flex items-center justify-between rounded-md bg-muted/60 px-3 py-2 text-sm">
          <span className="text-muted-foreground">
            {selectedCount} booking{selectedCount !== 1 ? "s" : ""} selected
          </span>
          <span className="font-semibold">{formatMoney(grandTotalEur, "EUR")}</span>
        </div>
      )}

      <DialogFooter>
        <Button variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="secondary" disabled={selectedCount === 0 || !hasInvoiceData} onClick={onDownload}>
          Download PDF
        </Button>
        <Button disabled={selectedCount === 0 || !hasInvoiceData} onClick={onNext}>
          <Send className="size-4" />
          Email invoice
        </Button>
      </DialogFooter>
    </>
  );
}

// ── Main dialog ───────────────────────────────────────────────────────────────

export default function CombinedInvoiceDialog({
  open,
  onClose,
  clientId,
  clientName,
  clientContactName,
  clientContactEmail,
  groupFiles,
}: {
  open: boolean;
  onClose: () => void;
  clientId: Id<"clients">;
  clientName: string;
  clientContactName?: string;
  clientContactEmail?: string;
  groupFiles: ClientGroupFile[];
}) {
  const [selected, setSelected] = useState<Set<Id<"groupFiles">>>(new Set());
  const [showEmail, setShowEmail] = useState(false);
  const [senderIdentities, setSenderIdentities] = useState<SenderIdentity[]>([]);

  const listIdentities = useAction(api.email.identities.list);
  const agencyProfile = useQuery(api.agencyProfile.get);

  const selectedIds = Array.from(selected);
  const invoiceData = useQuery(
    api.clients.getCombinedInvoiceData,
    selectedIds.length > 0 ? { clientId, groupFileIds: selectedIds } : "skip",
  );

  const invoiceNumber = `INV-COMB-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${clientId.slice(-5).toUpperCase()}`;

  // Fetch sender identities once when the dialog is opened.
  useEffect(() => {
    if (!open) return;
    listIdentities({}).then(setSenderIdentities).catch(() => setSenderIdentities([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const toggle = (id: Id<"groupFiles">) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const agency: AgencyProfilePDF = agencyProfile
    ? {
        agencyName: agencyProfile.agencyName,
        address: agencyProfile.address ?? undefined,
        phone: agencyProfile.phone ?? undefined,
        email: agencyProfile.email ?? undefined,
        website: agencyProfile.website ?? undefined,
        bankName: agencyProfile.bankName ?? undefined,
        iban: agencyProfile.iban ?? undefined,
        bic: agencyProfile.bic ?? undefined,
        paymentTerms: agencyProfile.paymentTerms ?? undefined,
        taxId: agencyProfile.taxId ?? undefined,
      }
    : null;

  const handleDownload = () => {
    if (!invoiceData || invoiceData.files.length === 0) return;
    generateCombinedInvoicePDF(clientName, invoiceData.files, invoiceNumber, agency);
    toast.success("Combined invoice downloaded");
  };

  const handleClose = () => {
    setSelected(new Set());
    setShowEmail(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <Receipt className="size-4 text-muted-foreground" />
            Combined invoice
          </DialogTitle>
          <DialogDescription>
            Select the bookings to include. One invoice PDF will cover all of them.
          </DialogDescription>
        </DialogHeader>

        {!showEmail ? (
          <SelectionStep
            groupFiles={groupFiles}
            selected={selected}
            onToggle={toggle}
            grandTotalEur={invoiceData?.grandTotalEur ?? 0}
            hasInvoiceData={Boolean(invoiceData)}
            onCancel={handleClose}
            onDownload={handleDownload}
            onNext={() => setShowEmail(true)}
          />
        ) : invoiceData ? (
          <EmailStep
            key={selectedIds.join(",")}
            clientName={clientName}
            clientContactName={clientContactName}
            clientContactEmail={clientContactEmail}
            invoiceNumber={invoiceNumber}
            files={invoiceData.files}
            grandTotalEur={invoiceData.grandTotalEur}
            groupFileIds={selectedIds}
            senderIdentities={senderIdentities}
            agency={agency}
            onBack={() => setShowEmail(false)}
            onSent={handleClose}
          />
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
