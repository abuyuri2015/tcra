/**
 * Import a single client by pulling their public website and letting AI
 * extract structured details (name, contact info, location).
 */
import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { Globe, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { PreviewField } from "@/components/ai-import-dialog.tsx";
import { clientKindLabel, type ClientKind } from "../_lib/categories.tsx";

type ClientData = {
  kind: ClientKind;
  name: string;
  contactName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
  taxId?: string;
  notes?: string;
};

type Step = "input" | "loading" | "preview" | "saving";

export default function ClientWebsiteImport() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("input");
  const [url, setUrl] = useState("");
  const [data, setData] = useState<ClientData | null>(null);

  const extractFromUrl = useAction(api.ai.extract.extractClientFromUrl);
  const bulkCreate = useMutation(api.clients.bulkCreate);

  const handleOpen = () => {
    setStep("input");
    setUrl("");
    setData(null);
    setOpen(true);
  };

  const handleFetch = async () => {
    const trimmed = url.trim();
    if (!trimmed) return;
    const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    setStep("loading");
    try {
      const result = await extractFromUrl({ url: withProtocol });
      const c = result.data;
      setData({
        ...c,
        kind: c.kind === "individual" ? "individual" : "company",
      });
      setStep("preview");
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Couldn't import that website. Please try again.";
      toast.error(msg);
      setStep("input");
    }
  };

  const handleConfirm = async () => {
    if (!data) return;
    setStep("saving");
    try {
      const result = await bulkCreate({ clients: [data] });
      if (result.imported === 0) {
        toast.info("A client with that name already exists — nothing imported.");
      } else {
        toast.success(`Imported ${data.name}`);
      }
      setOpen(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Import failed. Please try again.";
      toast.error(msg);
      setStep("preview");
    }
  };

  return (
    <>
      <Button variant="secondary" onClick={handleOpen}>
        <Globe className="size-4" />
        Import from website
      </Button>

      <Dialog open={open} onOpenChange={(v) => { if (!v) setOpen(false); }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-display">
              <Globe className="size-4 text-primary" />
              Import client from website
            </DialogTitle>
          </DialogHeader>

          {step === "input" && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Paste the client's website address. AI will read the page and extract their
                  name, contact person, location, and contact details.
                </p>
                <Input
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://www.acmecorp.com"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleFetch();
                    }
                  }}
                />
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleFetch} disabled={!url.trim()}>
                  <Sparkles className="size-4" />
                  Fetch & extract
                </Button>
              </DialogFooter>
            </>
          )}

          {step === "loading" && (
            <div className="flex flex-col items-center justify-center gap-3 py-12">
              <Loader2 className="size-6 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">
                Reading the website and extracting client details…
              </p>
            </div>
          )}

          {step === "preview" && data && (
            <>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Review the extracted details below. Click <strong>Confirm import</strong> to
                  save this client, or go back to try a different link.
                </p>
                <div className="grid grid-cols-2 gap-3 rounded-lg border bg-muted/30 px-4 py-4">
                  <PreviewField label="Name" value={data.name} />
                  <PreviewField label="Type" value={clientKindLabel(data.kind)} />
                  <PreviewField label="Contact" value={data.contactName} />
                  <PreviewField label="Email" value={data.email} />
                  <PreviewField label="Phone" value={data.phone} />
                  <PreviewField label="City" value={data.city} />
                  <PreviewField label="Country" value={data.country} />
                  <PreviewField label="Address" value={data.address} />
                  <PreviewField label="Tax / VAT ID" value={data.taxId} />
                  {data.notes && (
                    <div className="col-span-full">
                      <PreviewField label="Notes" value={data.notes} />
                    </div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setStep("input")}>
                  Back
                </Button>
                <Button onClick={handleConfirm}>Confirm import</Button>
              </DialogFooter>
            </>
          )}

          {step === "saving" && (
            <div className="flex items-center justify-center gap-3 py-12">
              <Loader2 className="size-5 animate-spin text-primary" />
              <span className="text-sm text-muted-foreground">Saving…</span>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
