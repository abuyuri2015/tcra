/**
 * Shared client create/edit form dialog. Used from both the clients list page
 * and the client detail page.
 */
import { useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { CLIENT_KIND_OPTIONS } from "../_lib/categories.tsx";

const clientSchema = z.object({
  kind: z.enum(["individual", "company"]),
  name: z.string().min(1, "Name is required"),
  contactName: z.string(),
  email: z.string().email("Invalid email").or(z.literal("")),
  phone: z.string(),
  address: z.string(),
  city: z.string(),
  country: z.string(),
  taxId: z.string(),
  notes: z.string(),
});

type ClientFormValues = z.infer<typeof clientSchema>;

function defaultValues(c?: Doc<"clients">): ClientFormValues {
  return {
    kind: c?.kind ?? "individual",
    name: c?.name ?? "",
    contactName: c?.contactName ?? "",
    email: c?.email ?? "",
    phone: c?.phone ?? "",
    address: c?.address ?? "",
    city: c?.city ?? "",
    country: c?.country ?? "",
    taxId: c?.taxId ?? "",
    notes: c?.notes ?? "",
  };
}

export default function ClientFormDialog({
  client,
  open,
  onClose,
  defaultParentId,
  forceKind,
}: {
  client?: Doc<"clients">;
  open: boolean;
  onClose: () => void;
  /** When creating a contact under a company, pre-fill and lock the parent link. */
  defaultParentId?: Id<"clients">;
  /** Lock the kind selector, e.g. always "individual" when adding a contact. */
  forceKind?: "individual" | "company";
}) {
  const create = useMutation(api.clients.create);
  const update = useMutation(api.clients.update);

  const form = useForm<ClientFormValues>({
    resolver: zodResolver(clientSchema),
    defaultValues: defaultValues(client),
  });

  const handleOpenChange = (v: boolean) => {
    if (!v) onClose();
    else form.reset(defaultValues(client));
  };

  const onSubmit = async (values: ClientFormValues) => {
    try {
      const payload = {
        kind: forceKind ?? values.kind,
        name: values.name.trim(),
        parentClientId:
          (forceKind ?? values.kind) === "individual"
            ? client?.parentClientId ?? defaultParentId
            : undefined,
        contactName: values.contactName.trim() || undefined,
        email: values.email.trim() || undefined,
        phone: values.phone.trim() || undefined,
        address: values.address.trim() || undefined,
        city: values.city.trim() || undefined,
        country: values.country.trim() || undefined,
        taxId: values.taxId.trim() || undefined,
        notes: values.notes.trim() || undefined,
      };
      if (client) {
        await update({ id: client._id, ...payload });
        toast.success("Client updated");
      } else {
        await create(payload);
        toast.success(payload.kind === "company" ? "Company added" : "Client added");
      }
      onClose();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not save client.";
      toast.error(msg);
    }
  };

  const kind = form.watch("kind");

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">
            {client
              ? `Edit ${client.kind === "company" ? "company" : "client"}`
              : defaultParentId
                ? "Add contact"
                : forceKind === "company"
                  ? "Add company"
                  : "Add client"}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            {!forceKind && (
              <FormField
                control={form.control}
                name="kind"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Type</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {CLIENT_KIND_OPTIONS.map((o) => (
                          <SelectItem key={o.value} value={o.value}>
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>{kind === "company" ? "Company name" : "Full name"}</FormLabel>
                  <FormControl>
                    <Input
                      placeholder={kind === "company" ? "Acme Corporation" : "Jane Doe"}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {kind === "company" && (
              <FormField
                control={form.control}
                name="contactName"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Primary contact</FormLabel>
                    <FormControl>
                      <Input placeholder="María López" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="jane@company.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input placeholder="+34 93 123 4567" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Address</FormLabel>
                  <FormControl>
                    <Input placeholder="123 Main Street" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <FormControl>
                    <Input placeholder="Barcelona" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="country"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Country</FormLabel>
                  <FormControl>
                    <Input placeholder="Spain" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {kind === "company" && (
              <FormField
                control={form.control}
                name="taxId"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Tax / VAT ID</FormLabel>
                    <FormControl>
                      <Input placeholder="ESB12345678" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={2} placeholder="Internal notes…" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button type="button" variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {client ? "Save changes" : "Add"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
