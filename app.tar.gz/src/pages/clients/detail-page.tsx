import { useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import {
  ArrowLeft,
  Building2,
  CalendarDays,
  FileText,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  Receipt,
  Trash2,
  UserRound,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  ErrorState,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { formatMoney } from "@/lib/domain.ts";
import { formatDateRange } from "@/lib/dates.ts";
import { clientKindLabel, ClientKindIcon, CLIENT_KIND_CHIP, type ClientKind } from "./_lib/categories.tsx";
import ClientFormDialog from "./_components/client-form-dialog.tsx";
import CombinedInvoiceDialog from "./_components/combined-invoice-dialog.tsx";

// ── Detail row ───────────────────────────────────────────────────────────────

function DetailRow({
  icon: Icon,
  label,
  value,
  href,
}: {
  icon: typeof UserRound;
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        {href ? (
          <a href={href} className="break-words text-sm font-medium text-primary hover:underline">
            {value}
          </a>
        ) : (
          <p className="break-words text-sm font-medium">{value}</p>
        )}
      </div>
    </div>
  );
}

// ── Group file row ───────────────────────────────────────────────────────────

function GroupFileRow({
  file,
}: {
  file: {
    _id: Id<"groupFiles">;
    reference: string;
    title: string;
    status: string;
    destination: string;
    startDate: string;
    endDate: string;
    pax: number;
    totalIncomeEur: number;
    totalCostEur: number;
    marginEur: number;
  };
}) {
  return (
    <Link
      to={`/files/${file._id}`}
      className="flex items-center justify-between gap-3 rounded-md px-3 py-2.5 transition-colors hover:bg-secondary/50"
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{file.title}</p>
        <p className="truncate text-xs text-muted-foreground">
          {file.reference} · {file.destination} · {file.pax} pax
        </p>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1">
        <StatusBadge status={file.status} />
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <CalendarDays className="size-3" />
          {formatDateRange(file.startDate, file.endDate)}
        </span>
        {file.totalIncomeEur > 0 && (
          <span className="text-xs font-medium text-foreground">
            {formatMoney(file.totalIncomeEur, "EUR")}
            {file.totalCostEur > 0 && (
              <span className={file.marginEur >= 0 ? "text-chart-3" : "text-destructive"}>
                {" "}· {formatMoney(file.marginEur, "EUR")} margin
              </span>
            )}
          </span>
        )}
      </div>
    </Link>
  );
}

// ── Main page ────────────────────────────────────────────────────────────────

export default function ClientDetailPage() {
  const { clientId } = useParams<{ clientId: string }>();
  const navigate = useNavigate();
  const [editOpen, setEditOpen] = useState(false);
  const [addContactOpen, setAddContactOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<Id<"clients"> | undefined>();
  const [invoiceOpen, setInvoiceOpen] = useState(false);

  const data = useQuery(
    api.clients.getDetail,
    clientId ? { id: clientId as Id<"clients"> } : "skip",
  );
  const editingContactData = useQuery(
    api.clients.get,
    editingContact ? { id: editingContact } : "skip",
  );
  const remove = useMutation(api.clients.remove);

  if (data === undefined) {
    return (
      <div className="mx-auto max-w-5xl space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  if (data === null) {
    return (
      <div className="mx-auto max-w-xl py-10">
        <ErrorState>
          <ErrorStateHeader>
            <ErrorStateMedia variant="icon">
              <Users />
            </ErrorStateMedia>
            <ErrorStateTitle>Client not found</ErrorStateTitle>
            <ErrorStateDescription>This client may have been deleted.</ErrorStateDescription>
          </ErrorStateHeader>
        </ErrorState>
      </div>
    );
  }

  const { client, parent, contacts, groupFiles, totalIncomeEur, totalCostEur, totalMarginEur } = data;

  const handleDelete = async () => {
    try {
      await remove({ id: client._id });
      toast.success("Client deleted");
      navigate("/clients");
    } catch (error) {
      const msg =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not delete client.";
      toast.error(msg);
    }
  };

  const location = [client.city, client.country].filter(Boolean).join(", ");

  return (
    <>
      <ClientFormDialog client={client} open={editOpen} onClose={() => setEditOpen(false)} />
      <ClientFormDialog
        open={addContactOpen}
        onClose={() => setAddContactOpen(false)}
        defaultParentId={client._id}
        forceKind="individual"
      />
      {editingContactData && (
        <ClientFormDialog
          client={editingContactData}
          open={!!editingContact}
          onClose={() => setEditingContact(undefined)}
          forceKind="individual"
        />
      )}
      <CombinedInvoiceDialog
        open={invoiceOpen}
        onClose={() => setInvoiceOpen(false)}
        clientId={client._id}
        clientName={client.name}
        clientContactName={client.contactName}
        clientContactEmail={client.email}
        groupFiles={groupFiles}
      />

      <div className="mx-auto max-w-5xl">
        <Link
          to="/clients"
          className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          All clients
        </Link>

        <PageHeader
          eyebrow={location || clientKindLabel(client.kind)}
          title={client.name}
          actions={
            <>
              <Button variant="secondary" onClick={() => setEditOpen(true)}>
                <Pencil className="size-4" />
                Edit
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="icon" aria-label="Delete client">
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete {client.name}?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently remove this client from your directory. Existing
                      group files will not be affected.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          }
        />

        {/* Kind badge + parent link */}
        <div className="mb-6 flex flex-wrap items-center gap-2">
          <span
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium",
              CLIENT_KIND_CHIP[client.kind as ClientKind],
            )}
          >
            <ClientKindIcon kind={client.kind} className="size-3" />
            {clientKindLabel(client.kind)}
          </span>
          {parent && (
            <Link
              to={`/clients/${parent._id}`}
              className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground hover:text-foreground"
            >
              <Building2 className="size-3" />
              Contact at {parent.name}
            </Link>
          )}
          {groupFiles.length > 0 && (
            <button
              type="button"
              onClick={() => setInvoiceOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary hover:bg-primary/20 cursor-pointer"
            >
              <Receipt className="size-3" />
              Create combined invoice
            </button>
          )}
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {/* Contact info */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display text-base">Contact details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {location && <DetailRow icon={MapPin} label="Location" value={location} />}
              {client.address && <DetailRow icon={MapPin} label="Address" value={client.address} />}
              {client.contactName && (
                <DetailRow icon={UserRound} label="Primary contact" value={client.contactName} />
              )}
              {client.email && (
                <DetailRow icon={Mail} label="Email" value={client.email} href={`mailto:${client.email}`} />
              )}
              {client.phone && (
                <DetailRow icon={Phone} label="Phone" value={client.phone} href={`tel:${client.phone}`} />
              )}
              {client.taxId && <DetailRow icon={Receipt} label="Tax / VAT ID" value={client.taxId} />}
              {!location &&
                !client.address &&
                !client.contactName &&
                !client.email &&
                !client.phone &&
                !client.taxId && (
                  <p className="text-sm text-muted-foreground">No contact details added yet.</p>
                )}
            </CardContent>
          </Card>

          {/* Notes + quick actions */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display text-base">Notes & actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {client.notes ? (
                <div className="rounded-md bg-muted/60 p-3 text-sm whitespace-pre-wrap">
                  {client.notes}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">No notes.</p>
              )}
              <div className="flex flex-wrap gap-2 pt-1">
                {client.email && (
                  <Button asChild variant="secondary" size="sm">
                    <a href={`mailto:${client.email}`}>
                      <Mail className="size-3.5" />
                      Email
                    </a>
                  </Button>
                )}
                {client.phone && (
                  <Button asChild variant="secondary" size="sm">
                    <a href={`tel:${client.phone}`}>
                      <Phone className="size-3.5" />
                      Call
                    </a>
                  </Button>
                )}
                {totalIncomeEur > 0 && (
                  <div className="ml-auto text-right text-sm">
                    <p className="font-medium">Total billed: {formatMoney(totalIncomeEur, "EUR")}</p>
                    {totalCostEur > 0 && (
                      <p className={cn("text-xs", totalMarginEur >= 0 ? "text-chart-3" : "text-destructive")}>
                        Margin: {formatMoney(totalMarginEur, "EUR")}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Linked contacts (companies only) */}
          {client.kind === "company" && (
            <Card className="lg:col-span-2">
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2 font-display text-base">
                  <Users className="size-4 text-muted-foreground" />
                  Contacts
                  {contacts.length > 0 && (
                    <span className="ml-1 rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                      {contacts.length}
                    </span>
                  )}
                </CardTitle>
                <Button size="sm" variant="secondary" onClick={() => setAddContactOpen(true)}>
                  <Plus className="size-4" />
                  Add contact
                </Button>
              </CardHeader>
              <CardContent>
                {contacts.length === 0 ? (
                  <Empty>
                    <EmptyHeader>
                      <EmptyMedia variant="icon">
                        <UserRound />
                      </EmptyMedia>
                      <EmptyTitle>No contacts yet</EmptyTitle>
                      <EmptyDescription>
                        Add individual contacts who work at {client.name}.
                      </EmptyDescription>
                    </EmptyHeader>
                    <EmptyContent>
                      <Button size="sm" onClick={() => setAddContactOpen(true)}>
                        <Plus className="size-4" />
                        Add first contact
                      </Button>
                    </EmptyContent>
                  </Empty>
                ) : (
                  <div className="grid gap-2 sm:grid-cols-2">
                    {contacts.map((c) => (
                      <button
                        key={c._id}
                        type="button"
                        onClick={() => setEditingContact(c._id)}
                        className="flex items-center justify-between gap-2 rounded-md border px-3 py-2.5 text-left transition-colors hover:bg-secondary/50 cursor-pointer"
                      >
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">{c.name}</p>
                          {c.email && (
                            <p className="truncate text-xs text-muted-foreground">{c.email}</p>
                          )}
                        </div>
                        <Pencil className="size-3.5 shrink-0 text-muted-foreground" />
                      </button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Matched group files */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 font-display text-base">
                <FileText className="size-4 text-muted-foreground" />
                Bookings
                {groupFiles.length > 0 && (
                  <span className="ml-1 rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                    {groupFiles.length}
                  </span>
                )}
              </CardTitle>
              {groupFiles.length > 0 && (
                <span className="text-sm font-medium">{formatMoney(totalIncomeEur, "EUR")} total</span>
              )}
            </CardHeader>
            <CardContent>
              {groupFiles.length === 0 ? (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon">
                      <FileText />
                    </EmptyMedia>
                    <EmptyTitle>No bookings yet</EmptyTitle>
                    <EmptyDescription>
                      Group files whose client name matches "{client.name}"
                      {client.kind === "company" ? " or one of its contacts" : ""} will appear
                      here automatically.
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ) : (
                <div className="space-y-1">
                  {groupFiles.map((f) => (
                    <GroupFileRow key={f._id} file={f} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
