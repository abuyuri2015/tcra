import { Building2, UserRound } from "lucide-react";

export const CLIENT_KIND_OPTIONS = [
  { value: "individual", label: "Individual" },
  { value: "company", label: "Company" },
] as const;

export type ClientKind = (typeof CLIENT_KIND_OPTIONS)[number]["value"];

export function clientKindLabel(value: string): string {
  return CLIENT_KIND_OPTIONS.find((k) => k.value === value)?.label ?? value;
}

/** Renders the icon for a client kind without storing a component reference in a render-time variable. */
export function ClientKindIcon({ kind, className }: { kind: string; className?: string }) {
  return kind === "company" ? (
    <Building2 className={className} />
  ) : (
    <UserRound className={className} />
  );
}

export const CLIENT_KIND_CHIP: Record<ClientKind, string> = {
  individual: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300",
  company: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300",
};
