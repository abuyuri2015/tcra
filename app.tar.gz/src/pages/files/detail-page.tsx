import { useState } from "react";
import { useNavigate, useParams, Link, useSearchParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import {
  ArrowLeft,
  Bookmark,
  Building2,
  CalendarRange,
  Coins,
  Copy,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Trash2,
  User,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import GroupFileFormDialog from "./_components/group-file-form-dialog.tsx";
import ReservationsTab from "./_components/reservations-tab.tsx";
import OffersTab from "./_components/offers-tab.tsx";
import FinanceTab from "./_components/finance-tab.tsx";
import ItineraryTab from "./_components/itinerary-tab.tsx";
import DocumentsTab from "./_components/documents-tab.tsx";
import EmailHistoryTab from "./_components/email-history-tab.tsx";
import TasksTab from "./_components/tasks-tab.tsx";
import DuplicateFileDialog from "./_components/duplicate-file-dialog.tsx";
import SaveAsTemplateDialog from "./_components/save-as-template-dialog.tsx";
import PassengersTab from "./_components/passengers-tab.tsx";
import AttachmentsSection from "./_components/attachments-section.tsx";
import ActivityTimeline from "./_components/activity-timeline.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs.tsx";
import {
  ErrorState,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import { FILE_STATUS_OPTIONS, typeLabel } from "@/lib/domain.ts";
import { formatDate, formatDateRange, nightsBetween } from "@/lib/dates.ts";
import { cn } from "@/lib/utils.ts";
import type { FileStatus } from "@/lib/domain.ts";

function DetailRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof User;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="break-words text-sm font-medium">{value}</p>
      </div>
    </div>
  );
}

function ComingSoonPanel({ title }: { title: string }) {
  return (
    <Card>
      <CardContent className="py-10 text-center text-sm text-muted-foreground">
        {title} arrives in a future milestone.
      </CardContent>
    </Card>
  );
}

export default function FileDetailPage() {
  const { fileId } = useParams<{ fileId: string }>();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get("tab") ?? "overview";

  const [duplicateOpen, setDuplicateOpen] = useState(false);
  const [templateOpen, setTemplateOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(() => searchParams.get("edit") === "1");
  const file = useQuery(
    api.groupFiles.get,
    fileId ? { id: fileId as Id<"groupFiles"> } : "skip",
  );
  const avgMarginPercent = useQuery(
    api.groupFiles.averageMarginPercent,
    file ? { id: file._id } : "skip",
  );
  const setStatus = useMutation(api.groupFiles.setStatus);
  const remove = useMutation(api.groupFiles.remove);
  const passengerCounts = useQuery(
    api.passengers.countsByFile,
    file ? { groupFileId: file._id } : "skip",
  );

  if (file === undefined) {
    return (
      <div className="mx-auto max-w-5xl space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (file === null) {
    return (
      <div className="mx-auto max-w-xl py-10">
        <ErrorState>
          <ErrorStateHeader>
            <ErrorStateMedia variant="icon">
              <MapPin />
            </ErrorStateMedia>
            <ErrorStateTitle>File not found</ErrorStateTitle>
            <ErrorStateDescription>
              This group file may have been deleted.
            </ErrorStateDescription>
          </ErrorStateHeader>
        </ErrorState>
      </div>
    );
  }

  const handleStatus = async (value: string) => {
    try {
      await setStatus({ id: file._id, status: value as FileStatus });
      toast.success("Status updated");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update the status.";
      toast.error(message);
    }
  };

  const handleDelete = async () => {
    try {
      await remove({ id: file._id });
      toast.success("File deleted");
      navigate("/files");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not delete the file.";
      toast.error(message);
    }
  };

  const nights = nightsBetween(file.startDate, file.endDate);

  return (
    <div className="mx-auto max-w-5xl">
      <Link
        to="/files"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" />
        All group files
      </Link>

      <PageHeader
        eyebrow={`${file.reference} · ${typeLabel(file.fileType)}`}
        title={file.title}
        description={`${file.clientName} · ${file.destination}`}
        actions={
          <>
            <Select value={file.status} onValueChange={handleStatus}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FILE_STATUS_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="secondary"
              onClick={() => setTemplateOpen(true)}
            >
              <Bookmark className="size-4" />
              Save as template
            </Button>
            <Button
              variant="secondary"
              onClick={() => setDuplicateOpen(true)}
            >
              <Copy className="size-4" />
              Duplicate
            </Button>
            <GroupFileFormDialog
              file={file}
              open={editOpen}
              onOpenChange={setEditOpen}
              trigger={
                <Button variant="secondary">
                  <Pencil className="size-4" />
                  Edit
                </Button>
              }
            />
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Delete file">
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this group file?</AlertDialogTitle>
                  <AlertDialogDescription>
                    {file.reference} and its details will be permanently
                    removed. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete}>
                    Delete file
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <DuplicateFileDialog
              fileId={file._id}
              fileTitle={file.title}
              open={duplicateOpen}
              onOpenChange={setDuplicateOpen}
            />
            <SaveAsTemplateDialog
              fileId={file._id}
              fileTitle={file.title}
              open={templateOpen}
              onOpenChange={setTemplateOpen}
            />
          </>
        }
      />

      <div className="grid gap-4 pb-6 sm:grid-cols-2 lg:grid-cols-4">
        {[
          {
            label: "Dates",
            value: formatDateRange(file.startDate, file.endDate),
            icon: CalendarRange,
          },
          { label: "Nights", value: String(nights), icon: CalendarRange },
          {
            label: "Travellers",
            value:
              passengerCounts && passengerCounts.total > 0
                ? `${passengerCounts.total} pax · ${passengerCounts.rooms} room${passengerCounts.rooms !== 1 ? "s" : ""}`
                : `${file.pax} pax`,
            icon: Users,
          },
          {
            label: "Currency",
            value: `${file.currency} @ ${file.exchangeRateToBase} EUR`,
            icon: Coins,
          },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="gap-2 p-4">
              <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground">
                <Icon className="size-3.5" />
                {stat.label}
              </div>
              <p className="font-display text-lg font-semibold">{stat.value}</p>
            </Card>
          );
        })}
        <Card className="gap-2 p-4">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground">
            <Coins className="size-3.5" />
            Avg. margin
          </div>
          <p
            className={cn(
              "font-display text-lg font-semibold",
              avgMarginPercent !== null && avgMarginPercent !== undefined
                ? avgMarginPercent >= 0
                  ? "text-chart-3"
                  : "text-destructive"
                : "",
            )}
          >
            {avgMarginPercent === undefined ? (
              <Skeleton className="h-6 w-16" />
            ) : avgMarginPercent === null ? (
              "—"
            ) : (
              `${avgMarginPercent.toFixed(1)}%`
            )}
          </p>
        </Card>
      </div>

      <Tabs
        value={activeTab}
        onValueChange={(v) => setSearchParams({ tab: v }, { replace: true })}
      >
        <TabsList className="flex-wrap">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="offers">Offers</TabsTrigger>
          <TabsTrigger value="reservations">Reservations</TabsTrigger>
          <TabsTrigger value="finance">Cost &amp; income</TabsTrigger>
          <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="emails">Emails</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="passengers">Passengers</TabsTrigger>
          <TabsTrigger value="attachments">Attachments</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="pt-4">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="font-display text-base">
                  Client
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <DetailRow
                  icon={Building2}
                  label="Company"
                  value={file.clientName}
                />
                <DetailRow
                  icon={User}
                  label="Contact"
                  value={file.clientContactName ?? "Not set"}
                />
                <DetailRow
                  icon={Mail}
                  label="Email"
                  value={file.clientContactEmail ?? "Not set"}
                />
                <DetailRow
                  icon={Phone}
                  label="Phone"
                  value={file.clientContactPhone ?? "Not set"}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="font-display text-base">
                  File details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <StatusBadge status={file.status} />
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-xs text-secondary-foreground">
                    {typeLabel(file.fileType)}
                  </span>
                </div>
                <DetailRow
                  icon={MapPin}
                  label="Destination"
                  value={file.destination}
                />
                <DetailRow
                  icon={User}
                  label="File owner"
                  value={file.ownerName ?? "Unassigned"}
                />
                <DetailRow
                  icon={CalendarRange}
                  label="Created"
                  value={formatDate(new Date(file._creationTime).toISOString())}
                />
                {file.notes ? (
                  <div className="rounded-md bg-muted/60 p-3 text-sm whitespace-pre-wrap">
                    {file.notes}
                  </div>
                ) : null}
              </CardContent>
            </Card>
          </div>

          {/* Activity timeline */}
          <ActivityTimeline groupFileId={file._id} />
        </TabsContent>

        <TabsContent value="offers" className="pt-4">
          <OffersTab groupFileId={file._id} fileCurrency={file.currency} file={file} />
        </TabsContent>
        <TabsContent value="reservations" className="pt-4">
          <ReservationsTab groupFileId={file._id} fileCurrency={file.currency} file={file} />
        </TabsContent>
        <TabsContent value="finance" className="pt-4">
          <FinanceTab
            groupFileId={file._id}
            fileCurrency={file.currency}
            fileExchangeRate={file.exchangeRateToBase}
            fileReference={file.reference}
            file={file}
          />
        </TabsContent>
        <TabsContent value="itinerary" className="pt-4">
          <ItineraryTab groupFileId={file._id} fileId={file._id} file={file} />
        </TabsContent>
        <TabsContent value="documents" className="pt-4">
          <DocumentsTab groupFileId={file._id} file={file} />
        </TabsContent>
        <TabsContent value="emails" className="pt-4">
          <EmailHistoryTab groupFileId={file._id} />
        </TabsContent>
        <TabsContent value="tasks" className="pt-4">
          <TasksTab groupFileId={file._id} />
        </TabsContent>
        <TabsContent value="passengers" className="pt-4">
          <PassengersTab groupFileId={file._id} fileTitle={file.title} file={file} />
        </TabsContent>
        <TabsContent value="attachments" className="pt-4">
          <AttachmentsSection groupFileId={file._id} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
