import type { Currency, FileStatus, FileType } from "@/lib/domain.ts";

/** Partial group file data collected by the AI wizard, before it's confirmed. */
export type WizardDraft = {
  title?: string;
  fileType?: FileType;
  clientName?: string;
  clientContactName?: string;
  clientContactEmail?: string;
  clientContactPhone?: string;
  destination?: string;
  /** Plain yyyy-MM-dd, no time component */
  startDate?: string;
  /** Plain yyyy-MM-dd, no time component */
  endDate?: string;
  pax?: number;
  currency?: Currency;
  notes?: string;
};

export const REQUIRED_DRAFT_FIELDS: Array<{
  key: keyof WizardDraft;
  label: string;
}> = [
  { key: "title", label: "File name" },
  { key: "clientName", label: "Client" },
  { key: "destination", label: "Destination" },
  { key: "startDate", label: "Start date" },
  { key: "endDate", label: "End date" },
  { key: "pax", label: "Traveller count" },
];

export function missingRequiredFields(draft: WizardDraft): string[] {
  return REQUIRED_DRAFT_FIELDS.filter((f) => {
    const value = draft[f.key];
    return value === undefined || value === null || value === "";
  }).map((f) => f.label);
}

export function mergeDraft(prev: WizardDraft, next: WizardDraft): WizardDraft {
  const merged: WizardDraft = { ...prev };
  const entries = Object.entries(next) as Array<
    [keyof WizardDraft, WizardDraft[keyof WizardDraft]]
  >;
  for (const [key, value] of entries) {
    if (value !== undefined && value !== null && value !== "") {
      merged[key] = value as never;
    }
  }
  return merged;
}

export const DEFAULT_STATUS: FileStatus = "enquiry";
