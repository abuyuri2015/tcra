/**
 * AI wizard for creating a group file. Two entry points:
 *  - Chat: describe the trip conversationally, AI extracts details turn by turn.
 *  - From email/document: paste text and/or upload a screenshot, AI extracts in one pass.
 * Both feed into the same review step, which uses the normal create mutation.
 */
import { useState } from "react";
import { Sparkles } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import WizardChatTab from "./wizard-chat-tab.tsx";
import WizardUploadTab from "./wizard-upload-tab.tsx";
import WizardReviewForm from "./wizard-review-form.tsx";
import DraftSummary from "./draft-summary.tsx";
import type { WizardDraft } from "./wizard-types.ts";
import type { ReactNode } from "react";

type Stage = "collect" | "review";

export default function GroupFileAiWizard({ trigger }: { trigger?: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [stage, setStage] = useState<Stage>("collect");
  const [draft, setDraft] = useState<WizardDraft>({});

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      setStage("collect");
      setDraft({});
    }
  };

  const handleReady = (d: WizardDraft) => {
    setDraft(d);
    setStage("review");
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {trigger ?? (
          <button className="hidden" aria-hidden>
            AI wizard
          </button>
        )}
      </DialogTrigger>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <Sparkles className="size-4 text-primary" />
            {stage === "review" ? "Review the new file" : "New file with AI"}
          </DialogTitle>
          <DialogDescription>
            {stage === "review"
              ? "Check the details AI pulled together, tweak anything, then create the file."
              : "Chat with AI or hand it an email to spin up a group file in seconds."}
          </DialogDescription>
        </DialogHeader>

        {stage === "collect" ? (
          <Tabs defaultValue="chat">
            <TabsList className="w-full">
              <TabsTrigger value="chat">Chat with AI</TabsTrigger>
              <TabsTrigger value="upload">From email / document</TabsTrigger>
            </TabsList>
            <TabsContent value="chat" className="pt-3">
              <WizardChatTab onReady={handleReady} />
            </TabsContent>
            <TabsContent value="upload" className="pt-3">
              <WizardUploadTab onReady={handleReady} />
            </TabsContent>
          </Tabs>
        ) : (
          <div className="space-y-4">
            <DraftSummary draft={draft} />
            <WizardReviewForm
              draft={draft}
              onBack={() => setStage("collect")}
              onCreated={() => setOpen(false)}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
