/**
 * Conversational tab of the AI group file wizard: chat with the assistant to
 * describe a trip in plain language, watch the file draft build up live, then
 * jump to review once the required fields are known.
 */
import { useRef, useState } from "react";
import { useAction } from "convex/react";
import { Loader2, Send, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { ScrollArea } from "@/components/ui/scroll-area.tsx";
import { cn } from "@/lib/utils.ts";
import DraftSummary from "./draft-summary.tsx";
import {
  mergeDraft,
  missingRequiredFields,
  type WizardDraft,
} from "./wizard-types.ts";

type ChatMessage = { role: "user" | "assistant"; content: string };

const STARTER = "Hi! Tell me about the trip you're setting up — client, destination, dates, group size, anything you've got.";

export default function WizardChatTab({
  onReady,
}: {
  onReady: (draft: WizardDraft) => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", content: STARTER },
  ]);
  const [draft, setDraft] = useState<WizardDraft>({});
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const chatTurn = useAction(api.ai.groupFileWizard.chatTurn);

  const send = async () => {
    const text = input.trim();
    if (!text || sending) return;
    const nextMessages: ChatMessage[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setSending(true);
    try {
      const result = await chatTurn({ messages: nextMessages });
      setMessages((prev) => [...prev, { role: "assistant", content: result.reply }]);
      setDraft((prev) => mergeDraft(prev, result.draft));
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong. Please try again.";
      toast.error(msg);
    } finally {
      setSending(false);
      requestAnimationFrame(() => {
        scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
      });
    }
  };

  const missing = missingRequiredFields(draft);
  const canReview = missing.length === 0;
  const hasStarted = messages.length > 1;

  return (
    <div className="flex flex-col gap-3">
      <ScrollArea className="h-64 rounded-lg border">
        <div ref={scrollRef} className="flex flex-col gap-3 p-3">
          {messages.map((m, i) => (
            <div
              key={i}
              className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}
            >
              <div
                className={cn(
                  "max-w-[85%] rounded-2xl px-3.5 py-2 text-sm",
                  m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground",
                )}
              >
                {m.content}
              </div>
            </div>
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="flex items-center gap-2 rounded-2xl bg-muted px-3.5 py-2 text-sm text-muted-foreground">
                <Loader2 className="size-3.5 animate-spin" />
                Thinking…
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {hasStarted && <DraftSummary draft={draft} />}

      <div className="flex items-end gap-2">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void send();
            }
          }}
          placeholder="e.g. Acme Corp wants a 25-person incentive trip to Lisbon in June…"
          rows={2}
          className="resize-none"
          disabled={sending}
        />
        <Button size="icon" onClick={() => void send()} disabled={!input.trim() || sending}>
          <Send className="size-4" />
        </Button>
      </div>

      <div className="flex items-center justify-between gap-2">
        <p className="text-xs text-muted-foreground">
          {canReview
            ? "All set — review the details before creating the file."
            : missing.length > 0
              ? `Still need: ${missing.join(", ")}`
              : "Chat a little more to fill in the details."}
        </p>
        <Button size="sm" variant="secondary" disabled={!canReview} onClick={() => onReady(draft)}>
          <Sparkles className="size-3.5" />
          Review & create
        </Button>
      </div>
    </div>
  );
}
