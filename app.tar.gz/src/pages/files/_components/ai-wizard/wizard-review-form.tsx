/**
 * Final review/edit step of the AI group file wizard. Pre-fills the standard
 * group file fields from the AI-assembled draft and lets the agent tweak
 * anything before creating the file via the normal `groupFiles.create` mutation.
 */
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { DialogFooter } from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { CURRENCY_OPTIONS, FILE_TYPE_OPTIONS } from "@/lib/domain.ts";
import { dateInputToIso } from "@/lib/dates.ts";
import type { WizardDraft } from "./wizard-types.ts";

const schema = z
  .object({
    title: z.string().min(2, "Give the file a name"),
    fileType: z.enum(["group", "meeting", "incentive", "conference", "event"]),
    clientName: z.string().min(2, "Client is required"),
    clientContactName: z.string(),
    clientContactEmail: z
      .string()
      .refine((v) => v === "" || z.string().email().safeParse(v).success, {
        message: "Enter a valid email",
      }),
    clientContactPhone: z.string(),
    destination: z.string().min(2, "Destination is required"),
    startDate: z.string().min(1, "Start date is required"),
    endDate: z.string().min(1, "End date is required"),
    pax: z
      .string()
      .refine((v) => Number.isInteger(Number(v)) && Number(v) >= 1, {
        message: "At least 1 traveller",
      }),
    currency: z.enum(CURRENCY_OPTIONS),
    notes: z.string(),
  })
  .refine((data) => data.endDate >= data.startDate, {
    path: ["endDate"],
    message: "End date must be on or after the start date",
  });

type FormValues = z.output<typeof schema>;

function defaultsFrom(draft: WizardDraft): FormValues {
  return {
    title: draft.title ?? "",
    fileType: draft.fileType ?? "group",
    clientName: draft.clientName ?? "",
    clientContactName: draft.clientContactName ?? "",
    clientContactEmail: draft.clientContactEmail ?? "",
    clientContactPhone: draft.clientContactPhone ?? "",
    destination: draft.destination ?? "",
    startDate: draft.startDate ?? "",
    endDate: draft.endDate ?? "",
    pax: draft.pax ? String(draft.pax) : "",
    currency: draft.currency ?? "EUR",
    notes: draft.notes ?? "",
  };
}

export default function WizardReviewForm({
  draft,
  onBack,
  onCreated,
}: {
  draft: WizardDraft;
  onBack: () => void;
  onCreated: () => void;
}) {
  const create = useMutation(api.groupFiles.create);
  const navigate = useNavigate();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(draft),
  });

  const onSubmit = async (values: FormValues) => {
    const parsed = schema.parse(values);
    try {
      const newId = await create({
        title: parsed.title.trim(),
        fileType: parsed.fileType,
        status: "enquiry",
        clientName: parsed.clientName.trim(),
        clientContactName: parsed.clientContactName.trim() || undefined,
        clientContactEmail: parsed.clientContactEmail.trim() || undefined,
        clientContactPhone: parsed.clientContactPhone.trim() || undefined,
        destination: parsed.destination.trim(),
        startDate: dateInputToIso(parsed.startDate),
        endDate: dateInputToIso(parsed.endDate),
        pax: Number(parsed.pax),
        currency: parsed.currency,
        exchangeRateToBase: 1,
        notes: parsed.notes.trim() || undefined,
      });
      toast.success("File created");
      onCreated();
      navigate(`/files/${newId}`);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not create the file. Please try again.";
      toast.error(message);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem className="sm:col-span-2">
              <FormLabel>File name</FormLabel>
              <FormControl>
                <Input placeholder="Acme Sales Kick-off 2026" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="fileType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Type</FormLabel>
              <Select value={field.value} onValueChange={field.onChange}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {FILE_TYPE_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="clientName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Client / company</FormLabel>
              <FormControl>
                <Input placeholder="Acme Corporation" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="destination"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Destination</FormLabel>
              <FormControl>
                <Input placeholder="Barcelona, Spain" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="clientContactName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Contact name</FormLabel>
              <FormControl>
                <Input placeholder="John Smith" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="clientContactEmail"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Contact email</FormLabel>
              <FormControl>
                <Input placeholder="example@gmail.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="clientContactPhone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Contact phone</FormLabel>
              <FormControl>
                <Input placeholder="+34 600 000 000" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="pax"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Travellers (pax)</FormLabel>
              <FormControl>
                <Input type="number" min={1} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="startDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Start date</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="endDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>End date</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="currency"
          render={({ field }) => (
            <FormItem>
              <FormLabel>File currency</FormLabel>
              <Select value={field.value} onValueChange={field.onChange}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {CURRENCY_OPTIONS.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem className="sm:col-span-2">
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea rows={3} {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <DialogFooter className="sm:col-span-2">
          <Button type="button" variant="secondary" onClick={onBack}>
            Back
          </Button>
          <Button type="submit" disabled={form.formState.isSubmitting}>
            {form.formState.isSubmitting ? <Spinner /> : null}
            Create file
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
