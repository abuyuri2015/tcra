/**
 * "From an email or document" tab of the AI group file wizard. The agent
 * pastes forwarded email text and/or uploads a screenshot/photo of a booking
 * request; AI extracts whatever structured details it can find. On failure to
 * find anything useful, it reports the failure so the agent can fall back to
 * pasting text or the manual form instead of creating an empty file.
 */
import { useRef, useState } from "react";
import { useAction, useMutation, useQuery } from "convex/react";
import { AlertTriangle, FileUp, Loader2, Sparkles, X } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.js";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  ErrorState,
  ErrorStateContent,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import DraftSummary from "./draft-summary.tsx";
import { missingRequiredFields, type WizardDraft } from "./wizard-types.ts";

type Status = "idle" | "uploading" | "extracting" | "failed" | "done";

export default function WizardUploadTab({
  onReady,
}: {
  onReady: (draft: WizardDraft) => void;
}) {
  const [text, setText] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [imageStorageId, setImageStorageId] = useState<Id<"_storage"> | null>(null);
  const [imageName, setImageName] = useState<string | null>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [draft, setDraft] = useState<WizardDraft | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.attachments.generateUploadUrl);
  const imageUrl = useQuery(
    api.attachments.resolveUploadUrl,
    imageStorageId ? { storageId: imageStorageId } : "skip",
  );
  const extract = useAction(api.ai.groupFileWizard.extractFromContent);

  const handleFilePick = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Upload a screenshot or photo of the email/document (JPG or PNG).");
      return;
    }
    setStatus("uploading");
    try {
      const uploadUrl = await generateUploadUrl();
      const res = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!res.ok) throw new Error("Upload failed");
      const { storageId } = (await res.json()) as { storageId: Id<"_storage"> };
      setImageStorageId(storageId);
      setImageName(file.name);
      setStatus("idle");
    } catch {
      toast.error("Couldn't upload that file. Please try again.");
      setStatus("idle");
    }
  };

  const handleExtract = async () => {
    if (!text.trim() && !imageStorageId) {
      toast.error("Paste some email text or upload a document first.");
      return;
    }
    if (imageStorageId && imageUrl === undefined) {
      // still resolving the URL
      return;
    }
    setStatus("extracting");
    setErrorMessage(null);
    try {
      const result = await extract({
        text: text.trim() || undefined,
        imageUrl: imageStorageId ? imageUrl ?? undefined : undefined,
      });
      setDraft(result.draft);
      setSummary(result.summary);
      setStatus("done");
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : "Couldn't create a group file from that content. Try pasting the email text instead.";
      setErrorMessage(msg);
      setStatus("failed");
    }
  };

  const clearImage = () => {
    setImageStorageId(null);
    setImageName(null);
  };

  const reset = () => {
    setStatus("idle");
    setErrorMessage(null);
    setDraft(null);
    setSummary(null);
  };

  if (status === "failed") {
    return (
      <ErrorState>
        <ErrorStateHeader>
          <ErrorStateMedia variant="icon">
            <AlertTriangle />
          </ErrorStateMedia>
          <ErrorStateTitle>Couldn't create the file</ErrorStateTitle>
          <ErrorStateDescription>{errorMessage}</ErrorStateDescription>
        </ErrorStateHeader>
        <ErrorStateContent>
          <Button size="sm" onClick={reset}>
            Try again
          </Button>
        </ErrorStateContent>
      </ErrorState>
    );
  }

  if (status === "done" && draft) {
    const missing = missingRequiredFields(draft);
    return (
      <div className="space-y-3">
        {summary && <p className="text-sm text-muted-foreground">{summary}</p>}
        <DraftSummary draft={draft} />
        <div className="flex items-center justify-between gap-2">
          <Button variant="secondary" size="sm" onClick={reset}>
            Start over
          </Button>
          <Button size="sm" onClick={() => onReady(draft)}>
            <Sparkles className="size-3.5" />
            {missing.length > 0 ? "Review & fill in the rest" : "Review & create"}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        Paste a forwarded email or booking request, and/or upload a screenshot of one. AI will
        pull out the trip details automatically.
      </p>
      <Textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Paste the email or document text here…"
        rows={8}
        className="resize-none font-mono text-sm"
      />

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void handleFilePick(file);
          e.target.value = "";
        }}
      />

      {imageName ? (
        <div className="flex items-center gap-2 rounded-lg border bg-muted/30 px-3 py-2 text-sm">
          <FileUp className="size-4 shrink-0 text-muted-foreground" />
          <span className="min-w-0 flex-1 truncate">{imageName}</span>
          <Button variant="ghost" size="icon" className="size-6" onClick={clearImage}>
            <X className="size-3.5" />
          </Button>
        </div>
      ) : (
        <Button
          type="button"
          variant="secondary"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          disabled={status === "uploading"}
        >
          {status === "uploading" ? (
            <Loader2 className="size-3.5 animate-spin" />
          ) : (
            <FileUp className="size-3.5" />
          )}
          Upload screenshot / photo
        </Button>
      )}

      <div className="flex justify-end">
        <Button
          onClick={() => void handleExtract()}
          disabled={
            (!text.trim() && !imageStorageId) ||
            status === "extracting" ||
            status === "uploading"
          }
        >
          {status === "extracting" ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Extracting…
            </>
          ) : (
            <>
              <Sparkles className="size-4" />
              Extract details
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
