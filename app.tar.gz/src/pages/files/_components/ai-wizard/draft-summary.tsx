import { CalendarRange, Mail, MapPin, Phone, User, Users } from "lucide-react";
import { typeLabel } from "@/lib/domain.ts";
import { missingRequiredFields, type WizardDraft } from "./wizard-types.ts";
import { cn } from "@/lib/utils.ts";

function Row({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value?: string | number;
}) {
  return (
    <div className="flex items-center gap-2.5 py-1.5">
      <Icon className="size-3.5 shrink-0 text-muted-foreground" />
      <span className="w-24 shrink-0 text-xs text-muted-foreground">{label}</span>
      <span className={cn("truncate text-sm", !value && "italic text-muted-foreground/70")}>
        {value ?? "Not yet known"}
      </span>
    </div>
  );
}

export default function DraftSummary({ draft }: { draft: WizardDraft }) {
  const missing = missingRequiredFields(draft);
  const dateRange =
    draft.startDate && draft.endDate
      ? `${draft.startDate} → ${draft.endDate}`
      : draft.startDate || draft.endDate;

  return (
    <div className="space-y-2 rounded-lg border bg-muted/30 p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          File so far
        </p>
        {draft.fileType && (
          <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] text-secondary-foreground">
            {typeLabel(draft.fileType)}
          </span>
        )}
      </div>

      {draft.title && (
        <p className="font-display text-base font-semibold leading-tight">{draft.title}</p>
      )}

      <div className="divide-y divide-border/60">
        <Row icon={User} label="Client" value={draft.clientName} />
        <Row icon={MapPin} label="Destination" value={draft.destination} />
        <Row icon={CalendarRange} label="Dates" value={dateRange} />
        <Row icon={Users} label="Travellers" value={draft.pax} />
        {(draft.clientContactEmail || draft.clientContactName) && (
          <Row
            icon={Mail}
            label="Contact"
            value={
              draft.clientContactName && draft.clientContactEmail
                ? `${draft.clientContactName} · ${draft.clientContactEmail}`
                : draft.clientContactName ?? draft.clientContactEmail
            }
          />
        )}
        {draft.clientContactPhone && (
          <Row icon={Phone} label="Phone" value={draft.clientContactPhone} />
        )}
      </div>

      {missing.length > 0 ? (
        <p className="pt-1 text-xs text-muted-foreground">
          Still missing: <span className="font-medium text-foreground">{missing.join(", ")}</span>
        </p>
      ) : (
        <p className="pt-1 text-xs font-medium text-primary">
          Everything needed is filled in — ready to create.
        </p>
      )}
    </div>
  );
}
