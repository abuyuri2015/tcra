import { useFieldArray, type Control } from "react-hook-form";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import PercentStepper from "@/components/ui/percent-stepper.tsx";
import { BLANK_ROOM_TYPE, type OfferFormValues } from "./offer-form-schema.ts";

/**
 * Repeatable room-type rows (single, double, Jr suite, ...) shown when
 * creating a brand-new hotel offer, so several room types can be bundled
 * under one hotel quote instead of adding each as a separate offer.
 */
export default function OfferRoomTypeFields({
  control,
  getValues,
  setValue,
}: {
  control: Control<OfferFormValues>;
  getValues: (name: `roomTypes.${number}.costPerUnit`) => string;
  setValue: (name: `roomTypes.${number}.ratePerUnit`, value: string) => void;
}) {
  const roomTypesArray = useFieldArray({ control, name: "roomTypes" });

  const applyMarkupToRoomType = (index: number, next: number) => {
    const cost = Number(getValues(`roomTypes.${index}.costPerUnit`));
    if (!Number.isFinite(cost) || cost <= 0) return;
    const suggested = cost * (1 + next / 100);
    setValue(`roomTypes.${index}.ratePerUnit`, suggested.toFixed(2));
  };

  return (
    <div className="space-y-3 sm:col-span-2">
      <FormLabel>Room types</FormLabel>
      {roomTypesArray.fields.map((field, index) => (
        <div key={field.id} className="rounded-lg border p-3">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Room type {index + 1}
            </p>
            {roomTypesArray.fields.length > 1 && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-6"
                aria-label="Remove room type"
                onClick={() => roomTypesArray.remove(index)}
              >
                <Trash2 className="size-3.5 text-destructive" />
              </Button>
            )}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <FormField
              control={control}
              name={`roomTypes.${index}.description`}
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Room type / description</FormLabel>
                  <FormControl>
                    <Input placeholder="Superior double, sea view" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={control}
              name={`roomTypes.${index}.units`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={control}
              name={`roomTypes.${index}.unitLabel`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unit label</FormLabel>
                  <FormControl>
                    <Input placeholder="rooms" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={control}
              name={`roomTypes.${index}.costPerUnit`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cost per unit</FormLabel>
                  <FormControl>
                    <Input type="number" min={0} step="0.01" placeholder="0.00" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={control}
              name={`roomTypes.${index}.ratePerUnit`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rate per unit (sell)</FormLabel>
                  <div className="flex items-center gap-2">
                    <FormControl>
                      <Input
                        type="number"
                        min={0}
                        step="0.01"
                        placeholder="0.00"
                        className="flex-1"
                        {...field}
                      />
                    </FormControl>
                    <PercentStepper
                      value={0}
                      onChange={(pct) => applyMarkupToRoomType(index, pct)}
                      size="sm"
                      className="w-24 shrink-0"
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
      ))}
      <Button
        type="button"
        variant="secondary"
        size="sm"
        onClick={() => roomTypesArray.append({ ...BLANK_ROOM_TYPE })}
      >
        <Plus className="size-3.5" />
        Add room type
      </Button>
    </div>
  );
}
