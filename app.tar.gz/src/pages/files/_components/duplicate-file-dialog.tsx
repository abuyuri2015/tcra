import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Label } from "@/components/ui/label.tsx";

export default function DuplicateFileDialog({
  fileId,
  fileTitle,
  open,
  onOpenChange,
}: {
  fileId: Id<"groupFiles">;
  fileTitle: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [copyItinerary, setCopyItinerary] = useState(true);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const duplicate = useMutation(api.groupFiles.duplicate);

  const handleDuplicate = async () => {
    setLoading(true);
    try {
      const newId = await duplicate({ id: fileId, copyItinerary });
      toast.success("File duplicated — opening the copy now.");
      onOpenChange(false);
      navigate(`/files/${newId}?edit=1`);
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not duplicate the file.";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Duplicate file</DialogTitle>
          <DialogDescription>
            Creates a copy of{" "}
            <span className="font-medium text-foreground">{fileTitle}</span>{" "}
            with status reset to <em>Enquiry</em>. Reservations, finances,
            tasks, and passengers are not copied.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-3 rounded-lg border p-4">
          <Checkbox
            id="copy-itinerary"
            checked={copyItinerary}
            onCheckedChange={(v) => setCopyItinerary(Boolean(v))}
          />
          <div className="space-y-0.5">
            <Label
              htmlFor="copy-itinerary"
              className="cursor-pointer text-sm font-medium"
            >
              Copy itinerary
            </Label>
            <p className="text-xs text-muted-foreground">
              Duplicate all days and itinerary items from this file
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button onClick={handleDuplicate} disabled={loading}>
            <Copy className="size-4" />
            {loading ? "Duplicating…" : "Duplicate file"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
