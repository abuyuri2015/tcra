import { useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { Loader2, MessageSquarePlus } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";

/**
 * Staff equivalent of the client's "Request a change" dialog. Confirmed
 * reservations can no longer be edited directly — every change, whether
 * from staff or the client, is sent to the hotel for approval and only
 * applies automatically once approved. This keeps a single source of truth.
 */
export default function StaffRequestChangeDialog({
  groupFileId,
  reservation,
  trigger,
}: {
  groupFileId: Id<"groupFiles">;
  reservation: Doc<"reservations">;
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<"units" | "other">("units");
  const [requestedUnits, setRequestedUnits] = useState(String(reservation.units));
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const submit = useMutation(api.modificationRequests.submitByStaff);

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      setKind("units");
      setRequestedUnits(String(reservation.units));
      setMessage("");
    }
  };
  const handleSubmit = async () => {
    if (kind === "other" && !message.trim()) {
      toast.error("Please describe the change you'd like to request.");
      return;
    }
    const unitsNum = Number(requestedUnits);
    if (kind === "units") {
      if (!Number.isInteger(unitsNum) || unitsNum < 0) {
        toast.error("Enter a valid number of rooms/units.");
        return;
      }
      if (unitsNum === reservation.units) {
        toast.error("That's already the currently booked quantity.");
        return;
      }
    }
    setSubmitting(true);
    try {
      await submit({
        groupFileId,
        reservationId: reservation._id,
        kind,
        requestedUnits: kind === "units" ? unitsNum : undefined,
        message: message.trim(),
        appOrigin: window.location.origin,
      });
      toast.success("Change request sent to the hotel for approval.");
      setOpen(false);
    } catch (error) {
      const msg =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not submit the request.";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const unitLabel = reservation.unitLabel || (reservation.type === "hotel" ? "rooms" : "units");

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button variant="secondary" size="sm">
            <MessageSquarePlus className="size-3.5" />
            Request a change
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Request a change</DialogTitle>
          <DialogDescription>
            {reservation.supplierName} — {reservation.description}. Confirmed
            reservations require hotel approval before a change is applied.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={kind} onValueChange={(v) => setKind(v as "units" | "other")}>
          <TabsList className="w-full">
            <TabsTrigger value="units" className="flex-1">
              Change {unitLabel}
            </TabsTrigger>
            <TabsTrigger value="other" className="flex-1">
              Other request
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {kind === "units" ? (
          <div className="space-y-3">
            <div>
              <p className="mb-1.5 text-sm font-medium">
                Requested number of {unitLabel}
              </p>
              <Input
                type="number"
                min={0}
                value={requestedUnits}
                onChange={(e) => setRequestedUnits(e.target.value)}
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Currently booked: {reservation.units} {unitLabel}
              </p>
            </div>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Any additional details (optional)…"
              rows={2}
            />
          </div>
        ) : (
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Describe the change you'd like, e.g. move to a later date, change room type…"
            rows={4}
            autoFocus
          />
        )}

        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)} disabled={submitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? <Loader2 className="size-4 animate-spin" /> : null}
            Send to hotel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
