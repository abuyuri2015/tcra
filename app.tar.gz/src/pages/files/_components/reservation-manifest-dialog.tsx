import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { ClipboardList, Download, MapPin, Phone, PlaneLanding, User } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { generateManifestPDF } from "@/lib/pdf-generators.ts";
import { formatDate } from "@/lib/dates.ts";
import type { ReactNode } from "react";

const ROOM_TYPE_LABELS: Record<string, string> = {
  single: "Single",
  double: "Double",
  twin: "Twin",
  triple: "Triple",
  suite: "Suite",
};

function ManifestRow({
  passenger,
  reservationId,
  locked,
}: {
  passenger: Doc<"passengers"> & { included: boolean };
  reservationId: Doc<"reservations">["_id"];
  locked: boolean;
}) {
  const setIncluded = useMutation(api.reservations.setPassengerIncluded);

  const handleToggle = async (checked: boolean) => {
    try {
      await setIncluded({ id: reservationId, passengerId: passenger._id, included: checked });
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update the manifest.";
      toast.error(message);
    }
  };

  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
      <div className="flex items-center gap-3">
        <Checkbox
          checked={passenger.included}
          onCheckedChange={(checked) => handleToggle(checked === true)}
          disabled={locked}
          aria-label={`Include ${passenger.firstName} ${passenger.lastName}`}
        />
        <div>
          <p className="text-sm font-medium">
            {passenger.firstName} {passenger.lastName}
          </p>
          <p className="text-xs text-muted-foreground">
            {ROOM_TYPE_LABELS[passenger.roomType] ?? passenger.roomType}
            {passenger.sharingWith ? ` · sharing with ${passenger.sharingWith}` : ""}
          </p>
        </div>
      </div>
      {!passenger.included ? (
        <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
          Excluded
        </span>
      ) : null}
    </div>
  );
}

export default function ReservationManifestDialog({
  reservation,
  fileReference,
  fileTitle,
  locked,
  trigger,
}: {
  reservation: Doc<"reservations">;
  fileReference: string;
  fileTitle: string;
  locked: boolean;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const manifest = useQuery(api.reservations.manifest, open ? { id: reservation._id } : "skip");

  const handleDownload = () => {
    if (!manifest) return;
    setDownloading(true);
    try {
      generateManifestPDF(reservation, manifest, { reference: fileReference, title: fileTitle });
      toast.success("Manifest downloaded");
    } catch {
      toast.error("Could not generate the manifest PDF.");
    } finally {
      setDownloading(false);
    }
  };

  const includedCount = manifest?.filter((p) => p.included).length ?? 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <ClipboardList className="size-5" />
            {reservation.supplierName}
          </DialogTitle>
          <DialogDescription>
            {reservation.description} · {formatDate(reservation.startDate)}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid gap-2 rounded-lg border bg-muted/40 p-3 text-sm sm:grid-cols-2">
            <div className="flex items-start gap-2">
              <MapPin className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Pickup place & time</p>
                <p className="font-medium">
                  {reservation.pickupLocation || "—"}
                  {reservation.pickupTime ? ` · ${reservation.pickupTime}` : ""}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <PlaneLanding className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Flight details</p>
                <p className="font-medium">{reservation.flightDetails || "—"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <User className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Guide</p>
                <p className="font-medium">{reservation.guideName || "—"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Phone className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Guide mobile</p>
                <p className="font-medium">{reservation.guidePhone || "—"}</p>
              </div>
            </div>
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-sm font-semibold">
                Passenger manifest
                {manifest ? (
                  <span className="ml-2 text-xs font-normal text-muted-foreground">
                    {includedCount} of {manifest.length} going
                  </span>
                ) : null}
              </p>
              <Button
                size="sm"
                variant="secondary"
                disabled={!manifest || manifest.length === 0 || downloading}
                onClick={handleDownload}
              >
                {downloading ? <Spinner /> : <Download className="size-4" />}
                PDF
              </Button>
            </div>
            {manifest === undefined ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : manifest.length === 0 ? (
              <p className="rounded-lg border px-3 py-4 text-center text-sm text-muted-foreground">
                Add passengers to this file to build a manifest.
              </p>
            ) : (
              <div className="max-h-80 space-y-2 overflow-y-auto">
                {manifest.map((p) => (
                  <ManifestRow
                    key={p._id}
                    passenger={p}
                    reservationId={reservation._id}
                    locked={locked}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
