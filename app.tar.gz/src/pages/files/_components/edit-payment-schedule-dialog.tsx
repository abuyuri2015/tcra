import { useEffect, useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { Plus, Settings2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";

type ScheduleItem = Doc<"paymentSchedules">["items"][number];

/** Local editable draft of an item — kept as strings for free typing in number inputs. */
type ItemDraft = {
  id: string;
  label: string;
  percent: string;
  triggerType: "on_confirmation" | "days_before_departure";
  triggerDays: string;
  financeLineId: ScheduleItem["financeLineId"];
  invoiceNumber: ScheduleItem["invoiceNumber"];
  invoicedAt: ScheduleItem["invoicedAt"];
};

function toDrafts(items: ScheduleItem[]): ItemDraft[] {
  return items.map((i) => ({
    id: i.id,
    label: i.label,
    percent: String(i.percent),
    triggerType: i.triggerType,
    triggerDays: i.triggerDays !== undefined ? String(i.triggerDays) : "",
    financeLineId: i.financeLineId,
    invoiceNumber: i.invoiceNumber,
    invoicedAt: i.invoicedAt,
  }));
}

export default function EditPaymentScheduleDialog({
  schedule,
}: {
  schedule: Doc<"paymentSchedules">;
}) {
  const [open, setOpen] = useState(false);
  const [totalValueEur, setTotalValueEur] = useState(String(schedule.totalValueEur));
  const [items, setItems] = useState<ItemDraft[]>(toDrafts(schedule.items));
  const [saving, setSaving] = useState(false);
  const update = useMutation(api.paymentSchedules.update);

  useEffect(() => {
    if (open) {
      setTotalValueEur(String(schedule.totalValueEur));
      setItems(toDrafts(schedule.items));
    }
  }, [open, schedule]);

  const updateItem = (id: string, fields: Partial<ItemDraft>) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...fields } : i)));
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const addItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).slice(2, 10),
        label: "New installment",
        percent: "0",
        triggerType: "days_before_departure",
        triggerDays: "7",
        financeLineId: undefined,
        invoiceNumber: undefined,
        invoicedAt: undefined,
      },
    ]);
  };

  const totalPercent = items.reduce((s, i) => s + (Number(i.percent) || 0), 0);

  const handleSave = async () => {
    const total = Number(totalValueEur);
    if (!Number.isFinite(total) || total < 0) {
      toast.error("Enter a valid total value.");
      return;
    }
    for (const item of items) {
      if (!item.label.trim()) {
        toast.error("Every installment needs a label.");
        return;
      }
      if (!Number.isFinite(Number(item.percent))) {
        toast.error("Enter a valid percentage for every installment.");
        return;
      }
      if (
        item.triggerType === "days_before_departure" &&
        (!Number.isFinite(Number(item.triggerDays)) || Number(item.triggerDays) < 0)
      ) {
        toast.error("Enter a valid number of days before departure.");
        return;
      }
    }

    setSaving(true);
    try {
      await update({
        id: schedule._id,
        totalValueEur: total,
        items: items.map((i) => ({
          id: i.id,
          label: i.label.trim(),
          percent: Number(i.percent),
          triggerType: i.triggerType,
          triggerDays:
            i.triggerType === "days_before_departure" ? Number(i.triggerDays) : undefined,
          financeLineId: i.financeLineId,
          invoiceNumber: i.invoiceNumber,
          invoicedAt: i.invoicedAt,
        })),
      });
      toast.success("Payment schedule updated");
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save the payment schedule.";
      toast.error(message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary" size="sm">
          <Settings2 className="size-4" />
          Edit schedule
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display">Edit payment schedule</DialogTitle>
          <DialogDescription>
            Adjust the package value, installment labels, percentages, and
            when each becomes due. Changes only affect invoices generated
            from now on.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>Total package value (EUR)</Label>
            <Input
              type="number"
              step="0.01"
              value={totalValueEur}
              onChange={(e) => setTotalValueEur(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            {items.map((item) => {
              const isInvoiced = item.financeLineId !== undefined;
              return (
                <div
                  key={item.id}
                  className="grid gap-2 rounded-lg border p-3 sm:grid-cols-[1fr_auto_auto_auto]"
                >
                  <div className="space-y-1.5">
                    <Label className="text-xs">Label</Label>
                    <Input
                      value={item.label}
                      disabled={isInvoiced}
                      onChange={(e) => updateItem(item.id, { label: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">%</Label>
                    <Input
                      type="number"
                      step="1"
                      className="w-20"
                      value={item.percent}
                      disabled={isInvoiced}
                      onChange={(e) => updateItem(item.id, { percent: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Due</Label>
                    <Select
                      value={item.triggerType}
                      disabled={isInvoiced}
                      onValueChange={(v) =>
                        updateItem(item.id, {
                          triggerType: v as ItemDraft["triggerType"],
                        })
                      }
                    >
                      <SelectTrigger className="w-44">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="on_confirmation">On confirmation</SelectItem>
                        <SelectItem value="days_before_departure">
                          Days before departure
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {item.triggerType === "days_before_departure" ? (
                    <div className="space-y-1.5">
                      <Label className="text-xs">Days</Label>
                      <Input
                        type="number"
                        step="1"
                        min={0}
                        className="w-20"
                        value={item.triggerDays}
                        disabled={isInvoiced}
                        onChange={(e) => updateItem(item.id, { triggerDays: e.target.value })}
                      />
                    </div>
                  ) : (
                    <div />
                  )}
                  <div className="col-span-full flex items-center justify-between">
                    {isInvoiced ? (
                      <p className="text-xs text-muted-foreground">
                        Already invoiced ({item.invoiceNumber}) — locked from editing.
                      </p>
                    ) : (
                      <span />
                    )}
                    {!isInvoiced && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="size-7"
                        onClick={() => removeItem(item.id)}
                        aria-label="Remove installment"
                      >
                        <Trash2 className="size-3.5 text-destructive" />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between">
            <Button type="button" variant="secondary" size="sm" onClick={addItem}>
              <Plus className="size-4" />
              Add installment
            </Button>
            <p
              className={
                totalPercent === 100
                  ? "text-sm text-muted-foreground"
                  : "text-sm font-medium text-amber-600 dark:text-amber-400"
              }
            >
              Total: {totalPercent}%
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={saving}>
            Cancel
          </Button>
          <Button type="button" onClick={handleSave} disabled={saving}>
            {saving ? "Saving…" : "Save schedule"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
