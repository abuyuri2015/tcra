import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  COST_CATEGORY_OPTIONS,
  CURRENCY_OPTIONS,
  formatMoney,
  INCOME_CATEGORY_OPTIONS,
} from "@/lib/domain.ts";
import { dateInputToIso, isoToDateInput } from "@/lib/dates.ts";
import type { ReactNode } from "react";

type FinanceLine = {
  _id: Id<"financeLines">;
  groupFileId: Id<"groupFiles">;
  kind: "cost" | "income";
  category: string;
  description: string;
  supplierName?: string;
  amount: number;
  currency: string;
  exchangeRateToBase: number;
  unitRate?: number;
  quantity?: number;
  quantityLabel?: string;
  notes?: string;
  paymentDueDate?: string;
};

const schema = z
  .object({
    kind: z.enum(["cost", "income"]),
    category: z.string().min(1, "Pick a category"),
    description: z.string().min(1, "Description is required"),
    supplierName: z.string(),
    useBreakdown: z.boolean(),
    unitRate: z.string(),
    quantity: z.string(),
    quantityLabel: z.string(),
    amount: z.string(),
    currency: z.enum(CURRENCY_OPTIONS),
    exchangeRateToBase: z
      .string()
      .refine((v) => Number(v) > 0, { message: "Rate must be > 0" }),
    notes: z.string(),
    paymentDueDate: z.string(),
  })
  .superRefine((values, ctx) => {
    if (values.useBreakdown) {
      if (!Number.isFinite(Number(values.unitRate)) || Number(values.unitRate) <= 0) {
        ctx.addIssue({ code: "custom", path: ["unitRate"], message: "Enter a rate per unit" });
      }
      if (!Number.isInteger(Number(values.quantity)) || Number(values.quantity) <= 0) {
        ctx.addIssue({ code: "custom", path: ["quantity"], message: "Enter a quantity" });
      }
    } else if (!Number.isFinite(Number(values.amount)) || Number(values.amount) === 0) {
      ctx.addIssue({
        code: "custom",
        path: ["amount"],
        message: "Enter an amount (use a negative value for a credit note)",
      });
    }
  });

type FormValues = z.output<typeof schema>;

function defaults(
  line: FinanceLine | undefined,
  fileCurrency: string,
  fileExchangeRate: number,
  initialKind: "cost" | "income",
): FormValues {
  if (!line) {
    return {
      kind: initialKind,
      category: "",
      description: "",
      supplierName: "",
      useBreakdown: false,
      unitRate: "",
      quantity: "",
      quantityLabel: "",
      amount: "",
      currency: fileCurrency as FormValues["currency"],
      exchangeRateToBase: String(fileExchangeRate),
      notes: "",
      paymentDueDate: "",
    };
  }
  const hasBreakdown = line.unitRate !== undefined && line.quantity !== undefined;
  return {
    kind: line.kind,
    category: line.category,
    description: line.description,
    supplierName: line.supplierName ?? "",
    useBreakdown: hasBreakdown,
    unitRate: hasBreakdown ? String(line.unitRate) : "",
    quantity: hasBreakdown ? String(line.quantity) : "",
    quantityLabel: line.quantityLabel ?? "",
    amount: String(line.amount),
    currency: line.currency as FormValues["currency"],
    exchangeRateToBase: String(line.exchangeRateToBase),
    notes: line.notes ?? "",
    paymentDueDate: line.paymentDueDate ? isoToDateInput(line.paymentDueDate) : "",
  };
}

export default function FinanceLineFormDialog({
  groupFileId,
  fileCurrency,
  fileExchangeRate,
  line,
  initialKind = "cost",
  trigger,
}: {
  groupFileId: Id<"groupFiles">;
  fileCurrency: string;
  fileExchangeRate: number;
  line?: FinanceLine;
  initialKind?: "cost" | "income";
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const create = useMutation(api.financeLines.create);
  const update = useMutation(api.financeLines.update);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaults(line, fileCurrency, fileExchangeRate, initialKind),
  });

  const watchKind = form.watch("kind");
  const watchCurrency = form.watch("currency");
  const watchUseBreakdown = form.watch("useBreakdown");
  const watchUnitRate = form.watch("unitRate");
  const watchQuantity = form.watch("quantity");
  const categories =
    watchKind === "cost" ? COST_CATEGORY_OPTIONS : INCOME_CATEGORY_OPTIONS;

  const computedAmount =
    watchUseBreakdown && Number(watchUnitRate) > 0 && Number(watchQuantity) > 0
      ? Number(watchUnitRate) * Number(watchQuantity)
      : undefined;

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next)
      form.reset(defaults(line, fileCurrency, fileExchangeRate, initialKind));
  };

  const onSubmit = async (values: FormValues) => {
    const amount = values.useBreakdown
      ? Number(values.unitRate) * Number(values.quantity)
      : Number(values.amount);
    const payload = {
      groupFileId,
      kind: values.kind,
      category: values.category,
      description: values.description.trim(),
      supplierName: values.supplierName.trim() || undefined,
      amount,
      currency: values.currency,
      exchangeRateToBase: Number(values.exchangeRateToBase),
      unitRate: values.useBreakdown ? Number(values.unitRate) : undefined,
      quantity: values.useBreakdown ? Number(values.quantity) : undefined,
      quantityLabel: values.useBreakdown
        ? values.quantityLabel.trim() || undefined
        : undefined,
      notes: values.notes.trim() || undefined,
      paymentDueDate: values.paymentDueDate ? dateInputToIso(values.paymentDueDate) : undefined,
    };
    try {
      if (line) {
        const { groupFileId: _groupFileId, ...updateFields } = payload;
        await update({ id: line._id, ...updateFields });
        toast.success("Line updated");
      } else {
        await create(payload);
        toast.success(
          `${values.kind === "cost" ? "Cost" : "Income"} line added`,
        );
      }
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save. Please try again.";
      toast.error(message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">
            {line ? "Edit line" : "Add finance line"}
          </DialogTitle>
          <DialogDescription>
            Track a cost or income item against this group file.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            {/* Kind toggle — only shown when creating */}
            {!line && (
              <FormField
                control={form.control}
                name="kind"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Type</FormLabel>
                    <FormControl>
                      <Tabs
                        value={field.value}
                        onValueChange={(v) => {
                          field.onChange(v);
                          form.setValue("category", "");
                        }}
                      >
                        <TabsList className="w-full">
                          <TabsTrigger value="cost" className="flex-1">
                            Cost
                          </TabsTrigger>
                          <TabsTrigger value="income" className="flex-1">
                            Income
                          </TabsTrigger>
                        </TabsList>
                      </Tabs>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Category */}
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select…" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((c) => (
                        <SelectItem key={c.value} value={c.value}>
                          {c.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Supplier */}
            <FormField
              control={form.control}
              name="supplierName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Supplier / source</FormLabel>
                  <FormControl>
                    <Input placeholder="Hotel Arts" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g. 20 rooms × 3 nights, half board"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Breakdown toggle */}
            <FormField
              control={form.control}
              name="useBreakdown"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>How was this calculated?</FormLabel>
                  <FormControl>
                    <Tabs
                      value={field.value ? "breakdown" : "flat"}
                      onValueChange={(v) => field.onChange(v === "breakdown")}
                    >
                      <TabsList className="w-full">
                        <TabsTrigger value="flat" className="flex-1">
                          Single amount
                        </TabsTrigger>
                        <TabsTrigger value="breakdown" className="flex-1">
                          Rate × quantity
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </FormControl>
                  <FormDescription>
                    Rate × quantity discloses the calculation to the client on
                    the invoice and booking confirmation, e.g. "€120 × 25
                    rooms". Use a single amount for one-off items.
                  </FormDescription>
                </FormItem>
              )}
            />

            {watchUseBreakdown ? (
              <>
                {/* Unit rate */}
                <FormField
                  control={form.control}
                  name="unitRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rate per unit</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="120.00" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                {/* Quantity */}
                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantity</FormLabel>
                      <FormControl>
                        <Input type="number" step="1" min={1} placeholder="25" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                {/* Quantity label */}
                <FormField
                  control={form.control}
                  name="quantityLabel"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Unit label (optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="rooms, pax, nights…" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                {computedAmount !== undefined && (
                  <p className="sm:col-span-2 rounded-md bg-muted/60 px-3 py-2 text-sm">
                    Total: <span className="font-semibold">{formatMoney(computedAmount, watchCurrency)}</span>
                  </p>
                )}
              </>
            ) : (
              /* Flat amount */
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Amount</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Use a negative amount for a credit note / refund
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Currency */}
            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Currency</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {CURRENCY_OPTIONS.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Exchange rate — shown when currency ≠ EUR */}
            {watchCurrency !== "EUR" && (
              <FormField
                control={form.control}
                name="exchangeRateToBase"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>
                      Exchange rate ({watchCurrency} → EUR)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={0.0001}
                        step="0.0001"
                        placeholder="1.0"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      1 {watchCurrency} = this many EUR. The file's default
                      rate is {fileExchangeRate}.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Payment due date */}
            <FormField
              control={form.control}
              name="paymentDueDate"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Payment due date (optional)</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormDescription>
                    Flags this line as an overdue payment on the dashboard once
                    it's unpaid past this date.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                {line ? "Save changes" : "Add line"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
