import { z } from "zod";
import { CURRENCY_OPTIONS } from "@/lib/domain.ts";

// Note: `description` is intentionally NOT required at the schema level.
// `roomTypes` always holds a default blank entry even for non-hotel or
// single-item offers (where it's hidden and unused), so a `.min(1)` here
// would block every offer submission, not just multi-room ones. The multi-
// room submit path validates non-empty descriptions itself (mirrored by the
// backend `createHotelOffer` mutation).
export const roomTypeSchema = z.object({
  description: z.string(),
  units: z
    .string()
    .refine((v) => Number.isInteger(Number(v)) && Number(v) >= 1, {
      message: "At least 1 unit",
    }),
  unitLabel: z.string(),
  ratePerUnit: z
    .string()
    .refine((v) => v === "" || Number(v) >= 0, { message: "Enter a positive rate" }),
  costPerUnit: z
    .string()
    .refine((v) => v === "" || Number(v) >= 0, { message: "Enter a positive cost" }),
});

export const offerFormSchema = z.object({
  type: z.enum([
    "hotel",
    "transfer",
    "restaurant",
    "activity",
    "venue",
    "flight",
    "other",
  ]),
  status: z.enum(["pending", "accepted", "rejected"]),
  supplierName: z.string().min(1, "Supplier name is required"),
  hotelId: z.string(),
  // Only required for a single-item offer. When adding a hotel offer with
  // several room types, this field is hidden and each room type's own
  // description is used instead — validated separately in the submit handler.
  description: z.string(),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string(),
  units: z
    .string()
    .refine((v) => Number.isInteger(Number(v)) && Number(v) >= 1, {
      message: "At least 1 unit",
    }),
  unitLabel: z.string(),
  board: z.string(),
  nights: z.string().refine(
    (v) => v === "" || (Number.isInteger(Number(v)) && Number(v) >= 0),
    { message: "Enter a whole number" },
  ),
  supplierRef: z.string(),
  ratePerUnit: z
    .string()
    .refine((v) => v === "" || Number(v) >= 0, { message: "Enter a positive rate" }),
  costPerUnit: z
    .string()
    .refine((v) => v === "" || Number(v) >= 0, { message: "Enter a positive cost" }),
  currency: z.enum(CURRENCY_OPTIONS),
  notes: z.string(),
  roomTypes: z.array(roomTypeSchema),
});

export type OfferFormValues = z.output<typeof offerFormSchema>;

export type BoardValue = "room-only" | "breakfast" | "half-board" | "full-board" | "all-inclusive";

export function isBoardValue(v: string): v is BoardValue {
  return ["room-only", "breakfast", "half-board", "full-board", "all-inclusive"].includes(v);
}

export const BLANK_ROOM_TYPE = {
  description: "",
  units: "1",
  unitLabel: "",
  ratePerUnit: "",
  costPerUnit: "",
};
