import { useState } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { differenceInCalendarDays, parseISO } from "date-fns";
import { AlertTriangle, CalendarClock, CircleCheck, FileText, ReceiptText } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import { formatDate } from "@/lib/dates.ts";
import { formatMoney } from "@/lib/domain.ts";
import EditPaymentScheduleDialog from "./edit-payment-schedule-dialog.tsx";
import SendScheduleInvoiceDialog from "./send-schedule-invoice-dialog.tsx";
import type { AgencyProfilePDF } from "@/lib/pdf-generators.ts";

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type ScheduleItem = Doc<"paymentSchedules">["items"][number];

/** Days an installment is flagged as "approaching" before its due date, even if not yet overdue. */
const APPROACHING_THRESHOLD_DAYS = 7;

/** Days until an item's due date, or null when it has no fixed due date yet (on_confirmation is always "due now"). */
function dueInDays(item: ScheduleItem, startDate: string): number | null {
  if (item.triggerType === "on_confirmation") return 0;
  const departure = parseISO(startDate);
  const dueDate = new Date(departure);
  dueDate.setDate(dueDate.getDate() - (item.triggerDays ?? 0));
  return differenceInCalendarDays(dueDate, new Date());
}

type DueUrgency = "overdue" | "approaching" | "normal";

function dueLabel(
  item: ScheduleItem,
  startDate: string,
): { text: string; urgency: DueUrgency } {
  if (item.financeLineId) {
    return { text: `Invoiced ${item.invoicedAt ? formatDate(item.invoicedAt) : ""}`, urgency: "normal" };
  }
  const days = dueInDays(item, startDate);
  if (days === null) return { text: "Due on confirmation", urgency: "approaching" };
  if (days < 0) return { text: `Overdue by ${Math.abs(days)}d`, urgency: "overdue" };
  if (days === 0) return { text: "Due today", urgency: "overdue" };
  if (days <= APPROACHING_THRESHOLD_DAYS) return { text: `Due in ${days}d`, urgency: "approaching" };
  return { text: `Due in ${days}d`, urgency: "normal" };
}


export default function PaymentScheduleCard({
  groupFileId,
  file,
  totalIncomeEur,
}: {
  groupFileId: Id<"groupFiles">;
  file: GroupFile;
  totalIncomeEur: number;
}) {
  const schedule = useQuery(api.paymentSchedules.getByFile, { groupFileId });
  const agencyProfile = useQuery(api.agencyProfile.get);
  const ensureDefault = useMutation(api.paymentSchedules.ensureDefault);
  const listIdentities = useAction(api.email.identities.list);
  const [senderIdentities, setSenderIdentities] = useState<
    { id: string; value: string; type: string; status: string }[]
  >([]);
  const [identitiesLoaded, setIdentitiesLoaded] = useState(false);
  const [creating, setCreating] = useState(false);

  const loadIdentities = () => {
    if (identitiesLoaded) return;
    setIdentitiesLoaded(true);
    listIdentities({}).then(setSenderIdentities).catch(() => setSenderIdentities([]));
  };

  if (schedule === undefined || agencyProfile === undefined) {
    return <Skeleton className="h-40 w-full" />;
  }

  const agency: AgencyProfilePDF = agencyProfile
    ? {
        agencyName: agencyProfile.agencyName,
        address: agencyProfile.address,
        phone: agencyProfile.phone,
        email: agencyProfile.email,
        website: agencyProfile.website,
        bankName: agencyProfile.bankName,
        iban: agencyProfile.iban,
        bic: agencyProfile.bic,
        paymentTerms: agencyProfile.paymentTerms,
        termsAndConditions: agencyProfile.termsAndConditions,
        taxId: agencyProfile.taxId,
      }
    : null;

  // Only offer a payment schedule once the file is confirmed or further
  // along — nothing to invoice while still an enquiry/quote.
  const eligible = file.status !== "enquiry" && file.status !== "quoted";
  if (!eligible && !schedule) return null;

  if (!schedule) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display flex items-center gap-2 text-base">
            <ReceiptText className="size-4 text-muted-foreground" />
            Payment schedule
          </CardTitle>
          <CardDescription>
            Split this booking into a deposit and pre-departure installments
            (10% / 50% / 40% by default — fully editable).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            size="sm"
            disabled={creating}
            onClick={async () => {
              setCreating(true);
              try {
                await ensureDefault({ groupFileId, totalValueEur: totalIncomeEur });
              } finally {
                setCreating(false);
              }
            }}
          >
            {creating ? "Creating…" : "Create payment schedule"}
          </Button>
        </CardContent>
      </Card>
    );
  }

  const items = schedule.items;
  const overdueCount = items.filter(
    (i) => !i.financeLineId && dueLabel(i, file.startDate).urgency === "overdue",
  ).length;
  const approachingCount = items.filter(
    (i) => !i.financeLineId && dueLabel(i, file.startDate).urgency === "approaching",
  ).length;

  return (
    <Card onMouseEnter={loadIdentities} onFocus={loadIdentities}>
      <CardHeader className="flex-row items-center justify-between">
        <div>
          <CardTitle className="font-display flex items-center gap-2 text-base">
            <ReceiptText className="size-4 text-muted-foreground" />
            Payment schedule
            {overdueCount > 0 && (
              <Badge variant="destructive" className="gap-1">
                <AlertTriangle className="size-3" />
                {overdueCount} overdue
              </Badge>
            )}
            {overdueCount === 0 && approachingCount > 0 && (
              <Badge variant="outline" className="gap-1 border-chart-2/50 bg-chart-2/10 text-chart-2 font-semibold">
                <CalendarClock className="size-3" />
                {approachingCount} due soon
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            Based on a package value of {formatMoney(schedule.totalValueEur, "EUR")}
          </CardDescription>
        </div>
        <EditPaymentScheduleDialog schedule={schedule} />
      </CardHeader>
      <CardContent className="space-y-2">
        {items.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted-foreground">
            No installments yet — click &quot;Edit schedule&quot; to add one.
          </p>
        ) : (
          items.map((item) => {
            const amountEur = (schedule.totalValueEur * item.percent) / 100;
            const due = dueLabel(item, file.startDate);
            const invoiced = item.financeLineId !== undefined;
            const invoiceNumber =
              item.invoiceNumber ?? `INV-${file.reference.replace(/^GM-/, "")}-${item.id.slice(0, 4).toUpperCase()}`;

            return (
              <div
                key={item.id}
                className={cn(
                  "flex flex-wrap items-center justify-between gap-3 rounded-lg border px-4 py-3",
                  !invoiced && due.urgency === "overdue" && "border-destructive/40 bg-destructive/5",
                  !invoiced && due.urgency === "approaching" && "border-chart-2/40 bg-chart-2/5",
                )}
              >
                <div className="min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium">{item.label}</span>
                    <Badge variant="secondary">{item.percent}%</Badge>
                    {invoiced ? (
                      <Badge variant="outline" className="gap-1 text-chart-3">
                        <CircleCheck className="size-3" />
                        Invoiced
                      </Badge>
                    ) : due.urgency === "overdue" ? (
                      <Badge variant="destructive" className="gap-1">
                        <AlertTriangle className="size-3" />
                        {due.text}
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className={cn(
                          "gap-1",
                          due.urgency === "approaching" && "border-chart-2/50 bg-chart-2/10 text-chart-2 font-semibold",
                        )}
                      >
                        <CalendarClock className="size-3" />
                        {due.text}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm font-semibold">{formatMoney(amountEur, "EUR")}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.triggerType === "on_confirmation"
                      ? "Due on confirmation"
                      : `Due ${item.triggerDays} days before departure (${formatDate(file.startDate)})`}
                  </p>
                </div>

                {file.clientContactEmail ? (
                  <SendScheduleInvoiceDialog
                    file={file}
                    scheduleId={schedule._id}
                    item={item}
                    invoiceNumber={invoiceNumber}
                    amountEur={amountEur}
                    agency={agency}
                    senderIdentities={senderIdentities}
                    trigger={
                      <Button size="sm" variant={invoiced ? "secondary" : "default"}>
                        <FileText className="size-4" />
                        {invoiced ? "Resend invoice" : "Generate & send"}
                      </Button>
                    }
                  />
                ) : (
                  <p className="text-xs text-muted-foreground">
                    Add a client email to send invoices
                  </p>
                )}
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
