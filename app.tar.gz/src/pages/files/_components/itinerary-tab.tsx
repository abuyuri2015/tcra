import { useMutation, useQuery, useAction } from "convex/react";
import { ConvexError } from "convex/values";
import {
  CalendarDays,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  MapPin,
  Pencil,
  Plus,
  RefreshCw,
  Send,
  Trash2,
} from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import ItineraryItemFormDialog from "./itinerary-item-form-dialog.tsx";
import ItineraryDayFormDialog from "./itinerary-day-form-dialog.tsx";
import SendItineraryDialog from "./send-itinerary-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { formatDate } from "@/lib/dates.ts";
import {
  ITINERARY_ITEM_TYPE_COLORS,
  itineraryItemTypeLabel,
} from "@/lib/itinerary.ts";
import ItineraryAiImport from "./itinerary-ai-import.tsx";

type Day = Doc<"itineraryDays"> & { items: Doc<"itineraryItems">[] };

function ItemRow({
  item,
  dayId,
  groupFileId,
  isFirst,
  isLast,
  totalItems,
}: {
  item: Doc<"itineraryItems">;
  dayId: Id<"itineraryDays">;
  groupFileId: Id<"groupFiles">;
  isFirst: boolean;
  isLast: boolean;
  totalItems: number;
}) {
  const removeItem = useMutation(api.itinerary.removeItem);
  const reorderItem = useMutation(api.itinerary.reorderItem);

  const handleDelete = async () => {
    try {
      await removeItem({ id: item._id });
      toast.success("Item removed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not remove item.";
      toast.error(message);
    }
  };

  const handleMove = async (direction: "up" | "down") => {
    const newOrder =
      direction === "up" ? item.sortOrder - 1.5 : item.sortOrder + 1.5;
    await reorderItem({ id: item._id, sortOrder: newOrder });
  };

  const colorClass =
    ITINERARY_ITEM_TYPE_COLORS[item.type] ?? "bg-muted text-muted-foreground";

  return (
    <div className="flex items-start gap-3 rounded-lg border px-4 py-3">
      {/* Time column */}
      <div className="w-14 shrink-0 pt-0.5 text-right text-xs font-mono text-muted-foreground">
        {item.time ?? ""}
      </div>

      {/* Type badge + content */}
      <div className="min-w-0 flex-1 space-y-0.5">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              colorClass,
            )}
          >
            {itineraryItemTypeLabel(item.type)}
          </span>
          <span className="text-sm font-medium">{item.title}</span>
        </div>
        {item.location && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="size-3" />
            {item.location}
          </div>
        )}
        {item.description && (
          <p className="text-sm text-muted-foreground">{item.description}</p>
        )}
        {item.notes && (
          <p className="rounded bg-muted/60 px-2 py-1 text-xs text-muted-foreground italic">
            Internal: {item.notes}
          </p>
        )}
      </div>

      {/* Actions */}
      <div className="flex shrink-0 items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="size-6"
          disabled={isFirst}
          onClick={() => handleMove("up")}
          aria-label="Move up"
        >
          <ChevronUp className="size-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-6"
          disabled={isLast}
          onClick={() => handleMove("down")}
          aria-label="Move down"
        >
          <ChevronDown className="size-3.5" />
        </Button>
        <ItineraryItemFormDialog
          dayId={dayId}
          groupFileId={groupFileId}
          nextSortOrder={totalItems}
          item={item}
          trigger={
            <Button variant="ghost" size="icon" className="size-6" aria-label="Edit">
              <Pencil className="size-3" />
            </Button>
          }
        />
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" className="size-6" aria-label="Remove">
              <Trash2 className="size-3 text-destructive" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Remove this item?</AlertDialogTitle>
              <AlertDialogDescription>
                "{item.title}" will be permanently removed from this day.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete}>Remove</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

function DayCard({
  day,
  groupFileId,
}: {
  day: Day;
  groupFileId: Id<"groupFiles">;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const removeDay = useMutation(api.itinerary.removeDay);

  const handleDeleteDay = async () => {
    try {
      await removeDay({ id: day._id });
      toast.success("Day removed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not remove day.";
      toast.error(message);
    }
  };

  const nextSortOrder = day.items.length > 0
    ? Math.max(...day.items.map((i) => i.sortOrder)) + 1
    : 1;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-2 pb-2">
        <button
          className="flex min-w-0 flex-1 items-center gap-3 text-left"
          onClick={() => setCollapsed((v) => !v)}
        >
          <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-sidebar-primary text-sidebar-primary-foreground text-xs font-bold">
            {day.dayNumber}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold">
              {day.title ?? `Day ${day.dayNumber}`}
            </p>
            <p className="text-xs text-muted-foreground">{formatDate(day.date)}</p>
          </div>
          {collapsed ? (
            <ChevronDown className="size-4 shrink-0 text-muted-foreground" />
          ) : (
            <ChevronUp className="size-4 shrink-0 text-muted-foreground" />
          )}
        </button>

        <div className="flex shrink-0 items-center gap-1">
          <ItineraryDayFormDialog
            day={day}
            trigger={
              <Button variant="ghost" size="icon" className="size-7" aria-label="Edit day">
                <Pencil className="size-3.5" />
              </Button>
            }
          />
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" className="size-7" aria-label="Remove day">
                <Trash2 className="size-3.5 text-destructive" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Remove Day {day.dayNumber}?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently remove Day {day.dayNumber} and all its{" "}
                  {day.items.length} item{day.items.length !== 1 ? "s" : ""}.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteDay}>Remove</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardHeader>

      {!collapsed && (
        <CardContent className="space-y-2 pt-0">
          {day.items.length === 0 ? (
            <p className="py-2 text-center text-sm text-muted-foreground">
              No items yet — add the first one below.
            </p>
          ) : (
            day.items.map((item, idx) => (
              <ItemRow
                key={item._id}
                item={item}
                dayId={day._id}
                groupFileId={groupFileId}
                isFirst={idx === 0}
                isLast={idx === day.items.length - 1}
                totalItems={day.items.length}
              />
            ))
          )}
          <ItineraryItemFormDialog
            dayId={day._id}
            groupFileId={groupFileId}
            nextSortOrder={nextSortOrder}
            trigger={
              <Button variant="secondary" size="sm" className="mt-1 w-full">
                <Plus className="size-4" />
                Add item to Day {day.dayNumber}
              </Button>
            }
          />
        </CardContent>
      )}
    </Card>
  );
}

export default function ItineraryTab({
  groupFileId,
  fileId,
  file,
}: {
  groupFileId: Id<"groupFiles">;
  fileId: string;
  file: Doc<"groupFiles"> & { ownerName?: string | null };
}) {
  const days = useQuery(api.itinerary.listByFile, { groupFileId });
  const generateDays = useMutation(api.itinerary.generateDays);
  const listIdentities = useAction(api.email.identities.list);
  const [generating, setGenerating] = useState(false);
  const [senderIdentities, setSenderIdentities] = useState<
    { id: string; value: string; type: string; status: string }[]
  >([]);

  useEffect(() => {
    listIdentities({}).then(setSenderIdentities).catch(() => setSenderIdentities([]));
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      await generateDays({ groupFileId });
      toast.success("Days generated from file dates");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not generate days.";
      toast.error(message);
    } finally {
      setGenerating(false);
    }
  };

  if (days === undefined) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  const clientUrl = `${window.location.origin}/itinerary/${fileId}`;

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {days.length > 0 && (
            <>
              <a
                href={clientUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm font-medium hover:bg-muted"
              >
                <ExternalLink className="size-4" />
                Client view
              </a>
              <SendItineraryDialog
                file={file}
                itineraryUrl={clientUrl}
                senderIdentities={senderIdentities}
                trigger={
                  <Button size="sm" variant="secondary">
                    <Send className="size-4" />
                    Email itinerary
                  </Button>
                }
              />
            </>
          )}
        </div>
        <div className="flex items-center gap-2">
          <ItineraryAiImport groupFileId={groupFileId} startDate={file.startDate} />
          <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="secondary" size="sm" disabled={generating}>
              <RefreshCw className={cn("size-4", generating && "animate-spin")} />
              {days.length > 0 ? "Regenerate days" : "Generate days from dates"}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {days.length > 0 ? "Regenerate all days?" : "Generate days?"}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {days.length > 0
                  ? "This will delete all existing days and items and recreate them from the file's start and end dates. This cannot be undone."
                  : "This will create one day per date between the file's start and end dates."}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleGenerate}>
                {days.length > 0 ? "Regenerate" : "Generate"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
        </div>
      </div>

      {days.length === 0 ? (
        <Card>
          <CardContent className="py-8">
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <CalendarDays />
                </EmptyMedia>
                <EmptyTitle>No itinerary yet</EmptyTitle>
                <EmptyDescription>
                  Generate days automatically from the file's dates, then add
                  events to each day. Share a clean client-facing view with one
                  click.
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" disabled={generating}>
                      <CalendarDays className="size-4" />
                      Generate days from dates
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Generate days?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will create one day per date between the file's
                        start and end dates.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleGenerate}>
                        Generate
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </EmptyContent>
            </Empty>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {days.map((day) => (
            <DayCard key={day._id} day={day} groupFileId={groupFileId} />
          ))}
        </div>
      )}
    </div>
  );
}
