import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, usePaginatedQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import OfferRoomTypeFields from "./offer-room-type-fields.tsx";
import OfferQuantityFields from "./offer-quantity-fields.tsx";
import OfferSupplierFields from "./offer-supplier-fields.tsx";
import {
  BLANK_ROOM_TYPE,
  isBoardValue,
  offerFormSchema,
  type OfferFormValues,
} from "./offer-form-schema.ts";
import {
  CURRENCY_OPTIONS,
  OFFER_STATUS_OPTIONS,
  RESERVATION_TYPE_OPTIONS,
} from "@/lib/domain.ts";
import { dateInputToIso, isoToDateInput } from "@/lib/dates.ts";
import type { ReactNode } from "react";

function defaultsFor(
  offer: Doc<"offers"> | undefined,
  fileCurrency: string,
  fileStartDate: string,
  fileEndDate: string,
): OfferFormValues {
  if (!offer) {
    return {
      type: "hotel",
      status: "pending",
      supplierName: "",
      hotelId: "",
      description: "",
      startDate: fileStartDate,
      endDate: fileEndDate,
      units: "1",
      unitLabel: "",
      board: "",
      nights: "",
      supplierRef: "",
      ratePerUnit: "",
      costPerUnit: "",
      currency: fileCurrency as OfferFormValues["currency"],
      notes: "",
      roomTypes: [{ ...BLANK_ROOM_TYPE }],
    };
  }
  return {
    type: offer.type,
    status: offer.status,
    supplierName: offer.supplierName,
    hotelId: offer.hotelId ?? "",
    description: offer.description,
    startDate: isoToDateInput(offer.startDate),
    endDate: offer.endDate ? isoToDateInput(offer.endDate) : "",
    units: String(offer.units),
    unitLabel: offer.unitLabel ?? "",
    board: offer.board ?? "",
    nights: offer.nights !== undefined ? String(offer.nights) : "",
    supplierRef: offer.supplierRef ?? "",
    ratePerUnit: offer.ratePerUnit !== undefined ? String(offer.ratePerUnit) : "",
    costPerUnit: offer.costPerUnit !== undefined ? String(offer.costPerUnit) : "",
    currency: offer.currency,
    notes: offer.notes ?? "",
    roomTypes: [{ ...BLANK_ROOM_TYPE }],
  };
}

/** Loads hotels for the picker — always rendered (hook rule) */
function useHotelOptions() {
  const { results, status } = usePaginatedQuery(
    api.hotels.list,
    {},
    { initialNumItems: 200 },
  );
  return { hotels: results, loading: status === "LoadingFirstPage" };
}

export default function OfferFormDialog({
  groupFileId,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
  offer,
  trigger,
}: {
  groupFileId: Id<"groupFiles">;
  fileCurrency: string;
  /** yyyy-MM-dd — used to default a new offer's dates to the group's dates */
  fileStartDate?: string;
  /** yyyy-MM-dd — used to default a new offer's dates to the group's dates */
  fileEndDate?: string;
  fileMarkupPercent?: number;
  offer?: Doc<"offers">;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const create = useMutation(api.offers.create);
  const update = useMutation(api.offers.update);
  const createHotelOffer = useMutation(api.offers.createHotelOffer);
  const { hotels, loading: hotelsLoading } = useHotelOptions();

  const form = useForm<OfferFormValues>({
    resolver: zodResolver(offerFormSchema),
    defaultValues: defaultsFor(
      offer,
      fileCurrency,
      fileStartDate ?? "",
      fileEndDate ?? "",
    ),
  });

  const watchType = form.watch("type");
  const isHotel = watchType === "hotel";
  // Multiple room types only apply when creating a brand-new hotel offer —
  // editing an existing offer always edits just that one room type's row.
  const isMultiRoomMode = isHotel && !offer;
  const watchCostPerUnit = form.watch("costPerUnit");
  const isLocked = Boolean(offer?.convertedReservationId);
  const [markupPct, setMarkupPct] = useState(fileMarkupPercent ?? 0);

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      form.reset(defaultsFor(offer, fileCurrency, fileStartDate ?? "", fileEndDate ?? ""));
      setMarkupPct(fileMarkupPercent ?? 0);
    }
  };

  const applyMarkupPct = (next: number) => {
    setMarkupPct(next);
    const cost = Number(watchCostPerUnit);
    if (!Number.isFinite(cost) || cost <= 0) {
      toast.error("Enter a cost per unit first.");
      return;
    }
    const suggested = cost * (1 + next / 100);
    form.setValue("ratePerUnit", suggested.toFixed(2));
  };

  const onSubmit = async (values: OfferFormValues) => {
    try {
      if (isMultiRoomMode) {
        let hasError = false;
        values.roomTypes.forEach((rt, index) => {
          if (!rt.description.trim()) {
            form.setError(`roomTypes.${index}.description`, {
              message: "Room type is required",
            });
            hasError = true;
          }
        });
        if (hasError) return;

        const roomTypes = values.roomTypes.map((rt) => ({
          description: rt.description.trim(),
          units: Number(rt.units),
          unitLabel: rt.unitLabel.trim() || undefined,
          ratePerUnit: rt.ratePerUnit.trim() === "" ? undefined : Number(rt.ratePerUnit),
          costPerUnit: rt.costPerUnit.trim() === "" ? undefined : Number(rt.costPerUnit),
        }));
        await createHotelOffer({
          groupFileId,
          status: values.status,
          supplierName: values.supplierName.trim(),
          hotelId: values.hotelId ? (values.hotelId as Id<"hotels">) : undefined,
          startDate: dateInputToIso(values.startDate),
          endDate: values.endDate ? dateInputToIso(values.endDate) : undefined,
          nights: values.nights.trim() === "" ? undefined : Number(values.nights),
          board: isBoardValue(values.board) ? values.board : undefined,
          supplierRef: values.supplierRef.trim() || undefined,
          currency: values.currency,
          notes: values.notes.trim() || undefined,
          roomTypes,
        });
        toast.success(
          `Offer added with ${roomTypes.length} room type${roomTypes.length > 1 ? "s" : ""}`,
        );
        setOpen(false);
        return;
      }

      if (!values.description.trim()) {
        form.setError("description", { message: "Description is required" });
        return;
      }

      const payload = {
        groupFileId,
        type: values.type,
        status: values.status,
        supplierName: values.supplierName.trim(),
        hotelId: values.hotelId ? (values.hotelId as Id<"hotels">) : undefined,
        description: values.description.trim(),
        startDate: dateInputToIso(values.startDate),
        endDate: values.endDate ? dateInputToIso(values.endDate) : undefined,
        units: Number(values.units),
        unitLabel: values.unitLabel.trim() || undefined,
        board: isBoardValue(values.board) ? values.board : undefined,
        nights: values.nights.trim() === "" ? undefined : Number(values.nights),
        supplierRef: values.supplierRef.trim() || undefined,
        ratePerUnit:
          values.ratePerUnit.trim() === "" ? undefined : Number(values.ratePerUnit),
        costPerUnit:
          values.costPerUnit.trim() === "" ? undefined : Number(values.costPerUnit),
        currency: values.currency,
        notes: values.notes.trim() || undefined,
      };
      if (offer) {
        const { groupFileId: _groupFileId, ...updateFields } = payload;
        await update({ id: offer._id, ...updateFields });
        toast.success("Offer updated");
      } else {
        await create(payload);
        toast.success("Offer added");
      }
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save. Please try again.";
      toast.error(message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display">
            {offer ? "Edit offer" : "Add offer"}
          </DialogTitle>
          <DialogDescription>
            {isMultiRoomMode
              ? "Add a hotel quote with one or more room types (e.g. single, double, Jr suite) under the same offer."
              : "Compare a hotel, transfer, restaurant, excursion or any other service option before booking it as a reservation."}
          </DialogDescription>
        </DialogHeader>

        {isLocked ? (
          <p className="rounded-md bg-muted/60 p-3 text-sm text-muted-foreground">
            This offer has already been converted into a reservation and can
            no longer be edited.
          </p>
        ) : (
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="grid gap-4 sm:grid-cols-2"
            >
              {/* ── Type & Status ───────────────────────────────────────── */}
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Service type</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                      disabled={Boolean(offer)}
                    >
                      <FormControl>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {RESERVATION_TYPE_OPTIONS.map((o) => (
                          <SelectItem key={o.value} value={o.value}>
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {OFFER_STATUS_OPTIONS.map((o) => (
                          <SelectItem key={o.value} value={o.value}>
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* ── Hotel/supplier identity ──────────────────────────────── */}
              <OfferSupplierFields
                control={form.control}
                setValue={form.setValue}
                watchType={watchType}
                isHotel={isHotel}
                showDescription={!isMultiRoomMode}
                hotels={hotels}
                hotelsLoading={hotelsLoading}
              />

              {/* ── Dates ───────────────────────────────────────────────── */}
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{isHotel ? "Check-in" : "Date"}</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {isHotel ? (
                <FormField
                  control={form.control}
                  name="nights"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nights</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} placeholder="3" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ) : (
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End date (optional)</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* ── Quantity / rate / cost (single-room mode only) ───────── */}
              {!isMultiRoomMode && (
                <OfferQuantityFields
                  control={form.control}
                  isHotel={isHotel}
                  markupPct={markupPct}
                  onMarkupChange={applyMarkupPct}
                />
              )}

              {/* ── Room types (multi-room hotel mode only) ──────────────── */}
              {isMultiRoomMode && (
                <OfferRoomTypeFields
                  control={form.control}
                  getValues={form.getValues}
                  setValue={form.setValue}
                />
              )}

              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {CURRENCY_OPTIONS.map((c) => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* ── Supplier ref ────────────────────────────────────────── */}
              <FormField
                control={form.control}
                name="supplierRef"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Supplier reference</FormLabel>
                    <FormControl>
                      <Input placeholder="OFFER-12345" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* ── Notes ───────────────────────────────────────────────── */}
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea rows={2} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter className="sm:col-span-2">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => setOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? <Spinner /> : null}
                  {offer ? "Save changes" : "Add offer"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
