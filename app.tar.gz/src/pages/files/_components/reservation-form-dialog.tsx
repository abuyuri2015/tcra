import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, usePaginatedQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import PercentStepper from "@/components/ui/percent-stepper.tsx";
import SupplierPicker from "@/components/supplier-picker.tsx";
import {
  BOARD_OPTIONS,
  CURRENCY_OPTIONS,
  RESERVATION_STATUS_OPTIONS,
  RESERVATION_TYPE_OPTIONS,
} from "@/lib/domain.ts";
import { dateInputToIso, isoToDateInput } from "@/lib/dates.ts";
import type { ReactNode } from "react";

const schema = z.object({
  type: z.enum([
    "hotel",
    "transfer",
    "restaurant",
    "activity",
    "venue",
    "flight",
    "other",
  ]),
  status: z.enum(["option", "requested", "confirmed", "cancelled"]),
  supplierName: z.string().min(1, "Supplier name is required"),
  hotelId: z.string(),
  description: z.string().min(1, "Description is required"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string(),
  units: z
    .string()
    .refine((v) => Number.isInteger(Number(v)) && Number(v) >= 1, {
      message: "At least 1 unit",
    }),
  unitLabel: z.string(),
  board: z.string(),
  nights: z.string().refine(
    (v) => v === "" || (Number.isInteger(Number(v)) && Number(v) >= 0),
    { message: "Enter a whole number" },
  ),
  supplierRef: z.string(),
  ratePerUnit: z
    .string()
    .refine((v) => v === "" || Number(v) >= 0, { message: "Enter a positive rate" }),
  costPerUnit: z
    .string()
    .refine((v) => v === "" || Number(v) >= 0, { message: "Enter a positive cost" }),
  currency: z.enum(CURRENCY_OPTIONS),
  notes: z.string(),
  pickupLocation: z.string(),
  pickupTime: z.string(),
  flightDetails: z.string(),
  guideName: z.string(),
  guidePhone: z.string(),
});

type FormValues = z.output<typeof schema>;

type BoardValue = "room-only" | "breakfast" | "half-board" | "full-board" | "all-inclusive";

function isBoardValue(v: string): v is BoardValue {
  return ["room-only", "breakfast", "half-board", "full-board", "all-inclusive"].includes(v);
}

function defaultsFor(
  res: Doc<"reservations"> | undefined,
  fileCurrency: string,
  fileStartDate: string,
  fileEndDate: string,
): FormValues {
  if (!res) {
    return {
      type: "hotel",
      status: "option",
      supplierName: "",
      hotelId: "",
      description: "",
      startDate: fileStartDate,
      endDate: fileEndDate,
      units: "1",
      unitLabel: "",
      board: "",
      nights: "",
      supplierRef: "",
      ratePerUnit: "",
      costPerUnit: "",
      currency: fileCurrency as FormValues["currency"],
      notes: "",
      pickupLocation: "",
      pickupTime: "",
      flightDetails: "",
      guideName: "",
      guidePhone: "",
    };
  }
  return {
    type: res.type,
    status: res.status,
    supplierName: res.supplierName,
    hotelId: res.hotelId ?? "",
    description: res.description,
    startDate: isoToDateInput(res.startDate),
    endDate: res.endDate ? isoToDateInput(res.endDate) : "",
    units: String(res.units),
    unitLabel: res.unitLabel ?? "",
    board: res.board ?? "",
    nights: res.nights !== undefined ? String(res.nights) : "",
    supplierRef: res.supplierRef ?? "",
    ratePerUnit: res.ratePerUnit !== undefined ? String(res.ratePerUnit) : "",
    costPerUnit: res.costPerUnit !== undefined ? String(res.costPerUnit) : "",
    currency: res.currency,
    notes: res.notes ?? "",
    pickupLocation: res.pickupLocation ?? "",
    pickupTime: res.pickupTime ?? "",
    flightDetails: res.flightDetails ?? "",
    guideName: res.guideName ?? "",
    guidePhone: res.guidePhone ?? "",
  };
}

/** Loads hotels for the picker — always rendered (hook rule) */
function useHotelOptions() {
  const { results, status } = usePaginatedQuery(
    api.hotels.list,
    {},
    { initialNumItems: 200 },
  );
  return { hotels: results, loading: status === "LoadingFirstPage" };
}

export default function ReservationFormDialog({
  groupFileId,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
  reservation,
  trigger,
}: {
  groupFileId: Id<"groupFiles">;
  fileCurrency: string;
  /** yyyy-MM-dd — used to default a new reservation's dates to the group's dates */
  fileStartDate?: string;
  /** yyyy-MM-dd — used to default a new reservation's dates to the group's dates */
  fileEndDate?: string;
  fileMarkupPercent?: number;
  reservation?: Doc<"reservations">;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const create = useMutation(api.reservations.create);
  const update = useMutation(api.reservations.update);
  const { hotels, loading: hotelsLoading } = useHotelOptions();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFor(
      reservation,
      fileCurrency,
      fileStartDate ?? "",
      fileEndDate ?? "",
    ),
  });

  const watchType = form.watch("type");
  const isHotel = watchType === "hotel";
  const isTransferOrActivity = watchType === "transfer" || watchType === "activity";
  const watchCostPerUnit = form.watch("costPerUnit");
  const [markupPct, setMarkupPct] = useState(fileMarkupPercent ?? 0);

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      form.reset(
        defaultsFor(reservation, fileCurrency, fileStartDate ?? "", fileEndDate ?? ""),
      );
      setMarkupPct(fileMarkupPercent ?? 0);
    }
  };

  const applyMarkupPct = (next: number) => {
    setMarkupPct(next);
    const cost = Number(watchCostPerUnit);
    if (!Number.isFinite(cost) || cost <= 0) {
      toast.error("Enter a cost per unit first.");
      return;
    }
    const suggested = cost * (1 + next / 100);
    form.setValue("ratePerUnit", suggested.toFixed(2));
  };

  const onSubmit = async (values: FormValues) => {
    const payload = {
      groupFileId,
      type: values.type,
      status: values.status,
      supplierName: values.supplierName.trim(),
      hotelId: values.hotelId ? (values.hotelId as Id<"hotels">) : undefined,
      description: values.description.trim(),
      startDate: dateInputToIso(values.startDate),
      endDate: values.endDate ? dateInputToIso(values.endDate) : undefined,
      units: Number(values.units),
      unitLabel: values.unitLabel.trim() || undefined,
      board: isBoardValue(values.board) ? values.board : undefined,
      nights: values.nights.trim() === "" ? undefined : Number(values.nights),
      supplierRef: values.supplierRef.trim() || undefined,
      ratePerUnit:
        values.ratePerUnit.trim() === "" ? undefined : Number(values.ratePerUnit),
      costPerUnit:
        values.costPerUnit.trim() === "" ? undefined : Number(values.costPerUnit),
      currency: values.currency,
      notes: values.notes.trim() || undefined,
      pickupLocation: values.pickupLocation.trim() || undefined,
      pickupTime: values.pickupTime.trim() || undefined,
      flightDetails: values.flightDetails.trim() || undefined,
      guideName: values.guideName.trim() || undefined,
      guidePhone: values.guidePhone.trim() || undefined,
    };
    try {
      if (reservation) {
        const { groupFileId: _groupFileId, ...updateFields } = payload;
        await update({ id: reservation._id, ...updateFields });
        toast.success("Reservation updated");
      } else {
        await create(payload);
        toast.success("Reservation added");
      }
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save. Please try again.";
      toast.error(message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display">
            {reservation ? "Edit reservation" : "Add reservation"}
          </DialogTitle>
          <DialogDescription>
            Add a hotel, transfer, activity, or any other service to this file.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            {/* ── Type & Status ───────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {RESERVATION_TYPE_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {RESERVATION_STATUS_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Hotel link (hotel type only) ─────────────────────────── */}
            {isHotel && (
              <FormField
                control={form.control}
                name="hotelId"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Link to hotel database</FormLabel>
                    <Select
                      value={field.value || "none"}
                      onValueChange={(v) => {
                        const id = v === "none" ? "" : v;
                        field.onChange(id);
                        if (id) {
                          const h = hotels.find((h) => h._id === id);
                          if (h) form.setValue("supplierName", h.name);
                        }
                      }}
                      disabled={hotelsLoading}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select hotel (optional)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">No link</SelectItem>
                        {hotels.map((h) => (
                          <SelectItem key={h._id} value={h._id}>
                            {h.name} — {h.city}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Linking auto-fills the hotel name
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* ── Supplier name ────────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="supplierName"
              render={({ field }) => (
                <FormItem className={isHotel ? "" : "sm:col-span-2"}>
                  <div className="flex items-center justify-between gap-2">
                    <FormLabel>{isHotel ? "Hotel name" : "Supplier / venue"}</FormLabel>
                    <SupplierPicker
                      reservationType={watchType as import("@/pages/suppliers/page.tsx").SupplierCategory}
                      onSelect={(s) => {
                        form.setValue("supplierName", s.name);
                      }}
                    />
                  </div>
                  <FormControl>
                    <Input placeholder="Hotel Arts Barcelona" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {isHotel && (
              <FormField
                control={form.control}
                name="board"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Board basis</FormLabel>
                    <Select
                      value={field.value || "none"}
                      onValueChange={(v) => field.onChange(v === "none" ? "" : v)}
                    >
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Not specified" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">Not specified</SelectItem>
                        {BOARD_OPTIONS.map((o) => (
                          <SelectItem key={o.value} value={o.value}>
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* ── Description ─────────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>
                    {isHotel ? "Room type / description" : "Service description"}
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder={
                        isHotel
                          ? "Superior double, sea view"
                          : "Airport – Hotel, 50-seat coach"
                      }
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Dates ───────────────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{isHotel ? "Check-in" : "Date"}</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {isHotel ? (
              <FormField
                control={form.control}
                name="nights"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nights</FormLabel>
                    <FormControl>
                      <Input type="number" min={1} placeholder="3" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ) : (
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End date (optional)</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* ── Quantity ────────────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="units"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="unitLabel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Unit label</FormLabel>
                  <FormControl>
                    <Input placeholder={isHotel ? "rooms" : "pax"} {...field} />
                  </FormControl>
                  <FormDescription>e.g. rooms, pax, seats</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Cost & rate ─────────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="costPerUnit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cost per unit</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>What you pay the supplier</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="ratePerUnit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rate per unit (sell)</FormLabel>
                  <div className="flex items-center gap-2">
                    <FormControl>
                      <Input
                        type="number"
                        min={0}
                        step="0.01"
                        placeholder="0.00"
                        className="flex-1"
                        {...field}
                      />
                    </FormControl>
                    <PercentStepper
                      value={markupPct}
                      onChange={applyMarkupPct}
                      size="sm"
                      className="w-28 shrink-0"
                    />
                  </div>
                  <FormDescription>
                    Nudge the markup % to recalculate the rate from the cost
                    per unit
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Currency</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {CURRENCY_OPTIONS.map((c) => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Supplier ref ────────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="supplierRef"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Supplier reference</FormLabel>
                  <FormControl>
                    <Input placeholder="CONF-12345" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* ── Transfer / activity operations details ──────────────── */}
            {isTransferOrActivity && (
              <>
                <div className="sm:col-span-2 mt-1 border-t pt-3">
                  <p className="text-sm font-semibold">Pickup, flight & guide details</p>
                  <p className="text-xs text-muted-foreground">
                    Shown on the confirmation and passenger manifest.
                  </p>
                </div>
                <FormField
                  control={form.control}
                  name="pickupLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pickup place</FormLabel>
                      <FormControl>
                        <Input placeholder="Hotel lobby / Airport arrivals" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pickupTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pickup time</FormLabel>
                      <FormControl>
                        <Input placeholder="09:00" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="flightDetails"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Flight details (optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="BA476 arriving 14:20 from LHR" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="guideName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Guide name</FormLabel>
                      <FormControl>
                        <Input placeholder="Maria Santos" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="guidePhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Guide mobile number</FormLabel>
                      <FormControl>
                        <Input placeholder="+34 600 123 456" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}

            {/* ── Notes ───────────────────────────────────────────────── */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                {reservation ? "Save changes" : "Add reservation"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
