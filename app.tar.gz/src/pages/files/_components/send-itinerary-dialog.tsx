import { useState, useEffect } from "react";
import { useAction } from "convex/react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Send, CalendarDays, AlertCircle, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { formatDateRange } from "@/lib/dates.ts";

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type SenderIdentity = { id: string; value: string; type: string; status: string };

const schema = z.object({
  from: z.string().min(1, "Select a sender address"),
  to: z.string().email("Enter a valid email address"),
  subject: z.string().min(1, "Subject is required"),
  body: z.string().min(1, "Message body is required"),
});
type FormValues = z.output<typeof schema>;

export default function SendItineraryDialog({
  file,
  itineraryUrl,
  senderIdentities,
  trigger,
}: {
  file: GroupFile;
  itineraryUrl: string;
  senderIdentities: SenderIdentity[];
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const sendItinerary = useAction(api.email.send.sendItinerary);

  const verifiedSenders = senderIdentities.filter((s) => s.status === "verified");

  const defaultTo = file.clientContactEmail ?? "";
  const defaultSubject = `Your Itinerary – ${file.title} · ${file.reference}`;
  const defaultBody = `Dear ${file.clientContactName ?? file.clientName},

Please find below the link to your programme for ${file.title}.

${formatDateRange(file.startDate, file.endDate)} · ${file.destination}

Click the button in the email (or copy the link below) to view the full itinerary.

We look forward to welcoming your group. Please do not hesitate to reach out with any questions.

Kind regards,
${file.ownerName ?? "Tessera Groups & MICE Team"}`;

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { from: verifiedSenders[0]?.value ?? "", to: defaultTo, subject: defaultSubject, body: defaultBody },
  });

  useEffect(() => {
    if (open) {
      form.reset({
        from: verifiedSenders[0]?.value ?? "",
        to: defaultTo,
        subject: defaultSubject,
        body: defaultBody,
      });
    }
  }, [open]);

  const onSubmit = async (values: FormValues) => {
    setSending(true);
    try {
      await sendItinerary({
        groupFileId: file._id,
        from: values.from,
        to: values.to,
        subject: values.subject,
        body: values.body,
        itineraryUrl,
      });
      toast.success(`Itinerary link sent to ${values.to}`);
      setOpen(false);
    } catch (err) {
      const message =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Failed to send email. Please try again.";
      toast.error(message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button size="sm" variant="secondary">
            <Send className="size-4" />
            Email itinerary
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <CalendarDays className="size-4 text-muted-foreground" />
            Send itinerary to client
          </DialogTitle>
          <DialogDescription>
            The client will receive a link to the public itinerary view — no login required.
          </DialogDescription>
        </DialogHeader>

        {/* Link preview */}
        <div className="flex items-center gap-2 rounded-md border bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
          <ExternalLink className="size-3.5 shrink-0" />
          <span className="truncate font-mono">{itineraryUrl}</span>
        </div>

        {verifiedSenders.length === 0 ? (
          <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
            <AlertCircle className="mt-0.5 size-4 shrink-0" />
            <p>
              No verified sender found. Go to{" "}
              <strong>Settings → Email sender identities</strong> to verify one.
            </p>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="from"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sender address" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {verifiedSenders.map((s) => (
                          <SelectItem key={s.id} value={s.value}>{s.value}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="to"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>To (client email)</FormLabel>
                    <FormControl>
                      <Input placeholder="client@company.com" type="email" {...field} />
                    </FormControl>
                    <FormDescription className="text-xs">
                      Pre-filled from the file's client contact email.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl><Input {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="body"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message</FormLabel>
                    <FormControl>
                      <Textarea rows={8} className="resize-none text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={sending}>
                  Cancel
                </Button>
                <Button type="submit" disabled={sending}>
                  {sending ? (
                    <><Loader2 className="size-4 animate-spin" />Sending…</>
                  ) : (
                    <><Send className="size-4" />Send itinerary</>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
