import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { formatRelative } from "date-fns";
import { CheckCircle2, ListChecks } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";
import { formatMoney } from "@/lib/domain.ts";

function SelectionItemRow({ offerId, requestedUnits }: { offerId: Id<"offers">; requestedUnits: number }) {
  const offer = useQuery(api.offers.get, { id: offerId });

  if (offer === undefined) {
    return <Skeleton className="h-10 w-full" />;
  }
  if (!offer) {
    return (
      <div className="rounded-md border px-3 py-2 text-xs text-muted-foreground">
        This offer is no longer available.
      </div>
    );
  }

  const total = offer.ratePerUnit !== undefined ? offer.ratePerUnit * requestedUnits : undefined;
  const unitLabel = offer.unitLabel || (offer.type === "hotel" ? "rooms" : "pax");

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border px-3 py-2">
      <div className="min-w-0">
        <p className="text-sm font-medium">{offer.supplierName}</p>
        <p className="text-xs text-muted-foreground">{offer.description}</p>
      </div>
      <div className="text-right text-xs">
        <p className="font-medium">
          {requestedUnits} {unitLabel}
        </p>
        {total !== undefined ? (
          <p className="text-muted-foreground">{formatMoney(total, offer.currency)}</p>
        ) : null}
      </div>
    </div>
  );
}

function SelectionCard({ selection }: { selection: Doc<"offerSelections"> }) {
  const markReviewed = useMutation(api.offerSelections.markReviewed);

  const handleMarkReviewed = async () => {
    try {
      await markReviewed({ id: selection._id, status: "reviewed" });
      toast.success("Marked as reviewed — selected offers booked as reservations");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update.";
      toast.error(message);
    }
  };

  return (
    <div
      className={cn(
        "space-y-3 rounded-lg border p-4",
        selection.status === "new" ? "border-chart-4/40 bg-chart-4/5" : "border-border",
      )}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              selection.status === "new"
                ? "bg-chart-4/15 text-chart-4"
                : "bg-chart-3/15 text-chart-3",
            )}
          >
            {selection.status === "new" ? "Needs review" : "Reviewed"}
          </span>
          <span className="text-xs text-muted-foreground">
            {formatRelative(new Date(selection.createdAt), new Date())}
          </span>
        </div>
        {selection.status === "new" ? (
          <Button size="sm" variant="secondary" onClick={handleMarkReviewed}>
            <CheckCircle2 className="size-3.5" />
            Accept & book
          </Button>
        ) : null}
      </div>

      <div className="space-y-2">
        {selection.items.map((item, i) => (
          <SelectionItemRow key={i} offerId={item.offerId} requestedUnits={item.requestedUnits} />
        ))}
      </div>

      {selection.clientNote ? (
        <p className="rounded-md bg-muted/60 p-2 text-sm italic text-muted-foreground">
          "{selection.clientNote}"
        </p>
      ) : null}
    </div>
  );
}

export default function OfferSelectionsSection({ groupFileId }: { groupFileId: Id<"groupFiles"> }) {
  const selections = useQuery(api.offerSelections.listByFile, { groupFileId });

  if (selections === undefined) {
    return (
      <Card>
        <CardContent className="space-y-3 py-6">
          <Skeleton className="h-16 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (selections.length === 0) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display flex items-center gap-2 text-base">
          <ListChecks className="size-4 text-muted-foreground" />
          Client selections
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          What the client picked from the offer link. Marking a submission as
          reviewed automatically accepts those offers and books them as
          reservations.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {selections.map((s) => (
          <SelectionCard key={s._id} selection={s} />
        ))}
      </CardContent>
    </Card>
  );
}
