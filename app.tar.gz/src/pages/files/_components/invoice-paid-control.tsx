import { useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { CalendarCheck } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover.tsx";
import { formatDate, dateInputToIso, isoToDateInput } from "@/lib/dates.ts";

type FinanceLine = Doc<"financeLines">;

/** An invoice is paid once every income line behind it has a payment date. */
export function isInvoicePaid(incomeLines: FinanceLine[]): boolean {
  return incomeLines.length > 0 && incomeLines.every((l) => l.paidAt !== undefined);
}

/**
 * Client invoices are paid as a whole (a % of the package value), not line by
 * line, so payment status is tracked at the invoice level — one checkbox and
 * date stamp covering every income line on the file.
 */
export default function InvoicePaidControl({
  groupFileId,
  incomeLines,
}: {
  groupFileId: Id<"groupFiles">;
  incomeLines: FinanceLine[];
}) {
  const setInvoicePaid = useMutation(api.financeLines.setInvoicePaid);
  const [submitting, setSubmitting] = useState(false);
  const [dateOpen, setDateOpen] = useState(false);

  const paid = isInvoicePaid(incomeLines);
  const paidAt = incomeLines.find((l) => l.paidAt)?.paidAt;

  if (incomeLines.length === 0) return null;

  const handleToggle = async (checked: boolean) => {
    setSubmitting(true);
    try {
      await setInvoicePaid({ groupFileId, paid: checked });
      toast.success(checked ? "Invoice marked as paid by client" : "Invoice marked as unpaid");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update payment status.";
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDateChange = async (value: string) => {
    if (!value) return;
    setSubmitting(true);
    try {
      await setInvoicePaid({ groupFileId, paid: true, paidAt: dateInputToIso(value) });
      setDateOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update payment date.";
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-muted/30 px-3 py-2">
      <Checkbox
        checked={paid}
        disabled={submitting}
        onCheckedChange={(checked) => handleToggle(checked === true)}
        aria-label="Paid by client"
      />
      {paid && paidAt ? (
        <Popover open={dateOpen} onOpenChange={setDateOpen}>
          <PopoverTrigger asChild>
            <button
              type="button"
              className="flex items-center gap-1 text-sm font-medium text-chart-3 hover:underline"
            >
              <CalendarCheck className="size-3.5" />
              Paid by client {formatDate(paidAt)}
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-auto space-y-2 p-3">
            <p className="text-xs font-medium text-muted-foreground">Payment date</p>
            <Input
              type="date"
              defaultValue={isoToDateInput(paidAt)}
              onChange={(e) => handleDateChange(e.target.value)}
              className="w-40"
            />
          </PopoverContent>
        </Popover>
      ) : (
        <span className="text-sm text-muted-foreground">Paid by client</span>
      )}
    </div>
  );
}
