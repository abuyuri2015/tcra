import { useState } from "react";
import { useMutation, useAction } from "convex/react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Send, Receipt, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import type { AgencyProfilePDF } from "@/lib/pdf-generators.ts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { generateInvoicePDFBase64 } from "@/lib/pdf-generators.ts";
import { formatMoney } from "@/lib/domain.ts";

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type ScheduleItem = Doc<"paymentSchedules">["items"][number];
type SenderIdentity = { id: string; value: string; type: string; status: string };

const schema = z.object({
  from: z.string().min(1, "Select a sender address"),
  to: z.string().email("Enter a valid email address"),
  subject: z.string().min(1, "Subject is required"),
  body: z.string().min(1, "Message body is required"),
});
type FormValues = z.output<typeof schema>;

/**
 * Generates an invoice for one payment-schedule installment (creating the
 * underlying income finance line the first time) and lets staff review and
 * send it to the client in one dialog. Nothing is emailed automatically —
 * staff must click "Send invoice".
 */
export default function SendScheduleInvoiceDialog({
  file,
  scheduleId,
  item,
  invoiceNumber,
  amountEur,
  agency,
  senderIdentities,
  trigger,
}: {
  file: GroupFile;
  scheduleId: Doc<"paymentSchedules">["_id"];
  item: ScheduleItem;
  invoiceNumber: string;
  amountEur: number;
  agency: AgencyProfilePDF;
  senderIdentities: SenderIdentity[];
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const generateInvoiceLine = useMutation(api.paymentSchedules.generateInvoiceLine);
  const sendInvoice = useAction(api.email.send.sendInvoice);

  const verifiedSenders = senderIdentities.filter((s) => s.status === "verified");
  const alreadyInvoiced = item.financeLineId !== undefined;

  const defaultTo = file.clientContactEmail ?? "";
  const defaultSubject = `${item.label} invoice ${invoiceNumber} – ${file.title}`;
  const defaultBody = `Dear ${file.clientContactName ?? file.clientName},

Please find attached the invoice for the "${item.label}" installment (${item.percent}% of the total package value) for the following event:

Group: ${file.title}
Reference: ${file.reference}
Amount due: ${formatMoney(amountEur, "EUR")}

Full booking terms & conditions are attached to this invoice.

Should you have any questions, please do not hesitate to contact us.

Kind regards,
${file.ownerName ?? "Tessera Groups & MICE Team"}`;

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { from: verifiedSenders[0]?.value ?? "", to: defaultTo, subject: defaultSubject, body: defaultBody },
  });

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) {
      form.reset({
        from: verifiedSenders[0]?.value ?? "",
        to: defaultTo,
        subject: defaultSubject,
        body: defaultBody,
      });
    }
  };

  const onSubmit = async (values: FormValues) => {
    setSending(true);
    try {
      // Create the finance line the first time this item is invoiced.
      const financeLineId = alreadyInvoiced
        ? item.financeLineId!
        : (await generateInvoiceLine({ id: scheduleId, itemId: item.id, invoiceNumber })).financeLineId;

      const financeLine = {
        _id: financeLineId,
        _creationTime: Date.now(),
        groupFileId: file._id,
        kind: "income" as const,
        category: "deposit",
        description: `${item.label} (${item.percent}% of package value) — ${invoiceNumber}`,
        supplierName: undefined,
        amount: amountEur,
        currency: "EUR",
        exchangeRateToBase: 1,
        unitRate: undefined,
        quantity: undefined,
        quantityLabel: undefined,
        notes: undefined,
        createdById: file.createdById,
        paidAt: undefined,
        amountInBase: amountEur,
      };
      const { base64, filename } = generateInvoicePDFBase64(
        file,
        [financeLine],
        invoiceNumber,
        agency,
      );
      await sendInvoice({
        groupFileId: file._id,
        from: values.from,
        to: values.to,
        subject: values.subject,
        body: values.body,
        pdfDataUri: base64,
        pdfFilename: filename,
        invoiceNumber,
      });
      toast.success(`Invoice sent to ${values.to}`);
      setOpen(false);
    } catch (err) {
      const message =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Failed to send email. Please try again.";
      toast.error(message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button size="sm">
            <Send className="size-4" />
            Generate & send
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <Receipt className="size-4 text-muted-foreground" />
            Send {item.label.toLowerCase()} invoice
          </DialogTitle>
          <DialogDescription>
            The invoice PDF ({invoiceNumber}) for {formatMoney(amountEur, "EUR")}, including
            your booking terms &amp; conditions, will be generated and attached automatically.
          </DialogDescription>
        </DialogHeader>

        {verifiedSenders.length === 0 ? (
          <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
            <AlertCircle className="mt-0.5 size-4 shrink-0" />
            <p>
              No verified sender found. Go to{" "}
              <strong>Settings → Email sender identities</strong> to verify one.
            </p>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="from"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sender address" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {verifiedSenders.map((s) => (
                          <SelectItem key={s.id} value={s.value}>{s.value}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="to"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>To (client email)</FormLabel>
                    <FormControl>
                      <Input placeholder="client@company.com" type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl><Input {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="body"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message</FormLabel>
                    <FormControl>
                      <Textarea rows={8} className="resize-none text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={sending}>
                  Cancel
                </Button>
                <Button type="submit" disabled={sending}>
                  {sending ? (
                    <><Loader2 className="size-4 animate-spin" />Sending…</>
                  ) : (
                    <><Send className="size-4" />Send invoice</>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
