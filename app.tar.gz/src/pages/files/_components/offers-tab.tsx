import { useEffect, useState } from "react";
import { useAction, useQuery } from "convex/react";
import {
  BedDouble,
  Building,
  Bus,
  ExternalLink,
  Package,
  Plane,
  Plus,
  Send,
  Sunset,
  UtensilsCrossed,
  XCircle,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import OfferFormDialog from "./offer-form-dialog.tsx";
import SendOfferDialog from "./send-offer-dialog.tsx";
import OfferSelectionsSection from "./offer-selections-section.tsx";
import HotelOfferGroupCard from "./hotel-offer-group-card.tsx";
import { OfferActionBar, OfferAmountSummary } from "./offer-actions.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import {
  OFFER_STATUS_STYLES,
  boardLabel,
  offerStatusLabel,
  reservationTypeLabel,
} from "@/lib/domain.ts";
import { formatDate, isoToDateInput } from "@/lib/dates.ts";
import type { ReservationType } from "@/lib/domain.ts";

const TYPE_ICONS: Record<ReservationType, typeof BedDouble> = {
  hotel: BedDouble,
  transfer: Bus,
  restaurant: UtensilsCrossed,
  activity: Sunset,
  venue: Building,
  flight: Plane,
  other: Package,
};

/** A standalone, non-grouped offer row (any non-hotel type, or a hotel offer with no room-type group) */
function OfferCard({
  offer,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
}: {
  offer: Doc<"offers">;
  fileCurrency: string;
  fileStartDate?: string;
  fileEndDate?: string;
  fileMarkupPercent?: number;
}) {
  const Icon = TYPE_ICONS[offer.type] ?? Package;
  const isConverted = Boolean(offer.convertedReservationId);

  const dateLabel = (() => {
    if (offer.type === "hotel" && offer.nights !== undefined) {
      return `${formatDate(offer.startDate)} · ${offer.nights} night${offer.nights > 1 ? "s" : ""}`;
    }
    if (offer.endDate) {
      return `${formatDate(offer.startDate)} – ${formatDate(offer.endDate)}`;
    }
    return formatDate(offer.startDate);
  })();

  return (
    <div className="flex flex-wrap items-start justify-between gap-3 rounded-lg border px-4 py-3">
      <div className="flex min-w-0 gap-3">
        <div className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
          <Icon className="size-4 text-muted-foreground" />
        </div>
        <div className="min-w-0 space-y-0.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">{offer.supplierName}</span>
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                OFFER_STATUS_STYLES[offer.status],
              )}
            >
              {offerStatusLabel(offer.status)}
            </span>
            {isConverted ? (
              <span className="rounded-full bg-chart-2/15 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-chart-2">
                Booked
              </span>
            ) : null}
          </div>
          <p className="text-sm text-muted-foreground">{offer.description}</p>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
            <span>{dateLabel}</span>
            <span>
              {offer.units} {offer.unitLabel || (offer.type === "hotel" ? "rooms" : "pax")}
            </span>
            {offer.board ? <span>{boardLabel(offer.board)}</span> : null}
            {offer.supplierRef ? (
              <span className="font-mono">{offer.supplierRef}</span>
            ) : null}
          </div>
          {offer.notes ? (
            <p className="text-xs text-muted-foreground italic">{offer.notes}</p>
          ) : null}
        </div>
      </div>

      <div className="flex shrink-0 items-start gap-2">
        <OfferAmountSummary offer={offer} />
        <OfferActionBar
          offer={offer}
          fileCurrency={fileCurrency}
          fileStartDate={fileStartDate}
          fileEndDate={fileEndDate}
          fileMarkupPercent={fileMarkupPercent}
        />
      </div>
    </div>
  );
}

/** One entry in a type section: either a single offer or a bundled hotel room-type group */
type DisplayEntry =
  | { kind: "single"; offer: Doc<"offers"> }
  | { kind: "group"; groupId: string; offers: Doc<"offers">[] };

/** Groups offers by service type, and within "hotel" further bundles by offerGroupId */
function GroupedOffers({
  offers,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
}: {
  offers: Doc<"offers">[];
  fileCurrency: string;
  fileStartDate?: string;
  fileEndDate?: string;
  fileMarkupPercent?: number;
}) {
  const order: ReservationType[] = [
    "hotel",
    "flight",
    "transfer",
    "venue",
    "restaurant",
    "activity",
    "other",
  ];

  const byType = order.reduce<Partial<Record<ReservationType, Doc<"offers">[]>>>(
    (acc, t) => {
      const items = offers.filter((o) => o.type === t);
      if (items.length > 0) acc[t] = items;
      return acc;
    },
    {},
  );

  const toEntries = (items: Doc<"offers">[]): DisplayEntry[] => {
    const groups = new Map<string, Doc<"offers">[]>();
    const singles: Doc<"offers">[] = [];
    for (const offer of items) {
      if (offer.offerGroupId) {
        const key = offer.offerGroupId;
        const existing = groups.get(key);
        if (existing) existing.push(offer);
        else groups.set(key, [offer]);
      } else {
        singles.push(offer);
      }
    }
    const entries: DisplayEntry[] = singles.map((offer) => ({ kind: "single", offer }));
    for (const [groupId, groupOffers] of groups) {
      if (groupOffers.length > 1) {
        entries.push({ kind: "group", groupId, offers: groupOffers });
      } else {
        entries.push({ kind: "single", offer: groupOffers[0] });
      }
    }
    return entries;
  };

  return (
    <div className="space-y-6">
      {(Object.entries(byType) as [ReservationType, Doc<"offers">[]][]).map(
        ([type, items]) => {
          const Icon = TYPE_ICONS[type] ?? Package;
          const label = reservationTypeLabel(type);
          const entries = toEntries(items);
          return (
            <div key={type}>
              <div className="mb-2 flex items-center gap-2">
                <Icon className="size-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  {label}
                </h3>
                <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                  {items.length}
                </span>
              </div>
              <div className="space-y-2">
                {entries.map((entry) =>
                  entry.kind === "group" ? (
                    <HotelOfferGroupCard
                      key={entry.groupId}
                      offers={entry.offers}
                      fileCurrency={fileCurrency}
                      fileStartDate={fileStartDate}
                      fileEndDate={fileEndDate}
                      fileMarkupPercent={fileMarkupPercent}
                    />
                  ) : (
                    <OfferCard
                      key={entry.offer._id}
                      offer={entry.offer}
                      fileCurrency={fileCurrency}
                      fileStartDate={fileStartDate}
                      fileEndDate={fileEndDate}
                      fileMarkupPercent={fileMarkupPercent}
                    />
                  ),
                )}
              </div>
            </div>
          );
        },
      )}
    </div>
  );
}

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type SenderIdentity = { id: string; value: string; type: string; status: string };

export default function OffersTab({
  groupFileId,
  fileCurrency,
  file,
}: {
  groupFileId: Id<"groupFiles">;
  fileCurrency: string;
  file?: GroupFile;
}) {
  const offers = useQuery(api.offers.listByFile, { groupFileId });
  const fileStartDate = file ? isoToDateInput(file.startDate) : undefined;
  const fileEndDate = file ? isoToDateInput(file.endDate) : undefined;
  const fileMarkupPercent = file?.markupPercent;

  const listIdentities = useAction(api.email.identities.list);
  const [senderIdentities, setSenderIdentities] = useState<SenderIdentity[]>([]);
  useEffect(() => {
    listIdentities({}).then(setSenderIdentities).catch(() => setSenderIdentities([]));
  }, []);

  const offerUrl = `${window.location.origin}/offer/${groupFileId}`;
  const pendingCount = offers?.filter((o) => o.status === "pending").length ?? 0;
  const emailLogs = useQuery(api.email.logs.listByFile, { groupFileId });
  const hasSentBefore = emailLogs?.some((l) => l.emailType === "offer") ?? false;

  if (offers === undefined) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="font-display text-base">Offers</CardTitle>
            <p className="text-sm text-muted-foreground">
              Collect and compare hotel, transfer, restaurant, and excursion
              options before booking them as reservations.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {offers.length > 0 ? (
              <a
                href={offerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm font-medium hover:bg-muted"
              >
                <ExternalLink className="size-4" />
                Client view
              </a>
            ) : null}
            {file && pendingCount > 0 ? (
              <SendOfferDialog
                file={file}
                offerUrl={offerUrl}
                senderIdentities={senderIdentities}
                isResend={hasSentBefore}
                trigger={
                  <Button size="sm" variant="secondary">
                    <Send className="size-4" />
                    {hasSentBefore ? "Resend offer" : "Send offer"}
                  </Button>
                }
              />
            ) : null}
            <OfferFormDialog
              groupFileId={groupFileId}
              fileCurrency={fileCurrency}
              fileStartDate={fileStartDate}
              fileEndDate={fileEndDate}
              fileMarkupPercent={fileMarkupPercent}
              trigger={
                <Button size="sm" className="shrink-0">
                  <Plus className="size-4" />
                  Add offer
                </Button>
              }
            />
          </div>
        </CardHeader>
        <CardContent>
          {offers.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <XCircle />
                </EmptyMedia>
                <EmptyTitle>No offers yet</EmptyTitle>
                <EmptyDescription>
                  Add several hotel, transfer, restaurant, or excursion options
                  to compare before booking one for this group.
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <OfferFormDialog
                  groupFileId={groupFileId}
                  fileCurrency={fileCurrency}
                  fileStartDate={fileStartDate}
                  fileEndDate={fileEndDate}
                  fileMarkupPercent={fileMarkupPercent}
                  trigger={
                    <Button size="sm">
                      <Plus className="size-4" />
                      Add offer
                    </Button>
                  }
                />
              </EmptyContent>
            </Empty>
          ) : (
            <GroupedOffers
              offers={offers}
              fileCurrency={fileCurrency}
              fileStartDate={fileStartDate}
              fileEndDate={fileEndDate}
              fileMarkupPercent={fileMarkupPercent}
            />
          )}
        </CardContent>
      </Card>

      <OfferSelectionsSection groupFileId={groupFileId} />
    </div>
  );
}
