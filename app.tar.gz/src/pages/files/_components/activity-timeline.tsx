import { useQuery } from "convex/react";
import { formatRelative } from "date-fns";
import {
  Activity,
  CheckCircle2,
  CircleDot,
  Copy,
  DollarSign,
  FileText,
  Paperclip,
  Pencil,
  Plus,
  Mail,
  Trash2,
  UserPlus,
  UserMinus,
  RefreshCw,
  Tags,
  ArrowRightLeft,
  MessageSquarePlus,
  Building2,
  XCircle,
  Send,
  ListChecks,
  CalendarCheck,
  CalendarX,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import type { Doc } from "@/convex/_generated/dataModel";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

// ── Icon mapping ─────────────────────────────────────────────────────────────

type Action = Doc<"activityLog">["action"];

const ACTION_ICON: Record<Action, typeof Activity> = {
  created: Plus,
  updated: Pencil,
  status_changed: CircleDot,
  duplicated: Copy,
  reservation_added: Plus,
  reservation_updated: Pencil,
  reservation_removed: Trash2,
  offer_added: Tags,
  offer_updated: Pencil,
  offer_removed: Trash2,
  offer_accepted: CheckCircle2,
  offer_converted: ArrowRightLeft,
  finance_line_added: DollarSign,
  finance_line_removed: Trash2,
  finance_line_paid: CalendarCheck,
  finance_line_unpaid: CalendarX,
  task_added: Plus,
  task_completed: CheckCircle2,
  task_reopened: RefreshCw,
  passenger_added: UserPlus,
  passenger_removed: UserMinus,
  attachment_added: Paperclip,
  attachment_removed: Trash2,
  email_sent: Mail,
  modification_requested: MessageSquarePlus,
  modification_approved: Building2,
  modification_declined: XCircle,
  offer_link_sent: Send,
  offer_selection_submitted: ListChecks,
};

const ACTION_COLOR: Record<Action, string> = {
  created: "text-chart-3",
  updated: "text-chart-4",
  status_changed: "text-chart-1",
  duplicated: "text-chart-2",
  reservation_added: "text-chart-3",
  reservation_updated: "text-chart-4",
  reservation_removed: "text-destructive",
  offer_added: "text-chart-3",
  offer_updated: "text-chart-4",
  offer_removed: "text-destructive",
  offer_accepted: "text-chart-3",
  offer_converted: "text-chart-2",
  finance_line_added: "text-chart-3",
  finance_line_removed: "text-destructive",
  finance_line_paid: "text-chart-3",
  finance_line_unpaid: "text-muted-foreground",
  task_added: "text-chart-3",
  task_completed: "text-chart-3",
  task_reopened: "text-chart-4",
  passenger_added: "text-chart-3",
  passenger_removed: "text-destructive",
  attachment_added: "text-chart-3",
  attachment_removed: "text-destructive",
  email_sent: "text-chart-2",
  modification_requested: "text-chart-4",
  modification_approved: "text-chart-3",
  modification_declined: "text-destructive",
  offer_link_sent: "text-chart-2",
  offer_selection_submitted: "text-chart-2",
};

// ── Component ────────────────────────────────────────────────────────────────

export default function ActivityTimeline({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const entries = useQuery(api.activityLog.listByFile, { groupFileId });

  if (entries === undefined) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="font-display text-base flex items-center gap-2">
            <Activity className="size-4 text-muted-foreground" />
            Activity
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-base flex items-center gap-2">
          <Activity className="size-4 text-muted-foreground" />
          Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {entries.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">
            No activity recorded yet. Changes will appear here automatically.
          </p>
        ) : (
          <div className="relative space-y-0">
            {/* Vertical line */}
            <div className="absolute left-[11px] top-2 bottom-2 w-px bg-border" />

            {entries.map((entry, i) => {
              const Icon = ACTION_ICON[entry.action] ?? Activity;
              const color = ACTION_COLOR[entry.action] ?? "text-muted-foreground";

              return (
                <div
                  key={entry._id}
                  className="relative flex gap-3 pb-4 last:pb-0"
                >
                  {/* Dot */}
                  <div className="relative z-10 mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-background border">
                    <Icon className={`size-3 ${color}`} />
                  </div>

                  {/* Content */}
                  <div className="min-w-0 flex-1 pt-0.5">
                    <p className="text-sm leading-snug">
                      {entry.description}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {entry.userName} · {formatRelative(new Date(entry.timestamp), new Date())}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
