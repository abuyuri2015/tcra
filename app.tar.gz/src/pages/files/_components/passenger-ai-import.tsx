/**
 * AI import panel for the Passengers tab.
 */
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.js";
import AiImportDialog, { PreviewCard, PreviewField } from "@/components/ai-import-dialog.tsx";
import { cn } from "@/lib/utils.ts";

type PassengerData = {
  firstName: string;
  lastName: string;
  roomType: "single" | "double" | "twin" | "triple" | "suite";
  sharingWith?: string;
  dietaryRequirements?: string;
  notes?: string;
};

const ROOM_CHIP: Record<PassengerData["roomType"], string> = {
  single: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  double: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  twin: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300",
  triple: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  suite: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
};

function PassengersPreview({ passengers }: { passengers: PassengerData[] }) {
  if (!passengers || passengers.length === 0) {
    return <p className="px-4 py-4 text-sm text-muted-foreground">No passengers extracted.</p>;
  }
  return (
    <div className="divide-y">
      {passengers.map((p, i) => (
        <div key={i} className="flex items-center gap-3 px-4 py-2.5">
          <span className="w-6 text-xs text-muted-foreground tabular-nums">{i + 1}</span>
          <p className="flex-1 text-sm font-medium">
            {p.lastName}, {p.firstName}
          </p>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              ROOM_CHIP[p.roomType],
            )}
          >
            {p.roomType}
          </span>
          {p.sharingWith && (
            <span className="text-xs text-muted-foreground hidden sm:block">
              with {p.sharingWith}
            </span>
          )}
          {p.dietaryRequirements && (
            <span className="text-xs text-amber-700 dark:text-amber-400 hidden sm:block">
              {p.dietaryRequirements}
            </span>
          )}
        </div>
      ))}
      <div className="px-4 py-2 text-xs text-muted-foreground">
        {passengers.length} passenger{passengers.length !== 1 ? "s" : ""}
      </div>
    </div>
  );
}

export default function PassengerAiImport({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const bulkCreate = useMutation(api.passengers.bulkCreate);

  const handleImport = async (data: PassengerData[]) => {
    if (!data || data.length === 0) {
      toast.error("No passengers to import.");
      return;
    }
    const valid = ["single", "double", "twin", "triple", "suite"] as const;
    type VRoom = (typeof valid)[number];
    const sanitised = data.map((p) => ({
      ...p,
      roomType: (valid.includes(p.roomType as VRoom) ? p.roomType : "double") as VRoom,
    }));
    const result = await bulkCreate({ groupFileId, passengers: sanitised });
    toast.success(
      `Imported ${result.imported} passenger${result.imported !== 1 ? "s" : ""}` +
        (result.skipped > 0 ? ` (${result.skipped} skipped)` : ""),
    );
  };

  return (
    <AiImportDialog
      type="passengers"
      title="Import passengers with AI"
      placeholder={`Paste a passenger list — any format works:

1. John Smith — double room (sharing with Jane Smith)
2. Jane Smith — double room (sharing with John Smith)
3. Bob Johnson — single room — vegetarian
4. Alice Brown — suite

Or paste a full rooming list email from your client.`}
      onImport={async (data) => handleImport(data as PassengerData[])}
      renderPreview={(data) => <PassengersPreview passengers={(data as PassengerData[]) ?? []} />}
    />
  );
}
