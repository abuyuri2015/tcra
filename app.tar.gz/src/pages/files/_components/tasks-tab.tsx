import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ConvexError } from "convex/values";
import {
  CheckCircle2,
  Circle,
  Clock,
  Loader2,
  MoreHorizontal,
  Pencil,
  Plus,
  Trash2,
  User,
} from "lucide-react";
import { format, parseISO, isPast } from "date-fns";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id, Doc } from "@/convex/_generated/dataModel.js";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { isoToDateInput, dateInputToIso } from "@/lib/dates.ts";

// ── Types ─────────────────────────────────────────────────────────────────────

type Task = Doc<"tasks">;
type TaskStatus = "open" | "in_progress" | "done";

const TASK_STATUS_OPTIONS: { value: TaskStatus; label: string }[] = [
  { value: "open", label: "Open" },
  { value: "in_progress", label: "In progress" },
  { value: "done", label: "Done" },
];

// ── Form schema ───────────────────────────────────────────────────────────────

const taskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  dueDate: z.string().optional(),
  assignee: z.string().optional(),
  status: z.enum(["open", "in_progress", "done"]),
  notes: z.string().optional(),
});

type TaskForm = z.infer<typeof taskSchema>;

// ── Status icon & colours ─────────────────────────────────────────────────────

function StatusIcon({ status }: { status: TaskStatus }) {
  if (status === "done")
    return <CheckCircle2 className="size-4 shrink-0 text-emerald-500" />;
  if (status === "in_progress")
    return <Loader2 className="size-4 shrink-0 animate-spin text-blue-500" />;
  return <Circle className="size-4 shrink-0 text-muted-foreground" />;
}

const STATUS_RING: Record<TaskStatus, string> = {
  open: "border-l-muted-foreground/40",
  in_progress: "border-l-blue-400",
  done: "border-l-emerald-400",
};

// ── Task dialog ───────────────────────────────────────────────────────────────

function TaskDialog({
  groupFileId,
  task,
  open,
  onClose,
}: {
  groupFileId: Id<"groupFiles">;
  task?: Task;
  open: boolean;
  onClose: () => void;
}) {
  const createTask = useMutation(api.tasks.create);
  const updateTask = useMutation(api.tasks.update);

  const form = useForm<TaskForm>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: task?.title ?? "",
      dueDate: task?.dueDate ? isoToDateInput(task.dueDate) : "",
      assignee: task?.assignee ?? "",
      status: task?.status ?? "open",
      notes: task?.notes ?? "",
    },
  });

  // Reset when dialog opens with new task
  useState(() => {
    if (open) {
      form.reset({
        title: task?.title ?? "",
        dueDate: task?.dueDate ? isoToDateInput(task.dueDate) : "",
        assignee: task?.assignee ?? "",
        status: task?.status ?? "open",
        notes: task?.notes ?? "",
      });
    }
  });

  const onSubmit = async (values: TaskForm) => {
    try {
      const payload = {
        title: values.title,
        dueDate: values.dueDate ? dateInputToIso(values.dueDate) : undefined,
        assignee: values.assignee || undefined,
        status: values.status,
        notes: values.notes || undefined,
      };
      if (task) {
        await updateTask({ id: task._id, ...payload });
        toast.success("Task updated");
      } else {
        await createTask({ groupFileId, ...payload });
        toast.success("Task created");
      }
      onClose();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Something went wrong";
      toast.error(msg);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{task ? "Edit task" : "New task"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Confirm rooming list" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {TASK_STATUS_OPTIONS.map((s) => (
                          <SelectItem key={s.value} value={s.value}>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="assignee"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assignee</FormLabel>
                  <FormControl>
                    <Input placeholder="Name or team" {...field} />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Additional details…"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {task ? "Save changes" : "Create task"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── Task row ──────────────────────────────────────────────────────────────────

function TaskRow({
  task,
  onEdit,
}: {
  task: Task;
  onEdit: (t: Task) => void;
}) {
  const setStatus = useMutation(api.tasks.setStatus);
  const remove = useMutation(api.tasks.remove);

  const isOverdue =
    task.status !== "done" &&
    task.dueDate &&
    isPast(parseISO(task.dueDate));

  const cycleStatus = async () => {
    const next: Record<TaskStatus, TaskStatus> = {
      open: "in_progress",
      in_progress: "done",
      done: "open",
    };
    await setStatus({ id: task._id, status: next[task.status] });
  };

  const handleDelete = async () => {
    try {
      await remove({ id: task._id });
      toast.success("Task deleted");
    } catch {
      toast.error("Could not delete task");
    }
  };

  return (
    <div
      className={cn(
        "flex items-start gap-3 rounded-md border-l-2 bg-card px-3 py-3 shadow-sm",
        STATUS_RING[task.status],
        task.status === "done" && "opacity-60",
      )}
    >
      {/* Status toggle */}
      <button
        type="button"
        onClick={cycleStatus}
        title="Click to advance status"
        className="mt-0.5 cursor-pointer transition-transform hover:scale-110"
      >
        <StatusIcon status={task.status} />
      </button>

      {/* Content */}
      <div className="min-w-0 flex-1">
        <p
          className={cn(
            "text-sm font-medium leading-snug",
            task.status === "done" && "line-through text-muted-foreground",
          )}
        >
          {task.title}
        </p>
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
          {task.dueDate && (
            <span
              className={cn(
                "flex items-center gap-1",
                isOverdue && "text-destructive font-medium",
              )}
            >
              <Clock className="size-3" />
              {format(parseISO(task.dueDate), "d MMM yyyy")}
              {isOverdue && " · overdue"}
            </span>
          )}
          {task.assignee && (
            <span className="flex items-center gap-1">
              <User className="size-3" />
              {task.assignee}
            </span>
          )}
          {task.notes && (
            <span className="truncate max-w-[200px] italic">{task.notes}</span>
          )}
        </div>
      </div>

      {/* Menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="size-7 shrink-0">
            <MoreHorizontal className="size-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => onEdit(task)}>
            <Pencil className="size-4" />
            Edit
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            className="text-destructive focus:text-destructive"
            onClick={handleDelete}
          >
            <Trash2 className="size-4" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

// ── Main tab ──────────────────────────────────────────────────────────────────

export default function TasksTab({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>(undefined);
  const [filter, setFilter] = useState<"all" | TaskStatus>("all");

  const tasks = useQuery(api.tasks.listByFile, { groupFileId });

  const filtered =
    filter === "all" ? tasks : tasks?.filter((t) => t.status === filter);

  const open = tasks?.filter((t) => t.status === "open") ?? [];
  const inProg = tasks?.filter((t) => t.status === "in_progress") ?? [];
  const done = tasks?.filter((t) => t.status === "done") ?? [];

  const openDialog = (task?: Task) => {
    setEditingTask(task);
    setDialogOpen(true);
  };

  const closeDialog = () => {
    setDialogOpen(false);
    setEditingTask(undefined);
  };

  return (
    <>
      <TaskDialog
        groupFileId={groupFileId}
        task={editingTask}
        open={dialogOpen}
        onClose={closeDialog}
      />

      <Card>
        <CardHeader className="flex-row items-center justify-between pb-3">
          <CardTitle className="font-display text-base">Tasks</CardTitle>
          <div className="flex items-center gap-2">
            {/* Filter pills */}
            <div className="flex gap-1 rounded-lg border p-1">
              {(["all", "open", "in_progress", "done"] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setFilter(f)}
                  className={cn(
                    "rounded-md px-2.5 py-1 text-xs transition-colors",
                    filter === f
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {f === "all"
                    ? "All"
                    : f === "in_progress"
                      ? "In progress"
                      : f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
            <Button size="sm" onClick={() => openDialog()}>
              <Plus className="size-4" />
              Add task
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Summary counts */}
          {tasks !== undefined && tasks.length > 0 && (
            <div className="mb-4 flex flex-wrap gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Circle className="size-3.5" />
                {open.length} open
              </span>
              <span className="flex items-center gap-1.5">
                <Loader2 className="size-3.5 text-blue-500" />
                {inProg.length} in progress
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="size-3.5 text-emerald-500" />
                {done.length} done
              </span>
            </div>
          )}

          {/* Task list */}
          {tasks === undefined ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered!.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <CheckCircle2 />
                </EmptyMedia>
                <EmptyTitle>
                  {filter === "all" ? "No tasks yet" : `No ${filter.replace("_", " ")} tasks`}
                </EmptyTitle>
                <EmptyDescription>
                  {filter === "all"
                    ? "Add tasks to track follow-ups and actions for this file."
                    : "Try switching to 'All' to see all tasks."}
                </EmptyDescription>
              </EmptyHeader>
              {filter === "all" && (
                <EmptyContent>
                  <Button size="sm" onClick={() => openDialog()}>
                    <Plus className="size-4" />
                    Add first task
                  </Button>
                </EmptyContent>
              )}
            </Empty>
          ) : (
            <div className="space-y-2">
              {filtered!.map((task) => (
                <TaskRow key={task._id} task={task} onEdit={openDialog} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
