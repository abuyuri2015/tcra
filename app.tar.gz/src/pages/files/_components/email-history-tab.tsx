import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id, Doc } from "@/convex/_generated/dataModel";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from "@/components/ui/empty.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  MailCheck,
  Receipt,
  CalendarDays,
  FileText,
  Inbox,
  CheckCircle2,
  Building2,
  ListChecks,
} from "lucide-react";
import { formatRelative } from "date-fns";

type EmailLog = Doc<"emailLogs">;

// ── Helpers ───────────────────────────────────────────────────────────────────

const TYPE_CONFIG: Record<
  EmailLog["emailType"],
  { label: string; icon: React.ReactNode; variant: "default" | "secondary" | "outline" }
> = {
  voucher: {
    label: "Voucher",
    icon: <FileText className="size-3.5" />,
    variant: "secondary",
  },
  invoice: {
    label: "Invoice",
    icon: <Receipt className="size-3.5" />,
    variant: "default",
  },
  quote: {
    label: "Quote",
    icon: <FileText className="size-3.5" />,
    variant: "outline",
  },
  itinerary: {
    label: "Itinerary",
    icon: <CalendarDays className="size-3.5" />,
    variant: "outline",
  },
  confirmation: {
    label: "Confirmation",
    icon: <CheckCircle2 className="size-3.5" />,
    variant: "default",
  },
  hotel_modification_request: {
    label: "Hotel request",
    icon: <Building2 className="size-3.5" />,
    variant: "secondary",
  },
  offer: {
    label: "Offer",
    icon: <ListChecks className="size-3.5" />,
    variant: "secondary",
  },
  other: {
    label: "Other",
    icon: <MailCheck className="size-3.5" />,
    variant: "outline",
  },
};

function formatSentAt(iso: string): string {
  try {
    return formatRelative(new Date(iso), new Date());
  } catch {
    return iso;
  }
}

function toLocalFull(iso: string): string {
  try {
    return new Date(iso).toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

// ── Row ───────────────────────────────────────────────────────────────────────

function EmailLogRow({ log }: { log: EmailLog }) {
  const config = TYPE_CONFIG[log.emailType] ?? TYPE_CONFIG.other;

  return (
    <div className="flex flex-col gap-1 rounded-lg border bg-card px-4 py-3 shadow-sm transition-colors hover:bg-muted/30 sm:flex-row sm:items-start sm:gap-4">
      {/* Type badge */}
      <div className="flex items-center gap-1.5 sm:w-28 sm:shrink-0">
        <Badge
          variant={config.variant}
          className="flex items-center gap-1 text-xs"
        >
          {config.icon}
          {config.label}
        </Badge>
      </div>

      {/* Main info */}
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{log.subject}</p>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
          <span className="truncate">
            <span className="font-medium text-foreground/70">To:</span>{" "}
            {log.to}
          </span>
          <span className="truncate">
            <span className="font-medium text-foreground/70">From:</span>{" "}
            {log.senderAddress}
          </span>
          {log.refLabel && (
            <span className="truncate">
              <span className="font-medium text-foreground/70">Ref:</span>{" "}
              {log.refLabel}
            </span>
          )}
        </div>
      </div>

      {/* Timestamp */}
      <div className="shrink-0 text-right text-xs text-muted-foreground">
        <span title={toLocalFull(log.sentAt)}>{formatSentAt(log.sentAt)}</span>
      </div>
    </div>
  );
}

// ── Tab ───────────────────────────────────────────────────────────────────────

export default function EmailHistoryTab({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const logs = useQuery(api.email.logs.listByFile, { groupFileId });

  if (logs === undefined) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (logs.length === 0) {
    return (
      <Empty>
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <Inbox />
          </EmptyMedia>
          <EmptyTitle>No emails sent yet</EmptyTitle>
          <EmptyDescription>
            Every voucher, invoice, or itinerary you send from this file will
            appear here.
          </EmptyDescription>
        </EmptyHeader>
      </Empty>
    );
  }

  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        {logs.length} email{logs.length !== 1 ? "s" : ""} sent · newest first
      </p>
      {logs.map((log) => (
        <EmailLogRow key={log._id} log={log} />
      ))}
    </div>
  );
}
