import { useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { CheckCircle2, Pencil, Trash2 } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import OfferFormDialog from "./offer-form-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip.tsx";
import { cn } from "@/lib/utils.ts";
import { OFFER_STATUS_OPTIONS, formatMoney } from "@/lib/domain.ts";
import type { OfferStatus } from "@/lib/domain.ts";

/**
 * Status select + convert/edit/delete actions shared by a standalone offer
 * row and a room-type row inside a grouped hotel offer card.
 */
export function useOfferActions(offer: Doc<"offers">) {
  const [converting, setConverting] = useState(false);
  const setStatus = useMutation(api.offers.setStatus);
  const remove = useMutation(api.offers.remove);
  const convertToReservation = useMutation(api.offers.convertToReservation);

  const handleStatus = async (value: string) => {
    try {
      await setStatus({ id: offer._id, status: value as OfferStatus });
      if (value === "accepted") {
        toast.success("Offer accepted — booked as a reservation with cost/income added");
      }
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update status.";
      toast.error(message);
    }
  };

  const handleDelete = async () => {
    try {
      await remove({ id: offer._id });
      toast.success("Offer removed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not remove offer.";
      toast.error(message);
    }
  };

  const handleConvert = async () => {
    setConverting(true);
    try {
      await convertToReservation({ id: offer._id });
      toast.success("Offer booked as a reservation");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not convert this offer.";
      toast.error(message);
    } finally {
      setConverting(false);
    }
  };

  return { converting, handleStatus, handleDelete, handleConvert };
}

/** Right-aligned rate/margin summary for one offer row */
export function OfferAmountSummary({ offer }: { offer: Doc<"offers"> }) {
  const total =
    offer.ratePerUnit !== undefined ? offer.ratePerUnit * offer.units : undefined;
  const totalCost =
    offer.costPerUnit !== undefined ? offer.costPerUnit * offer.units : undefined;
  const margin =
    total !== undefined && totalCost !== undefined ? total - totalCost : undefined;

  if (total === undefined) return null;
  return (
    <div className="text-right">
      <p className="text-sm font-semibold">{formatMoney(total, offer.currency)}</p>
      <p className="text-xs text-muted-foreground">
        {formatMoney(offer.ratePerUnit!, offer.currency)} ×{offer.units}
      </p>
      {margin !== undefined ? (
        <p
          className={cn(
            "text-xs font-medium",
            margin >= 0 ? "text-chart-3" : "text-destructive",
          )}
        >
          Margin {formatMoney(margin, offer.currency)}
        </p>
      ) : null}
    </div>
  );
}

/** Status select + convert/edit/delete buttons for one offer row */
export function OfferActionBar({
  offer,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
}: {
  offer: Doc<"offers">;
  fileCurrency: string;
  fileStartDate?: string;
  fileEndDate?: string;
  fileMarkupPercent?: number;
}) {
  const { converting, handleStatus, handleDelete, handleConvert } =
    useOfferActions(offer);
  const isConverted = Boolean(offer.convertedReservationId);

  return (
    <div className="flex shrink-0 items-start gap-2">
      {!isConverted && (
        <Select value={offer.status} onValueChange={handleStatus}>
          <SelectTrigger className="h-7 w-28 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {OFFER_STATUS_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value} className="text-xs">
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {!isConverted && (
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-7 text-chart-3"
              aria-label="Convert to reservation"
              disabled={converting}
              onClick={handleConvert}
            >
              <CheckCircle2 className="size-3.5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Book as reservation</TooltipContent>
        </Tooltip>
      )}

      <OfferFormDialog
        groupFileId={offer.groupFileId}
        fileCurrency={fileCurrency}
        fileStartDate={fileStartDate}
        fileEndDate={fileEndDate}
        fileMarkupPercent={fileMarkupPercent}
        offer={offer}
        trigger={
          <Button variant="ghost" size="icon" className="size-7" aria-label="Edit">
            <Pencil className="size-3.5" />
          </Button>
        }
      />

      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button variant="ghost" size="icon" className="size-7" aria-label="Remove">
            <Trash2 className="size-3.5 text-destructive" />
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this offer?</AlertDialogTitle>
            <AlertDialogDescription>
              {offer.supplierName} — {offer.description} will be permanently
              removed from this file.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
