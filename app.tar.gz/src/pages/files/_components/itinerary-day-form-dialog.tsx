import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { dateInputToIso, isoToDateInput } from "@/lib/dates.ts";
import type { ReactNode } from "react";

type Day = Doc<"itineraryDays">;

const schema = z.object({
  title: z.string(),
  notes: z.string(),
});

type FormValues = z.output<typeof schema>;

export default function ItineraryDayFormDialog({
  day,
  trigger,
}: {
  day: Day;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const update = useMutation(api.itinerary.updateDay);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { title: day.title ?? "", notes: day.notes ?? "" },
  });

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) form.reset({ title: day.title ?? "", notes: day.notes ?? "" });
  };

  const onSubmit = async (values: FormValues) => {
    try {
      await update({
        id: day._id,
        title: values.title.trim() || undefined,
        notes: values.notes.trim() || undefined,
      });
      toast.success("Day updated");
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save.";
      toast.error(message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="font-display">Edit day {day.dayNumber}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Day title (optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Arrival & welcome dinner" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Internal notes (optional)</FormLabel>
                  <FormControl>
                    <Textarea rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                Save
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
