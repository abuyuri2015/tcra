import { useState, useEffect } from "react";
import { useAction } from "convex/react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Send, FileText, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { generateQuotePDFBase64 } from "@/lib/pdf-generators.ts";
import { formatMoney } from "@/lib/domain.ts";

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type FinanceLine = Doc<"financeLines"> & { amountInBase: number };
type ItineraryDay = Doc<"itineraryDays"> & { items: Doc<"itineraryItems">[] };
type SenderIdentity = { id: string; value: string; type: string; status: string };

const schema = z.object({
  from: z.string().min(1, "Select a sender address"),
  to: z.string().email("Enter a valid email address"),
  subject: z.string().min(1, "Subject is required"),
  body: z.string().min(1, "Message body is required"),
  coverMessage: z.string(),
});
type FormValues = z.output<typeof schema>;

export default function SendQuoteDialog({
  file,
  financeLines,
  itineraryDays,
  quoteNumber,
  senderIdentities,
  trigger,
}: {
  file: GroupFile;
  financeLines: FinanceLine[];
  itineraryDays: ItineraryDay[];
  quoteNumber: string;
  senderIdentities: SenderIdentity[];
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const sendQuote = useAction(api.email.send.sendQuote);

  const verifiedSenders = senderIdentities.filter((s) => s.status === "verified");
  const incomeLines = financeLines.filter((l) => l.kind === "income");
  const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);

  const defaultTo = file.clientContactEmail ?? "";
  const defaultSubject = `Quote ${quoteNumber} – ${file.title}`;
  const defaultCover = `Dear ${file.clientContactName ?? file.clientName},

Please find attached our quote for the following programme:

Group: ${file.title}
Reference: ${file.reference}
Total value: ${formatMoney(totalEur, "EUR")}

We would be delighted to discuss this proposal further. Please do not hesitate to contact us with any questions.

Kind regards,
${file.ownerName ?? "Tessera Groups & MICE Team"}`;

  const defaultBody = `Dear ${file.clientContactName ?? file.clientName},\n\nPlease find attached quote ${quoteNumber} for ${file.title}.\n\nKind regards,\n${file.ownerName ?? "Tessera Groups & MICE Team"}`;

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      from: verifiedSenders[0]?.value ?? "",
      to: defaultTo,
      subject: defaultSubject,
      body: defaultBody,
      coverMessage: defaultCover,
    },
  });

  useEffect(() => {
    if (open) {
      form.reset({
        from: verifiedSenders[0]?.value ?? "",
        to: defaultTo,
        subject: defaultSubject,
        body: defaultBody,
        coverMessage: defaultCover,
      });
    }
  }, [open]);

  const onSubmit = async (values: FormValues) => {
    setSending(true);
    try {
      const { base64, filename } = generateQuotePDFBase64(
        file,
        financeLines,
        itineraryDays,
        values.coverMessage,
        quoteNumber,
      );
      await sendQuote({
        groupFileId: file._id,
        from: values.from,
        to: values.to,
        subject: values.subject,
        body: values.body,
        pdfDataUri: base64,
        pdfFilename: filename,
        quoteNumber,
      });
      toast.success(`Quote sent to ${values.to}`);
      setOpen(false);
    } catch (err) {
      const message =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Failed to send email. Please try again.";
      toast.error(message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button size="sm">
            <Send className="size-4" />
            Email quote
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <FileText className="size-4 text-muted-foreground" />
            Send quote to client
          </DialogTitle>
          <DialogDescription>
            The quote PDF ({quoteNumber}) will be generated and attached automatically.
          </DialogDescription>
        </DialogHeader>

        {verifiedSenders.length === 0 ? (
          <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
            <AlertCircle className="mt-0.5 size-4 shrink-0" />
            <p>
              No verified sender found. Go to{" "}
              <strong>Settings → Email sender identities</strong> to verify one.
            </p>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="from"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sender address" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {verifiedSenders.map((s) => (
                          <SelectItem key={s.id} value={s.value}>{s.value}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="to"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>To (client email)</FormLabel>
                    <FormControl>
                      <Input placeholder="client@company.com" type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl><Input {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="coverMessage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cover message (appears in PDF)</FormLabel>
                    <FormControl>
                      <Textarea rows={6} className="resize-none text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="body"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email body</FormLabel>
                    <FormControl>
                      <Textarea rows={4} className="resize-none text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={sending}>
                  Cancel
                </Button>
                <Button type="submit" disabled={sending}>
                  {sending ? (
                    <><Loader2 className="size-4 animate-spin" />Sending…</>
                  ) : (
                    <><Send className="size-4" />Send quote</>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
