import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { ITINERARY_ITEM_TYPE_OPTIONS } from "@/lib/itinerary.ts";
import type { ReactNode } from "react";

type Item = Doc<"itineraryItems">;

const schema = z.object({
  type: z.enum([
    "arrival", "departure", "transfer", "hotel", "meal",
    "activity", "meeting", "flight", "free-time", "other",
  ]),
  time: z.string(),
  title: z.string().min(1, "Title is required"),
  description: z.string(),
  location: z.string(),
  notes: z.string(),
});

type FormValues = z.output<typeof schema>;

function defaults(item?: Item): FormValues {
  if (!item) {
    return {
      type: "activity",
      time: "",
      title: "",
      description: "",
      location: "",
      notes: "",
    };
  }
  return {
    type: item.type,
    time: item.time ?? "",
    title: item.title,
    description: item.description ?? "",
    location: item.location ?? "",
    notes: item.notes ?? "",
  };
}

export default function ItineraryItemFormDialog({
  dayId,
  groupFileId,
  nextSortOrder,
  item,
  trigger,
}: {
  dayId: Id<"itineraryDays">;
  groupFileId: Id<"groupFiles">;
  nextSortOrder: number;
  item?: Item;
  trigger: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const create = useMutation(api.itinerary.createItem);
  const update = useMutation(api.itinerary.updateItem);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaults(item),
  });

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (next) form.reset(defaults(item));
  };

  const onSubmit = async (values: FormValues) => {
    try {
      if (item) {
        await update({
          id: item._id,
          type: values.type,
          time: values.time || undefined,
          title: values.title.trim(),
          description: values.description.trim() || undefined,
          location: values.location.trim() || undefined,
          notes: values.notes.trim() || undefined,
        });
        toast.success("Item updated");
      } else {
        await create({
          dayId,
          groupFileId,
          sortOrder: nextSortOrder,
          type: values.type,
          time: values.time || undefined,
          title: values.title.trim(),
          description: values.description.trim() || undefined,
          location: values.location.trim() || undefined,
          notes: values.notes.trim() || undefined,
        });
        toast.success("Item added");
      }
      setOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save. Please try again.";
      toast.error(message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">
            {item ? "Edit item" : "Add itinerary item"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ITINERARY_ITEM_TYPE_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="time"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Time (optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="09:00" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Welcome lunch at La Boqueria" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Location (optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Hotel lobby / La Boqueria, Barcelona" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Description (optional)</FormLabel>
                  <FormControl>
                    <Textarea rows={2} placeholder="Details shown to the client…" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Internal notes (optional)</FormLabel>
                  <FormControl>
                    <Textarea rows={2} placeholder="Only visible to staff…" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                {item ? "Save changes" : "Add item"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
