import { useState, useEffect } from "react";
import { useAction } from "convex/react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Send, Mail, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { generateVoucherPDFBase64 } from "@/lib/pdf-generators.ts";
import { formatDate, formatDateRange } from "@/lib/dates.ts";
import { reservationTypeLabel } from "@/lib/domain.ts";

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type Reservation = Doc<"reservations">;
type SenderIdentity = { id: string; value: string; type: string; status: string };

const schema = z.object({
  from: z.string().min(1, "Select a sender address"),
  to: z.string().email("Enter a valid email address"),
  subject: z.string().min(1, "Subject is required"),
  body: z.string().min(1, "Message body is required"),
});
type FormValues = z.output<typeof schema>;

function buildDefaultSubject(file: GroupFile, reservation: Reservation) {
  return `Service Voucher – ${reservation.supplierName} · ${file.reference}`;
}

function buildDefaultBody(file: GroupFile, reservation: Reservation) {
  const dateLabel =
    reservation.type === "hotel" && reservation.nights !== undefined
      ? `${formatDate(reservation.startDate)} (${reservation.nights} night${reservation.nights > 1 ? "s" : ""})`
      : reservation.endDate
        ? formatDateRange(reservation.startDate, reservation.endDate)
        : formatDate(reservation.startDate);

  return `Dear ${reservation.supplierName} Team,

Please find attached the service voucher for the following booking:

Group: ${file.title}
Client: ${file.clientName}
Service: ${reservationTypeLabel(reservation.type)} – ${reservation.description}
Date: ${dateLabel}
Pax / Units: ${reservation.units}${reservation.supplierRef ? `\nYour reference: ${reservation.supplierRef}` : ""}

Please confirm receipt and availability at your earliest convenience.

Kind regards,
${file.ownerName ?? "Tessera Groups & MICE Team"}`;
}

export default function SendVoucherDialog({
  file,
  reservation,
  senderIdentities,
  trigger,
}: {
  file: GroupFile;
  reservation: Reservation;
  senderIdentities: SenderIdentity[];
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const sendVoucher = useAction(api.email.send.sendVoucher);

  const verifiedSenders = senderIdentities.filter((s) => s.status === "verified");

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      from: verifiedSenders[0]?.value ?? "",
      to: "",
      subject: buildDefaultSubject(file, reservation),
      body: buildDefaultBody(file, reservation),
    },
  });

  // Reset defaults when dialog opens
  useEffect(() => {
    if (open) {
      form.reset({
        from: verifiedSenders[0]?.value ?? "",
        to: "",
        subject: buildDefaultSubject(file, reservation),
        body: buildDefaultBody(file, reservation),
      });
    }
  }, [open]);

  const onSubmit = async (values: FormValues) => {
    setSending(true);
    try {
      const { base64, filename } = generateVoucherPDFBase64(file, reservation);
      await sendVoucher({
        groupFileId: file._id,
        reservationId: reservation._id,
        from: values.from,
        to: values.to,
        subject: values.subject,
        body: values.body,
        pdfDataUri: base64,
        pdfFilename: filename,
        supplierName: reservation.supplierName,
      });
      toast.success(`Voucher sent to ${values.to}`);
      setOpen(false);
    } catch (err) {
      const message =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Failed to send email. Please try again.";
      toast.error(message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button size="sm" variant="secondary">
            <Mail className="size-4" />
            Email voucher
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <Send className="size-4 text-muted-foreground" />
            Send voucher to supplier
          </DialogTitle>
          <DialogDescription>
            The voucher PDF will be attached automatically.
          </DialogDescription>
        </DialogHeader>

        {verifiedSenders.length === 0 ? (
          <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
            <AlertCircle className="mt-0.5 size-4 shrink-0" />
            <p>
              No verified sender address found. Go to{" "}
              <strong>Settings → Email sender identities</strong> to verify one
              before sending emails.
            </p>
          </div>
        ) : (
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="space-y-4"
            >
              {/* From */}
              <FormField
                control={form.control}
                name="from"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sender address" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {verifiedSenders.map((s) => (
                          <SelectItem key={s.id} value={s.value}>
                            {s.value}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* To */}
              <FormField
                control={form.control}
                name="to"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>To (supplier email)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="reservations@supplier.com"
                        type="email"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription className="text-xs">
                      Enter the supplier's reservations or group email address.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Subject */}
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Body */}
              <FormField
                control={form.control}
                name="body"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message</FormLabel>
                    <FormControl>
                      <Textarea rows={8} className="resize-none text-sm" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setOpen(false)}
                  disabled={sending}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={sending}>
                  {sending ? (
                    <>
                      <Loader2 className="size-4 animate-spin" />
                      Sending…
                    </>
                  ) : (
                    <>
                      <Send className="size-4" />
                      Send voucher
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
