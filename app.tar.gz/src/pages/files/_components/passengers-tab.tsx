import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ConvexError } from "convex/values";
import {
  Download,
  FileText,
  MoreHorizontal,
  Pencil,
  Plus,
  Trash2,
  Users,
  UtensilsCrossed,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.js";
import { downloadCsv } from "@/lib/csv-export.ts";
import { generateRoomingListPDF } from "@/lib/pdf-generators.ts";
import type { AgencyProfilePDF } from "@/lib/pdf-generators.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import PassengerAiImport from "./passenger-ai-import.tsx";

// ── Room type config ──────────────────────────────────────────────────────────

type RoomType = "single" | "double" | "twin" | "triple" | "suite";

const ROOM_TYPE_OPTIONS: { value: RoomType; label: string }[] = [
  { value: "single", label: "Single" },
  { value: "double", label: "Double" },
  { value: "twin", label: "Twin" },
  { value: "triple", label: "Triple" },
  { value: "suite", label: "Suite" },
];

const ROOM_CHIP: Record<RoomType, string> = {
  single: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  double: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  twin: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300",
  triple: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  suite: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
};

// ── Form schema ───────────────────────────────────────────────────────────────

const schema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  roomType: z.enum(["single", "double", "twin", "triple", "suite"]),
  sharingWith: z.string(),
  dietaryRequirements: z.string(),
  notes: z.string(),
});

type FormValues = z.infer<typeof schema>;

function defaultValues(p?: Doc<"passengers">): FormValues {
  return {
    firstName: p?.firstName ?? "",
    lastName: p?.lastName ?? "",
    roomType: p?.roomType ?? "single",
    sharingWith: p?.sharingWith ?? "",
    dietaryRequirements: p?.dietaryRequirements ?? "",
    notes: p?.notes ?? "",
  };
}

// ── Passenger dialog ──────────────────────────────────────────────────────────

function PassengerDialog({
  groupFileId,
  passenger,
  open,
  onClose,
}: {
  groupFileId: Id<"groupFiles">;
  passenger?: Doc<"passengers">;
  open: boolean;
  onClose: () => void;
}) {
  const create = useMutation(api.passengers.create);
  const update = useMutation(api.passengers.update);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultValues(passenger),
  });

  const handleOpenChange = (v: boolean) => {
    if (!v) onClose();
    else form.reset(defaultValues(passenger));
  };

  const onSubmit = async (values: FormValues) => {
    try {
      const payload = {
        firstName: values.firstName.trim(),
        lastName: values.lastName.trim(),
        roomType: values.roomType,
        sharingWith: values.sharingWith.trim() || undefined,
        dietaryRequirements: values.dietaryRequirements.trim() || undefined,
        notes: values.notes.trim() || undefined,
      };
      if (passenger) {
        await update({ id: passenger._id, ...payload });
        toast.success("Passenger updated");
      } else {
        await create({ groupFileId, ...payload });
        toast.success("Passenger added");
      }
      onClose();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not save passenger.";
      toast.error(msg);
    }
  };

  const roomType = form.watch("roomType");
  const needsSharingField =
    roomType === "double" || roomType === "twin" || roomType === "triple";

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">
            {passenger ? "Edit passenger" : "Add passenger"}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>First name</FormLabel>
                  <FormControl>
                    <Input placeholder="John" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="lastName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Last name</FormLabel>
                  <FormControl>
                    <Input placeholder="Smith" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="roomType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Room type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ROOM_TYPE_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            {needsSharingField && (
              <FormField
                control={form.control}
                name="sharingWith"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sharing with</FormLabel>
                    <FormControl>
                      <Input placeholder="Jane Smith" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            <FormField
              control={form.control}
              name="dietaryRequirements"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Dietary requirements</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Vegetarian, Gluten-free, Nut allergy" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={2} placeholder="Special requests, accessibility needs…" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="sm:col-span-2">
              <Button type="button" variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {passenger ? "Save changes" : "Add passenger"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ── CSV export ────────────────────────────────────────────────────────────────

function exportToCsv(passengers: Doc<"passengers">[], fileTitle: string) {
  const rows = passengers.map((p) => ({
    "Last name": p.lastName,
    "First name": p.firstName,
    "Room type":
      ROOM_TYPE_OPTIONS.find((o) => o.value === p.roomType)?.label ?? p.roomType,
    "Sharing with": p.sharingWith ?? "",
    "Dietary requirements": p.dietaryRequirements ?? "",
    Notes: p.notes ?? "",
  }));
  const slug = fileTitle.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  downloadCsv(rows, `rooming-list-${slug}.csv`);
}

// ── Passenger row ─────────────────────────────────────────────────────────────

function PassengerRow({
  passenger,
  index,
  onEdit,
}: {
  passenger: Doc<"passengers">;
  index: number;
  onEdit: () => void;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const remove = useMutation(api.passengers.remove);

  const handleDelete = async () => {
    try {
      await remove({ id: passenger._id });
      toast.success("Passenger removed");
    } catch {
      toast.error("Could not remove passenger");
    }
  };

  const hasDiet = Boolean(passenger.dietaryRequirements);

  return (
    <>
      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Remove {passenger.firstName} {passenger.lastName}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the passenger from the rooming list.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <tr className="group border-b last:border-0 transition-colors hover:bg-secondary/30">
        <td className="py-3 pl-4 pr-2 text-xs text-muted-foreground tabular-nums">
          {index + 1}
        </td>
        <td className="py-3 pr-3">
          <p className="text-sm font-medium">
            {passenger.lastName}, {passenger.firstName}
          </p>
          {passenger.notes && (
            <p className="text-xs text-muted-foreground italic truncate max-w-[200px]">
              {passenger.notes}
            </p>
          )}
        </td>
        <td className="py-3 pr-3">
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              ROOM_CHIP[passenger.roomType],
            )}
          >
            {ROOM_TYPE_OPTIONS.find((o) => o.value === passenger.roomType)?.label}
          </span>
        </td>
        <td className="py-3 pr-3 text-sm text-muted-foreground">
          {passenger.sharingWith ?? <span className="italic text-xs">—</span>}
        </td>
        <td className="py-3 pr-3">
          {hasDiet ? (
            <span className="flex items-center gap-1 text-xs text-amber-700 dark:text-amber-400">
              <UtensilsCrossed className="size-3 shrink-0" />
              <span className="truncate max-w-[160px]">{passenger.dietaryRequirements}</span>
            </span>
          ) : (
            <span className="text-xs text-muted-foreground italic">—</span>
          )}
        </td>
        <td className="py-3 pr-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-7 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreHorizontal className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>
                <Pencil className="size-4" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-destructive focus:text-destructive"
                onClick={() => setConfirmDelete(true)}
              >
                <Trash2 className="size-4" />
                Remove
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </td>
      </tr>
    </>
  );
}

// ── Main tab ──────────────────────────────────────────────────────────────────

export default function PassengersTab({
  groupFileId,
  fileTitle,
  file,
}: {
  groupFileId: Id<"groupFiles">;
  fileTitle: string;
  file?: Doc<"groupFiles"> & { ownerName?: string | null };
}) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Doc<"passengers"> | undefined>();

  const passengers = useQuery(api.passengers.listByFile, { groupFileId });
  const agencyProfile = useQuery(api.agencyProfile.get);

  const openCreate = () => {
    setEditing(undefined);
    setDialogOpen(true);
  };

  const openEdit = (p: Doc<"passengers">) => {
    setEditing(p);
    setDialogOpen(true);
  };

  const handleDownloadPdf = () => {
    if (!passengers || passengers.length === 0 || !file) return;
    const agency: AgencyProfilePDF = agencyProfile
      ? {
          agencyName: agencyProfile.agencyName,
          address: agencyProfile.address ?? undefined,
          phone: agencyProfile.phone ?? undefined,
          email: agencyProfile.email ?? undefined,
          website: agencyProfile.website ?? undefined,
          bankName: agencyProfile.bankName ?? undefined,
          iban: agencyProfile.iban ?? undefined,
          bic: agencyProfile.bic ?? undefined,
          paymentTerms: agencyProfile.paymentTerms ?? undefined,
          taxId: agencyProfile.taxId ?? undefined,
        }
      : null;
    generateRoomingListPDF(file, passengers, agency);
    toast.success("Rooming list PDF downloaded");
  };

  // Summary stats
  const totalPax = passengers?.length ?? 0;
  const roomsByType = passengers?.reduce<Partial<Record<RoomType, number>>>(
    (acc, p) => {
      acc[p.roomType] = (acc[p.roomType] ?? 0) + 1;
      return acc;
    },
    {},
  );
  const hasDietary = passengers?.filter((p) => p.dietaryRequirements).length ?? 0;

  return (
    <>
      <PassengerDialog
        key={editing?._id ?? "new"}
        groupFileId={groupFileId}
        passenger={editing}
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
      />

      <Card>
        <CardHeader className="flex-row items-center justify-between pb-3">
          <CardTitle className="font-display text-base">Rooming list</CardTitle>
          <div className="flex items-center gap-2">
            {passengers !== undefined && passengers.length > 0 && (
              <>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleDownloadPdf}
                  disabled={!file}
                >
                  <FileText className="size-4" />
                  Download PDF
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => exportToCsv(passengers, fileTitle)}
                >
                  <Download className="size-4" />
                  Export CSV
                </Button>
              </>
            )}
            <PassengerAiImport groupFileId={groupFileId} />
            <Button size="sm" onClick={openCreate}>
              <Plus className="size-4" />
              Add passenger
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Summary bar */}
          {passengers !== undefined && passengers.length > 0 && (
            <div className="mb-4 flex flex-wrap gap-4 text-xs text-muted-foreground border-b pb-4">
              <span className="flex items-center gap-1.5">
                <Users className="size-3.5" />
                <span className="font-medium text-foreground">{totalPax}</span> passenger{totalPax !== 1 ? "s" : ""}
              </span>
              {Object.entries(roomsByType ?? {}).map(([type, count]) => (
                <span key={type} className="flex items-center gap-1.5">
                  <span
                    className={cn(
                      "rounded-full px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                      ROOM_CHIP[type as RoomType],
                    )}
                  >
                    {ROOM_TYPE_OPTIONS.find((o) => o.value === type)?.label}
                  </span>
                  ×{count}
                </span>
              ))}
              {hasDietary > 0 && (
                <span className="flex items-center gap-1 text-amber-700 dark:text-amber-400">
                  <UtensilsCrossed className="size-3.5" />
                  {hasDietary} dietary req.
                </span>
              )}
            </div>
          )}

          {/* Table */}
          {passengers === undefined ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : passengers.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <Users />
                </EmptyMedia>
                <EmptyTitle>No passengers yet</EmptyTitle>
                <EmptyDescription>
                  Add each traveller with their room type to build the rooming list for this group.
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <Button size="sm" onClick={openCreate}>
                  <Plus className="size-4" />
                  Add first passenger
                </Button>
              </EmptyContent>
            </Empty>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px] text-left">
                <thead>
                  <tr className="border-b">
                    <th className="pb-2 pl-4 pr-2 text-[10px] uppercase tracking-widest text-muted-foreground">#</th>
                    <th className="pb-2 pr-3 text-[10px] uppercase tracking-widest text-muted-foreground">Name</th>
                    <th className="pb-2 pr-3 text-[10px] uppercase tracking-widest text-muted-foreground">Room</th>
                    <th className="pb-2 pr-3 text-[10px] uppercase tracking-widest text-muted-foreground">Sharing with</th>
                    <th className="pb-2 pr-3 text-[10px] uppercase tracking-widest text-muted-foreground">Dietary</th>
                    <th className="pb-2 pr-2" />
                  </tr>
                </thead>
                <tbody>
                  {passengers.map((p, i) => (
                    <PassengerRow
                      key={p._id}
                      passenger={p}
                      index={i}
                      onEdit={() => openEdit(p)}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
