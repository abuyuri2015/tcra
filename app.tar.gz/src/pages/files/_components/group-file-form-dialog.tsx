import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { useNavigate } from "react-router-dom";
import { Bookmark, CalendarRange, FileText, MapPin, Users } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import PercentStepper from "@/components/ui/percent-stepper.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  CURRENCY_OPTIONS,
  FILE_STATUS_OPTIONS,
  FILE_TYPE_OPTIONS,
} from "@/lib/domain.ts";
import { dateInputToIso, isoToDateInput } from "@/lib/dates.ts";
import { cn } from "@/lib/utils.ts";
import type { ReactNode } from "react";

const schema = z
  .object({
    title: z.string().min(2, "Give the file a name"),
    fileType: z.enum(["group", "meeting", "incentive", "conference", "event"]),
    status: z.enum([
      "enquiry",
      "quoted",
      "confirmed",
      "operating",
      "closed",
      "cancelled",
    ]),
    clientName: z.string().min(2, "Client is required"),
    clientContactName: z.string(),
    clientContactEmail: z
      .string()
      .refine((v) => v === "" || z.string().email().safeParse(v).success, {
        message: "Enter a valid email",
      }),
    clientContactPhone: z.string(),
    destination: z.string().min(2, "Destination is required"),
    startDate: z.string().min(1, "Start date is required"),
    endDate: z.string().min(1, "End date is required"),
    pax: z
      .string()
      .refine((v) => Number.isInteger(Number(v)) && Number(v) >= 1, {
        message: "At least 1 traveller",
      }),
    currency: z.enum(CURRENCY_OPTIONS),
    exchangeRateToBase: z
      .string()
      .refine((v) => Number(v) > 0, { message: "Rate must be above 0" }),
    markupPercent: z
      .string()
      .refine((v) => v === "" || Number(v) >= 0, {
        message: "Markup % cannot be negative",
      }),
    notes: z.string(),
  })
  .refine((data) => data.endDate >= data.startDate, {
    path: ["endDate"],
    message: "End date must be on or after the start date",
  });

type FormValues = z.output<typeof schema>;

function defaultsFor(file?: Doc<"groupFiles">): FormValues {
  if (!file) {
    return {
      title: "",
      fileType: "group",
      status: "enquiry",
      clientName: "",
      clientContactName: "",
      clientContactEmail: "",
      clientContactPhone: "",
      destination: "",
      startDate: "",
      endDate: "",
      pax: "20",
      currency: "EUR",
      exchangeRateToBase: "1",
      markupPercent: "20",
      notes: "",
    };
  }

  return {
    title: file.title,
    fileType: file.fileType,
    status: file.status,
    clientName: file.clientName,
    clientContactName: file.clientContactName ?? "",
    clientContactEmail: file.clientContactEmail ?? "",
    clientContactPhone: file.clientContactPhone ?? "",
    destination: file.destination,
    startDate: isoToDateInput(file.startDate),
    endDate: isoToDateInput(file.endDate),
    pax: String(file.pax),
    currency: file.currency,
    exchangeRateToBase: String(file.exchangeRateToBase),
    markupPercent: file.markupPercent !== undefined ? String(file.markupPercent) : "",
    notes: file.notes ?? "",
  };
}

// ── Template picker card ─────────────────────────────────────────────────────

function TemplateCard({
  template,
  selected,
  onSelect,
}: {
  template: Doc<"fileTemplates">;
  selected: boolean;
  onSelect: () => void;
}) {
  const dayCount = template.itineraryDays.length;
  const financeCount = template.financeLines.length;

  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "w-full cursor-pointer rounded-lg border p-3 text-left transition-colors",
        selected
          ? "border-primary bg-primary/5 ring-1 ring-primary"
          : "hover:border-primary/40 hover:bg-secondary/40",
      )}
    >
      <div className="flex items-start gap-2">
        <Bookmark className={cn("mt-0.5 size-4 shrink-0", selected ? "text-primary" : "text-muted-foreground")} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium">{template.name}</p>
          {template.description && (
            <p className="mt-0.5 truncate text-xs text-muted-foreground">{template.description}</p>
          )}
          <div className="mt-1.5 flex flex-wrap gap-2 text-[10px] text-muted-foreground">
            {template.destination && (
              <span className="flex items-center gap-0.5">
                <MapPin className="size-3" />
                {template.destination}
              </span>
            )}
            {template.pax !== undefined && (
              <span className="flex items-center gap-0.5">
                <Users className="size-3" />
                {template.pax} pax
              </span>
            )}
            {dayCount > 0 && (
              <span className="flex items-center gap-0.5">
                <CalendarRange className="size-3" />
                {dayCount} day{dayCount !== 1 ? "s" : ""}
              </span>
            )}
            {financeCount > 0 && (
              <span className="flex items-center gap-0.5">
                <FileText className="size-3" />
                {financeCount} line{financeCount !== 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}

// ── Main dialog ──────────────────────────────────────────────────────────────

export default function GroupFileFormDialog({
  file,
  trigger,
  open: controlledOpen,
  onOpenChange: controlledOnOpenChange,
}: {
  file?: Doc<"groupFiles">;
  trigger: ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) {
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : internalOpen;
  const navigate = useNavigate();

  const create = useMutation(api.groupFiles.create);
  const createFromTemplate = useMutation(api.groupFiles.createFromTemplate);
  const update = useMutation(api.groupFiles.update);

  // Only fetch templates in "create" mode
  const templates = useQuery(
    api.fileTemplates.list,
    file ? "skip" : {},
  );

  const [selectedTemplateId, setSelectedTemplateId] = useState<Id<"fileTemplates"> | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFor(file),
  });

  const handleOpenChange = (next: boolean) => {
    if (isControlled) {
      controlledOnOpenChange?.(next);
    } else {
      setInternalOpen(next);
    }
    if (next) {
      form.reset(defaultsFor(file));
      setSelectedTemplateId(null);
    }
  };

  const applyTemplate = (template: Doc<"fileTemplates">) => {
    if (selectedTemplateId === template._id) {
      // Deselect
      setSelectedTemplateId(null);
      form.reset(defaultsFor(file));
      return;
    }
    setSelectedTemplateId(template._id);
    // Pre-fill form fields from template
    form.setValue("fileType", template.fileType);
    if (template.destination) form.setValue("destination", template.destination);
    if (template.pax !== undefined) form.setValue("pax", String(template.pax));
    form.setValue("currency", template.currency);
    if (template.notes) form.setValue("notes", template.notes);
  };

  const onSubmit = async (values: FormValues) => {
    const parsed = schema.parse(values);
    const payload = {
      title: parsed.title.trim(),
      fileType: parsed.fileType,
      status: parsed.status,
      clientName: parsed.clientName.trim(),
      clientContactName: parsed.clientContactName.trim() || undefined,
      clientContactEmail: parsed.clientContactEmail.trim() || undefined,
      clientContactPhone: parsed.clientContactPhone.trim() || undefined,
      destination: parsed.destination.trim(),
      startDate: dateInputToIso(parsed.startDate),
      endDate: dateInputToIso(parsed.endDate),
      pax: Number(parsed.pax),
      currency: parsed.currency,
      exchangeRateToBase: Number(parsed.exchangeRateToBase),
      markupPercent:
        parsed.markupPercent.trim() === "" ? undefined : Number(parsed.markupPercent),
      notes: parsed.notes.trim() || undefined,
    };
    try {
      if (file) {
        await update({ id: file._id, ...payload });
        toast.success("File updated");
      } else if (selectedTemplateId) {
        const newId = await createFromTemplate({ templateId: selectedTemplateId, ...payload });
        toast.success("File created from template");
        navigate(`/files/${newId}`);
      } else {
        await create(payload);
        toast.success("File created");
      }
      handleOpenChange(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not save the file. Please try again.";
      toast.error(message);
    }
  };

  const hasTemplates = !file && templates && templates.length > 0;

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display">
            {file ? "Edit group file" : "New group file"}
          </DialogTitle>
          <DialogDescription>
            {file
              ? `Reference ${file.reference}`
              : "A reference is assigned automatically."}
          </DialogDescription>
        </DialogHeader>

        {/* Template picker — only in create mode when templates exist */}
        {hasTemplates && (
          <div className="space-y-2">
            <p className="text-sm font-medium">Start from a template</p>
            <div className="grid gap-2 sm:grid-cols-2 max-h-40 overflow-y-auto pr-1">
              {templates.map((t) => (
                <TemplateCard
                  key={t._id}
                  template={t}
                  selected={selectedTemplateId === t._id}
                  onSelect={() => applyTemplate(t)}
                />
              ))}
            </div>
            <div className="border-b pt-1" />
          </div>
        )}

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>File name</FormLabel>
                  <FormControl>
                    <Input placeholder="Acme Sales Kick-off 2026" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="fileType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FILE_TYPE_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FILE_STATUS_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="clientName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Client / company</FormLabel>
                  <FormControl>
                    <Input placeholder="Acme Corporation" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="destination"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Destination</FormLabel>
                  <FormControl>
                    <Input placeholder="Barcelona, Spain" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="clientContactName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Smith" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="clientContactEmail"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact email</FormLabel>
                  <FormControl>
                    <Input placeholder="example@gmail.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="clientContactPhone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact phone</FormLabel>
                  <FormControl>
                    <Input placeholder="+34 600 000 000" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="pax"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Travellers (pax)</FormLabel>
                  <FormControl>
                    <Input type="number" min={1} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Start date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="endDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>End date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>File currency</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {CURRENCY_OPTIONS.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="exchangeRateToBase"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Rate to EUR</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.0001" min="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="markupPercent"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Markup %</FormLabel>
                  <FormControl>
                    <PercentStepper
                      value={field.value.trim() === "" ? 0 : Number(field.value)}
                      onChange={(next) => field.onChange(String(next))}
                    />
                  </FormControl>
                  <FormDescription>
                    Default suggested markup used only when adding a new offer or
                    reservation. The file's actual margin % shown elsewhere is
                    calculated live from what's been priced.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={3} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => handleOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                {file ? "Save changes" : selectedTemplateId ? "Create from template" : "Create file"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
