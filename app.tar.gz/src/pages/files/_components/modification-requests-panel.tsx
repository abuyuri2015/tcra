import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { formatDistanceToNow } from "date-fns";
import { Building2, CheckCircle2, Clock, Loader2, MessageSquarePlus, Send, XCircle } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { cn } from "@/lib/utils.ts";

type ModRequest = Doc<"modificationRequests">;

const STATUS_CONFIG: Record<
  ModRequest["status"],
  { label: string; className: string; icon: typeof Clock }
> = {
  pending_hotel: {
    label: "Awaiting hotel response",
    className: "bg-chart-4/15 text-chart-4",
    icon: Clock,
  },
  no_hotel_contact: {
    label: "Needs manual routing",
    className: "bg-destructive/12 text-destructive",
    icon: MessageSquarePlus,
  },
  approved: {
    label: "Approved by hotel",
    className: "bg-chart-3/15 text-chart-3",
    icon: CheckCircle2,
  },
  declined: {
    label: "Declined by hotel",
    className: "bg-destructive/12 text-destructive",
    icon: XCircle,
  },
};

export default function ModificationRequestsPanel({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const requests = useQuery(api.modificationRequests.listByFile, { groupFileId });
  const resendToHotel = useMutation(api.modificationRequests.resendToHotel);
  const [resendingId, setResendingId] = useState<Id<"modificationRequests"> | null>(null);

  if (requests === undefined) {
    return <Skeleton className="h-24 w-full" />;
  }
  if (requests.length === 0) return null;

  const handleResend = async (req: ModRequest) => {
    setResendingId(req._id);
    try {
      await resendToHotel({ requestId: req._id });
      toast.success(`Resent the request to ${req.supplierName}`);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not resend this request.";
      toast.error(message);
    } finally {
      setResendingId(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-base flex items-center gap-2">
          <Building2 className="size-4 text-muted-foreground" />
          Change requests
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {requests.map((req) => {
          const config = STATUS_CONFIG[req.status];
          const Icon = config.icon;
          return (
            <div
              key={req._id}
              className="flex flex-wrap items-start justify-between gap-3 rounded-lg border px-4 py-3"
            >
              <div className="min-w-0 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-medium">{req.supplierName}</span>
                  <span
                    className={cn(
                      "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                      config.className,
                    )}
                  >
                    <Icon className="size-3" />
                    {config.label}
                  </span>
                  <span className="inline-flex items-center rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    {req.submittedBy === "staff" ? "From staff" : "From client"}
                  </span>
                  {req.status === "approved" && req.kind === "units" ? (
                    <span className="inline-flex items-center rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
                      Applied automatically
                    </span>
                  ) : null}
                </div>
                <p className="text-sm text-muted-foreground">{req.message}</p>
                {req.responseNote ? (
                  <p className="text-xs italic text-muted-foreground">
                    Hotel note: {req.responseNote}
                  </p>
                ) : null}
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(req.createdAt), { addSuffix: true })}
                </span>
                {req.status === "pending_hotel" && req.hotelContactEmail ? (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-xs"
                    disabled={resendingId === req._id}
                    onClick={() => handleResend(req)}
                  >
                    {resendingId === req._id ? (
                      <Loader2 className="size-3.5 animate-spin" />
                    ) : (
                      <Send className="size-3.5" />
                    )}
                    Resend to hotel
                  </Button>
                ) : null}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
