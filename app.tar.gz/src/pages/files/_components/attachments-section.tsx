import { useRef, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import {
  Download,
  FileArchive,
  FileImage,
  FileSpreadsheet,
  FileText,
  FileType,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { format } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";

// ── Helpers ───────────────────────────────────────────────────────────────────

const ACCEPTED = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
].join(",");

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function FileIcon({ contentType }: { contentType: string }) {
  if (contentType === "application/pdf") return <FileText className="size-5 text-red-500" />;
  if (contentType.startsWith("image/")) return <FileImage className="size-5 text-blue-500" />;
  if (contentType.includes("spreadsheet") || contentType.includes("excel"))
    return <FileSpreadsheet className="size-5 text-green-600" />;
  if (contentType.includes("word") || contentType.includes("document"))
    return <FileType className="size-5 text-blue-600" />;
  if (contentType.includes("zip") || contentType.includes("archive"))
    return <FileArchive className="size-5 text-amber-500" />;
  return <FileText className="size-5 text-muted-foreground" />;
}

// ── Main component ────────────────────────────────────────────────────────────

export default function AttachmentsSection({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const attachments = useQuery(api.attachments.listByFile, { groupFileId });
  const generateUploadUrl = useMutation(api.attachments.generateUploadUrl);
  const saveAttachment = useMutation(api.attachments.saveAttachment);
  const removeAttachment = useMutation(api.attachments.remove);

  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      // Step 1: get upload URL
      const uploadUrl = await generateUploadUrl({});

      // Step 2: POST file
      const response = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!response.ok) throw new Error("Upload failed");
      const { storageId } = (await response.json()) as { storageId: Id<"_storage"> };

      // Step 3: save metadata
      await saveAttachment({
        groupFileId,
        storageId,
        filename: file.name,
        contentType: file.type || "application/octet-stream",
        size: file.size,
      });

      toast.success(`"${file.name}" uploaded`);
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Upload failed. Please try again.";
      toast.error(msg);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const handleDelete = async (id: Id<"groupFileAttachments">, filename: string) => {
    try {
      await removeAttachment({ id });
      toast.success(`"${filename}" deleted`);
    } catch {
      toast.error("Could not delete attachment.");
    }
  };

  if (attachments === undefined) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-14 w-full" />
        <Skeleton className="h-14 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Upload trigger */}
      <div>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED}
          className="hidden"
          onChange={handleFileChange}
          disabled={uploading}
        />
        <Button
          variant="secondary"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
        >
          {uploading ? (
            <>
              <Spinner className="size-4" />
              Uploading…
            </>
          ) : (
            <>
              <Upload className="size-4" />
              Upload attachment
            </>
          )}
        </Button>
        <p className="mt-1.5 text-xs text-muted-foreground">
          PDF, Word, Excel, or image files accepted.
        </p>
      </div>

      {/* List */}
      {attachments.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <FileText />
            </EmptyMedia>
            <EmptyTitle>No attachments yet</EmptyTitle>
            <EmptyDescription>
              Upload contracts, briefs, visa letters, or any other documents for this file.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => inputRef.current?.click()}
              disabled={uploading}
            >
              <Upload className="size-4" />
              Upload first attachment
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="space-y-2">
          {attachments.map((a) => (
            <div
              key={a._id}
              className="flex items-center justify-between gap-3 rounded-lg border px-4 py-3"
            >
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-muted">
                  <FileIcon contentType={a.contentType} />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{a.filename}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatBytes(a.size)} · {format(new Date(a._creationTime), "d MMM yyyy")}
                  </p>
                </div>
              </div>

              <div className="flex shrink-0 gap-1.5">
                {a.url && (
                  <Button size="sm" variant="secondary" asChild>
                    <a href={a.url} download={a.filename} target="_blank" rel="noopener noreferrer">
                      <Download className="size-4" />
                      Download
                    </a>
                  </Button>
                )}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="ghost" aria-label="Delete attachment">
                      <Trash2 className="size-4 text-destructive" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete attachment?</AlertDialogTitle>
                      <AlertDialogDescription>
                        <span className="font-medium">{a.filename}</span> will be permanently
                        deleted. This cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDelete(a._id, a.filename)}>
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
