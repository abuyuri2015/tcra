import type { Control } from "react-hook-form";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import PercentStepper from "@/components/ui/percent-stepper.tsx";
import type { OfferFormValues } from "./offer-form-schema.ts";

/**
 * Quantity, unit label, cost, and sell rate fields for the single-item offer
 * form (used for non-hotel types and for editing an existing hotel offer
 * row). Hidden in multi-room-type hotel creation mode, which uses
 * OfferRoomTypeFields instead.
 */
export default function OfferQuantityFields({
  control,
  isHotel,
  markupPct,
  onMarkupChange,
}: {
  control: Control<OfferFormValues>;
  isHotel: boolean;
  markupPct: number;
  onMarkupChange: (next: number) => void;
}) {
  return (
    <>
      <FormField
        control={control}
        name="units"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Quantity</FormLabel>
            <FormControl>
              <Input type="number" min={1} {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="unitLabel"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Unit label</FormLabel>
            <FormControl>
              <Input placeholder={isHotel ? "rooms" : "pax"} {...field} />
            </FormControl>
            <FormDescription>e.g. rooms, pax, seats</FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="costPerUnit"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Cost per unit</FormLabel>
            <FormControl>
              <Input type="number" min={0} step="0.01" placeholder="0.00" {...field} />
            </FormControl>
            <FormDescription>What the supplier quoted you</FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="ratePerUnit"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Rate per unit (sell)</FormLabel>
            <div className="flex items-center gap-2">
              <FormControl>
                <Input
                  type="number"
                  min={0}
                  step="0.01"
                  placeholder="0.00"
                  className="flex-1"
                  {...field}
                />
              </FormControl>
              <PercentStepper
                value={markupPct}
                onChange={onMarkupChange}
                size="sm"
                className="w-28 shrink-0"
              />
            </div>
            <FormDescription>
              Nudge the markup % to recalculate the rate from the cost per unit
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
    </>
  );
}
