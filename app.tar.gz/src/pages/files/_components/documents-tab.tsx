import { useState } from "react";
import { useQuery, useAction } from "convex/react";
import {
  Download,
  FileText,
  Receipt,
  BedDouble,
  Bus,
  UtensilsCrossed,
  Sunset,
  Building,
  Plane,
  Package,
  Mail,
  Send,
  ClipboardList,
  Paperclip,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { formatDate, formatDateRange } from "@/lib/dates.ts";
import {
  formatMoney,
  reservationTypeLabel,
  RESERVATION_STATUS_STYLES,
  reservationStatusLabel,
} from "@/lib/domain.ts";
import { generateVoucherPDF, generateInvoicePDF, generateQuotePDF } from "@/lib/pdf-generators.ts";
import SendVoucherDialog from "./send-voucher-dialog.tsx";
import SendInvoiceDialog from "./send-invoice-dialog.tsx";
import SendQuoteDialog from "./send-quote-dialog.tsx";
import AttachmentsSection from "./attachments-section.tsx";
import type { ReservationType } from "@/lib/domain.ts";
import { useEffect } from "react";

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type Reservation = Doc<"reservations">;
type FinanceLine = Doc<"financeLines"> & { amountInBase: number };
type ItineraryDay = Doc<"itineraryDays"> & { items: Doc<"itineraryItems">[] };
type SenderIdentity = { id: string; value: string; type: string; status: string };

const TYPE_ICONS: Record<ReservationType, typeof BedDouble> = {
  hotel: BedDouble,
  transfer: Bus,
  restaurant: UtensilsCrossed,
  activity: Sunset,
  venue: Building,
  flight: Plane,
  other: Package,
};

// ── Quote section ─────────────────────────────────────────────────────────────

function QuoteSection({
  file,
  financeLines,
  itineraryDays,
  senderIdentities,
}: {
  file: GroupFile;
  financeLines: FinanceLine[];
  itineraryDays: ItineraryDay[];
  senderIdentities: SenderIdentity[];
}) {
  const [loading, setLoading] = useState(false);
  const [coverMessage, setCoverMessage] = useState("");
  const quoteNumber = `QUO-${file.reference}-001`;
  const incomeLines = financeLines.filter((l) => l.kind === "income");
  const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);

  const defaultCover = `Dear ${file.clientContactName ?? file.clientName},

Please find our quote for the following programme:

Group: ${file.title}
Reference: ${file.reference}
Total value: ${formatMoney(totalEur, "EUR")}

We would be delighted to discuss this proposal further. Please do not hesitate to contact us with any questions.

Kind regards,
${file.ownerName ?? "Tessera Groups & MICE Team"}`;

  // Initialise once
  useEffect(() => {
    if (!coverMessage) setCoverMessage(defaultCover);
  }, []);

  const handleDownload = () => {
    setLoading(true);
    try {
      generateQuotePDF(file, financeLines, itineraryDays, coverMessage, quoteNumber);
      toast.success("Quote PDF downloaded");
    } catch {
      toast.error("Could not generate quote PDF.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Quote summary */}
      <div className="rounded-lg border p-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Quote number</p>
            <p className="font-mono text-sm font-semibold">{quoteNumber}</p>
            <p className="text-xs text-muted-foreground">
              {file.pax} pax · {file.destination} · {formatDateRange(file.startDate, file.endDate)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Total value</p>
            {incomeLines.length > 0 ? (
              <p className="font-display text-2xl font-bold text-chart-3">
                {formatMoney(totalEur, "EUR")}
              </p>
            ) : (
              <p className="text-sm text-muted-foreground">No income lines yet</p>
            )}
            {itineraryDays.length > 0 && (
              <p className="text-xs text-muted-foreground">
                {itineraryDays.length} itinerary day{itineraryDays.length !== 1 ? "s" : ""} included
              </p>
            )}
          </div>
        </div>

        {incomeLines.length > 0 && (
          <>
            <Separator className="my-3" />
            <div className="space-y-1">
              {incomeLines.map((l) => (
                <div key={l._id} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{l.description}</span>
                  <span className="font-medium tabular-nums">
                    {formatMoney(l.amount, l.currency)}
                    {l.currency !== "EUR" && (
                      <span className="ml-1 text-xs text-muted-foreground">
                        ≈ {formatMoney(l.amountInBase, "EUR")}
                      </span>
                    )}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Cover message editor */}
      <div className="space-y-1.5">
        <label className="text-sm font-medium">Cover message (appears in PDF)</label>
        <textarea
          className="w-full resize-none rounded-md border bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          rows={6}
          value={coverMessage}
          onChange={(e) => setCoverMessage(e.target.value)}
        />
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-2">
        <Button onClick={handleDownload} disabled={loading}>
          <Download className="size-4" />
          {loading ? "Generating…" : "Download quote PDF"}
        </Button>
        <SendQuoteDialog
          file={file}
          financeLines={financeLines}
          itineraryDays={itineraryDays}
          quoteNumber={quoteNumber}
          senderIdentities={senderIdentities}
          trigger={
            <Button variant="secondary">
              <Send className="size-4" />
              Email quote to client
            </Button>
          }
        />
      </div>
    </div>
  );
}

// ── Voucher row ───────────────────────────────────────────────────────────────

function VoucherRow({
  reservation,
  file,
  senderIdentities,
}: {
  reservation: Reservation;
  file: GroupFile;
  senderIdentities: SenderIdentity[];
}) {
  const [loading, setLoading] = useState(false);
  const Icon = TYPE_ICONS[reservation.type] ?? Package;

  const handleDownload = async () => {
    setLoading(true);
    try {
      generateVoucherPDF(file, reservation);
      toast.success("Voucher downloaded");
    } catch {
      toast.error("Could not generate voucher.");
    } finally {
      setLoading(false);
    }
  };

  const dateLabel =
    reservation.type === "hotel" && reservation.nights !== undefined
      ? `${formatDate(reservation.startDate)} · ${reservation.nights}n`
      : formatDate(reservation.startDate);

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border px-4 py-3">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
          <Icon className="size-4 text-muted-foreground" />
        </div>
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">{reservation.supplierName}</span>
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                RESERVATION_STATUS_STYLES[reservation.status],
              )}
            >
              {reservationStatusLabel(reservation.status)}
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            {reservationTypeLabel(reservation.type)} · {reservation.description} · {dateLabel}
          </p>
        </div>
      </div>
      <div className="flex shrink-0 flex-wrap gap-2">
        <Button
          size="sm"
          variant="secondary"
          onClick={handleDownload}
          disabled={loading}
        >
          <Download className="size-4" />
          {loading ? "Generating…" : "PDF"}
        </Button>
        <SendVoucherDialog
          file={file}
          reservation={reservation}
          senderIdentities={senderIdentities}
          trigger={
            <Button size="sm" variant="secondary">
              <Mail className="size-4" />
              Email
            </Button>
          }
        />
      </div>
    </div>
  );
}

// ── Invoice section ───────────────────────────────────────────────────────────

function InvoiceSection({
  file,
  incomeLines,
  senderIdentities,
}: {
  file: GroupFile;
  incomeLines: FinanceLine[];
  senderIdentities: SenderIdentity[];
}) {
  const [loading, setLoading] = useState(false);
  const invoiceNumber = `INV-${file.reference.replace(/^GM-/, "")}`;
  const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);

  const handleDownload = async () => {
    setLoading(true);
    try {
      generateInvoicePDF(file, incomeLines, invoiceNumber);
      toast.success("Invoice downloaded");
    } catch {
      toast.error("Could not generate invoice.");
    } finally {
      setLoading(false);
    }
  };

  if (incomeLines.length === 0) {
    return (
      <Empty>
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <Receipt />
          </EmptyMedia>
          <EmptyTitle>No income lines yet</EmptyTitle>
          <EmptyDescription>
            Add income lines in the Cost &amp; income tab to generate an invoice.
          </EmptyDescription>
        </EmptyHeader>
      </Empty>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-lg border p-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Invoice</p>
            <p className="font-mono text-sm font-semibold">{invoiceNumber}</p>
            <p className="text-xs text-muted-foreground">
              {incomeLines.length} line{incomeLines.length !== 1 ? "s" : ""}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Total due</p>
            <p className="font-display text-2xl font-bold text-chart-3">
              {formatMoney(totalEur, "EUR")}
            </p>
            <p className="text-xs text-muted-foreground">all amounts converted to EUR</p>
          </div>
        </div>
        <Separator className="my-3" />
        <div className="space-y-1">
          {incomeLines.map((l) => (
            <div key={l._id} className="flex justify-between text-sm">
              <span className="text-muted-foreground">{l.description}</span>
              <span className="font-medium tabular-nums">
                {formatMoney(l.amount, l.currency)}
                {l.currency !== "EUR" && (
                  <span className="ml-1 text-xs text-muted-foreground">
                    ≈ {formatMoney(l.amountInBase, "EUR")}
                  </span>
                )}
              </span>
            </div>
          ))}
        </div>
      </div>
      <Button onClick={handleDownload} disabled={loading} className="w-full sm:w-auto">
        <Download className="size-4" />
        {loading ? "Generating…" : "Download PDF"}
      </Button>
      <SendInvoiceDialog
        file={file}
        incomeLines={incomeLines}
        invoiceNumber={invoiceNumber}
        senderIdentities={senderIdentities}
        trigger={
          <Button variant="secondary" className="w-full sm:w-auto">
            <Send className="size-4" />
            Email to client
          </Button>
        }
      />
    </div>
  );
}

// ── Main tab ──────────────────────────────────────────────────────────────────

export default function DocumentsTab({
  groupFileId,
  file,
}: {
  groupFileId: Id<"groupFiles">;
  file: GroupFile;
}) {
  const reservations = useQuery(api.reservations.listByFile, { groupFileId });
  const financeLines = useQuery(api.financeLines.listByFile, { groupFileId });
  const itineraryDays = useQuery(api.itinerary.listByFile, { groupFileId });
  const listIdentities = useAction(api.email.identities.list);
  const [senderIdentities, setSenderIdentities] = useState<SenderIdentity[]>([]);

  useEffect(() => {
    listIdentities({}).then(setSenderIdentities).catch(() => setSenderIdentities([]));
  }, []);

  if (reservations === undefined || financeLines === undefined || itineraryDays === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const incomeLines = financeLines.filter((l) => l.kind === "income");
  const activeReservations = reservations.filter((r) => r.status !== "cancelled");

  return (
    <div className="space-y-6">
      {/* ── Quote ────────────────────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display flex items-center gap-2 text-base">
            <ClipboardList className="size-4 text-muted-foreground" />
            Client quote
          </CardTitle>
          <CardDescription>
            Generate a branded quote PDF with itinerary overview and pricing for the client.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <QuoteSection
            file={file}
            financeLines={financeLines}
            itineraryDays={itineraryDays}
            senderIdentities={senderIdentities}
          />
        </CardContent>
      </Card>

      {/* ── Vouchers ─────────────────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display flex items-center gap-2 text-base">
            <FileText className="size-4 text-muted-foreground" />
            Supplier vouchers
          </CardTitle>
          <CardDescription>
            Download or email a service voucher PDF for each reservation.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {activeReservations.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <FileText />
                </EmptyMedia>
                <EmptyTitle>No active reservations</EmptyTitle>
                <EmptyDescription>
                  Add reservations in the Reservations tab to generate vouchers.
                </EmptyDescription>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="space-y-2">
              {activeReservations.map((r) => (
                <VoucherRow
                  key={r._id}
                  reservation={r}
                  file={file}
                  senderIdentities={senderIdentities}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Invoice ──────────────────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display flex items-center gap-2 text-base">
            <Receipt className="size-4 text-muted-foreground" />
            Client invoice
          </CardTitle>
          <CardDescription>
            Generate a PDF invoice from the income lines for this file.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <InvoiceSection file={file} incomeLines={incomeLines} senderIdentities={senderIdentities} />
        </CardContent>
      </Card>

      {/* ── Attachments ──────────────────────────────────────────────── */}
      <Card>
        <CardHeader>
          <CardTitle className="font-display flex items-center gap-2 text-base">
            <Paperclip className="size-4 text-muted-foreground" />
            Attachments
          </CardTitle>
          <CardDescription>
            Store contracts, client briefs, visa letters, and other documents for this file.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <AttachmentsSection groupFileId={groupFileId} />
        </CardContent>
      </Card>
    </div>
  );
}
