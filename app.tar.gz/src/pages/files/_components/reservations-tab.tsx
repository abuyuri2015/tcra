import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import {
  BedDouble,
  Building,
  Bus,
  ClipboardList,
  Download,
  Lock,
  MessageSquarePlus,
  Package,
  Pencil,
  Plane,
  Plus,
  Sunset,
  Trash2,
  UtensilsCrossed,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import ReservationFormDialog from "./reservation-form-dialog.tsx";
import ReservationManifestDialog from "./reservation-manifest-dialog.tsx";
import ModificationRequestsPanel from "./modification-requests-panel.tsx";
import StaffRequestChangeDialog from "./staff-request-change-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import {
  RESERVATION_STATUS_OPTIONS,
  RESERVATION_STATUS_STYLES,
  boardLabel,
  formatMoney,
  reservationStatusLabel,
  reservationTypeLabel,
} from "@/lib/domain.ts";
import { formatDate, isoToDateInput } from "@/lib/dates.ts";
import { generateVoucherPDF } from "@/lib/pdf-generators.ts";
import type { ReservationStatus, ReservationType } from "@/lib/domain.ts";

const TYPE_ICONS: Record<ReservationType, typeof BedDouble> = {
  hotel: BedDouble,
  transfer: Bus,
  restaurant: UtensilsCrossed,
  activity: Sunset,
  venue: Building,
  flight: Plane,
  other: Package,
};

function ReservationCard({
  res,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
  file,
  locked,
}: {
  res: Doc<"reservations">;
  fileCurrency: string;
  fileStartDate?: string;
  fileEndDate?: string;
  fileMarkupPercent?: number;
  file?: Doc<"groupFiles"> & { ownerName: string | null };
  locked: boolean;
}) {
  const [downloading, setDownloading] = useState(false);
  const setStatus = useMutation(api.reservations.setStatus);
  const remove = useMutation(api.reservations.remove);
  const Icon = TYPE_ICONS[res.type] ?? Package;

  const handleStatus = async (value: string) => {
    try {
      await setStatus({
        id: res._id,
        status: value as ReservationStatus,
        appOrigin: window.location.origin,
      });
      if (value === "confirmed") {
        toast.success("Status updated.");
      }
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update status.";
      toast.error(message);
    }
  };

  const handleDelete = async () => {
    try {
      await remove({ id: res._id });
      toast.success("Reservation removed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not remove reservation.";
      toast.error(message);
    }
  };

  const handleDownloadVoucher = () => {
    if (!file) return;
    setDownloading(true);
    try {
      generateVoucherPDF(file, res);
      toast.success("Voucher downloaded");
    } catch {
      toast.error("Could not generate voucher.");
    } finally {
      setDownloading(false);
    }
  };

  const total =
    res.ratePerUnit !== undefined ? res.ratePerUnit * res.units : undefined;
  const totalCost =
    res.costPerUnit !== undefined ? res.costPerUnit * res.units : undefined;
  const margin =
    total !== undefined && totalCost !== undefined ? total - totalCost : undefined;

  const dateLabel = (() => {
    if (res.type === "hotel" && res.nights !== undefined) {
      return `${formatDate(res.startDate)} · ${res.nights} night${res.nights > 1 ? "s" : ""}`;
    }
    if (res.endDate) {
      return `${formatDate(res.startDate)} – ${formatDate(res.endDate)}`;
    }
    return formatDate(res.startDate);
  })();

  return (
    <div className="flex flex-wrap items-start justify-between gap-3 rounded-lg border px-4 py-3">
      {/* Left: icon + details */}
      <div className="flex min-w-0 gap-3">
        <div className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
          <Icon className="size-4 text-muted-foreground" />
        </div>
        <div className="min-w-0 space-y-0.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">{res.supplierName}</span>
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                RESERVATION_STATUS_STYLES[res.status],
              )}
            >
              {reservationStatusLabel(res.status)}
            </span>
            {locked ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-destructive/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-destructive">
                <Lock className="size-2.5" />
                Locked
              </span>
            ) : null}
          </div>
          <p className="text-sm text-muted-foreground">{res.description}</p>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
            <span>{dateLabel}</span>
            <span>
              {res.units} {res.unitLabel || (res.type === "hotel" ? "rooms" : "pax")}
            </span>
            {res.board ? <span>{boardLabel(res.board)}</span> : null}
            {res.supplierRef ? (
              <span className="font-mono">{res.supplierRef}</span>
            ) : null}
          </div>
          {res.notes ? (
            <p className="text-xs text-muted-foreground italic">{res.notes}</p>
          ) : null}
        </div>
      </div>

      {/* Right: rate + actions */}
      <div className="flex shrink-0 items-start gap-2">
        {total !== undefined ? (
          <div className="text-right">
            <p className="text-sm font-semibold">
              {formatMoney(total, res.currency)}
            </p>
            <p className="text-xs text-muted-foreground">
              {formatMoney(res.ratePerUnit!, res.currency)} ×{res.units}
            </p>
            {margin !== undefined ? (
              <p
                className={cn(
                  "text-xs font-medium",
                  margin >= 0 ? "text-chart-3" : "text-destructive",
                )}
              >
                Margin {formatMoney(margin, res.currency)}
              </p>
            ) : null}
          </div>
        ) : null}

        <Select
          value={res.status}
          onValueChange={handleStatus}
          disabled={locked || res.status === "confirmed"}
        >
          <SelectTrigger className="h-7 w-28 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {RESERVATION_STATUS_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value} className="text-xs">
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {file && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-7"
                aria-label="Download voucher"
                disabled={downloading}
                onClick={handleDownloadVoucher}
              >
                <Download className="size-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Download voucher PDF</TooltipContent>
          </Tooltip>
        )}

        {file && (res.type === "transfer" || res.type === "activity") ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <ReservationManifestDialog
                reservation={res}
                fileReference={file.reference}
                fileTitle={file.title}
                locked={locked}
                trigger={
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-7"
                    aria-label="Pickup, guide & manifest"
                  >
                    <ClipboardList className="size-3.5" />
                  </Button>
                }
              />
            </TooltipTrigger>
            <TooltipContent>Pickup, guide & manifest</TooltipContent>
          </Tooltip>
        ) : null}

        {res.status === "confirmed" ? (
          <StaffRequestChangeDialog
            groupFileId={res.groupFileId}
            reservation={res}
            trigger={
              <Button
                variant="ghost"
                size="icon"
                className="size-7"
                aria-label="Request a change"
                disabled={locked}
              >
                <MessageSquarePlus className="size-3.5" />
              </Button>
            }
          />
        ) : (
          <ReservationFormDialog
            groupFileId={res.groupFileId}
            fileCurrency={fileCurrency}
            fileStartDate={fileStartDate}
            fileEndDate={fileEndDate}
            fileMarkupPercent={fileMarkupPercent}
            reservation={res}
            trigger={
              <Button variant="ghost" size="icon" className="size-7" aria-label="Edit" disabled={locked}>
                <Pencil className="size-3.5" />
              </Button>
            }
          />
        )}

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-7"
              aria-label="Remove"
              disabled={locked || res.status === "confirmed"}
            >
              <Trash2 className="size-3.5 text-destructive" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Remove this reservation?</AlertDialogTitle>
              <AlertDialogDescription>
                {res.supplierName} — {res.description} will be permanently
                removed from this file.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete}>Remove</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

/** Groups reservations by service type and renders one section per type */
function GroupedReservations({
  reservations,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
  file,
  locked,
}: {
  reservations: Doc<"reservations">[];
  fileCurrency: string;
  fileStartDate?: string;
  fileEndDate?: string;
  fileMarkupPercent?: number;
  groupFileId: Id<"groupFiles">;
  file?: Doc<"groupFiles"> & { ownerName: string | null };
  locked: boolean;
}) {
  const order: ReservationType[] = [
    "hotel",
    "flight",
    "transfer",
    "venue",
    "restaurant",
    "activity",
    "other",
  ];

  const byType = order.reduce<Partial<Record<ReservationType, Doc<"reservations">[]>>>(
    (acc, t) => {
      const items = reservations.filter((r) => r.type === t);
      if (items.length > 0) acc[t] = items;
      return acc;
    },
    {},
  );

  return (
    <div className="space-y-6">
      {(Object.entries(byType) as [ReservationType, Doc<"reservations">[]][]).map(
        ([type, items]) => {
          const Icon = TYPE_ICONS[type] ?? Package;
          const label = reservationTypeLabel(type);
          return (
            <div key={type}>
              <div className="mb-2 flex items-center gap-2">
                <Icon className="size-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  {label}
                </h3>
                <span className="rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                  {items.length}
                </span>
              </div>
              <div className="space-y-2">
                {items.map((res) => (
                  <ReservationCard
                    key={res._id}
                    res={res}
                    fileCurrency={fileCurrency}
                    fileStartDate={fileStartDate}
                    fileEndDate={fileEndDate}
                    fileMarkupPercent={fileMarkupPercent}
                    file={file}
                    locked={locked}
                  />
                ))}
              </div>
            </div>
          );
        },
      )}
    </div>
  );
}

export default function ReservationsTab({
  groupFileId,
  fileCurrency,
  file,
}: {
  groupFileId: Id<"groupFiles">;
  fileCurrency: string;
  file?: Doc<"groupFiles"> & { ownerName: string | null };
}) {
  const reservations = useQuery(api.reservations.listByFile, { groupFileId });
  const fileStartDate = file ? isoToDateInput(file.startDate) : undefined;
  const fileEndDate = file ? isoToDateInput(file.endDate) : undefined;
  const fileMarkupPercent = file?.markupPercent;
  const locked = file?.financeLocked === true;

  if (reservations === undefined) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <CardTitle className="font-display text-base">Reservations</CardTitle>
        <ReservationFormDialog
          groupFileId={groupFileId}
          fileCurrency={fileCurrency}
          fileStartDate={fileStartDate}
          fileEndDate={fileEndDate}
          fileMarkupPercent={fileMarkupPercent}
          trigger={
            <Button size="sm">
              <Plus className="size-4" />
              Add reservation
            </Button>
          }
        />
      </CardHeader>
      <CardContent className="space-y-6">
        {locked ? (
          <div className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
            <Lock className="size-4 shrink-0" />
            This file is closed for full payment. Existing reservations are
            locked — add a new item or a credit note under Cost &amp; income
            instead.
          </div>
        ) : null}
        <ModificationRequestsPanel groupFileId={groupFileId} />
        {reservations.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <BedDouble />
              </EmptyMedia>
              <EmptyTitle>No reservations yet</EmptyTitle>
              <EmptyDescription>
                Add hotels, transfers, activities and any other services for
                this group.
              </EmptyDescription>
            </EmptyHeader>
            <EmptyContent>
              <ReservationFormDialog
                groupFileId={groupFileId}
                fileCurrency={fileCurrency}
                fileStartDate={fileStartDate}
                fileEndDate={fileEndDate}
                fileMarkupPercent={fileMarkupPercent}
                trigger={
                  <Button size="sm">
                    <Plus className="size-4" />
                    Add reservation
                  </Button>
                }
              />
            </EmptyContent>
          </Empty>
        ) : (
          <GroupedReservations
            reservations={reservations}
            fileCurrency={fileCurrency}
            fileStartDate={fileStartDate}
            fileEndDate={fileEndDate}
            fileMarkupPercent={fileMarkupPercent}
            groupFileId={groupFileId}
            file={file}
            locked={locked}
          />
        )}
      </CardContent>
    </Card>
  );
}
