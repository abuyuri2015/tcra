import { useState } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { ConvexError } from "convex/values";
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  CalendarCheck,
  Download,
  FileDown,
  Lock,
  LockOpen,
  Pencil,
  Plus,
  Trash2,
  TrendingUp,
} from "lucide-react";
import { toast } from "sonner";
import { useEffect } from "react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import FinanceLineFormDialog from "./finance-line-form-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover.tsx";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { cn } from "@/lib/utils.ts";
import { formatDate, dateInputToIso, isoToDateInput } from "@/lib/dates.ts";
import {
  costCategoryLabel,
  financeLineBreakdown,
  formatMoney,
  incomeCategoryLabel,
} from "@/lib/domain.ts";
import { downloadCsv } from "@/lib/csv-export.ts";
import { generateInvoicePDF } from "@/lib/pdf-generators.ts";
import PaymentScheduleCard from "./payment-schedule-card.tsx";
import InvoicePaidControl from "./invoice-paid-control.tsx";
import ResendInvoiceButton from "./resend-invoice-button.tsx";

type FinanceLine = {
  _id: Id<"financeLines">;
  _creationTime: number;
  groupFileId: Id<"groupFiles">;
  kind: "cost" | "income";
  category: string;
  description: string;
  supplierName?: string;
  amount: number;
  currency: string;
  exchangeRateToBase: number;
  unitRate?: number;
  quantity?: number;
  quantityLabel?: string;
  notes?: string;
  createdById: Id<"users">;
  paidAt?: string;
  paymentDueDate?: string;
  amountInBase: number;
};

function SummaryCards({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const summary = useQuery(api.financeLines.summaryByFile, { groupFileId });

  if (!summary) {
    return (
      <div className="grid gap-3 sm:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  const { totalCostEur, totalIncomeEur, marginEur, marginPct } = summary;

  const stats = [
    {
      label: "Total income",
      value: formatMoney(totalIncomeEur, "EUR"),
      icon: ArrowDownToLine,
      color: "text-chart-3",
      bg: "bg-chart-3/10",
    },
    {
      label: "Total cost",
      value: formatMoney(totalCostEur, "EUR"),
      icon: ArrowUpFromLine,
      color: "text-destructive",
      bg: "bg-destructive/10",
    },
    {
      label: "Margin",
      value: formatMoney(marginEur, "EUR"),
      sub:
        marginPct !== null
          ? `${marginPct.toFixed(1)}%`
          : "–",
      icon: TrendingUp,
      color: marginEur >= 0 ? "text-chart-3" : "text-destructive",
      bg: marginEur >= 0 ? "bg-chart-3/10" : "bg-destructive/10",
    },
  ];

  return (
    <div className="grid gap-3 sm:grid-cols-3">
      {stats.map((s) => {
        const Icon = s.icon;
        return (
          <Card key={s.label} className="gap-2 p-4">
            <div className={cn("flex items-center gap-2 text-xs font-medium uppercase tracking-wide", s.color)}>
              <span className={cn("flex size-6 items-center justify-center rounded-md", s.bg)}>
                <Icon className="size-3.5" />
              </span>
              {s.label}
            </div>
            <p className={cn("font-display text-xl font-semibold", s.color)}>
              {s.value}
            </p>
            {s.sub ? (
              <p className="text-xs text-muted-foreground">{s.sub} margin</p>
            ) : null}
          </Card>
        );
      })}
    </div>
  );
}

function CurrencyBreakdown({
  groupFileId,
}: {
  groupFileId: Id<"groupFiles">;
}) {
  const summary = useQuery(api.financeLines.summaryByFile, { groupFileId });
  if (!summary) return null;

  const { totalCostByCurrency, totalIncomeByCurrency } = summary;
  const allCurrencies = Array.from(
    new Set([
      ...Object.keys(totalCostByCurrency),
      ...Object.keys(totalIncomeByCurrency),
    ]),
  ).sort();

  if (allCurrencies.length <= 1) return null;

  return (
    <div className="rounded-lg border">
      <div className="border-b px-4 py-2.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        By original currency
      </div>
      <div className="divide-y">
        {allCurrencies.map((cur) => (
          <div
            key={cur}
            className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 text-sm"
          >
            <span className="font-medium">{cur}</span>
            <div className="flex gap-6">
              {totalIncomeByCurrency[cur] ? (
                <span className="text-chart-3">
                  +{formatMoney(totalIncomeByCurrency[cur], cur)}
                </span>
              ) : null}
              {totalCostByCurrency[cur] ? (
                <span className="text-destructive">
                  −{formatMoney(totalCostByCurrency[cur], cur)}
                </span>
              ) : null}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FinanceLockToggle({
  file,
}: {
  file: Doc<"groupFiles"> & { ownerName: string | null };
}) {
  const setLocked = useMutation(api.groupFiles.setFinanceLocked);
  const [submitting, setSubmitting] = useState(false);
  const locked = file.financeLocked === true;

  const handleToggle = async () => {
    setSubmitting(true);
    try {
      await setLocked({ id: file._id, locked: !locked });
      toast.success(
        locked
          ? "File reopened — reservations can be edited again"
          : "File closed for full payment — reservations are now locked",
      );
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update the lock.";
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className={cn(
        "flex flex-wrap items-center justify-between gap-3 rounded-lg border px-4 py-3",
        locked ? "border-destructive/30 bg-destructive/5" : "bg-muted/30",
      )}
    >
      <div className="flex items-center gap-2">
        {locked ? (
          <Lock className="size-4 text-destructive" />
        ) : (
          <LockOpen className="size-4 text-muted-foreground" />
        )}
        <div>
          <p className="text-sm font-medium">
            {locked ? "Closed for full payment" : "Open for changes"}
          </p>
          <p className="text-xs text-muted-foreground">
            {locked
              ? "Reservations are locked. You can still add new items or record a credit note."
              : "Close this file once full payment is in/out to lock existing reservations."}
          </p>
        </div>
      </div>
      <Button
        variant={locked ? "secondary" : "destructive"}
        size="sm"
        onClick={handleToggle}
        disabled={submitting}
      >
        {locked ? (
          <>
            <LockOpen className="size-4" />
            Reopen
          </>
        ) : (
          <>
            <Lock className="size-4" />
            Close for full payment
          </>
        )}
      </Button>
    </div>
  );
}

/** Payment status control for cost lines — paid to the supplier/hotel, tracked per line. */
function PaymentStatusControl({ line }: { line: FinanceLine }) {
  const setPaid = useMutation(api.financeLines.setPaid);
  const [submitting, setSubmitting] = useState(false);
  const [dateOpen, setDateOpen] = useState(false);
  const isPaid = line.paidAt !== undefined;
  const label = "Paid to supplier";
  const isOverdue =
    !isPaid && line.paymentDueDate !== undefined && line.paymentDueDate < new Date().toISOString();

  const handleToggle = async (checked: boolean) => {
    setSubmitting(true);
    try {
      await setPaid({ id: line._id, paid: checked });
      toast.success(checked ? `Marked as ${label.toLowerCase()}` : "Marked as unpaid");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update payment status.";
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDateChange = async (value: string) => {
    if (!value) return;
    setSubmitting(true);
    try {
      await setPaid({ id: line._id, paid: true, paidAt: dateInputToIso(value) });
      setDateOpen(false);
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not update payment date.";
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Checkbox
        checked={isPaid}
        disabled={submitting}
        onCheckedChange={(checked) => handleToggle(checked === true)}
        aria-label={label}
      />
      {isPaid && line.paidAt ? (
        <Popover open={dateOpen} onOpenChange={setDateOpen}>
          <PopoverTrigger asChild>
            <button
              type="button"
              className="flex items-center gap-1 text-xs font-medium text-chart-3 hover:underline"
            >
              <CalendarCheck className="size-3.5" />
              {label} {formatDate(line.paidAt)}
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-auto space-y-2 p-3">
            <p className="text-xs font-medium text-muted-foreground">
              Payment date
            </p>
            <Input
              type="date"
              defaultValue={isoToDateInput(line.paidAt)}
              onChange={(e) => handleDateChange(e.target.value)}
              className="w-40"
            />
          </PopoverContent>
        </Popover>
      ) : (
        <span className="text-xs text-muted-foreground">{label}</span>
      )}
      {!isPaid && line.paymentDueDate ? (
        <span
          className={cn(
            "flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium",
            isOverdue
              ? "bg-destructive/10 text-destructive"
              : "bg-muted text-muted-foreground",
          )}
        >
          <CalendarCheck className="size-3" />
          {isOverdue ? "Overdue since" : "Due"} {formatDate(line.paymentDueDate)}
        </span>
      ) : null}
    </div>
  );
}

function LineRow({
  line,
  fileCurrency,
  fileExchangeRate,
}: {
  line: FinanceLine;
  fileCurrency: string;
  fileExchangeRate: number;
}) {
  const remove = useMutation(api.financeLines.remove);
  const isCost = line.kind === "cost";
  const categoryLabel = isCost
    ? costCategoryLabel(line.category)
    : incomeCategoryLabel(line.category);

  const handleDelete = async () => {
    try {
      await remove({ id: line._id });
      toast.success("Line removed");
    } catch (error) {
      const message =
        error instanceof ConvexError
          ? (error.data as { message: string }).message
          : "Could not remove line.";
      toast.error(message);
    }
  };

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border px-4 py-3">
      <div className="min-w-0 space-y-0.5">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              isCost
                ? "bg-destructive/10 text-destructive"
                : "bg-chart-3/15 text-chart-3",
            )}
          >
            {categoryLabel}
          </span>
          {line.supplierName ? (
            <span className="text-sm font-medium">{line.supplierName}</span>
          ) : null}
        </div>
        <p className="text-sm text-muted-foreground">{line.description}</p>
        {financeLineBreakdown(line) ? (
          <p className="text-xs font-medium text-foreground/80">
            {financeLineBreakdown(line)} = {formatMoney(line.amount, line.currency)}
          </p>
        ) : null}
        {line.notes ? (
          <p className="text-xs text-muted-foreground italic">{line.notes}</p>
        ) : null}
        {/* Client invoices are paid as a whole (see the invoice section above),
            so only cost lines (paid to supplier) get a per-line control here. */}
        {isCost ? <PaymentStatusControl line={line} /> : null}
      </div>

      <div className="flex shrink-0 items-center gap-3">
        <div className="text-right">
          <p
            className={cn(
              "text-sm font-semibold",
              isCost ? "text-destructive" : "text-chart-3",
            )}
          >
            {isCost ? "−" : "+"}
            {formatMoney(line.amount, line.currency)}
          </p>
          {line.currency !== "EUR" && (
            <p className="text-xs text-muted-foreground">
              ≈ {formatMoney(line.amountInBase, "EUR")}
            </p>
          )}
        </div>

        <FinanceLineFormDialog
          groupFileId={line.groupFileId}
          fileCurrency={fileCurrency}
          fileExchangeRate={fileExchangeRate}
          line={line}
          trigger={
            <Button
              variant="ghost"
              size="icon"
              className="size-7"
              aria-label="Edit"
            >
              <Pencil className="size-3.5" />
            </Button>
          }
        />

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-7"
              aria-label="Remove"
            >
              <Trash2 className="size-3.5 text-destructive" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Remove this line?</AlertDialogTitle>
              <AlertDialogDescription>
                {line.description} ({formatMoney(line.amount, line.currency)})
                will be permanently removed.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete}>Remove</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

function LineSection({
  kind,
  lines,
  groupFileId,
  fileCurrency,
  fileExchangeRate,
}: {
  kind: "cost" | "income";
  lines: FinanceLine[];
  groupFileId: Id<"groupFiles">;
  fileCurrency: string;
  fileExchangeRate: number;
}) {
  const isCost = kind === "cost";
  const Icon = isCost ? ArrowUpFromLine : ArrowDownToLine;
  const label = isCost ? "Costs" : "Income";

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <CardTitle className="font-display flex items-center gap-2 text-base">
          <Icon
            className={cn(
              "size-4",
              isCost ? "text-destructive" : "text-chart-3",
            )}
          />
          {label}
        </CardTitle>
        <FinanceLineFormDialog
          groupFileId={groupFileId}
          fileCurrency={fileCurrency}
          fileExchangeRate={fileExchangeRate}
          initialKind={kind}
          trigger={
            <Button size="sm" variant="secondary">
              <Plus className="size-4" />
              Add {isCost ? "cost" : "income"}
            </Button>
          }
        />
      </CardHeader>
      <CardContent>
        {lines.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted-foreground">
            No {kind} lines yet.
          </p>
        ) : (
          <div className="space-y-2">
            {lines.map((l) => (
              <LineRow
                key={l._id}
                line={l}
                fileCurrency={fileCurrency}
                fileExchangeRate={fileExchangeRate}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function FinanceTab({
  groupFileId,
  fileCurrency,
  fileExchangeRate,
  fileReference,
  file,
}: {
  groupFileId: Id<"groupFiles">;
  fileCurrency: string;
  fileExchangeRate: number;
  fileReference?: string;
  file?: Doc<"groupFiles"> & { ownerName: string | null };
}) {
  const [downloadingInvoice, setDownloadingInvoice] = useState(false);
  const lines = useQuery(api.financeLines.listByFile, { groupFileId });
  const emailLogs = useQuery(
    api.email.logs.listByFile,
    file ? { groupFileId: file._id } : "skip",
  );
  const listIdentities = useAction(api.email.identities.list);
  const [senderIdentities, setSenderIdentities] = useState<
    { id: string; value: string; type: string; status: string }[]
  >([]);

  useEffect(() => {
    listIdentities({}).then(setSenderIdentities).catch(() => setSenderIdentities([]));
  }, []);

  const handleExport = () => {
    if (!lines || lines.length === 0) return;
    const rows = lines.map((l) => ({
      Kind: l.kind,
      Category: l.kind === "cost" ? costCategoryLabel(l.category) : incomeCategoryLabel(l.category),
      Description: l.description,
      Supplier: l.supplierName ?? "",
      Amount: l.amount,
      Currency: l.currency,
      "Amount (EUR)": l.amountInBase,
      Paid: l.paidAt ? "Yes" : "No",
      "Paid date": l.paidAt ? formatDate(l.paidAt) : "",
      Notes: l.notes ?? "",
    }));
    const slug = fileReference ? fileReference.toLowerCase().replace(/[^a-z0-9]/g, "-") : "file";
    downloadCsv(rows, `finance-${slug}.csv`);
  };

  const handleDownloadInvoice = () => {
    if (!file || !lines) return;
    const incomeOnly = lines.filter((l) => l.kind === "income");
    if (incomeOnly.length === 0) {
      toast.error("No income lines to include in the invoice.");
      return;
    }
    setDownloadingInvoice(true);
    try {
      const invoiceNumber = `INV-${file.reference.replace(/^GM-/, "")}`;
      generateInvoicePDF(file, incomeOnly, invoiceNumber);
      toast.success("Invoice downloaded");
    } catch {
      toast.error("Could not generate invoice.");
    } finally {
      setDownloadingInvoice(false);
    }
  };

  if (lines === undefined) {
    return (
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const costLines = lines.filter((l) => l.kind === "cost");
  const incomeLines = lines.filter((l) => l.kind === "income");

  if (lines.length === 0) {
    return (
      <div className="space-y-4">
        {file && <FinanceLockToggle file={file} />}
        {file && (
          <PaymentScheduleCard groupFileId={groupFileId} file={file} totalIncomeEur={0} />
        )}
        <Card>
          <CardContent className="py-8">
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <TrendingUp />
                </EmptyMedia>
                <EmptyTitle>No finance lines yet</EmptyTitle>
                <EmptyDescription>
                  Track costs and income for this group file. All amounts are
                  converted to EUR for the margin calculation.
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent className="flex gap-2">
                <FinanceLineFormDialog
                  groupFileId={groupFileId}
                  fileCurrency={fileCurrency}
                  fileExchangeRate={fileExchangeRate}
                  initialKind="cost"
                  trigger={
                    <Button size="sm" variant="secondary">
                      <Plus className="size-4" />
                      Add cost
                    </Button>
                  }
                />
                <FinanceLineFormDialog
                  groupFileId={groupFileId}
                  fileCurrency={fileCurrency}
                  fileExchangeRate={fileExchangeRate}
                  initialKind="income"
                  trigger={
                    <Button size="sm">
                      <Plus className="size-4" />
                      Add income
                    </Button>
                  }
                />
              </EmptyContent>
            </Empty>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {file && <FinanceLockToggle file={file} />}
      {file && (
        <PaymentScheduleCard
          groupFileId={groupFileId}
          file={file}
          totalIncomeEur={incomeLines.reduce((s, l) => s + l.amountInBase, 0)}
        />
      )}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {file && incomeLines.length > 0 ? (
          <InvoicePaidControl groupFileId={groupFileId} incomeLines={incomeLines} />
        ) : (
          <div />
        )}
        <div className="flex items-center gap-2">
          {file && incomeLines.length > 0 && (
            <>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={handleDownloadInvoice}
                    disabled={downloadingInvoice}
                  >
                    <FileDown className="size-4" />
                    {downloadingInvoice ? "Generating…" : "Download invoice"}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Download client invoice PDF</TooltipContent>
              </Tooltip>
              {emailLogs?.some((l) => l.emailType === "invoice") && (
                <ResendInvoiceButton
                  file={file}
                  incomeLines={incomeLines}
                  invoiceNumber={`INV-${file.reference.replace(/^GM-/, "")}`}
                  senderIdentities={senderIdentities}
                />
              )}
            </>
          )}
          <Button variant="secondary" size="sm" onClick={handleExport}>
            <Download className="size-4" />
            Export CSV
          </Button>
        </div>
      </div>
      <SummaryCards groupFileId={groupFileId} />
      <CurrencyBreakdown groupFileId={groupFileId} />
      <LineSection
        kind="income"
        lines={incomeLines}
        groupFileId={groupFileId}
        fileCurrency={fileCurrency}
        fileExchangeRate={fileExchangeRate}
      />
      <LineSection
        kind="cost"
        lines={costLines}
        groupFileId={groupFileId}
        fileCurrency={fileCurrency}
        fileExchangeRate={fileExchangeRate}
      />
    </div>
  );
}
