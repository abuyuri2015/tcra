import { BedDouble } from "lucide-react";
import type { Doc } from "@/convex/_generated/dataModel";
import { OfferActionBar, OfferAmountSummary } from "./offer-actions.tsx";
import { cn } from "@/lib/utils.ts";
import { OFFER_STATUS_STYLES, boardLabel, offerStatusLabel } from "@/lib/domain.ts";
import { formatDate } from "@/lib/dates.ts";

/**
 * One room-type row inside a grouped hotel offer card. Each row is still its
 * own offer under the hood (own status/rate/actions), just displayed nested
 * under the shared hotel details above it.
 */
function RoomTypeRow({
  offer,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
}: {
  offer: Doc<"offers">;
  fileCurrency: string;
  fileStartDate?: string;
  fileEndDate?: string;
  fileMarkupPercent?: number;
}) {
  const isConverted = Boolean(offer.convertedReservationId);
  return (
    <div className="flex flex-wrap items-start justify-between gap-3 rounded-md bg-muted/40 px-3 py-2">
      <div className="min-w-0 space-y-0.5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium">{offer.description}</span>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              OFFER_STATUS_STYLES[offer.status],
            )}
          >
            {offerStatusLabel(offer.status)}
          </span>
          {isConverted ? (
            <span className="rounded-full bg-chart-2/15 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-chart-2">
              Booked
            </span>
          ) : null}
        </div>
        <p className="text-xs text-muted-foreground">
          {offer.units} {offer.unitLabel || "rooms"}
        </p>
        {offer.notes ? (
          <p className="text-xs text-muted-foreground italic">{offer.notes}</p>
        ) : null}
      </div>
      <div className="flex shrink-0 items-start gap-2">
        <OfferAmountSummary offer={offer} />
        <OfferActionBar
          offer={offer}
          fileCurrency={fileCurrency}
          fileStartDate={fileStartDate}
          fileEndDate={fileEndDate}
          fileMarkupPercent={fileMarkupPercent}
        />
      </div>
    </div>
  );
}

/**
 * Renders a hotel quote as one card: shared hotel details up top (name,
 * dates, board, reference) with every room type (single, double, Jr suite,
 * ...) nested underneath as its own row.
 */
export default function HotelOfferGroupCard({
  offers,
  fileCurrency,
  fileStartDate,
  fileEndDate,
  fileMarkupPercent,
}: {
  offers: Doc<"offers">[];
  fileCurrency: string;
  fileStartDate?: string;
  fileEndDate?: string;
  fileMarkupPercent?: number;
}) {
  const head = offers[0];
  const dateLabel =
    head.nights !== undefined
      ? `${formatDate(head.startDate)} · ${head.nights} night${head.nights > 1 ? "s" : ""}`
      : formatDate(head.startDate);

  return (
    <div className="space-y-2 rounded-lg border px-4 py-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
          <BedDouble className="size-4 text-muted-foreground" />
        </div>
        <span className="text-sm font-medium">{head.supplierName}</span>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
          <span>{dateLabel}</span>
          {head.board ? <span>{boardLabel(head.board)}</span> : null}
          {head.supplierRef ? <span className="font-mono">{head.supplierRef}</span> : null}
        </div>
        <span className="ml-auto rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
          {offers.length} room type{offers.length > 1 ? "s" : ""}
        </span>
      </div>
      <div className="space-y-1.5 pl-11">
        {offers.map((offer) => (
          <RoomTypeRow
            key={offer._id}
            offer={offer}
            fileCurrency={fileCurrency}
            fileStartDate={fileStartDate}
            fileEndDate={fileEndDate}
            fileMarkupPercent={fileMarkupPercent}
          />
        ))}
      </div>
    </div>
  );
}
