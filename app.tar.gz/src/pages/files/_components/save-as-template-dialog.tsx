import { useState } from "react";
import { useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ConvexError } from "convex/values";
import { Bookmark } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.js";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";

const schema = z.object({
  name: z.string().min(2, "Give the template a name"),
  description: z.string(),
  includeItinerary: z.boolean(),
  includeFinanceLines: z.boolean(),
});

type FormValues = z.infer<typeof schema>;

export default function SaveAsTemplateDialog({
  fileId,
  fileTitle,
  open,
  onOpenChange,
}: {
  fileId: Id<"groupFiles">;
  fileTitle: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const saveFromFile = useMutation(api.fileTemplates.saveFromFile);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: fileTitle,
      description: "",
      includeItinerary: true,
      includeFinanceLines: true,
    },
  });

  const handleOpenChange = (next: boolean) => {
    onOpenChange(next);
    if (next) {
      form.reset({
        name: fileTitle,
        description: "",
        includeItinerary: true,
        includeFinanceLines: true,
      });
    }
  };

  const onSubmit = async (values: FormValues) => {
    try {
      await saveFromFile({
        groupFileId: fileId,
        name: values.name.trim(),
        description: values.description.trim() || undefined,
        includeItinerary: values.includeItinerary,
        includeFinanceLines: values.includeFinanceLines,
      });
      toast.success("Template saved");
      handleOpenChange(false);
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not save template.";
      toast.error(msg);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <Bookmark className="size-5 text-primary" />
            Save as template
          </DialogTitle>
          <DialogDescription>
            Create a reusable template from{" "}
            <span className="font-medium text-foreground">{fileTitle}</span>.
            Future files can be pre-filled from this template.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Template name</FormLabel>
                  <FormControl>
                    <Input placeholder="Annual Sales Conference" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={2}
                      placeholder="Brief description of when to use this template"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-3">
              <p className="text-sm font-medium">Include in template</p>

              <div className="flex items-center gap-3 rounded-lg border p-3">
                <Checkbox
                  id="tpl-itinerary"
                  checked={form.watch("includeItinerary")}
                  onCheckedChange={(v) =>
                    form.setValue("includeItinerary", Boolean(v))
                  }
                />
                <div className="space-y-0.5">
                  <Label htmlFor="tpl-itinerary" className="cursor-pointer text-sm font-medium">
                    Itinerary structure
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Day titles and all itinerary items (times, descriptions, locations)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 rounded-lg border p-3">
                <Checkbox
                  id="tpl-finance"
                  checked={form.watch("includeFinanceLines")}
                  onCheckedChange={(v) =>
                    form.setValue("includeFinanceLines", Boolean(v))
                  }
                />
                <div className="space-y-0.5">
                  <Label htmlFor="tpl-finance" className="cursor-pointer text-sm font-medium">
                    Finance line categories
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Cost and income categories with descriptions (amounts are not saved)
                  </p>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                onClick={() => handleOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? <Spinner /> : null}
                Save template
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
