import type { Control } from "react-hook-form";
import type { Doc } from "@/convex/_generated/dataModel";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import SupplierPicker from "@/components/supplier-picker.tsx";
import { BOARD_OPTIONS } from "@/lib/domain.ts";
import type { OfferFormValues } from "./offer-form-schema.ts";
import type { SupplierCategory } from "@/pages/suppliers/page.tsx";

/**
 * Supplier/hotel identity fields shared by every offer type: hotel database
 * link + board basis (hotel only), and the supplier/venue name with its
 * quick-pick from the Suppliers database.
 */
export default function OfferSupplierFields({
  control,
  setValue,
  watchType,
  isHotel,
  showDescription,
  hotels,
  hotelsLoading,
}: {
  control: Control<OfferFormValues>;
  setValue: (name: "supplierName", value: string) => void;
  watchType: string;
  isHotel: boolean;
  showDescription: boolean;
  hotels: Doc<"hotels">[];
  hotelsLoading: boolean;
}) {
  return (
    <>
      {isHotel && (
        <FormField
          control={control}
          name="hotelId"
          render={({ field }) => (
            <FormItem className="sm:col-span-2">
              <FormLabel>Link to hotel database</FormLabel>
              <Select
                value={field.value || "none"}
                onValueChange={(v) => {
                  const id = v === "none" ? "" : v;
                  field.onChange(id);
                  if (id) {
                    const h = hotels.find((h) => h._id === id);
                    if (h) setValue("supplierName", h.name);
                  }
                }}
                disabled={hotelsLoading}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select hotel (optional)" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="none">No link</SelectItem>
                  {hotels.map((h) => (
                    <SelectItem key={h._id} value={h._id}>
                      {h.name} — {h.city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormDescription>Linking auto-fills the hotel name</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
      )}

      <FormField
        control={control}
        name="supplierName"
        render={({ field }) => (
          <FormItem className={isHotel ? "" : "sm:col-span-2"}>
            <div className="flex items-center justify-between gap-2">
              <FormLabel>{isHotel ? "Hotel name" : "Supplier / venue"}</FormLabel>
              <SupplierPicker
                reservationType={watchType as SupplierCategory}
                onSelect={(s) => setValue("supplierName", s.name)}
              />
            </div>
            <FormControl>
              <Input placeholder="Hotel Arts Barcelona" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      {isHotel && (
        <FormField
          control={control}
          name="board"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Board basis</FormLabel>
              <Select
                value={field.value || "none"}
                onValueChange={(v) => field.onChange(v === "none" ? "" : v)}
              >
                <FormControl>
                  <SelectTrigger><SelectValue placeholder="Not specified" /></SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="none">Not specified</SelectItem>
                  {BOARD_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
      )}

      {/* Description only shown for a single-item offer */}
      {showDescription && (
        <FormField
          control={control}
          name="description"
          render={({ field }) => (
            <FormItem className="sm:col-span-2">
              <FormLabel>
                {isHotel ? "Room type / description" : "Service description"}
              </FormLabel>
              <FormControl>
                <Input
                  placeholder={
                    isHotel ? "Superior double, sea view" : "Airport – Hotel, 50-seat coach"
                  }
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
    </>
  );
}
