/**
 * AI import panel for the Itinerary tab.
 * Generates days + items from pasted text.
 */
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.js";
import AiImportDialog, { PreviewField } from "@/components/ai-import-dialog.tsx";
import { cn } from "@/lib/utils.ts";
import { ITINERARY_ITEM_TYPE_COLORS, itineraryItemTypeLabel } from "@/lib/itinerary.ts";

type ItemData = {
  sortOrder: number;
  type: string;
  time?: string;
  title: string;
  description?: string;
  location?: string;
  notes?: string;
};

type DayData = {
  dayNumber: number;
  date?: string;
  title?: string;
  notes?: string;
  items: ItemData[];
};

function ItineraryPreview({ days }: { days: DayData[] }) {
  if (!days || days.length === 0) {
    return <p className="px-4 py-4 text-sm text-muted-foreground">No itinerary days extracted.</p>;
  }
  return (
    <div className="divide-y">
      {days.map((day, i) => (
        <div key={i} className="px-4 py-3 space-y-2">
          <div className="flex items-center gap-2">
            <span className="flex size-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-[11px] font-bold shrink-0">
              {day.dayNumber}
            </span>
            <p className="text-sm font-semibold">
              {day.title || `Day ${day.dayNumber}`}
            </p>
            {day.date && (
              <span className="text-xs text-muted-foreground ml-auto">
                {day.date}
              </span>
            )}
          </div>
          {day.notes && (
            <p className="text-xs text-muted-foreground italic pl-8">{day.notes}</p>
          )}
          <div className="space-y-1 pl-8">
            {day.items.map((item, j) => (
              <div key={j} className="flex items-start gap-2">
                {item.time && (
                  <span className="text-[11px] text-muted-foreground tabular-nums w-10 shrink-0 pt-0.5">
                    {item.time}
                  </span>
                )}
                <span
                  className={cn(
                    "mt-0.5 rounded px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wide shrink-0",
                    ITINERARY_ITEM_TYPE_COLORS[
                      item.type as keyof typeof ITINERARY_ITEM_TYPE_COLORS
                    ] ?? "bg-muted text-muted-foreground",
                  )}
                >
                  {itineraryItemTypeLabel(item.type)}
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-medium">{item.title}</p>
                  {item.description && (
                    <p className="text-xs text-muted-foreground line-clamp-1">{item.description}</p>
                  )}
                  {item.location && (
                    <p className="text-xs text-muted-foreground">{item.location}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function ItineraryAiImport({
  groupFileId,
  startDate,
}: {
  groupFileId: Id<"groupFiles">;
  startDate?: string;
}) {
  const createDay = useMutation(api.itinerary.createDay);
  const createItem = useMutation(api.itinerary.createItem);

  const handleImport = async (days: DayData[]) => {
    if (!days || days.length === 0) {
      toast.error("No itinerary days to import.");
      return;
    }

    let totalItems = 0;
    for (const day of days) {
      // Compute date from startDate + dayNumber if available
      let date = day.date;
      if (!date && startDate) {
        const d = new Date(startDate);
        d.setDate(d.getDate() + (day.dayNumber - 1));
        date = d.toISOString();
      }
      if (!date) {
        // Fallback: use epoch + dayNumber
        const d = new Date(0);
        d.setDate(d.getDate() + (day.dayNumber - 1));
        date = d.toISOString();
      }

      const dayId = await createDay({
        groupFileId,
        date,
        dayNumber: day.dayNumber,
        title: day.title || undefined,
        notes: day.notes || undefined,
      });

      for (const item of day.items) {
        const validTypes = [
          "arrival",
          "departure",
          "transfer",
          "hotel",
          "meal",
          "activity",
          "meeting",
          "flight",
          "free-time",
          "other",
        ] as const;
        type ValidItemType = (typeof validTypes)[number];
        const itemType: ValidItemType = validTypes.includes(item.type as ValidItemType)
          ? (item.type as ValidItemType)
          : "other";

        await createItem({
          dayId,
          groupFileId,
          sortOrder: item.sortOrder,
          type: itemType,
          time: item.time || undefined,
          title: item.title,
          description: item.description || undefined,
          location: item.location || undefined,
          notes: item.notes || undefined,
        });
        totalItems++;
      }
    }

    toast.success(
      `Imported ${days.length} day${days.length !== 1 ? "s" : ""} with ${totalItems} item${totalItems !== 1 ? "s" : ""}`,
    );
  };

  return (
    <AiImportDialog
      type="itinerary"
      title="Build itinerary with AI"
      placeholder={`Paste your programme, run-of-show, or itinerary in any format:

Day 1 - Arrival in Barcelona
09:00 - Airport transfer from El Prat to Hotel Arts
14:00 - Welcome lunch at La Barceloneta restaurant
18:00 - City walking tour
20:00 - Welcome dinner at El Nacional

Day 2 - Barcelona city programme
09:00 - Breakfast at hotel
10:00 - Guided tour of Sagrada Família
13:00 - Lunch (free time)
15:00 - Team activity: cooking class
19:30 - Coach transfer to gala venue`}
      onImport={async (data) => handleImport(data as DayData[])}
      renderPreview={(data) => <ItineraryPreview days={(data as DayData[]) ?? []} />}
      startDate={startDate}
    />
  );
}
