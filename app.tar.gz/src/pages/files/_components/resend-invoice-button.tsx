import { useState } from "react";
import { useAction, useQuery } from "convex/react";
import { RotateCw } from "lucide-react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button.tsx";
import { generateInvoicePDFBase64 } from "@/lib/pdf-generators.ts";
import { formatMoney } from "@/lib/domain.ts";

type GroupFile = Doc<"groupFiles"> & { ownerName?: string | null };
type FinanceLine = Doc<"financeLines"> & { amountInBase: number };
type SenderIdentity = { id: string; value: string; type: string; status: string };

/**
 * Re-sends the invoice email with a single click, reusing the last verified
 * sender and the client's email on file — no need to reopen the compose
 * dialog. Only rendered once the invoice has been emailed at least once
 * (see `hasSentBefore` in the caller).
 */
export default function ResendInvoiceButton({
  file,
  incomeLines,
  invoiceNumber,
  senderIdentities,
}: {
  file: GroupFile;
  incomeLines: FinanceLine[];
  invoiceNumber: string;
  senderIdentities: SenderIdentity[];
}) {
  const [sending, setSending] = useState(false);
  const sendInvoice = useAction(api.email.send.sendInvoice);
  const lastLog = useQuery(api.email.logs.listByFile, { groupFileId: file._id });

  const verifiedSenders = senderIdentities.filter((s) => s.status === "verified");
  const lastInvoiceLog = lastLog?.find((l) => l.emailType === "invoice");

  const handleResend = async () => {
    const from = verifiedSenders[0]?.value;
    const to = lastInvoiceLog?.to ?? file.clientContactEmail;
    if (!from) {
      toast.error("No verified sender found. Verify one in Settings → Email sender identities.");
      return;
    }
    if (!to) {
      toast.error("No client email on file to resend to.");
      return;
    }

    setSending(true);
    try {
      const totalEur = incomeLines.reduce((s, l) => s + l.amountInBase, 0);
      const { base64, filename } = generateInvoicePDFBase64(file, incomeLines, invoiceNumber);
      const subject = `Invoice ${invoiceNumber} – ${file.title}`;
      const body = `Dear ${file.clientContactName ?? file.clientName},

Please find attached invoice ${invoiceNumber} for the following event:

Group: ${file.title}
Reference: ${file.reference}
Total due: ${formatMoney(totalEur, "EUR")}

Payment is due within 30 days. Please reference the invoice number on your bank transfer.

Should you have any questions, please do not hesitate to contact us.

Kind regards,
${file.ownerName ?? "Tessera Groups & MICE Team"}`;

      await sendInvoice({
        groupFileId: file._id,
        from,
        to,
        subject,
        body,
        pdfDataUri: base64,
        pdfFilename: filename,
        invoiceNumber,
      });
      toast.success(`Invoice resent to ${to}`);
    } catch (err) {
      const message =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Failed to resend the invoice. Please try again.";
      toast.error(message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Button size="sm" variant="secondary" onClick={handleResend} disabled={sending}>
      <RotateCw className={sending ? "size-4 animate-spin" : "size-4"} />
      {sending ? "Resending…" : "Resend invoice"}
    </Button>
  );
}
