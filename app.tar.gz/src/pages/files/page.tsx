import { useState } from "react";
import { Link } from "react-router-dom";
import { usePaginatedQuery, useQuery, useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import {
  Bookmark,
  CalendarRange,
  CheckSquare,
  ChevronDown,
  Copy,
  Download,
  FileText,
  MapPin,
  MoreHorizontal,
  Plus,
  Search,
  Sparkles,
  Square,
  Trash2,
  User,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.js";
import PageHeader from "@/components/page-header.tsx";
import StatusBadge from "@/components/status-badge.tsx";
import GroupFileFormDialog from "./_components/group-file-form-dialog.tsx";
import GroupFileAiWizard from "./_components/ai-wizard/group-file-ai-wizard.tsx";
import DuplicateFileDialog from "./_components/duplicate-file-dialog.tsx";
import SaveAsTemplateDialog from "./_components/save-as-template-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible.tsx";
import { FILE_STATUS_OPTIONS, typeLabel } from "@/lib/domain.ts";
import { formatDateRange } from "@/lib/dates.ts";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { downloadCsv } from "@/lib/csv-export.ts";
import type { FileStatus } from "@/lib/domain.ts";
import { cn } from "@/lib/utils.ts";

// ── File card ────────────────────────────────────────────────────────────────

function FileCard({
  file,
  selected,
  onToggle,
}: {
  file: Doc<"groupFiles">;
  selected: boolean;
  onToggle: () => void;
}) {
  const [duplicateOpen, setDuplicateOpen] = useState(false);
  const [templateOpen, setTemplateOpen] = useState(false);

  return (
    <div className="group relative">
      {/* Checkbox — left side */}
      <div className="absolute left-3 top-1/2 z-10 -translate-y-1/2">
        <Checkbox
          checked={selected}
          onCheckedChange={onToggle}
          onClick={(e) => e.stopPropagation()}
          className={cn(
            "transition-opacity",
            selected ? "opacity-100" : "opacity-0 group-hover:opacity-100",
          )}
          aria-label={`Select ${file.title}`}
        />
      </div>

      <Link
        to={`/files/${file._id}`}
        className="block"
        onClick={(e) => selected && e.preventDefault()}
      >
        <Card
          className={cn(
            "gap-0 p-4 pl-10 transition-colors sm:p-5 sm:pl-11",
            selected
              ? "border-primary/60 bg-primary/5 ring-1 ring-primary/30"
              : "hover:border-ring/60 hover:bg-secondary/40",
          )}
        >
          <div className="flex flex-wrap items-start justify-between gap-3 pr-8">
            <div className="min-w-0 space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">
                  {file.reference}
                </span>
                <StatusBadge status={file.status} />
                <span className="rounded-full bg-secondary px-2 py-0.5 text-xs text-secondary-foreground">
                  {typeLabel(file.fileType)}
                </span>
              </div>
              <h2 className="truncate font-display text-lg font-semibold">
                {file.title}
              </h2>
              <p className="truncate text-sm text-muted-foreground">
                {file.clientName} · {file.destination}
              </p>
            </div>
            <div className="shrink-0 space-y-1 text-right">
              <p className="text-sm font-medium">
                {formatDateRange(file.startDate, file.endDate)}
              </p>
              <p className="flex items-center justify-end gap-1.5 text-sm text-muted-foreground">
                <Users className="size-3.5" />
                {file.pax} pax
              </p>
              <p className="text-xs text-muted-foreground">{file.currency}</p>
            </div>
          </div>
        </Card>
      </Link>

      {/* Row action menu */}
      <div className="absolute right-3 top-3">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-7 opacity-0 transition-opacity group-hover:opacity-100"
              onClick={(e) => e.preventDefault()}
            >
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem
              onClick={(e) => {
                e.preventDefault();
                setDuplicateOpen(true);
              }}
            >
              <Copy className="size-4" />
              Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={(e) => {
                e.preventDefault();
                setTemplateOpen(true);
              }}
            >
              <Bookmark className="size-4" />
              Save as template
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <DuplicateFileDialog
        fileId={file._id}
        fileTitle={file.title}
        open={duplicateOpen}
        onOpenChange={setDuplicateOpen}
      />
      <SaveAsTemplateDialog
        fileId={file._id}
        fileTitle={file.title}
        open={templateOpen}
        onOpenChange={setTemplateOpen}
      />
    </div>
  );
}

// ── Bulk actions toolbar ─────────────────────────────────────────────────────

function BulkToolbar({
  count,
  total,
  staff,
  onSelectAll,
  onDeselectAll,
  onExport,
  onChangeStatus,
  onAssignOwner,
  onDelete,
}: {
  count: number;
  total: number;
  staff: Doc<"users">[] | undefined;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onExport: () => void;
  onChangeStatus: (status: FileStatus) => void;
  onAssignOwner: (ownerId: Id<"users">) => void;
  onDelete: () => void;
}) {
  const allSelected = count === total && total > 0;

  return (
    <div className="sticky top-14 z-20 mb-3 flex flex-wrap items-center gap-2 rounded-xl border border-primary/30 bg-card px-4 py-2.5 shadow-sm">
      {/* Select all / deselect toggle */}
      <Button
        variant="ghost"
        size="sm"
        className="gap-2 text-sm"
        onClick={allSelected ? onDeselectAll : onSelectAll}
      >
        {allSelected ? (
          <CheckSquare className="size-4 text-primary" />
        ) : (
          <Square className="size-4" />
        )}
        {allSelected ? "Deselect all" : `Select all ${total}`}
      </Button>

      <div className="h-4 w-px bg-border" />

      <span className="text-sm font-medium text-primary">
        {count} selected
      </span>

      <div className="ml-auto flex flex-wrap items-center gap-2">
        {/* Export selected */}
        <Button variant="secondary" size="sm" onClick={onExport}>
          <Download className="size-4" />
          Export CSV
        </Button>

        {/* Change status */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="sm">
              Change status
              <ChevronDown className="size-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {FILE_STATUS_OPTIONS.map((o) => (
              <DropdownMenuItem
                key={o.value}
                onClick={() => onChangeStatus(o.value as FileStatus)}
              >
                {o.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Assign owner */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="sm">
              <User className="size-3.5" />
              Assign owner
              <ChevronDown className="size-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {staff === undefined || staff.length === 0 ? (
              <DropdownMenuItem disabled>No teammates found</DropdownMenuItem>
            ) : (
              staff.map((s) => (
                <DropdownMenuItem key={s._id} onClick={() => onAssignOwner(s._id)}>
                  {s.name ?? s.email ?? "Unnamed user"}
                </DropdownMenuItem>
              ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Delete */}
        <Button
          variant="destructive"
          size="sm"
          onClick={onDelete}
        >
          <Trash2 className="size-4" />
          Delete
        </Button>

        {/* Clear selection */}
        <Button variant="ghost" size="icon" className="size-8" onClick={onDeselectAll}>
          <X className="size-4" />
          <span className="sr-only">Clear selection</span>
        </Button>
      </div>
    </div>
  );
}

// ── Templates section ────────────────────────────────────────────────────────

function TemplatesSection({
  templates,
  open,
  onOpenChange,
  onDelete,
}: {
  templates: Doc<"fileTemplates">[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onDelete: (id: Id<"fileTemplates">) => void;
}) {
  const [deleteId, setDeleteId] = useState<Id<"fileTemplates"> | null>(null);

  return (
    <>
      <Collapsible open={open} onOpenChange={onOpenChange} className="mb-4">
        <div className="flex items-center justify-between rounded-lg border bg-secondary/30 px-4 py-2.5">
          <div className="flex items-center gap-2">
            <Bookmark className="size-4 text-primary" />
            <span className="text-sm font-medium">Saved templates</span>
            <span className="rounded-full bg-primary/15 px-2 py-0.5 text-xs font-medium text-primary">
              {templates.length}
            </span>
          </div>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
              {open ? "Hide" : "Show"}
              <ChevronDown
                className={cn(
                  "size-3.5 transition-transform duration-200",
                  open && "rotate-180",
                )}
              />
            </Button>
          </CollapsibleTrigger>
        </div>

        <CollapsibleContent>
          <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {templates.map((t) => {
              const dayCount = t.itineraryDays.length;
              const financeCount = t.financeLines.length;
              return (
                <Card key={t._id} className="gap-0 p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{t.name}</p>
                      {t.description && (
                        <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">
                          {t.description}
                        </p>
                      )}
                      <div className="mt-1.5 flex flex-wrap gap-2 text-[10px] text-muted-foreground">
                        {t.destination && (
                          <span className="flex items-center gap-0.5">
                            <MapPin className="size-3" />
                            {t.destination}
                          </span>
                        )}
                        {t.pax !== undefined && (
                          <span className="flex items-center gap-0.5">
                            <Users className="size-3" />
                            {t.pax} pax
                          </span>
                        )}
                        {dayCount > 0 && (
                          <span className="flex items-center gap-0.5">
                            <CalendarRange className="size-3" />
                            {dayCount} day{dayCount !== 1 ? "s" : ""}
                          </span>
                        )}
                        {financeCount > 0 && (
                          <span className="flex items-center gap-0.5">
                            <FileText className="size-3" />
                            {financeCount} line{financeCount !== 1 ? "s" : ""}
                          </span>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-7 shrink-0 text-muted-foreground hover:text-destructive"
                      onClick={() => setDeleteId(t._id)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </CollapsibleContent>
      </Collapsible>

      <AlertDialog
        open={deleteId !== null}
        onOpenChange={(o) => {
          if (!o) setDeleteId(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete template?</AlertDialogTitle>
            <AlertDialogDescription>
              This template will be permanently removed. Existing files created
              from it are not affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (deleteId) onDelete(deleteId);
                setDeleteId(null);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// ── Page ─────────────────────────────────────────────────────────────────────

export default function FilesPage() {
  const [statusFilter, setStatusFilter] = useState<FileStatus | "all">("all");
  const [search, setSearch] = useState("");
  const [debouncedSearch] = useDebounce(search, 250);
  const [templatesOpen, setTemplatesOpen] = useState(false);

  // Multi-select
  const [selectedIds, setSelectedIds] = useState<Set<Id<"groupFiles">>>(
    new Set(),
  );
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);

  const { results, status, loadMore } = usePaginatedQuery(
    api.groupFiles.list,
    statusFilter === "all" ? {} : { status: statusFilter },
    { initialNumItems: 25 },
  );

  const templates = useQuery(api.fileTemplates.list);
  const staff = useQuery(api.users.listStaff);
  const removeTemplate = useMutation(api.fileTemplates.remove);
  const bulkUpdateStatus = useMutation(api.groupFiles.bulkUpdateStatus);
  const bulkAssignOwner = useMutation(api.groupFiles.bulkAssignOwner);
  const bulkDelete = useMutation(api.groupFiles.bulkDelete);

  const term = debouncedSearch.trim().toLowerCase();
  const visible = term
    ? results.filter((f) =>
        [f.reference, f.title, f.clientName, f.destination]
          .join(" ")
          .toLowerCase()
          .includes(term),
      )
    : results;

  const isFirstLoad = status === "LoadingFirstPage";
  const hasSelection = selectedIds.size > 0;

  // ── Helpers ──────────────────────────────────────────────────────────────

  const toggleSelect = (id: Id<"groupFiles">) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const selectAll = () =>
    setSelectedIds(new Set(visible.map((f) => f._id)));

  const deselectAll = () => setSelectedIds(new Set());

  const handleExport = (subset?: Doc<"groupFiles">[]) => {
    const files = subset ?? visible;
    if (files.length === 0) return;
    const rows = files.map((f) => ({
      Reference: f.reference,
      Title: f.title,
      Type: typeLabel(f.fileType),
      Status: f.status,
      Client: f.clientName,
      Destination: f.destination,
      "Start date": f.startDate.slice(0, 10),
      "End date": f.endDate.slice(0, 10),
      Pax: f.pax,
      Currency: f.currency,
    }));
    const today = new Date().toISOString().slice(0, 10);
    downloadCsv(rows, `group-files-${today}.csv`);
  };

  const handleBulkExport = () => {
    const selected = visible.filter((f) => selectedIds.has(f._id));
    handleExport(selected);
  };

  const handleBulkChangeStatus = async (status: FileStatus) => {
    try {
      await bulkUpdateStatus({
        ids: Array.from(selectedIds),
        status,
      });
      toast.success(
        `Updated ${selectedIds.size} file${selectedIds.size !== 1 ? "s" : ""} to "${status}"`,
      );
      deselectAll();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not update files.";
      toast.error(msg);
    }
  };

  const handleBulkAssignOwner = async (ownerId: Id<"users">) => {
    try {
      await bulkAssignOwner({
        ids: Array.from(selectedIds),
        ownerId,
      });
      const owner = staff?.find((s) => s._id === ownerId);
      toast.success(
        `Assigned ${selectedIds.size} file${selectedIds.size !== 1 ? "s" : ""} to ${owner?.name ?? owner?.email ?? "the selected teammate"}`,
      );
      deselectAll();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not assign owner.";
      toast.error(msg);
    }
  };

  const handleBulkDelete = async () => {
    try {
      await bulkDelete({ ids: Array.from(selectedIds) });
      toast.success(
        `Deleted ${selectedIds.size} file${selectedIds.size !== 1 ? "s" : ""}`,
      );
      deselectAll();
    } catch (err) {
      const msg =
        err instanceof ConvexError
          ? (err.data as { message: string }).message
          : "Could not delete files.";
      toast.error(msg);
    } finally {
      setBulkDeleteOpen(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        eyebrow="Operations"
        title="Group files"
        description="Every group, meeting, incentive and event you are handling, in one place."
        actions={
          <div className="flex items-center gap-2">
            {!hasSelection && visible.length > 0 && (
              <Button variant="secondary" onClick={() => handleExport()}>
                <Download className="size-4" />
                Export CSV
              </Button>
            )}
            <GroupFileAiWizard
              trigger={
                <Button variant="secondary">
                  <Sparkles className="size-4" />
                  New file with AI
                </Button>
              }
            />
            <GroupFileFormDialog
              trigger={
                <Button>
                  <Plus className="size-4" />
                  New file
                </Button>
              }
            />
          </div>
        }
      />

      <div className="flex flex-col gap-3 pb-5 sm:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search reference, client or destination"
            className="pl-9"
          />
        </div>
        <Select
          value={statusFilter}
          onValueChange={(v) => setStatusFilter(v as FileStatus | "all")}
        >
          <SelectTrigger className="sm:w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {FILE_STATUS_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Saved templates section */}
      {templates && templates.length > 0 && (
        <TemplatesSection
          templates={templates}
          open={templatesOpen}
          onOpenChange={setTemplatesOpen}
          onDelete={async (id) => {
            try {
              await removeTemplate({ id });
              toast.success("Template deleted");
            } catch (err) {
              const msg =
                err instanceof ConvexError
                  ? (err.data as { message: string }).message
                  : "Could not delete template.";
              toast.error(msg);
            }
          }}
        />
      )}

      {/* Bulk actions toolbar */}
      {hasSelection && (
        <BulkToolbar
          count={selectedIds.size}
          total={visible.length}
          staff={staff}
          onSelectAll={selectAll}
          onDeselectAll={deselectAll}
          onExport={handleBulkExport}
          onChangeStatus={handleBulkChangeStatus}
          onAssignOwner={handleBulkAssignOwner}
          onDelete={() => setBulkDeleteOpen(true)}
        />
      )}

      {isFirstLoad ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      ) : visible.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <FileText />
            </EmptyMedia>
            <EmptyTitle>
              {term || statusFilter !== "all"
                ? "No files match your filters"
                : "No group files yet"}
            </EmptyTitle>
            <EmptyDescription>
              {term || statusFilter !== "all"
                ? "Try a different search or status."
                : "Create your first file to start tracking a group."}
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <div className="flex flex-wrap justify-center gap-2">
              <GroupFileAiWizard
                trigger={
                  <Button size="sm" variant="secondary">
                    <Sparkles className="size-4" />
                    New file with AI
                  </Button>
                }
              />
              <GroupFileFormDialog
                trigger={
                  <Button size="sm">
                    <Plus className="size-4" />
                    New file
                  </Button>
                }
              />
            </div>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="space-y-3">
          {visible.map((file) => (
            <FileCard
              key={file._id}
              file={file}
              selected={selectedIds.has(file._id)}
              onToggle={() => toggleSelect(file._id)}
            />
          ))}

          {status === "CanLoadMore" || status === "LoadingMore" ? (
            <div className="pt-2 text-center">
              <Button
                variant="secondary"
                onClick={() => loadMore(25)}
                disabled={status === "LoadingMore"}
              >
                Load more
              </Button>
            </div>
          ) : null}
        </div>
      )}

      {/* Bulk delete confirmation */}
      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete {selectedIds.size} file{selectedIds.size !== 1 ? "s" : ""}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the selected group files and all their
              associated data (itinerary, finance, passengers, etc.). This cannot
              be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleBulkDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
